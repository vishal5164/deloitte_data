# YATRIKALA — Start Here
*The art of travel. Journeys, designed by hand.*

You are holding a complete business-in-a-folder: a bespoke travel-itinerary studio for Indians travelling internationally. Fixed-fee trip design, zero booking risk, AI-leveraged production, affiliate income on the side.

## What's in the box

| File | What it is | Who uses it |
|---|---|---|
| [playbook/PLAYBOOK.md](playbook/PLAYBOOK.md) | **Read this first.** Verified market research, pricing, 14-day launch plan, affiliate stack, legal checklist, message templates | You |
| [apps/journey-designer.html](apps/journey-designer.html) | **The lead magnet.** Interactive Journey Designer: persona → destination (or "surprise me" matching) → country-clubbing → instant personalized itinerary, gated after Day 2 → WhatsApp CTA. Put this link in your Instagram bio | Clients |
| [apps/client-intake.html](apps/client-intake.html) | Client-facing intake form → structured trip brief lands on your WhatsApp | Clients |
| [apps/quote-builder.html](apps/quote-builder.html) | Pick trip parameters → market-calibrated price + ready-to-send quote message | You |
| [apps/itinerary-studio.html](apps/itinerary-studio.html) | The production engine: paste itinerary JSON → premium branded document → print to PDF. Ships with a full 8-day Japan honeymoon sample | You |
| [prompts/itinerary-master-prompt.md](prompts/itinerary-master-prompt.md) | The prompt that turns a client brief into itinerary JSON (use with Claude Pro) | You + Claude |
| [crm/Yatrikala-CRM.xlsx](crm/Yatrikala-CRM.xlsx) | Leads, Trips, Payments + a self-computing dashboard (pipeline, win rate, money, GST radar) | You |
| [brand/brand-guide.md](brand/brand-guide.md) + [brand/yatrikala-logo.svg](brand/yatrikala-logo.svg) | Name story, palette, voice, wordmark | You |

## Your first hour

1. **Register yatrikala.com + yatrikala.in and claim @yatrikala on Instagram — today.** Both domains were verified unregistered on 13 July 2026; that fact has a shelf life.
2. Put your WhatsApp number into the `CONFIG` block of **both** client-facing apps: `apps/client-intake.html` and `apps/journey-designer.html` (`"91XXXXXXXXXX"` format — until you do, the WhatsApp buttons stay hidden and visitors only get "copy brief"). Tell Claude the number and it can also redeploy the shared artifact links with it baked in.
3. Open `apps/itinerary-studio.html` in your browser → it renders the Japan sample → click **Print / PDF**. That PDF is what clients pay for. Send it to yourself on WhatsApp and imagine receiving it.
4. Open the CRM, delete the "(example row, delete me)" rows when your first real lead arrives.
5. Read the playbook §3 and start Day 1–2 items — including the Deloitte COI declaration.

## The production loop (once running)

Intake form → brief on WhatsApp → Quote Builder → 50% advance → master prompt + Claude → JSON → Itinerary Studio → **your judgment pass** → PDF → deliver → review → referral. Target: under 90 minutes of your time per trip, of which an hour is the judgment pass. That margin is the business.

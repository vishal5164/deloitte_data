# Yatrikala Platform

Production web platform for **Yatrikala** — a bespoke travel-itinerary studio for Indian travellers.
Next.js 15 (App Router, TypeScript) · Supabase (Postgres + Auth) · Vercel · Razorpay · Claude API.

| Surface | Route | What it does |
|---|---|---|
| Landing | `/` | Brand, tiers, CTAs |
| Journey Designer | `/design` | Persona → destination/combos or "surprise me" quiz → auto-generated personalized itinerary, gated after Day 2 → WhatsApp CTA |
| Shared draft | `/itinerary/[slug]` | Public link to any generated draft |
| Deals radar | `/deals` | Real observed round-trip fares + hotel nightly medians per destination (so quotes rest on real numbers) |
| Travellers like you | `/insights` | Aggregated + AI-synthesized behaviour of travellers with similar itineraries |
| Intake | `/start` | Full trip brief → lead |
| Admin | `/admin` | Dashboard, leads, billing (quotes → Razorpay payment links → webhook reconciliation), destination content manager |

## Architecture notes

- **Engine first, AI on top.** `src/engine` is a deterministic itinerary engine over destination "packs" (JSON content, seeded to the `destinations` table, editable in `/admin/content`). `src/lib/claude.ts` optionally refines drafts with the Claude API and degrades gracefully to the engine when `ANTHROPIC_API_KEY` is absent.
- **Price adapters.** `src/lib/prices` defines one `PriceSource` interface with two implementations — Travelpayouts (default; free, affiliate-linked) and Amadeus (optional). Selected via `PRICE_SOURCE`. A Vercel cron snapshots fares into `price_snapshots` daily; `/deals` renders snapshots, never live-blocks on third parties.
- **Serverless-safe DB.** Postgres via Supabase transaction pooler (`prepare:false, max:1`). Migrations use the direct (5432) connection.
- **Everything degrades.** No DB → packs load from `src/content/packs.json`, pages render with friendly empty states. No Razorpay keys → invoices created for manual collection. No price token → deals page explains how to enable.

## Deploy (about 45 minutes, all free tiers)

### 1. Supabase (database + auth)
1. Create a project at [supabase.com](https://supabase.com) (region: `ap-south-1` Mumbai).
2. Project Settings → Database → copy both connection strings:
   - **Transaction pooler** (port 6543) → `DATABASE_URL`
   - **Direct** (port 5432) → `DIRECT_DATABASE_URL`
3. Project Settings → API → copy `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
4. Authentication → Providers: enable **Email** (magic link / OTP is the default — no password setup needed).
5. Authentication → URL Configuration: add your site URL + `http://localhost:3000` to redirect allow-list.

### 2. Local setup
```bash
cp .env.example .env.local     # fill in everything from step 1
npm install
npm run db:generate            # emits SQL to supabase/migrations from src/db/schema.ts
npm run db:migrate             # applies migrations (uses DIRECT_DATABASE_URL)
npm run db:seed                # loads all destination packs into the DB
npm run dev                    # http://localhost:3000
```
Set `ADMIN_EMAILS` to your email, open `/admin/login`, request the magic link, and you're in.

### 3. Razorpay (billing)
1. [dashboard.razorpay.com](https://dashboard.razorpay.com) → API Keys → generate → `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`. (Test mode first; switch to live keys after KYC.)
2. Webhooks → Add: URL `https://<your-domain>/api/razorpay/webhook`, secret of your choosing → `RAZORPAY_WEBHOOK_SECRET`, event: **payment_link.paid**.
3. Flow: Admin → Billing → create quote → create advance invoice → send the generated short URL on WhatsApp → webhook marks it paid automatically.

### 4. Price data (deals radar)
- **Travelpayouts (default):** sign up at travelpayouts.com (free), copy your API token and marker → `TRAVELPAYOUTS_TOKEN`, `TRAVELPAYOUTS_MARKER`. Prices are cached market observations — the UI labels them "observed", which is exactly right for quote sanity checks.
- **Amadeus (optional):** developers.amadeus.com → self-service app → `AMADEUS_CLIENT_ID/SECRET`, set `PRICE_SOURCE=amadeus`. Test keys hit test data; production keys require Amadeus approval.
- First fill: `curl -X POST https://<domain>/api/deals/refresh` while signed into admin, or wait for the nightly cron.

### 5. Claude API (optional but recommended)
[console.anthropic.com](https://console.anthropic.com) → API key → `ANTHROPIC_API_KEY`. Powers per-visitor itinerary refinement and the weekly insights synthesis (~₹1–3 per generation). Without it, the deterministic engine handles everything.

### 6. Vercel
1. Push this repo to GitHub, import in [vercel.com](https://vercel.com).
2. Add **all** env vars from `.env.local` (plus `CRON_SECRET` — any random string; Vercel sends it as the Authorization header to cron routes).
3. Set `NEXT_PUBLIC_SITE_URL` to the deployed URL.
4. Crons (already declared in `vercel.json`): deals refresh daily 02:30 UTC, insights weekly Monday 03:00 UTC.
5. Add your domain (e.g. `yatrikala.com`) in Vercel → Domains; update Supabase auth redirect URLs + Razorpay webhook URL to match.

### 7. Go-live checklist
- [ ] `ADMIN_EMAILS` set, magic-link login verified
- [ ] Migrations + seed ran against production DB
- [ ] `NEXT_PUBLIC_WHATSAPP_NUMBER` set (WhatsApp CTAs stay hidden without it)
- [ ] Razorpay in live mode + webhook secret set + one ₹1 test payment reconciled
- [ ] Deals refresh ran once (check `/deals`)
- [ ] Insights refresh ran once (check `/insights`)
- [ ] `npm test` green
- [ ] `/api/health?deep=1` returns all `true`
- [ ] Legal pages (`/terms`, `/privacy`, `/refunds`) reviewed
- [ ] Uptime monitor pointed at `/api/health`

## Development

```bash
npm run dev          # local dev
npm run typecheck    # tsc --noEmit
npm test             # engine matrix, billing helpers, price parsers
npm run build        # production build
npm run db:generate  # schema change → new migration
npm run db:seed      # re-seed/refresh destination packs from src/content/packs.json
```

Repo conventions, architecture map, and task recipes for AI-assisted work live in
[CLAUDE.md](./CLAUDE.md) and `.claude/skills/`.

## Reliability & operations

- **Tests.** `npm test` runs the whole suite — the engine matrix (every persona × destination produces a valid itinerary), billing helpers (invoice numbering, quote math), and the price-source parsers. Plain `node:test` via `tsx`, no framework to maintain.
- **CI.** GitHub Actions runs typecheck + test + build on every push, so nothing red ever reaches Vercel.
- **Health endpoint.** `GET /api/health` returns a shallow env-status JSON — one boolean per integration, no secrets. Add `?deep=1` and it also pings the database. Wire a free UptimeRobot or BetterStack monitor to it and you'll hear about an outage before a client does.
- **Security headers.** Set globally in `next.config.ts` (frame, sniffing, referrer, permissions policies) — they apply to every route with no per-page work.
- **AI cost cap.** `MAX_AI_GENERATIONS_PER_DAY` (default **200/day**) caps Claude API usage; past the cap the app silently falls back to the deterministic engine, so a traffic spike can never turn into a surprise bill.
- **Legal pages.** `/terms`, `/privacy`, `/refunds` — required for Razorpay live-mode approval. They are honest, Yatrikala-specific templates, **not legal advice**: review them (ideally with a professional) before going live.

## Scaling notes

- Vercel serverless + Supabase pooler scale horizontally with zero config; the DB client is `max:1` per instance by design.
- `loadPacks()` caches packs in-instance for 10 min; content edits call `invalidatePacksCache()` and `revalidatePath`.
- Public pages use ISR (`revalidate`) — deals/insights render from snapshots, not third-party calls, so traffic spikes never hit external APIs.
- When volume justifies it: move price snapshots to a queue (Vercel cron → QStash), add Sentry (`@sentry/nextjs`), and turn on Supabase PITR backups (Pro plan).

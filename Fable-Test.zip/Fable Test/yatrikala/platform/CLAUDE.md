# CLAUDE.md — Yatrikala Platform

Bespoke travel-itinerary studio for Indian travellers. Next.js 15 App Router + TypeScript strict,
Supabase Postgres (Drizzle ORM), Razorpay billing, optional Claude API generation. Deployed on Vercel.

## Commands
- `npm run dev` / `npm run build` / `npm run typecheck`
- `npm test` — all `*.test.ts` (engine matrix, billing helpers, price parsers) via `node:test` through `tsx`
- `npm run db:generate` → new migration from `src/db/schema.ts`; `npm run db:migrate`; `npm run db:seed`

## Map
- `src/engine/` — deterministic itinerary engine. Pure functions, safe in client + server. `engineGenerate(brief, packs)`, `scoreDestinations(...)`, `COMBOS` (country-clubbing), `filterBlocks` (persona filtering). Types in `types.ts` are the platform's core vocabulary (DestinationPack, Brief, Itinerary, Persona).
- `src/content/packs.json` — destination pack seed data (30 destinations). DB (`destinations` table) is runtime source of truth; this file is seed + no-DB fallback via `loadPacks()`.
- `src/db/schema.ts` — all tables. Money is integer whole INR. Never bigint/decimal for fees.
- `src/lib/claude.ts` — AI layer. ALWAYS degrade to engine when key missing or parse fails.
- `src/lib/prices/` — `PriceSource` interface + travelpayouts/amadeus adapters. Add sources here only.
- `src/lib/razorpay.ts` — payment links, webhook HMAC verify, invoice numbering (YTK-<FY>-<seq>).
- `src/lib/auth.ts` — Supabase SSR client, `requireAdmin()` (redirect) / `getAdmin()` (null), `isCronAuthorized`.
- `src/app/` — routes: `/` landing, `/design` (Journey Designer), `/itinerary/[slug]`, `/deals`, `/insights`, `/start`, `/terms` `/privacy` `/refunds` (legal — required for Razorpay live approval), `/admin/*` (login outside, pages inside `(protected)` group), API: `generate`, `leads`, `deals/refresh`, `insights/refresh`, `razorpay/webhook`, `health` (deploy verification; `?deep=1` also pings DB). SEO: `robots.ts` + `sitemap.ts`.
- `src/app/globals.css` — the design system: "Electric Dusk". Night #160F33, violet-ink #251A4D, sunset ramp magenta #E1467C → coral #F26B4E → gold #F5AE3D (`--grad-sunset`), warm ivory #FAF5EC for paper surfaces (itineraries/admin stay calm and light). Georgia serif display, dotted-route motif, Y-route logo (`src/components/Logo.tsx`, favicon `src/app/icon.svg`). USE THE TOKENS/CLASSES; do not introduce Tailwind or new design languages. Per-destination SKIES gradient maps are scenery and exempt from token rules.

## Hard conventions
- Server Components by default; `"use client"` only for interactivity. NEVER import `src/db`, `src/lib/auth`, `src/lib/prices`, `src/lib/razorpay`, or `src/content/loadPacks` into client files.
- Every DB call is try/caught: the app must render (with friendly empty states) before Supabase is configured.
- Next 15: `await props.params`, `await searchParams`, `await cookies()`.
- All third-party prices are labelled indicative/observed with timestamps. Brand voice: warm, specific, no fluff, no "explore the city".
- Client-facing money: `₹` + en-IN grouping; engine's `inr()` for compact display.
- Persona personalization is the product: any new day/block content must carry honest `personas`/`excludePersonas` tags.
- Money actions must stay race-safe — invoice numbering retries on 23505 (unique violation); never bypass it.
- All `*.test.ts` files run in CI via `node:test` through `tsx` — new pure logic gets a test.

## Task recipes (skills)
- `.claude/skills/deploy` — env vars, migrations, Vercel/Supabase/Razorpay setup, cron testing
- `.claude/skills/add-destination` — authoring workflow + schema + quality gates for new packs
- `.claude/skills/price-tracker` — how adapters/snapshots/crons work; adding a source
- `.claude/skills/billing-ops` — quote → invoice → payment-link → webhook lifecycle; test-mode drills

## Legacy
`../apps/` holds the pre-platform single-file tools (journey-designer.html, itinerary-studio.html,
client-intake.html, quote-builder.html) and `../playbook/PLAYBOOK.md` holds the verified business
research (pricing tiers, affiliate programs, India compliance). The platform supersedes the HTML
tools but they remain the offline/no-deploy fallback.

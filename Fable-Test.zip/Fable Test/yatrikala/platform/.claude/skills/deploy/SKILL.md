---
name: deploy
description: Deploy or troubleshoot the Yatrikala platform — Supabase setup, migrations, Vercel env/crons, Razorpay webhook wiring, and post-deploy smoke checks. Use when the user says deploy, ship, go live, production, migration failed, webhook not firing, or cron not running.
---

# Deploying the Yatrikala platform

Follow README.md "Deploy" top to bottom for a first deploy. This skill adds the operational detail.

## Env truth table (what breaks without each)
| Var | Missing ⇒ |
|---|---|
| DATABASE_URL / DIRECT_DATABASE_URL | pages render from packs.json fallback; no leads/briefs/billing persistence |
| NEXT_PUBLIC_SUPABASE_URL/ANON_KEY, ADMIN_EMAILS | /admin unusable (login impossible) |
| ANTHROPIC_API_KEY | engine-only generation, aggregate-only insights (fine) |
| TRAVELPAYOUTS_TOKEN (+MARKER) | deals refresh returns {skipped}; /deals shows empty state |
| RAZORPAY_* | invoices created without payment links (manual collection mode) |
| CRON_SECRET | crons open in dev; in prod Vercel sends Bearer CRON_SECRET — set it |
| NEXT_PUBLIC_WHATSAPP_NUMBER | all WhatsApp CTAs hidden |
| MAX_AI_GENERATIONS_PER_DAY | default cap of 200/day applies; past the cap, generation silently falls back to the engine |

## Migrations
- Schema lives ONLY in src/db/schema.ts. `npm run db:generate` → SQL in supabase/migrations → `npm run db:migrate` (needs DIRECT_DATABASE_URL, port 5432 — the 6543 pooler WILL fail DDL).
- Never edit applied migration files; generate a new one.
- After schema changes that touch packs: `npm run db:seed` is idempotent (upserts).

## Webhook verification drill (test mode)
1. Razorpay test keys in env; create a quote + advance invoice in /admin/billing.
2. Pay the short_url with test card 4111 1111 1111 1111.
3. Expect: invoice status → paid, payments row inserted. If not: check Vercel function logs for `/api/razorpay/webhook` — 401 means RAZORPAY_WEBHOOK_SECRET mismatch; Razorpay dashboard → Webhooks shows delivery attempts + retries.

## Cron smoke test
- `curl -X POST https://<domain>/api/deals/refresh` (must be signed in admin) or `curl -H "Authorization: Bearer $CRON_SECRET" https://<domain>/api/deals/refresh`.
- Success shape: `{inserted: n, failed: []}`. `{skipped:true}` = price source not configured.
- Vercel → Project → Crons shows last run status for the scheduled ones.

## Health & monitoring
- `GET /api/health` — shallow: JSON with `ok` plus one boolean per integration (DB, Supabase auth, Razorpay, price source, Anthropic, WhatsApp). Reports configured/not-configured only; never echoes secrets. Always fast — safe for load balancers and uptime pings.
- `GET /api/health?deep=1` — additionally runs a real query against the DB; `ok` (and the db check) go false if the ping fails. Use this shape for the go-live check: everything should be `true`.
- Point a free uptime monitor (UptimeRobot or BetterStack) at `/api/health` — alert on non-200 or `"ok":false`. Use `?deep=1` on a slower interval if you also want DB alerts.
- NEVER run `npm run dev` on top of a production `.next` directory (e.g. after `npm run build` on the same checkout). Symptom: webpack "module not found"/missing-chunk errors on pages that are fine. Fix: stop the server, delete `.next`, restart dev.

## Smoke checklist after every deploy
/ (loads) → /design (generate a Japan couple draft end-to-end) → /itinerary/<slug from response> → /deals → /insights → /admin (login → dashboard KPIs render) → create test lead in /admin/leads.

---
name: billing-ops
description: Yatrikala billing lifecycle — quotes, invoices, Razorpay payment links, webhook reconciliation, GST radar. Use when asked about quotes, invoices, payments, Razorpay, refunds, invoice numbering, or billing bugs.
---

# Billing operations

Lifecycle: lead → quote (draft→sent→accepted) → advance invoice (ceil 50%) → payment link on WhatsApp → `payment_link.paid` webhook marks paid → design work → balance invoice → paid → done.

## Where things live
- UI + server actions: src/app/admin/(protected)/billing/ (actions.ts holds all mutations; every action re-checks getAdmin()).
- Razorpay helpers: src/lib/razorpay.ts — `createPaymentLink` (amount in whole INR, converts to paise), `verifyWebhookSignature` (HMAC-SHA256 of RAW body — never re-serialize the JSON), `invoiceNumber(seq)` → YTK-<FY>-<seq> (Indian FY, April roll).
- Webhook: src/app/api/razorpay/webhook/route.ts — idempotent, always 200 for handled/ignored (Razorpay retries non-2xx), reference_id = our invoice number.

## Rules that must not break
- Money = integer whole INR everywhere in DB; paise only at the Razorpay boundary.
- Balance invoice only after an advance invoice exists for the quote.
- Manual "Mark paid" (UPI-direct payments) must also insert a `payments` row (method 'manual') — the dashboard's collected ₹ sums payments via invoices.
- Invoice numbers are unique + sequential per FY; never reuse or backfill.
- GST radar: collected fees vs ₹20L/FY threshold (Notification 10/2017-IGST covers interstate services below it). Warn loudly in UI from 70%. Registration must happen within 30 days of crossing.
- Advisory-only guardrail: never add flows that collect client money FOR bookings (flights/hotels) — that triggers TCS (flat 2%, s.394(1) Income-tax Act 2025) and a different compliance class. Design fees only.

## Test-mode drill
Razorpay test keys → create quote → advance invoice → pay short_url with card 4111 1111 1111 1111 → verify invoice paid + payments row + dashboard KPIs move. Webhook logs: Vercel function logs + Razorpay dashboard → Webhooks → deliveries.

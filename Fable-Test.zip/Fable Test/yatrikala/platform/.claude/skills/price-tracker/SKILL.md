---
name: price-tracker
description: Work on the deals radar — flight/hotel price snapshots, Travelpayouts/Amadeus adapters, cron refresh, trend badges. Use when asked about flight prices, hotel prices, deals page, price source, adding a data source, or wrong/missing prices.
---

# Price tracking system

Flow: cron (vercel.json) → /api/deals/refresh → PriceSource adapter → `price_snapshots` rows → /deals renders latest + 30-day trend. Pages NEVER call third-party APIs directly — snapshots only.

## Adapters (src/lib/prices/)
- `types.ts` — `PriceSource` interface, `DEST_GATEWAYS` (packId → {iata, city}), `ORIGINS` (DEL/BOM/BLR).
- `travelpayouts.ts` — default. v1/prices/cheap (flights, cached market fares) + Hotellook cache (hotels). Free with affiliate token; deep links carry TRAVELPAYOUTS_MARKER (revenue!). Data is up to ~48h-old observations → UI must say "observed", never "bookable".
- `amadeus.ts` — optional live offers. OAuth token cached in-module; AMADEUS_BASE switches test/prod. Test env returns test data — don't quote it to clients.
- Selection: PRICE_SOURCE env ('travelpayouts' | 'amadeus') via `priceSource()`.

## Adding a source
Implement `PriceSource` in a new file, export it, extend `priceSource()`'s switch and `priceSourceConfigured()`. Keep INR output (convert if needed), keep the sort (cheapest first), keep per-route try/catch in the refresh route.

## Gotchas
- Refresh is capped (~60 routes/invocation, 300ms courtesy delay, maxDuration 300) — full sweep may take 2 cron days after adding many destinations; use `?dest=<packId>` for targeted refills.
- Trend badge compares latest snapshot vs 30-day min/avg for that (kind, origin, destCode) — needs ≥2 days of history before it appears.
- IATA city codes (TYO/LON/PAR/ROM/SEL) are metro codes on Travelpayouts; Amadeus flight search accepts them as city codes too.
- Quote sanity workflow for the founder: /deals per origin → compare with the fee quote's flight assumption; snapshots are also joined into admin dashboard freshness KPI.

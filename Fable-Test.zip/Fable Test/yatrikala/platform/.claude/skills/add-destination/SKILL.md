---
name: add-destination
description: Add or edit Yatrikala destination packs (the content that powers the Journey Designer, deals radar, and insights). Use when asked to add a country/destination, refresh content, fix a pack, or add a country-combo route.
---

# Adding a destination

A destination is one JSON "pack" conforming to `DestinationPack` in src/engine/types.ts. Read that type first — schema is enforced by shape, voice is enforced by review.

## Authoring rules (the product depends on these)
- Voice: specific, warm, insider. Exact street/dish/viewpoint/train-seat-side. "Explore the city" is banned.
- 3–6 template days along the canonical route; 3–4 blocks/day; every day has a `teaser` (≤85 chars) that makes the locked state ache.
- Persona tags are the product: tag blocks honestly with `personas`/`excludePersonas` (sunrise trek excludes seniors+family; nightlife = friends/couple/solo). **Every persona must still see ≥2 blocks per day after filtering** — add gentle alternatives where needed.
- `personaNotes` (pace/stayStyle/tip × 5 personas) must be concrete, not generic.
- Costs in INR, indicative, rounded. `budgetFloorPP` = honest 7-night floor ex-flights. Visa values marked indicative in `visa.note`.

## Mass-authoring with a workflow
The proven approach: a Workflow with one agent per destination returning the pack via a JSON
schema (see the SCHEMA in `../../..//..?` — the canonical copy of the authoring schema + prompt
is preserved in the session workflow scripts and mirrored by the shape of src/content/packs.json;
derive the JSON Schema from src/engine/types.ts). Validate every pack with the quality gate below
before shipping.

## Quality gate (run before seeding)
```js
// for each pack, each day, each persona:
// visibleBlocks = blocks where (!personas || includes p) && (!excludePersonas || !includes p)
// assert visibleBlocks.length >= 2 and day.teaser is non-empty
```

## Wiring checklist
1. Append pack to src/content/packs.json (keep 1-space indent).
2. Gateway for deals radar: add `{iata, city}` to DEST_GATEWAYS in src/lib/prices/types.ts.
3. Combos (optional): add to COMBOS in src/engine/index.ts — `{ids, split, transit (with ₹ and duration), tag, minNights}`. Combo-only mini destinations (3 days) also go in MINI_IDS.
4. `npm run db:seed` (idempotent upsert) — or paste the pack JSON in /admin/content without a deploy.
5. Verify: /design shows the card; generate one itinerary per persona; check /deals picks up the gateway after next refresh.

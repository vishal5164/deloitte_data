export type Persona = "couple" | "family" | "seniors" | "friends" | "solo";
export const PERSONAS: Persona[] = ["couple", "family", "seniors", "friends", "solo"];

export type BlockTime = "Morning" | "Lunch" | "Afternoon" | "Evening" | "Dinner";

/** The third product dimension after persona + destination. */
export type TravelStyle = "Smart" | "Comfort" | "Luxe";
export const STYLES: TravelStyle[] = ["Smart", "Comfort", "Luxe"];

export interface StayOption { name: string; area: string; priceNight: string }

export interface Block {
  time: BlockTime;
  name: string;
  details: string;
  cost: string;
  tip?: string;
  personas?: Persona[];
  excludePersonas?: Persona[];
}

export interface DayTemplate {
  city: string;
  title: string;
  icon: string;
  teaser: string;
  blocks: Block[];
  /** Comfort-tier stay (legacy field, also the fallback when `stays` is absent). */
  stay: StayOption;
  /** Researched stays per travel style. */
  stays?: { smart: StayOption; comfort: StayOption; luxe: StayOption };
  /** One budget hack + one worth-the-splurge, specific to this day. */
  moneyTips?: { smart: string; luxe: string };
  transport: string;
  dailyCost: string;
}

export interface PersonaNote { pace: string; stayStyle: string; tip: string }

export interface DestinationPack {
  id: string;
  name: string;
  flag: string;
  tagline: string;
  bestMonths: number[]; // 1-12
  budgetFloorPP: number; // INR, 7-night floor ex-flights
  budgetBand: string;
  longHaul: boolean;
  visa: { label: string; ease: 1 | 2 | 3; time: string; cost: string; note: string };
  vibes: string[];
  personaFit: Record<Persona, number>;
  whyGo: string[];
  cities: { name: string; suggestedNights: number }[];
  days: DayTemplate[];
  personaNotes: Record<Persona, PersonaNote>;
  foods: { name: string; what: string }[];
  /** Budget multipliers relative to the Comfort floor (comfort is always 1). */
  styleMults?: { smart: number; luxe: number };
  /** Destination-level money intelligence: 3 hacks, 3 splurges that earn their price. */
  moneyMoves?: { smart: string[]; luxe: string[] };
}

export interface Combo {
  ids: [string, string];
  split: [number, number];
  transit: string;
  tag: string;
  minNights: number;
}

export interface Brief {
  persona: Persona;
  /** single destination id, or null when comboKey used */
  pick: string | null;
  /** 'vietnam+cambodia' style key from COMBOS, or null */
  comboKey: string | null;
  month: number; // 0-11
  nights: number;
  pace: "Gentle" | "Balanced" | "Full days";
  vibes: string[];
  /** travel style — defaults to Comfort when absent (older clients) */
  style?: TravelStyle;
}

export type PlanItem =
  | (DayTemplate & { destId: string; leisure?: boolean })
  | { transit: string; after: number };

export interface Itinerary {
  title: string;
  dispName: string;
  destIds: string[];
  comboKey: string | null;
  plan: PlanItem[];
  route: string;
  budgetLine: string;
  seasonNote: string;
  persona: Persona;
  nights: number;
  month: number;
  pace: string;
  style: TravelStyle;
  /** tier-matched money intelligence for the whole trip */
  moneyMoves: { smart: string[]; luxe: string[] };
  /** per-destination visa cards, persona note, foods — denormalised for rendering */
  visas: { name: string; label: string; ease: number; time: string; cost: string; note: string }[];
  personaNote: PersonaNote;
  whyGo: string[];
  vibes: string[];
  foods: { name: string; what: string }[];
}

export interface MatchResult {
  destId: string;
  name: string;
  flag: string;
  score: number;
  pct: number;
  reasons: string[];
  budgetBand: string;
  visaLabel: string;
  visaEase: number;
  pairsWith: string | null;
}

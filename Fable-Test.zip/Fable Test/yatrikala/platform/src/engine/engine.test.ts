import { test } from "node:test";
import assert from "node:assert/strict";
import {
  engineGenerate, scoreDestinations, filterBlocks, inr,
  COMBOS, comboKey, MINI_IDS,
} from "./index";
import type { Brief, DestinationPack, Persona } from "./types";
import { PERSONAS } from "./types";
import packsJson from "../content/packs.json";

const packs = packsJson as unknown as DestinationPack[];
const mainPacks = packs.filter((p) => !MINI_IDS.includes(p.id));

test("content: 30 packs, unique ids, all engine-complete", () => {
  assert.equal(packs.length, 30);
  assert.equal(new Set(packs.map((p) => p.id)).size, packs.length);
  for (const p of packs) {
    assert.ok(p.days.length >= 3, `${p.id} has ${p.days.length} days`);
    assert.ok(p.budgetFloorPP > 10000, `${p.id} budget floor suspicious`);
    for (const per of PERSONAS) assert.ok(p.personaNotes[per], `${p.id} missing personaNotes.${per}`);
  }
});

test("quality gate: every persona sees >=2 blocks on every day, every day has a teaser", () => {
  for (const p of packs) {
    p.days.forEach((d, i) => {
      assert.ok(d.teaser.length > 0, `${p.id} day${i + 1} missing teaser`);
      for (const per of PERSONAS) {
        const visible = filterBlocks(d, per).length;
        assert.ok(visible >= 2, `${p.id} day${i + 1}: persona '${per}' sees only ${visible} blocks`);
      }
    });
  }
});

test("generation matrix: every destination x persona x trip length", () => {
  for (const d of mainPacks) {
    for (const persona of PERSONAS) {
      for (const nights of [4, 7, 14]) {
        const brief: Brief = { persona, pick: d.id, comboKey: null, month: 10, nights, pace: "Balanced", vibes: [] };
        const it = engineGenerate(brief, packs);
        const days = it.plan.filter((x) => !("transit" in x));
        assert.equal(days.length, nights, `${d.id}/${persona}/${nights}n plan length`);
        assert.ok(!it.title.includes("{d}"), `${d.id}/${persona} unexpanded title`);
        assert.match(it.budgetLine, /₹/, `${d.id}/${persona} budget line`);
        assert.equal(it.visas.length, 1);
        assert.ok(it.personaNote.pace.length > 0);
        for (const day of it.plan.slice(2)) {
          if (!("transit" in day)) assert.ok(day.teaser, `${d.id}: locked day without teaser`);
        }
      }
    }
  }
});

test("combos: valid splits, exactly one transit, both visas, min-nights respected", () => {
  for (const c of COMBOS) {
    if (!c.ids.every((id) => packs.some((p) => p.id === id))) continue;
    const brief: Brief = {
      persona: "couple", pick: null, comboKey: comboKey(c),
      month: 9, nights: c.minNights, pace: "Balanced", vibes: [],
    };
    const it = engineGenerate(brief, packs);
    const days = it.plan.filter((x) => !("transit" in x));
    const transits = it.plan.filter((x) => "transit" in x);
    assert.equal(days.length, c.minNights, `${comboKey(c)} day count`);
    assert.equal(transits.length, 1, `${comboKey(c)} transit cards`);
    assert.equal(it.visas.length, 2, `${comboKey(c)} visa cards`);
    assert.match(it.route, /→/);
    // both destinations must actually contribute days
    const perDest = new Set(days.map((d) => ("destId" in d ? d.destId : "")));
    assert.equal(perDest.size, 2, `${comboKey(c)} both destinations present`);
  }
});

test("engine is deterministic: same brief -> same itinerary", () => {
  const brief: Brief = { persona: "friends", pick: "georgia", comboKey: null, month: 5, nights: 8, pace: "Full days", vibes: ["food"] };
  assert.deepEqual(engineGenerate(brief, packs), engineGenerate(brief, packs));
});

test("recommendations: sane ordering and reasons", () => {
  const results = scoreDestinations(
    { persona: "couple", month: 10, budgetIdx: 2, vibes: ["beach", "food"], visaPatience: 0 },
    packs,
  );
  assert.ok(results.length >= 10);
  assert.ok(results[0].score >= results[1].score, "sorted by score");
  assert.ok(results[0].reasons.length > 0, "top match has reasons");
  for (const r of results.slice(0, 3)) {
    assert.ok(r.pct >= 64 && r.pct <= 97, `pct in band: ${r.pct}`);
    assert.ok(!MINI_IDS.includes(r.destId), "combo-only minis never recommended standalone");
  }
  // a monsoon-July friends budget trip must not top-rank long-haul premium Europe
  const july = scoreDestinations(
    { persona: "friends", month: 6, budgetIdx: 1, vibes: ["nightlife", "adventure"], visaPatience: 0 },
    packs,
  );
  assert.ok(!["switzerland", "italy", "greece"].includes(july[0].destId), `july budget pick was ${july[0].destId}`);
});

test("travel styles: budgets scale Smart < Comfort < Luxe, style lands on the itinerary", () => {
  const parseLow = (line: string) => {
    const m = line.match(/₹([\d.]+)(L|k)/);
    assert.ok(m, `parseable budget: ${line}`);
    return parseFloat(m![1]) * (m![2] === "L" ? 100000 : 1000);
  };
  const base: Brief = { persona: "couple", pick: "japan", comboKey: null, month: 10, nights: 8, pace: "Balanced", vibes: [] };
  const smart = engineGenerate({ ...base, style: "Smart" }, packs);
  const comfort = engineGenerate({ ...base, style: "Comfort" }, packs);
  const luxe = engineGenerate({ ...base, style: "Luxe" }, packs);
  assert.equal(smart.style, "Smart");
  assert.equal(engineGenerate(base, packs).style, "Comfort", "style defaults to Comfort");
  assert.ok(parseLow(smart.budgetLine) < parseLow(comfort.budgetLine), "smart < comfort");
  assert.ok(parseLow(comfort.budgetLine) < parseLow(luxe.budgetLine), "comfort < luxe");
  // when tiered stays exist, the resolved stay must match the tier
  const withStays = packs.find((p) => p.days.some((d) => d.stays));
  if (withStays) {
    const it = engineGenerate({ ...base, pick: withStays.id, style: "Luxe" }, packs);
    const day = it.plan.find((x) => !("transit" in x) && x.stays);
    if (day && !("transit" in day)) assert.equal(day.stay.name, day.stays!.luxe.name);
  }
});

test("inr formatting", () => {
  assert.equal(inr(50000), "₹50k");
  assert.equal(inr(99000), "₹99k");
  assert.equal(inr(120000), "₹1.2L");
  assert.equal(inr(1000000), "₹10L");
});

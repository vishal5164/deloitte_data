import type {
  Brief, Combo, DayTemplate, DestinationPack, Itinerary, MatchResult, Persona, PlanItem,
} from "./types";
import { PERSONAS } from "./types";

export const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
export const BUDGET_BANDS = [
  { label: "Under ₹50k", max: 50000 },
  { label: "₹50k–1L", max: 100000 },
  { label: "₹1–2L", max: 200000 },
  { label: "₹2L+", max: Number.MAX_SAFE_INTEGER },
];

/** Combo-only add-on destinations hidden from the standalone grid and quiz. */
export const MINI_IDS = ["cambodia", "armenia"];

export const COMBOS: Combo[] = [
  { ids: ["vietnam", "cambodia"],   split: [0.7, 0.3],  transit: "1h05 flight Da Nang → Siem Reap · ~₹9k", tag: "Lanterns to lost temples", minNights: 9 },
  { ids: ["thailand", "vietnam"],   split: [0.45, 0.55],transit: "1h20 flight Bangkok → Hanoi · ~₹7k", tag: "Two kitchens of Asia", minNights: 10 },
  { ids: ["singapore", "bali"],     split: [0.4, 0.6],  transit: "2h35 flight Singapore → Denpasar · ~₹10k", tag: "Skyline, then surf", minNights: 8 },
  { ids: ["singapore", "malaysia"], split: [0.45, 0.55],transit: "45-min flight or 4h coach SIN → KL · ~₹4k", tag: "Two cities, one hawker crawl", minNights: 7 },
  { ids: ["switzerland", "italy"],  split: [0.5, 0.5],  transit: "Scenic rail into Milan · ~₹4k · 3h", tag: "Alps into aperitivo", minNights: 10 },
  { ids: ["italy", "greece"],       split: [0.55, 0.45],transit: "1h55 flight Rome → Athens · ~₹8k", tag: "Empires and islands", minNights: 10 },
  { ids: ["france", "spain"],       split: [0.5, 0.5],  transit: "TGV Paris → Barcelona · ~₹9k · 6h30", tag: "Wine borders, tapas nights", minNights: 10 },
  { ids: ["georgia", "armenia"],    split: [0.6, 0.4],  transit: "Tbilisi → Yerevan scenic road · ~₹2.5k · 5–6h", tag: "The Caucasus, both sides", minNights: 8 },
  { ids: ["dubai", "maldives"],     split: [0.45, 0.55],transit: "4h flight Dubai → Malé · ~₹18k", tag: "Gold city, blue lagoon", minNights: 8 },
  { ids: ["dubai", "oman"],         split: [0.5, 0.5],  transit: "1h flight or 5h drive Dubai → Muscat · ~₹8k", tag: "Skyline to wadi country", minNights: 7 },
  { ids: ["srilanka", "maldives"],  split: [0.55, 0.45],transit: "1h30 flight Colombo → Malé · ~₹12k", tag: "Tea hills to house reefs", minNights: 8 },
  { ids: ["japan", "southkorea"],   split: [0.55, 0.45],transit: "2h flight Osaka → Seoul · ~₹11k", tag: "Neon twins of the East", minNights: 10 },
  { ids: ["nepal", "bhutan"],       split: [0.5, 0.5],  transit: "1h Kathmandu → Paro, Himalaya out the right window · ~₹16k", tag: "Two Himalayas, two tempos", minNights: 9 },
  { ids: ["australia", "newzealand"], split: [0.5, 0.5],transit: "3h flight Sydney → Auckland · ~₹15k", tag: "The great down-under arc", minNights: 12 },
];

export const comboKey = (c: Combo) => c.ids.join("+");
export const findCombo = (key: string | null | undefined) =>
  COMBOS.find((c) => comboKey(c) === key) ?? null;

const TITLES: Record<Persona, string[]> = {
  couple: ["{d}, Just for Two", "{d}, In Its Golden Hour", "{d}, Slowly, Together"],
  family: ["The {d} Family Chapter", "{d}, Little Feet Welcome", "{d}, Wonder-Sized"],
  seniors: ["{d}, Unhurried", "{d}, at an Easy Pace", "{d}, Comfort First"],
  friends: ["{d}: The Group Chat Comes True", "{d}, With the Squad", "{d}, Loud & Alive"],
  solo: ["{d}, On Your Own Terms", "{d}, One Ticket", "{d}, Just You"],
};

const LEISURE: Record<Persona, { icon: string; title: string; teaser: string }[]> = {
  couple: [
    { icon: "🕯️", title: "A day that plans itself", teaser: "Slow breakfast, one hidden lane, and a dinner we choose for your last-night mood." },
    { icon: "🌅", title: "The golden-hour day", teaser: "One viewpoint, one long lunch, and nowhere you have to be." },
  ],
  family: [
    { icon: "🎈", title: "The everyone-naps day", teaser: "Pool morning, park picnic, early ice-cream dinner. Heroic in its simplicity." },
    { icon: "🧸", title: "Small wonders day", teaser: "The little museum, the toy shop street, and the playground with the view." },
  ],
  seniors: [
    { icon: "🍵", title: "The verandah day", teaser: "A gentle drive, a long tea, and an evening of doing beautifully little." },
    { icon: "🌿", title: "Gardens & stories day", teaser: "One garden, one heritage walk with benches, dinner at golden hour." },
  ],
  friends: [
    { icon: "🎉", title: "The unplanned classic", teaser: "Late start, street-food crawl, and the night that becomes the story." },
    { icon: "🛶", title: "Dare-each-other day", teaser: "One adrenaline hit, one feast, one sunset the group photo deserves." },
  ],
  solo: [
    { icon: "📖", title: "The wanderer's day", teaser: "No alarms. A café, a long walk, and one conversation with a stranger." },
    { icon: "🚶", title: "Get-lost-on-purpose day", teaser: "One neighbourhood, zero plans, and the best meal found by accident." },
  ],
};

function hash(s: string): number {
  let h = 0;
  for (const ch of s) h = (h * 31 + ch.charCodeAt(0)) | 0;
  return Math.abs(h);
}

export function inr(n: number): string {
  return n >= 100000 ? "₹" + Math.round(n / 10000) / 10 + "L" : "₹" + Math.round(n / 1000) + "k";
}

export function filterBlocks(day: DayTemplate, persona: Persona) {
  return day.blocks.filter(
    (b) =>
      (!b.personas || b.personas.includes(persona)) &&
      (!b.excludePersonas || !b.excludePersonas.includes(persona)),
  );
}

function alloc(dest: DestinationPack, nights: number, persona: Persona): PlanItem[] {
  const out: PlanItem[] = [];
  const leisure = LEISURE[persona];
  for (let i = 0; i < nights; i++) {
    if (i < dest.days.length) out.push({ ...dest.days[i], destId: dest.id });
    else {
      const L = leisure[(i - dest.days.length) % leisure.length];
      const last = dest.days[dest.days.length - 1];
      out.push({
        city: last.city, title: L.title, icon: L.icon, teaser: L.teaser,
        blocks: [], stay: last.stay, stays: last.stays,
        transport: "", dailyCost: "", destId: dest.id, leisure: true,
      });
    }
  }
  return out;
}

const shortName = (d: DestinationPack) => d.name.split(" (")[0];

/**
 * The deterministic generation engine. Pure function: same brief + packs → same itinerary.
 * Swap point for Claude-powered generation lives in src/lib/claude.ts, which falls back here.
 */
export function engineGenerate(brief: Brief, packs: DestinationPack[]): Itinerary {
  const byId = (id: string) => {
    const d = packs.find((p) => p.id === id);
    if (!d) throw new Error(`unknown destination: ${id}`);
    return d;
  };
  const combo = findCombo(brief.comboKey);
  const dests = combo ? combo.ids.map(byId) : [byId(brief.pick!)];
  const names = dests.map(shortName);
  const dispName = names.join(" + ");
  const style = brief.style ?? "Comfort";
  const styleKey = style.toLowerCase() as "smart" | "comfort" | "luxe";

  let plan: PlanItem[] = [];
  if (combo) {
    const nA = Math.max(2, Math.round(brief.nights * combo.split[0]));
    plan = [
      ...alloc(dests[0], nA, brief.persona),
      { transit: combo.transit, after: nA },
      ...alloc(dests[1], brief.nights - nA, brief.persona),
    ];
  } else plan = alloc(dests[0], brief.nights, brief.persona);

  // resolve each day's stay for the chosen style (moneyTips stay raw — renderers pick)
  for (const item of plan) {
    if ("transit" in item) continue;
    if (item.stays) item.stay = item.stays[styleKey] ?? item.stay;
  }

  const styleMult = (d: DestinationPack) =>
    style === "Smart" ? (d.styleMults?.smart ?? 0.72)
    : style === "Luxe" ? (d.styleMults?.luxe ?? 1.9)
    : 1;
  const perNight = dests.reduce(
    (s, d, i) => s + (d.budgetFloorPP / 7) * styleMult(d) * (combo ? combo.split[i] : 1), 0);
  const personaMult = { couple: 1.15, family: 1.12, seniors: 1.2, friends: 0.95, solo: 1.0 }[brief.persona];
  const paceMult = { Gentle: 1.0, Balanced: 1.05, "Full days": 1.12 }[brief.pace] ?? 1;
  const lo = perNight * brief.nights * personaMult * paceMult + (combo ? 9000 : 0);

  const t = TITLES[brief.persona];
  const title = t[hash(dests[0].id) % t.length].replace("{d}", dispName);

  const monthOK = dests.every((d) => d.bestMonths.includes(brief.month + 1));
  const bmNames = [...new Set(dests[0].bestMonths)].slice(0, 3).map((m) => MONTHS[m - 1]).join(", ");
  const dayCount = (destId: string) =>
    plan.filter((p) => !("transit" in p) && p.destId === destId).length;

  return {
    title, dispName,
    destIds: dests.map((d) => d.id),
    comboKey: combo ? comboKey(combo) : null,
    plan,
    route: combo
      ? `${names[0]} (${dayCount(dests[0].id)}n) → ${names[1]} (${dayCount(dests[1].id)}n)`
      : dests[0].cities.map((c) => c.name).join(" → "),
    budgetLine: `${inr(lo)} – ${inr(lo * 1.35)} pp`,
    seasonNote: monthOK
      ? `${MONTHS[brief.month]} is a sweet spot for this route — you chose well.`
      : `Heads-up: locals would nudge you toward ${bmNames}. ${MONTHS[brief.month]} still works — we'd just design around it.`,
    persona: brief.persona,
    nights: brief.nights,
    month: brief.month,
    pace: brief.pace,
    style,
    moneyMoves: {
      smart: dests.flatMap((d) => d.moneyMoves?.smart ?? []).slice(0, 4),
      luxe: dests.flatMap((d) => d.moneyMoves?.luxe ?? []).slice(0, 4),
    },
    visas: dests.map((d) => ({ name: shortName(d), ...d.visa })),
    personaNote: dests[0].personaNotes[brief.persona],
    whyGo: dests[0].whyGo,
    vibes: dests[0].vibes,
    foods: dests.flatMap((d) => d.foods),
  };
}

/** Destination recommendation scoring for the "surprise me" path. */
export function scoreDestinations(
  q: { persona: Persona; month: number; budgetIdx: number; vibes: string[]; visaPatience: 0 | 1 },
  packs: DestinationPack[],
): MatchResult[] {
  const candidates = packs.filter((d) => !MINI_IDS.includes(d.id));
  const destBudgetIdx = (d: DestinationPack) =>
    d.budgetFloorPP <= 50000 ? 0 : d.budgetFloorPP <= 95000 ? 1 : d.budgetFloorPP <= 180000 ? 2 : 3;

  const scored = candidates.map((d) => {
    let sc = 0;
    const why: string[] = [];
    const m = q.month + 1;
    if (d.bestMonths.includes(m)) { sc += 28; why.push(`${MONTHS[q.month]} is ${shortName(d)}'s sweet spot`); }
    else if (d.bestMonths.includes(m === 12 ? 1 : m + 1) || d.bestMonths.includes(m === 1 ? 12 : m - 1)) {
      sc += 12; why.push("shoulder season — fewer crowds");
    }
    const db = destBudgetIdx(d);
    if (q.budgetIdx >= db) { sc += 22; why.push("fits your budget comfortably"); }
    else if (q.budgetIdx === db - 1) { sc += 6; why.push("a stretch, but doable done smartly"); }
    else sc -= 14;
    const hits = d.vibes.filter((v) => q.vibes.includes(v));
    sc += Math.min(hits.length * 9, 27);
    if (hits.length) why.push(`made for ${hits.slice(0, 3).join(", ")}`);
    if (q.visaPatience === 0) {
      sc += d.visa.ease === 1 ? 14 : d.visa.ease === 2 ? 4 : -16;
      if (d.visa.ease === 1) why.push(`${d.visa.label} — near-zero visa friction`);
    } else {
      sc += 6;
      if (d.visa.ease === 3) why.push("complex visa — exactly what we refusal-proof");
    }
    sc += (d.personaFit[q.persona] - 3) * 7;
    if (d.personaFit[q.persona] >= 4) why.push(`a natural fit for this kind of trip`);
    return { d, sc, why };
  }).sort((a, b) => b.sc - a.sc);

  const max = scored[0]?.sc || 1;
  return scored.map(({ d, sc, why }) => ({
    destId: d.id,
    name: d.name,
    flag: d.flag,
    score: sc,
    pct: Math.max(64, Math.min(97, Math.round(64 + 33 * (sc / (max + 8))))),
    reasons: why.slice(0, 3),
    budgetBand: d.budgetBand,
    visaLabel: d.visa.label,
    visaEase: d.visa.ease,
    pairsWith: (() => {
      const c = COMBOS.find((c) => c.ids[0] === d.id && packs.some((p) => p.id === c.ids[1]));
      return c ? shortName(packs.find((p) => p.id === c.ids[1])!) : null;
    })(),
  }));
}

export { PERSONAS };
export type * from "./types";

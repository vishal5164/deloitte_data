import type { Metadata } from "next";
import TopNav from "@/components/TopNav";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Terms of Service",
  description:
    "The plain-language terms of working with Yatrikala: what we design, what you book, and what happens to your money.",
};

const EMAIL = "hello@yatrikala.com";

export default function TermsPage() {
  const wa = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "").replace(/\D/g, "");

  return (
    <>
      <TopNav />
      <main className="wrap-narrow" style={{ paddingBottom: 40 }}>
        <header style={{ padding: "36px 0 4px" }}>
          <h1 className="serif" style={{ color: "var(--ink)", fontSize: 30, fontWeight: 400 }}>
            Terms of Service
          </h1>
          <p className="subnote" style={{ marginTop: 6 }}>
            Last updated: July 2026 · Written to be read, not skimmed past.
          </p>
        </header>

        <h2 className="h-sec">What we do — and don&apos;t do</h2>
        <p style={{ fontSize: 14.5 }}>
          Yatrikala designs travel itineraries. That is the whole service: we research, plan and
          hand you a day-by-day journey design with stays shortlists, a reservations plan and visa
          paperwork guidance, for a fixed design fee.
        </p>
        <p style={{ fontSize: 14.5, marginTop: 10 }}>
          We are <b>not</b> a travel agent or tour operator. We never book flights, hotels, trains
          or activities on your behalf, and we never hold your travel funds. You make every booking
          yourself, directly with the provider, at the provider&apos;s own price. Our fee is for
          design and advice only.
        </p>

        <h2 className="h-sec">Deliverables and revisions</h2>
        <p style={{ fontSize: 14.5 }}>
          Each engagement includes the itinerary design described in your quote and{" "}
          <b>two rounds of revisions</b>. A revision round is a consolidated set of changes — swap a
          city, stretch a budget, slow a day down — not a single tweak. Further rounds are happily
          done, quoted separately before we start them.
        </p>

        <h2 className="h-sec">Fees and payment</h2>
        <p style={{ fontSize: 14.5 }}>
          Design fees are fixed and quoted upfront (from ₹4,999 depending on trip length and
          complexity). We take a <b>50% advance</b> to begin work, paid via Razorpay or UPI. The
          balance is due before we hand over the final itinerary. All amounts are in Indian rupees.
          Refunds are covered by our{" "}
          <a href="/refunds" style={{ color: "var(--terracotta)" }}>
            Refund &amp; Cancellation Policy
          </a>
          .
        </p>

        <h2 className="h-sec">Prices, visas and other moving targets</h2>
        <p style={{ fontSize: 14.5 }}>
          Everything third-party in your itinerary — fares, hotel rates, entry fees, visa rules,
          opening hours — is <b>indicative</b>, correct to the best of our research at the time we
          write it, and liable to change without notice. Always verify prices at the moment of
          booking and visa requirements at the moment of application. Final decisions rest with you
          and, for visas, with the relevant embassy or authority — a well-built file improves your
          odds, it does not guarantee an outcome.
        </p>

        <h2 className="h-sec">Affiliate links</h2>
        <p style={{ fontSize: 14.5 }}>
          Some booking links we share are affiliate links, and we say so wherever they appear. If
          you book through one, the provider may pay us a small commission.{" "}
          <b>Your price never changes</b> — you pay exactly what you would pay going to the provider
          directly. Our recommendations are chosen for your trip, never for the commission.
        </p>

        <h2 className="h-sec">Limitation of liability</h2>
        <p style={{ fontSize: 14.5 }}>
          Because we design and you book, our liability to you is capped at the design fee you
          actually paid us. We are not liable for the acts, omissions or failures of third-party
          providers (airlines, hotels, transport, activity operators), for visa refusals or delays,
          or for travel disruptions such as cancellations, strikes, weather or force majeure. This
          does not limit any liability that cannot be excluded under Indian law.
        </p>

        <h2 className="h-sec">Your itinerary is yours (mostly)</h2>
        <p style={{ fontSize: 14.5 }}>
          The itinerary we design is licensed to you for your personal use and that of your travel
          party. Share it with your co-travellers, print it, scribble on it. Please don&apos;t
          resell it, republish it or use it commercially — the underlying research, formats and
          templates remain Yatrikala&apos;s.
        </p>

        <h2 className="h-sec">Governing law</h2>
        <p style={{ fontSize: 14.5 }}>
          Yatrikala is a sole proprietorship based in Pune, Maharashtra, India. These terms are
          governed by Indian law, and any dispute falls under the exclusive jurisdiction of the
          courts at Pune, Maharashtra.
        </p>

        <h2 className="h-sec">Talk to us</h2>
        <p style={{ fontSize: 14.5 }}>
          Questions about these terms? Message us{" "}
          {wa ? (
            <>
              on{" "}
              <a
                href={`https://wa.me/${wa}`}
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: "var(--terracotta)" }}
              >
                WhatsApp
              </a>{" "}
              or{" "}
            </>
          ) : null}
          at{" "}
          <a href={`mailto:${EMAIL}`} style={{ color: "var(--terracotta)" }}>
            {EMAIL}
          </a>
          . A person answers, not a queue.
        </p>
      </main>
      <Footer />
    </>
  );
}

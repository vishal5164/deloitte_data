import TopNav from "@/components/TopNav";
import Footer from "@/components/Footer";
import Landing, { type MarqueeCard, type PersonaPitch } from "./Landing";
import { loadPacks } from "@/content/loadPacks";
import { inr, MINI_IDS } from "@/engine";
import type { DestinationPack, Persona } from "@/engine/types";

export const revalidate = 86400; // persona pitches re-pick against the current month daily

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://yatrikala.com";

const PERSONA_META: { id: Persona; label: string; line: (n: string) => string }[] = [
  { id: "couple", label: "Two of us", line: (n) => `${n}, in its golden hour — just for two.` },
  { id: "family", label: "With little ones", line: (n) => `${n}, nap-proofed and wonder-sized.` },
  { id: "seniors", label: "With parents", line: (n) => `${n}, unhurried. Zero rushed mornings.` },
  { id: "friends", label: "The squad", line: (n) => `${n}, with the whole group chat. Loud and alive.` },
  { id: "solo", label: "Just me", line: (n) => `${n} — one ticket, entirely your own terms.` },
];

function bestFor(persona: Persona, packs: DestinationPack[], month: number): DestinationPack {
  return [...packs]
    .filter((p) => !MINI_IDS.includes(p.id))
    .sort(
      (a, b) =>
        b.personaFit[persona] - a.personaFit[persona] ||
        Number(b.bestMonths.includes(month + 1)) - Number(a.bestMonths.includes(month + 1)) ||
        a.budgetFloorPP - b.budgetFloorPP,
    )[0];
}

export default async function Home() {
  const packs = await loadPacks();
  const month = new Date().getMonth();

  const pitches: PersonaPitch[] = PERSONA_META.map((m) => {
    const d = bestFor(m.id, packs, month);
    const name = d.name.split(" (")[0];
    return {
      id: m.id,
      label: m.label,
      flag: d.flag,
      line: m.line(name),
      from: `from ${inr(d.budgetFloorPP)} pp ex-flights · ${d.visa.label}`,
    };
  });

  const cards: MarqueeCard[] = packs
    .filter((p) => !MINI_IDS.includes(p.id))
    .map((p) => ({
      id: p.id,
      name: p.name.split(" (")[0],
      flag: p.flag,
      tagline: p.tagline,
      budgetBand: p.budgetBand,
      visaLabel: p.visa.label,
      visaEase: p.visa.ease,
    }));

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "TravelAgency",
    name: "Yatrikala",
    description:
      "Bespoke travel itinerary design studio for Indian travellers — auto-drafted journeys finished by hand, visa strategy included.",
    url: SITE_URL,
    areaServed: "IN",
    priceRange: "₹4,999–₹59,999",
  };

  return (
    <>
      <TopNav active="/" />
      <Landing pitches={pitches} cards={cards} />
      <Footer />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
    </>
  );
}

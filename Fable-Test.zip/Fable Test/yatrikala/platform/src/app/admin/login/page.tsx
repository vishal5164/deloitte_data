"use client";

import { useState } from "react";
import { createBrowserClient } from "@supabase/ssr";

/**
 * Admin studio sign-in: email → Supabase magic link → back to /admin
 * (the middleware completes the code exchange on landing).
 */
export default function AdminLoginPage() {
  const [email, setEmail] = useState("");
  const [phase, setPhase] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [message, setMessage] = useState("");

  async function sendLink(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const addr = email.trim();
    if (!addr) return;
    setPhase("sending");
    setMessage("");
    try {
      const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
      const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
      if (!url || !anonKey) {
        throw new Error(
          "Supabase isn't configured yet — set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY, then redeploy.",
        );
      }
      const supabase = createBrowserClient(url, anonKey);
      const { error } = await supabase.auth.signInWithOtp({
        email: addr,
        options: { emailRedirectTo: `${location.origin}/admin` },
      });
      if (error) throw error;
      setPhase("sent");
    } catch (err) {
      setMessage(err instanceof Error ? err.message : "Something went wrong — try again.");
      setPhase("error");
    }
  }

  return (
    <main
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
    >
      <div className="card rise" style={{ width: "100%", maxWidth: 420, padding: 28 }}>
        <div className="wordmark" style={{ fontSize: 18, marginBottom: 4 }}>
          YATRIKALA
        </div>
        <div className="wordsub" style={{ marginBottom: 18 }}>STUDIO</div>

        <div className="routeline" style={{ marginBottom: 22 }}>
          <span className="rl-dot" />
          <span className="rl-dash" />
          <span className="rl-star">✦</span>
        </div>

        {phase === "sent" ? (
          <div>
            <h1 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 22, marginBottom: 8 }}>
              Magic link sent
            </h1>
            <p style={{ fontSize: 14, marginBottom: 14 }}>
              Check <strong style={{ color: "var(--ink)" }}>{email.trim()}</strong> and tap the link — it signs
              you straight into the studio. The link expires in about an hour.
            </p>
            <button
              className="btn-ghost"
              onClick={() => setPhase("idle")}
              style={{ fontSize: 13 }}
            >
              Use a different email
            </button>
          </div>
        ) : (
          <form onSubmit={sendLink}>
            <h1 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 22, marginBottom: 6 }}>
              Sign in to the studio
            </h1>
            <p style={{ fontSize: 13.5, marginBottom: 14 }}>
              No passwords here. Enter your admin email and we&apos;ll send a one-tap magic link.
            </p>
            <label className="lbl" htmlFor="admin-email">Email</label>
            <input
              id="admin-email"
              type="email"
              required
              autoFocus
              placeholder="you@yatrikala.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={phase === "sending"}
            />
            {phase === "error" && message && (
              <p style={{ fontSize: 12.5, color: "var(--bad)", marginTop: 8 }}>{message}</p>
            )}
            <button
              type="submit"
              className="cta"
              disabled={phase === "sending"}
              style={{ width: "100%", marginTop: 16 }}
            >
              {phase === "sending" ? "Sending…" : "Send magic link"}
            </button>
            <p className="fine" style={{ marginTop: 12 }}>
              Only emails on the ADMIN_EMAILS allow-list can enter, link or not.
            </p>
          </form>
        )}
      </div>
    </main>
  );
}

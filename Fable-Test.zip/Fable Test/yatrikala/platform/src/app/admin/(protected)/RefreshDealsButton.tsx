"use client";

import { useState } from "react";

/** Small client helper for the admin nav: POSTs to /api/deals/refresh. */
export default function RefreshDealsButton() {
  const [phase, setPhase] = useState<"idle" | "busy" | "done" | "error">("idle");

  async function refresh() {
    if (phase === "busy") return;
    setPhase("busy");
    try {
      const res = await fetch("/api/deals/refresh", { method: "POST" });
      setPhase(res.ok ? "done" : "error");
    } catch {
      setPhase("error");
    }
    window.setTimeout(() => setPhase("idle"), 3500);
  }

  const label =
    phase === "busy" ? "Refreshing…"
    : phase === "done" ? "Deals refreshed ✦"
    : phase === "error" ? "Refresh failed — retry"
    : "Refresh deals";

  return (
    <button
      onClick={refresh}
      disabled={phase === "busy"}
      className="btn-ghost"
      title="Pull fresh flight & hotel price observations now"
      style={{
        fontSize: 12.5,
        padding: "6px 14px",
        whiteSpace: "nowrap",
        color: phase === "error" ? "var(--bad)" : phase === "done" ? "var(--good)" : undefined,
        opacity: phase === "busy" ? 0.6 : 1,
      }}
    >
      {label}
    </button>
  );
}

import Link from "next/link";
import { db, tables } from "@/db";
import { count, desc, gte, inArray, sum } from "drizzle-orm";
import { MONTHS } from "@/engine";

type Lead = typeof tables.leads.$inferSelect;
type Brief = typeof tables.briefs.$inferSelect;

const LEAD_STATUSES = ["new", "brief", "quoted", "won", "lost", "cold"] as const;

const money = (n: number) => "₹" + Math.round(n).toLocaleString("en-IN");

const fmtDate = (d: Date) =>
  new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short" }).format(d);

function age(from: Date): string {
  const mins = Math.max(0, Math.floor((Date.now() - from.getTime()) / 60_000));
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export default async function AdminDashboard() {
  let dbOk = true;
  const safe = async <T,>(q: () => Promise<T>, fallback: T): Promise<T> => {
    try {
      return await q();
    } catch {
      dbOk = false;
      return fallback;
    }
  };

  const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);

  const [
    statusRows,
    pipelineRow,
    collectedRow,
    briefs7Row,
    itinerariesRow,
    latestSnapRow,
    recentLeads,
    recentBriefs,
  ] = await Promise.all([
    safe(
      () =>
        db
          .select({ status: tables.leads.status, n: count() })
          .from(tables.leads)
          .groupBy(tables.leads.status),
      [] as { status: string; n: number }[],
    ),
    safe(
      () =>
        db
          .select({ total: sum(tables.quotes.amountInr) })
          .from(tables.quotes)
          .where(inArray(tables.quotes.status, ["draft", "sent"])),
      [] as { total: string | null }[],
    ),
    safe(
      () =>
        db
          .select({ total: sum(tables.invoices.amountInr) })
          .from(tables.invoices)
          .where(inArray(tables.invoices.status, ["paid"])),
      [] as { total: string | null }[],
    ),
    safe(
      () =>
        db
          .select({ n: count() })
          .from(tables.briefs)
          .where(gte(tables.briefs.createdAt, weekAgo)),
      [] as { n: number }[],
    ),
    safe(() => db.select({ n: count() }).from(tables.itineraries), [] as { n: number }[]),
    safe(
      () =>
        db
          .select({ at: tables.priceSnapshots.foundAt })
          .from(tables.priceSnapshots)
          .orderBy(desc(tables.priceSnapshots.foundAt))
          .limit(1),
      [] as { at: Date }[],
    ),
    safe(
      () => db.select().from(tables.leads).orderBy(desc(tables.leads.createdAt)).limit(5),
      [] as Lead[],
    ),
    safe(
      () => db.select().from(tables.briefs).orderBy(desc(tables.briefs.createdAt)).limit(5),
      [] as Brief[],
    ),
  ]);

  const byStatus: Record<string, number> = {};
  for (const r of statusRows) byStatus[r.status] = r.n;
  const totalLeads = statusRows.reduce((s, r) => s + r.n, 0);
  const breakdown = LEAD_STATUSES.filter((s) => byStatus[s])
    .map((s) => `${s} ${byStatus[s]}`)
    .join(" · ");

  const pipeline = Number(pipelineRow[0]?.total ?? 0);
  const collected = Number(collectedRow[0]?.total ?? 0);
  const briefs7 = briefs7Row[0]?.n ?? 0;
  const itineraries = itinerariesRow[0]?.n ?? 0;
  const latestSnapAt = latestSnapRow[0]?.at ?? null;

  return (
    <div className="rise">
      <h1 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 26 }}>
        The studio at a glance
      </h1>
      <p className="subnote">Leads, money and the machinery — all of it, on one quiet page.</p>

      {!dbOk && (
        <p className="tipbox" style={{ marginBottom: 16 }}>
          Database not connected yet — showing zeros. Point DATABASE_URL at Supabase and these
          tiles light up on the next load.
        </p>
      )}

      <div className="kpis">
        <div className="kpi">
          <b>Leads</b>
          <div className="v num">{totalLeads}</div>
          <small>{breakdown || "none yet"}</small>
        </div>
        <div className="kpi">
          <b>Open pipeline</b>
          <div className="v num">{money(pipeline)}</div>
          <small>quotes in draft or sent</small>
        </div>
        <div className="kpi">
          <b>Collected</b>
          <div className="v num">{money(collected)}</div>
          <small>invoices marked paid</small>
        </div>
        <div className="kpi">
          <b>Briefs, last 7 days</b>
          <div className="v num">{briefs7}</div>
          <small>journeys drafted by visitors</small>
        </div>
        <div className="kpi">
          <b>Itineraries generated</b>
          <div className="v num">{itineraries}</div>
          <small>engine + Claude, all time</small>
        </div>
        <div className="kpi">
          <b>Price snapshot</b>
          <div className="v num">{latestSnapAt ? age(latestSnapAt) : "—"}</div>
          <small>
            {latestSnapAt
              ? `observed ${latestSnapAt.toLocaleString("en-IN")}`
              : "no observations yet — hit Refresh deals"}
          </small>
        </div>
      </div>

      <h2 className="h-sec">Recent leads</h2>
      <p className="subnote">
        The five newest. <Link href="/admin/leads">Work the full list →</Link>
      </p>
      <div className="tbl-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>Created</th>
              <th>Name</th>
              <th>Contact</th>
              <th>Persona</th>
              <th>Destination</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {recentLeads.length === 0 ? (
              <tr>
                <td colSpan={6} className="fine">
                  No leads yet — they&apos;ll appear here the moment a traveller leaves their
                  details in the Journey Designer.
                </td>
              </tr>
            ) : (
              recentLeads.map((l) => (
                <tr key={l.id}>
                  <td className="num">{fmtDate(l.createdAt)}</td>
                  <td style={{ color: "var(--ink)" }}>{l.name}</td>
                  <td>
                    {l.phone && <div className="num">{l.phone}</div>}
                    {l.email && <div>{l.email}</div>}
                    {!l.phone && !l.email && <span className="fine">—</span>}
                  </td>
                  <td>{l.persona ?? "—"}</td>
                  <td>{l.destination ?? "—"}</td>
                  <td>
                    <span className={`status ${l.status}`}>{l.status}</span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <h2 className="h-sec">Recent briefs</h2>
      <p className="subnote">What travellers asked the Journey Designer for, most recent first.</p>
      <div className="tbl-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>Created</th>
              <th>Persona</th>
              <th>Destinations</th>
              <th>Month</th>
              <th>Nights</th>
              <th>Pace</th>
            </tr>
          </thead>
          <tbody>
            {recentBriefs.length === 0 ? (
              <tr>
                <td colSpan={6} className="fine">
                  No briefs yet — each Journey Designer run lands one here.
                </td>
              </tr>
            ) : (
              recentBriefs.map((b) => (
                <tr key={b.id}>
                  <td className="num">{fmtDate(b.createdAt)}</td>
                  <td>{b.persona}</td>
                  <td style={{ color: "var(--ink)" }}>{b.destIds.join(" + ")}</td>
                  <td>{MONTHS[b.month] ?? b.month}</td>
                  <td className="num">{b.nights}</td>
                  <td>{b.pace}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

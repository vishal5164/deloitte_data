import Link from "next/link";
import { redirect } from "next/navigation";
import { createSupabaseServer, requireAdmin } from "@/lib/auth";
import RefreshDealsButton from "./RefreshDealsButton";

// Admin pages must never be statically cached, regardless of env timing at build.
export const dynamic = "force-dynamic";

/**
 * Auth-gated shell for every admin page except /admin/login (which lives
 * outside this route group). requireAdmin() bounces strangers to the login page.
 */
export default async function ProtectedAdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // Pre-setup grace: without Supabase env vars requireAdmin() cannot run, so we
  // show a setup note instead of crashing (and never expose gated content).
  const supabaseConfigured = Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  );
  if (!supabaseConfigured) {
    return (
      <main className="wrap-narrow" style={{ paddingTop: 64, paddingBottom: 64 }}>
        <div className="card" style={{ padding: 28 }}>
          <div className="wordmark" style={{ fontSize: 17, marginBottom: 4 }}>YATRIKALA</div>
          <div className="wordsub" style={{ marginBottom: 16 }}>STUDIO</div>
          <h1 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 22, marginBottom: 8 }}>
            One step before the studio opens
          </h1>
          <p style={{ fontSize: 14 }}>
            Admin sign-in runs on Supabase. Add <code>NEXT_PUBLIC_SUPABASE_URL</code>,{" "}
            <code>NEXT_PUBLIC_SUPABASE_ANON_KEY</code> and <code>ADMIN_EMAILS</code> to your
            environment, then reload this page.
          </p>
        </div>
      </main>
    );
  }

  const user = await requireAdmin();

  async function signOut() {
    "use server";
    const supabase = await createSupabaseServer();
    await supabase.auth.signOut();
    redirect("/admin/login");
  }

  return (
    <>
      <nav className="topnav">
        <div className="inner">
          <Link
            href="/admin"
            className="wordmark"
            style={{ fontSize: 16, textDecoration: "none", whiteSpace: "nowrap" }}
          >
            YATRIKALA <span className="wordsub">STUDIO</span>
          </Link>
          <span className="spacer" />
          <Link href="/admin">Dashboard</Link>
          <Link href="/admin/leads">Leads</Link>
          <Link href="/admin/billing">Billing</Link>
          <Link href="/admin/content">Content</Link>
          <RefreshDealsButton />
        </div>
      </nav>

      <div style={{ background: "var(--sheet)", borderBottom: "1px solid var(--sand)" }}>
        <div
          className="wrap"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            paddingTop: 6,
            paddingBottom: 6,
          }}
        >
          <span className="fine">
            Signed in as <strong style={{ color: "var(--ink)" }}>{user.email}</strong>
          </span>
          <span style={{ flex: 1 }} />
          <Link href="/" className="fine" style={{ textDecoration: "none" }}>
            View site →
          </Link>
          <form action={signOut}>
            <button
              className="fine"
              style={{ color: "var(--terracotta)", textDecoration: "underline" }}
            >
              Sign out
            </button>
          </form>
        </div>
      </div>

      <main className="wrap" style={{ paddingTop: 26, paddingBottom: 70 }}>
        {children}
      </main>
    </>
  );
}

import Link from "next/link";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db, tables } from "@/db";
import { count, desc, eq } from "drizzle-orm";
import { getAdmin } from "@/lib/auth";
import { PERSONAS } from "@/engine";

type Lead = typeof tables.leads.$inferSelect;

const LEAD_STATUSES = ["new", "brief", "quoted", "won", "lost", "cold"] as const;

const fmtDate = (d: Date) =>
  new Intl.DateTimeFormat("en-IN", { day: "2-digit", month: "short", year: "2-digit" }).format(d);

async function updateLeadStatus(id: string, formData: FormData): Promise<void> {
  "use server";
  if (!(await getAdmin())) redirect("/admin/login");
  const status = String(formData.get("status") ?? "");
  if (!(LEAD_STATUSES as readonly string[]).includes(status)) return;
  try {
    await db.update(tables.leads).set({ status }).where(eq(tables.leads.id, id));
  } catch {
    // DB unreachable — the page re-render will show the unchanged row
  }
  revalidatePath("/admin/leads");
}

async function createLead(formData: FormData): Promise<void> {
  "use server";
  if (!(await getAdmin())) redirect("/admin/login");
  const name = String(formData.get("name") ?? "").trim();
  if (!name) return;
  const opt = (key: string) => {
    const v = String(formData.get(key) ?? "").trim();
    return v || null;
  };
  try {
    await db.insert(tables.leads).values({
      name,
      phone: opt("phone"),
      email: opt("email"),
      persona: opt("persona"),
      destination: opt("destination"),
      notes: opt("notes"),
      source: "studio",
      status: "new",
    });
  } catch {
    // DB unreachable — nothing saved; the empty-state note explains why
  }
  revalidatePath("/admin/leads");
}

export default async function LeadsPage(props: {
  searchParams: Promise<{ status?: string }>;
}) {
  const sp = await props.searchParams;
  const filter =
    sp.status && (LEAD_STATUSES as readonly string[]).includes(sp.status) ? sp.status : null;

  let dbOk = true;
  let rows: Lead[] = [];
  let statusCounts: Record<string, number> = {};
  try {
    rows = filter
      ? await db
          .select()
          .from(tables.leads)
          .where(eq(tables.leads.status, filter))
          .orderBy(desc(tables.leads.createdAt))
          .limit(200)
      : await db
          .select()
          .from(tables.leads)
          .orderBy(desc(tables.leads.createdAt))
          .limit(200);
    const counted = await db
      .select({ status: tables.leads.status, n: count() })
      .from(tables.leads)
      .groupBy(tables.leads.status);
    statusCounts = Object.fromEntries(counted.map((r) => [r.status, r.n]));
  } catch {
    dbOk = false;
  }
  const total = Object.values(statusCounts).reduce((s, n) => s + n, 0);

  return (
    <div className="rise">
      <h1 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 26 }}>
        Leads
      </h1>
      <p className="subnote">
        Every traveller who raised a hand. Move them along the pipeline as conversations progress.
      </p>

      {!dbOk && (
        <p className="tipbox" style={{ marginBottom: 16 }}>
          Database not connected yet — the pipeline will fill in once DATABASE_URL points at
          Supabase.
        </p>
      )}

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", margin: "14px 0 18px" }}>
        <Link href="/admin/leads" className={`chip${!filter ? " sel" : ""}`} style={{ textDecoration: "none" }}>
          All <span className="num">{total}</span>
        </Link>
        {LEAD_STATUSES.map((s) => (
          <Link
            key={s}
            href={`/admin/leads?status=${s}`}
            className={`chip${filter === s ? " sel" : ""}`}
            style={{ textDecoration: "none" }}
          >
            {s} <span className="num">{statusCounts[s] ?? 0}</span>
          </Link>
        ))}
      </div>

      <div className="tbl-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>Created</th>
              <th>Name</th>
              <th>Contact</th>
              <th>Persona</th>
              <th>Destination</th>
              <th>Status</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={7} className="fine">
                  {filter
                    ? `No leads in “${filter}” right now.`
                    : "No leads yet — add one below, or let the Journey Designer bring them in."}
                </td>
              </tr>
            ) : (
              rows.map((l) => (
                <tr key={l.id}>
                  <td className="num">{fmtDate(l.createdAt)}</td>
                  <td style={{ color: "var(--ink)" }}>
                    {l.name}
                    <div className="fine">{l.source}</div>
                  </td>
                  <td>
                    {l.phone && <div className="num">{l.phone}</div>}
                    {l.email && <div>{l.email}</div>}
                    {!l.phone && !l.email && <span className="fine">—</span>}
                  </td>
                  <td>{l.persona ?? "—"}</td>
                  <td>{l.destination ?? "—"}</td>
                  <td>
                    <span className={`status ${l.status}`}>{l.status}</span>
                    <form
                      action={updateLeadStatus.bind(null, l.id)}
                      style={{ display: "flex", gap: 6, marginTop: 7, alignItems: "center" }}
                    >
                      <select
                        name="status"
                        defaultValue={l.status}
                        style={{ width: "auto", padding: "3px 6px", fontSize: 12 }}
                        aria-label={`Change status for ${l.name}`}
                      >
                        {LEAD_STATUSES.map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                      <button className="btn-ghost" style={{ padding: "3px 10px", fontSize: 11.5 }}>
                        Set
                      </button>
                    </form>
                  </td>
                  <td style={{ maxWidth: 220 }}>{l.notes ?? <span className="fine">—</span>}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <h2 className="h-sec">Add a lead</h2>
      <p className="subnote">Walk-ins, WhatsApp pings, aunty referrals — get them into the pipeline.</p>
      <div className="card">
        <form action={createLead}>
          <div className="formrow">
            <div>
              <label className="lbl" htmlFor="lead-name">Name</label>
              <input id="lead-name" name="name" required placeholder="Traveller's name" />
            </div>
            <div>
              <label className="lbl" htmlFor="lead-phone">Phone</label>
              <input id="lead-phone" name="phone" placeholder="+91 98…" />
            </div>
            <div>
              <label className="lbl" htmlFor="lead-email">Email</label>
              <input id="lead-email" name="email" type="email" placeholder="name@example.com" />
            </div>
          </div>
          <div className="formrow">
            <div>
              <label className="lbl" htmlFor="lead-persona">Persona</label>
              <select id="lead-persona" name="persona" defaultValue="">
                <option value="">— not sure yet —</option>
                {PERSONAS.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="lbl" htmlFor="lead-destination">Destination</label>
              <input id="lead-destination" name="destination" placeholder="japan, vietnam+cambodia…" />
            </div>
            <div>
              <label className="lbl" htmlFor="lead-notes">Notes</label>
              <input id="lead-notes" name="notes" placeholder="How they found us, what they want" />
            </div>
          </div>
          <button className="cta gold" style={{ marginTop: 16 }}>
            Add lead
          </button>
        </form>
      </div>
    </div>
  );
}

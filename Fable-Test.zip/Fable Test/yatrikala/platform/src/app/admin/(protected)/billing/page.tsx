import type { CSSProperties } from "react";
import type { Metadata } from "next";
import { desc, eq, inArray } from "drizzle-orm";
import { db, tables } from "@/db";
import { requireAdmin } from "@/lib/auth";
import { createInvoice, createQuote, markInvoicePaid, markQuoteStatus } from "./actions";

export const metadata: Metadata = { title: "Billing" };
export const dynamic = "force-dynamic";

type LeadRow = typeof tables.leads.$inferSelect;
type QuoteRow = { q: typeof tables.quotes.$inferSelect; leadName: string | null };
type InvoiceRow = { inv: typeof tables.invoices.$inferSelect; tripLabel: string | null };

/** All reads wrapped: the desk renders (empty, with a note) before DATABASE_URL exists. */
async function loadDesk(): Promise<{
  ok: boolean;
  leads: LeadRow[];
  quotes: QuoteRow[];
  invoices: InvoiceRow[];
}> {
  try {
    const [leads, quotes, invoices] = await Promise.all([
      db
        .select()
        .from(tables.leads)
        .where(inArray(tables.leads.status, ["new", "brief", "quoted", "won"]))
        .orderBy(desc(tables.leads.createdAt)),
      db
        .select({ q: tables.quotes, leadName: tables.leads.name })
        .from(tables.quotes)
        .leftJoin(tables.leads, eq(tables.quotes.leadId, tables.leads.id))
        .orderBy(desc(tables.quotes.createdAt)),
      db
        .select({ inv: tables.invoices, tripLabel: tables.quotes.tripLabel })
        .from(tables.invoices)
        .leftJoin(tables.quotes, eq(tables.invoices.quoteId, tables.quotes.id))
        .orderBy(desc(tables.invoices.issuedAt)),
    ]);
    return { ok: true, leads, quotes, invoices };
  } catch {
    return { ok: false, leads: [], quotes: [], invoices: [] };
  }
}

const nfIN = new Intl.NumberFormat("en-IN");
const rupees = (n: number) => `₹${nfIN.format(n)}`;
const fmtDate = (d: Date | null | undefined) =>
  d ? d.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "2-digit" }) : "—";

const btnSm: CSSProperties = { padding: "5px 12px", fontSize: 12.5, borderRadius: 8 };
const GST_THRESHOLD = 2_000_000; // ₹20L services registration threshold

export default async function BillingPage() {
  await requireAdmin();
  const desk = await loadDesk();
  const { leads, quotes, invoices } = desk;

  // ---- KPIs -------------------------------------------------------------
  const now = new Date();
  const fyStartYear = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1;
  const fyStart = new Date(fyStartYear, 3, 1); // 1 April
  const fyLabel = `FY ${fyStartYear}-${String((fyStartYear + 1) % 100).padStart(2, "0")}`;

  const collected = invoices
    .filter((r) => r.inv.status === "paid" && r.inv.paidAt && r.inv.paidAt >= fyStart)
    .reduce((s, r) => s + r.inv.amountInr, 0);
  const outstanding = invoices
    .filter((r) => r.inv.status === "created")
    .reduce((s, r) => s + r.inv.amountInr, 0);
  const gstPct = Math.round((collected / GST_THRESHOLD) * 1000) / 10;
  const gstHot = gstPct > 70;

  // Which quotes already have which invoice kinds (drives button states).
  const kindsByQuote = new Map<string, Set<string>>();
  for (const r of invoices) {
    const set = kindsByQuote.get(r.inv.quoteId) ?? new Set<string>();
    set.add(r.inv.kind);
    kindsByQuote.set(r.inv.quoteId, set);
  }

  return (
    <div className="wrap" style={{ padding: "26px 20px 70px" }}>
      <h1 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 30 }}>
        The money desk
      </h1>
      <p className="subnote">
        Quote → invoice → payment link → paid. Whole rupees, {fyLabel}.
      </p>

      {!desk.ok && (
        <p className="tipbox" style={{ margin: "10px 0 4px" }}>
          Database not connected yet — set DATABASE_URL and this desk lights up. Nothing is
          broken; there is simply nothing to show.
        </p>
      )}

      {/* ---- (d) KPI header ---- */}
      <div className="kpis" style={{ marginTop: 16 }}>
        <div className="kpi">
          <b>Collected this FY</b>
          <div className="v num">{rupees(collected)}</div>
          <small>paid invoices since 1 Apr {fyStartYear}</small>
        </div>
        <div className="kpi">
          <b>Outstanding</b>
          <div className="v num">{rupees(outstanding)}</div>
          <small>invoices raised, not yet paid</small>
        </div>
        <div className="kpi">
          <b>GST radar</b>
          <div className="v num" style={gstHot ? { color: "var(--terracotta)" } : undefined}>
            {gstPct}%
          </div>
          <small style={gstHot ? { color: "var(--terracotta)" } : undefined}>
            {gstHot
              ? `of the ₹20L threshold — time to talk GST registration`
              : `of the ₹20L services registration threshold`}
          </small>
        </div>
      </div>

      {/* ---- (a) Create quote ---- */}
      <h2 className="h-sec">Create quote</h2>
      <p className="subnote">Design-fee quote against a live lead. It lands as a draft.</p>
      <div className="card">
        {leads.length === 0 ? (
          <p className="fine">
            No open leads (new / brief / quoted / won) to quote against
            {desk.ok ? " yet — capture one from the Journey Designer first." : "."}
          </p>
        ) : (
          <form action={createQuote}>
            <div className="formrow">
              <div>
                <label className="lbl" htmlFor="bq-lead" style={{ marginTop: 0 }}>
                  Lead
                </label>
                <select id="bq-lead" name="leadId" required defaultValue="">
                  <option value="" disabled>
                    Pick a lead…
                  </option>
                  {leads.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name} · {l.status}
                      {l.destination ? ` · ${l.destination}` : ""}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="lbl" htmlFor="bq-label" style={{ marginTop: 0 }}>
                  Trip label
                </label>
                <input
                  id="bq-label"
                  name="tripLabel"
                  required
                  placeholder="Japan — 8n honeymoon"
                  maxLength={120}
                />
              </div>
              <div>
                <label className="lbl" htmlFor="bq-amount" style={{ marginTop: 0 }}>
                  Amount (₹)
                </label>
                <input
                  id="bq-amount"
                  name="amountInr"
                  type="number"
                  required
                  min={1}
                  step={1}
                  placeholder="15000"
                />
              </div>
            </div>
            <button className="cta" style={{ marginTop: 14, padding: "11px 22px" }}>
              Create draft quote
            </button>
          </form>
        )}
      </div>

      {/* ---- (b) Quotes ---- */}
      <h2 className="h-sec">Quotes</h2>
      <p className="subnote">
        Advance = half up front (rounded up); balance follows once the advance exists.
      </p>
      <div className="tbl-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>Created</th>
              <th>Lead</th>
              <th>Trip</th>
              <th style={{ textAlign: "right" }}>Amount</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {quotes.length === 0 ? (
              <tr>
                <td colSpan={6} className="fine" style={{ textAlign: "center", padding: 18 }}>
                  No quotes yet — create the first one above.
                </td>
              </tr>
            ) : (
              quotes.map(({ q, leadName }) => {
                const kinds = kindsByQuote.get(q.id) ?? new Set<string>();
                const hasAdvance = kinds.has("advance");
                const hasBalance = kinds.has("balance");
                return (
                  <tr key={q.id}>
                    <td className="num">{fmtDate(q.createdAt)}</td>
                    <td>{leadName ?? "—"}</td>
                    <td>{q.tripLabel}</td>
                    <td className="num" style={{ textAlign: "right" }}>
                      {rupees(q.amountInr)}
                    </td>
                    <td>
                      <span className={`status ${q.status}`}>{q.status}</span>
                    </td>
                    <td>
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        {q.status === "draft" && (
                          <form action={markQuoteStatus}>
                            <input type="hidden" name="quoteId" value={q.id} />
                            <input type="hidden" name="status" value="sent" />
                            <button className="btn-ghost" style={btnSm}>
                              Mark sent
                            </button>
                          </form>
                        )}
                        {q.status === "sent" && (
                          <form action={markQuoteStatus}>
                            <input type="hidden" name="quoteId" value={q.id} />
                            <input type="hidden" name="status" value="accepted" />
                            <button className="btn-ghost" style={btnSm}>
                              Mark accepted
                            </button>
                          </form>
                        )}
                        <form action={createInvoice}>
                          <input type="hidden" name="quoteId" value={q.id} />
                          <input type="hidden" name="kind" value="advance" />
                          <button
                            className="btn-ghost"
                            style={btnSm}
                            disabled={hasAdvance}
                            title={
                              hasAdvance
                                ? "Advance invoice already raised"
                                : `Advance ${rupees(Math.ceil(q.amountInr / 2))}`
                            }
                          >
                            Advance invoice
                          </button>
                        </form>
                        <form action={createInvoice}>
                          <input type="hidden" name="quoteId" value={q.id} />
                          <input type="hidden" name="kind" value="balance" />
                          <button
                            className="btn-ghost"
                            style={btnSm}
                            disabled={!hasAdvance || hasBalance}
                            title={
                              !hasAdvance
                                ? "Raise the advance first"
                                : hasBalance
                                  ? "Balance invoice already raised"
                                  : `Balance ${rupees(q.amountInr - Math.ceil(q.amountInr / 2))}`
                            }
                          >
                            Balance invoice
                          </button>
                        </form>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* ---- (c) Invoices ---- */}
      <h2 className="h-sec">Invoices</h2>
      <p className="subnote">
        Razorpay links collect themselves via webhook; UPI-direct payments get Mark paid.
      </p>
      <div className="tbl-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>Number</th>
              <th>Trip</th>
              <th>Kind</th>
              <th style={{ textAlign: "right" }}>Amount</th>
              <th>Status</th>
              <th>Payment link</th>
              <th>Issued</th>
              <th>Paid</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {invoices.length === 0 ? (
              <tr>
                <td colSpan={9} className="fine" style={{ textAlign: "center", padding: 18 }}>
                  No invoices yet — they appear here the moment you raise one from a quote.
                </td>
              </tr>
            ) : (
              invoices.map(({ inv, tripLabel }) => (
                <tr key={inv.id}>
                  <td className="num">{inv.number}</td>
                  <td>{tripLabel ?? "—"}</td>
                  <td>
                    <span className="pip">{inv.kind}</span>
                  </td>
                  <td className="num" style={{ textAlign: "right" }}>
                    {rupees(inv.amountInr)}
                  </td>
                  <td>
                    <span className={`status ${inv.status}`}>{inv.status}</span>
                  </td>
                  <td style={{ maxWidth: 190 }}>
                    {inv.shortUrl ? (
                      <a
                        href={inv.shortUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="num"
                        style={{ fontSize: 12, color: "var(--ink)", wordBreak: "break-all", whiteSpace: "normal" }}
                        title="Open, or right-click to copy this Razorpay payment link"
                      >
                        {inv.shortUrl}
                      </a>
                    ) : (
                      <span className="fine">manual collection</span>
                    )}
                  </td>
                  <td className="num">{fmtDate(inv.issuedAt)}</td>
                  <td className="num">{fmtDate(inv.paidAt)}</td>
                  <td>
                    {inv.status === "created" && (
                      <form action={markInvoicePaid}>
                        <input type="hidden" name="invoiceId" value={inv.id} />
                        <button
                          className="btn-ghost"
                          style={btnSm}
                          title="Settles the invoice and records a manual payment"
                        >
                          Mark paid
                        </button>
                      </form>
                    )}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      <p className="fine" style={{ marginTop: 14 }}>
        Invoice numbers run YTK-{String(fyStartYear).slice(2)}
        {String((fyStartYear + 1) % 100).padStart(2, "0")}-#### in sequence. Mark paid is for
        money that arrived outside Razorpay (UPI-direct) — it records a manual payment entry.
      </p>
    </div>
  );
}

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { db, tables } from "@/db";
import { eq } from "drizzle-orm";
import { getAdmin } from "@/lib/auth";
import { invalidatePacksCache } from "@/content/loadPacks";

type Destination = typeof tables.destinations.$inferSelect;

const errTo = (msg: string) => `/admin/content?error=${encodeURIComponent(msg)}`;

const fmtStamp = (d: Date) =>
  new Intl.DateTimeFormat("en-IN", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);

function daysCount(pack: unknown): number {
  if (pack && typeof pack === "object" && Array.isArray((pack as { days?: unknown }).days)) {
    return (pack as { days: unknown[] }).days.length;
  }
  return 0;
}

async function toggleActive(id: string, next: boolean): Promise<void> {
  "use server";
  if (!(await getAdmin())) redirect("/admin/login");
  try {
    await db
      .update(tables.destinations)
      .set({ active: next, updatedAt: new Date() })
      .where(eq(tables.destinations.id, id));
  } catch {
    redirect(errTo("Could not reach the database — check DATABASE_URL and try again."));
  }
  invalidatePacksCache();
  revalidatePath("/admin/content");
}

async function savePack(id: string, formData: FormData): Promise<void> {
  "use server";
  if (!(await getAdmin())) redirect("/admin/login");
  const raw = String(formData.get("pack") ?? "");
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    redirect(errTo(`"${id}": that isn't valid JSON — nothing was saved.`));
  }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    redirect(errTo(`"${id}": a pack must be a JSON object, not a value or array.`));
  }
  try {
    await db
      .update(tables.destinations)
      .set({ pack: parsed, updatedAt: new Date() })
      .where(eq(tables.destinations.id, id));
  } catch {
    redirect(errTo("Could not reach the database — check DATABASE_URL and try again."));
  }
  invalidatePacksCache();
  revalidatePath("/admin/content");
  redirect(`/admin/content?saved=${encodeURIComponent(id)}`);
}

async function createDestination(formData: FormData): Promise<void> {
  "use server";
  if (!(await getAdmin())) redirect("/admin/login");
  const id = String(formData.get("id") ?? "").trim().toLowerCase();
  const name = String(formData.get("name") ?? "").trim();
  const raw = String(formData.get("pack") ?? "");
  if (!/^[a-z0-9-]+$/.test(id)) {
    redirect(errTo("New destination id must be a lowercase slug (a–z, 0–9, hyphens)."));
  }
  if (!name) {
    redirect(errTo("New destination needs a display name."));
  }
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    redirect(errTo(`"${id}": the pack isn't valid JSON — nothing was saved.`));
  }
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    redirect(errTo(`"${id}": a pack must be a JSON object, not a value or array.`));
  }
  try {
    await db.insert(tables.destinations).values({ id, name, pack: parsed, active: true });
  } catch {
    redirect(
      errTo(`Could not save "${id}" — is that id already taken, or is the database unreachable?`),
    );
  }
  invalidatePacksCache();
  revalidatePath("/admin/content");
  redirect(`/admin/content?saved=${encodeURIComponent(id)}`);
}

export default async function ContentPage(props: {
  searchParams: Promise<{ error?: string; saved?: string }>;
}) {
  const sp = await props.searchParams;

  let dbOk = true;
  let rows: Destination[] = [];
  try {
    rows = await db.select().from(tables.destinations).orderBy(tables.destinations.name);
  } catch {
    dbOk = false;
  }

  return (
    <div className="rise">
      <h1 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 26 }}>
        Destination packs
      </h1>
      <p className="subnote">
        The engine&apos;s fuel. Edits go live immediately — saving re-validates the JSON and clears
        the pack cache, no deploy needed.
      </p>

      {sp.error && (
        <p
          className="card-flat"
          style={{ borderColor: "#E2B4A0", color: "var(--bad)", marginBottom: 14, fontSize: 13.5 }}
        >
          {sp.error}
        </p>
      )}
      {sp.saved && (
        <p className="tipbox" style={{ marginBottom: 14 }}>
          Saved &ldquo;{sp.saved}&rdquo; — pack cache invalidated, the live site picks it up on the
          next page view.
        </p>
      )}
      {!dbOk && (
        <p className="tipbox" style={{ marginBottom: 14 }}>
          Database not connected — the site is serving the bundled seed packs from packs.json.
          Point DATABASE_URL at Supabase and run the seed to manage packs here.
        </p>
      )}
      {dbOk && rows.length === 0 && (
        <p className="tipbox" style={{ marginBottom: 14 }}>
          No destinations in the database yet — run <code>npm run db:seed</code> to load the
          bundled packs, or add one below.
        </p>
      )}

      <div className="tbl-wrap">
        <table className="tbl">
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
              <th>Days authored</th>
              <th>Visibility</th>
              <th>Updated</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={5} className="fine">
                  Nothing to show yet.
                </td>
              </tr>
            ) : (
              rows.map((d) => (
                <tr key={d.id}>
                  <td className="num">{d.id}</td>
                  <td style={{ color: "var(--ink)" }}>{d.name}</td>
                  <td className="num">{daysCount(d.pack)}</td>
                  <td>
                    <form action={toggleActive.bind(null, d.id, !d.active)}>
                      <button
                        className={`status ${d.active ? "won" : "cold"}`}
                        title={d.active ? "Click to hide from the site" : "Click to publish"}
                      >
                        {d.active ? "active" : "hidden"}
                      </button>
                    </form>
                  </td>
                  <td className="num">{fmtStamp(d.updatedAt)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {rows.length > 0 && (
        <>
          <h2 className="h-sec">Edit a pack</h2>
          <p className="subnote">
            Open a destination, edit the JSON, save. Invalid JSON is rejected outright — the live
            pack is never half-written.
          </p>
          {rows.map((d) => (
            <details
              key={d.id}
              className="card"
              style={{ marginBottom: 10, padding: 0, overflow: "hidden" }}
            >
              <summary style={{ padding: "14px 18px", cursor: "pointer", listStyle: "none" }}>
                <span className="serif" style={{ color: "var(--ink)", fontSize: 16 }}>
                  {d.name}
                </span>{" "}
                <span className="fine">
                  ({d.id}) · {daysCount(d.pack)} authored days · {d.active ? "active" : "hidden"}
                </span>
              </summary>
              <form action={savePack.bind(null, d.id)} style={{ padding: "0 18px 18px" }}>
                <textarea
                  name="pack"
                  rows={20}
                  defaultValue={JSON.stringify(d.pack, null, 2)}
                  spellCheck={false}
                  style={{
                    fontFamily: "ui-monospace, SFMono-Regular, Consolas, monospace",
                    fontSize: 12.5,
                    lineHeight: 1.5,
                    background: "var(--sheet)",
                  }}
                />
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginTop: 10 }}>
                  <button className="cta" style={{ padding: "10px 20px", fontSize: 14 }}>
                    Save pack
                  </button>
                  <span className="fine">
                    Saving validates the JSON and refreshes the live cache.
                  </span>
                </div>
              </form>
            </details>
          ))}
        </>
      )}

      <h2 className="h-sec">Add a destination</h2>
      <p className="subnote">
        Paste a full pack JSON (same shape as the existing ones). It goes live as active.
      </p>
      <div className="card">
        <form action={createDestination}>
          <div className="formrow">
            <div>
              <label className="lbl" htmlFor="dest-id">Id (slug)</label>
              <input id="dest-id" name="id" required placeholder="portugal" pattern="[a-z0-9-]+" />
            </div>
            <div>
              <label className="lbl" htmlFor="dest-name">Name</label>
              <input id="dest-name" name="name" required placeholder="Portugal (Lisbon & Porto)" />
            </div>
          </div>
          <label className="lbl" htmlFor="dest-pack">Pack JSON</label>
          <textarea
            id="dest-pack"
            name="pack"
            required
            rows={10}
            spellCheck={false}
            placeholder='{"id": "portugal", "name": "Portugal (Lisbon & Porto)", "flag": "🇵🇹", "tagline": "…", "bestMonths": [4,5,9,10], "days": [ … ] }'
            style={{
              fontFamily: "ui-monospace, SFMono-Regular, Consolas, monospace",
              fontSize: 12.5,
              lineHeight: 1.5,
            }}
          />
          <button className="cta gold" style={{ marginTop: 14 }}>
            Add destination
          </button>
        </form>
      </div>
    </div>
  );
}

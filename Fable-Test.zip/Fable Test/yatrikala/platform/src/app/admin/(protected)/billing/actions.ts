"use server";

import { revalidatePath } from "next/cache";
import { and, count, eq } from "drizzle-orm";
import { db, tables } from "@/db";
import { getAdmin } from "@/lib/auth";
import { createPaymentLink, invoiceNumber, razorpayConfigured } from "@/lib/razorpay";

/** Every money action goes through this gate. */
async function assertAdmin() {
  const admin = await getAdmin();
  if (!admin) throw new Error("Not authorised — admin sign-in required.");
  return admin;
}

/** (a) Create a draft quote against a lead. */
export async function createQuote(formData: FormData) {
  await assertAdmin();
  const leadId = String(formData.get("leadId") ?? "").trim();
  const tripLabel = String(formData.get("tripLabel") ?? "").trim();
  const amountInr = Math.round(Number(formData.get("amountInr")));
  if (!leadId || !tripLabel || !Number.isFinite(amountInr) || amountInr <= 0) {
    throw new Error("A quote needs a lead, a trip label and a positive ₹ amount.");
  }
  await db.insert(tables.quotes).values({ leadId, tripLabel, amountInr, status: "draft" });
  revalidatePath("/admin/billing");
}

/** (b) Move a quote to 'sent' or 'accepted'. */
export async function markQuoteStatus(formData: FormData) {
  await assertAdmin();
  const quoteId = String(formData.get("quoteId") ?? "").trim();
  const status = String(formData.get("status") ?? "").trim();
  if (!quoteId || (status !== "sent" && status !== "accepted")) {
    throw new Error("Quotes can only be marked sent or accepted here.");
  }
  await db.update(tables.quotes).set({ status }).where(eq(tables.quotes.id, quoteId));
  revalidatePath("/admin/billing");
}

/**
 * (b) Raise an invoice from a quote.
 * advance = ceil(amount/2); balance = amount − advance (only after an advance exists).
 * Number = count+1 through invoiceNumber(). Razorpay link when keys are set,
 * otherwise a plain invoice row for manual (UPI-direct) collection.
 */
export async function createInvoice(formData: FormData) {
  await assertAdmin();
  const quoteId = String(formData.get("quoteId") ?? "").trim();
  const kind = String(formData.get("kind") ?? "").trim();
  if (!quoteId || (kind !== "advance" && kind !== "balance")) {
    throw new Error("Invoices come in two kinds: advance or balance.");
  }

  const [row] = await db
    .select({ q: tables.quotes, lead: tables.leads })
    .from(tables.quotes)
    .leftJoin(tables.leads, eq(tables.quotes.leadId, tables.leads.id))
    .where(eq(tables.quotes.id, quoteId))
    .limit(1);
  if (!row) throw new Error("Quote not found.");

  const advance = Math.ceil(row.q.amountInr / 2);
  let amountInr = advance;
  if (kind === "balance") {
    const [adv] = await db
      .select({ id: tables.invoices.id })
      .from(tables.invoices)
      .where(and(eq(tables.invoices.quoteId, quoteId), eq(tables.invoices.kind, "advance")))
      .limit(1);
    if (!adv) throw new Error("Raise the advance invoice first — the balance follows it.");
    amountInr = row.q.amountInr - advance;
  }
  if (amountInr <= 0) throw new Error("Nothing left to invoice on this quote.");

  // Allocate the number and insert FIRST, then attach the payment link. This order
  // (a) makes the unique index the arbiter of numbering races — a concurrent 23505
  // just renumbers and retries — and (b) guarantees the Razorpay reference_id always
  // matches a row that already exists when the webhook comes back.
  let invoiceId: string | null = null;
  let number = "";
  for (let attempt = 0; attempt < 5 && !invoiceId; attempt++) {
    const [{ n }] = await db.select({ n: count() }).from(tables.invoices);
    number = invoiceNumber(Number(n) + 1 + attempt);
    try {
      const [ins] = await db
        .insert(tables.invoices)
        .values({ quoteId, number, kind, amountInr, status: "created" })
        .returning({ id: tables.invoices.id });
      invoiceId = ins.id;
    } catch (e) {
      if ((e as { code?: string })?.code !== "23505") throw e; // only absorb duplicate-number races
    }
  }
  if (!invoiceId) throw new Error("Could not allocate an invoice number — please retry.");

  if (razorpayConfigured()) {
    try {
      const link = await createPaymentLink({
        amountInr,
        description: `${row.q.tripLabel} — ${kind}`,
        reference: number,
        customer: row.lead
          ? {
              name: row.lead.name,
              contact: row.lead.phone ?? undefined,
              email: row.lead.email ?? undefined,
            }
          : undefined,
      });
      await db
        .update(tables.invoices)
        .set({ razorpayLinkId: link.id, shortUrl: link.shortUrl })
        .where(eq(tables.invoices.id, invoiceId));
    } catch {
      // Razorpay hiccup — the invoice stands; collect manually and use Mark paid.
    }
  }
  revalidatePath("/admin/billing");
}

/** (c) Manual settle — for UPI-direct payments outside Razorpay. Idempotent. */
export async function markInvoicePaid(formData: FormData) {
  await assertAdmin();
  const invoiceId = String(formData.get("invoiceId") ?? "").trim();
  if (!invoiceId) throw new Error("Missing invoice.");

  const [inv] = await db
    .select()
    .from(tables.invoices)
    .where(eq(tables.invoices.id, invoiceId))
    .limit(1);
  if (!inv) throw new Error("Invoice not found.");
  if (inv.status === "paid") return; // already settled — nothing to do

  await db
    .update(tables.invoices)
    .set({ status: "paid", paidAt: new Date() })
    .where(eq(tables.invoices.id, invoiceId));
  await db.insert(tables.payments).values({
    invoiceId: inv.id,
    amountInr: inv.amountInr,
    method: "manual",
  });
  revalidatePath("/admin/billing");
}

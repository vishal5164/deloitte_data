import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Studio",
};

/**
 * Pass-through shell for everything under /admin.
 * The auth gate + admin nav live in the (protected) route-group layout, so that
 * /admin/login (which sits outside the group) is never wrapped by requireAdmin().
 */
export default function AdminShell({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

import TopNav from "@/components/TopNav";

/** Branded skeleton while the Deals radar gathers price observations. */
export default function Loading() {
  return (
    <>
      <TopNav active="/deals" />
      <main className="wrap" style={{ padding: "56px 20px 80px" }}>
        <div className="routeline" style={{ margin: "0 auto 14px" }}>
          <div className="rl-dot" />
          <div className="rl-dash" />
          <span className="rl-star">✦</span>
        </div>
        <p className="fine" style={{ textAlign: "center", marginBottom: 22 }}>
          Scanning the fare radar…
        </p>
        <div className="card" style={{ maxWidth: 560, margin: "0 auto", display: "grid", gap: 14 }}>
          <div className="skeleton" style={{ width: "58%" }} />
          <div className="skeleton" />
          <div className="skeleton" style={{ width: "82%" }} />
        </div>
      </main>
    </>
  );
}

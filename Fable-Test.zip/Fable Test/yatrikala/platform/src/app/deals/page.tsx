import type { Metadata } from "next";
import Link from "next/link";
import TopNav from "@/components/TopNav";
import { db, tables } from "@/db";
import { desc, gte } from "drizzle-orm";
import { loadPacks } from "@/content/loadPacks";
import { DEST_GATEWAYS, ORIGINS } from "@/lib/prices";

export const revalidate = 3600;

export const metadata: Metadata = {
  title: "Deals radar — real observed flight & hotel prices",
  description:
    "Round-trip fares from Delhi, Mumbai and Bengaluru and hotel nightly medians, observed and timestamped — the real numbers under every Yatrikala design.",
};

/* ---------- types & small helpers (local to this page) ---------- */

type Snap = typeof tables.priceSnapshots.$inferSelect;

interface FlightMeta {
  airline?: string;
  departAt?: string;
  returnAt?: string;
  transfers?: number;
  deepLink?: string;
}

interface HotelMeta {
  city?: string;
  sampleSize?: number;
  starsMin?: number;
  starsMax?: number;
}

interface FlightCard {
  destCode: string;
  name: string;
  flag: string;
  price: number;
  min30: number;
  avg30: number;
  obs: number;
  meta: FlightMeta;
  source: string;
  foundAt: Date;
}

interface HotelRow {
  destCode: string;
  city: string;
  flag: string | null;
  median: number;
  meta: HotelMeta;
  source: string;
  foundAt: Date;
}

const DAY = 86_400_000;
const ORIGIN_LABELS: Record<string, string> = { DEL: "Delhi", BOM: "Mumbai", BLR: "Bengaluru" };

const slugify = (city: string) => city.toLowerCase().replace(/\s+/g, "-");
const shortName = (n: string) => n.split(" (")[0];
const fmtINR = (n: number) => "₹" + Math.round(n).toLocaleString("en-IN");
const compactINR = (n: number) =>
  n >= 1000 ? `₹${(n / 1000).toFixed(1).replace(/\.0$/, "")}k` : `₹${Math.round(n)}`;

const stampFmt = new Intl.DateTimeFormat("en-IN", {
  day: "numeric", month: "short", hour: "numeric", minute: "2-digit", timeZone: "Asia/Kolkata",
});
const dateFmt = new Intl.DateTimeFormat("en-IN", {
  day: "numeric", month: "short", timeZone: "Asia/Kolkata",
});
const fmtStamp = (d: Date) => `${stampFmt.format(d)} IST`;
const fmtDateOnly = (d: Date) => dateFmt.format(d);
function fmtDay(iso?: string): string | null {
  if (!iso) return null;
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? null : dateFmt.format(d);
}

function metaLine(m: FlightMeta): string {
  const parts: string[] = [];
  if (m.airline) parts.push(m.airline);
  const dep = fmtDay(m.departAt);
  const ret = fmtDay(m.returnAt);
  if (dep && ret) parts.push(`${dep} → ${ret}`);
  else if (dep) parts.push(dep);
  if (typeof m.transfers === "number") {
    parts.push(m.transfers === 0 ? "non-stop" : `${m.transfers} stop${m.transfers > 1 ? "s" : ""}`);
  }
  return parts.join(" · ");
}

function trendBadge(c: FlightCard): { text: string; color?: string; border?: string } {
  if (c.obs < 2) return { text: "first observation on this route" };
  const delta = Math.round(c.avg30 - c.price);
  if (delta >= 300)
    return { text: `${compactINR(delta)} below 30-day avg`, color: "var(--good)", border: "#9FCDA8" };
  if (delta <= -300)
    return { text: `${compactINR(-delta)} above 30-day avg`, color: "var(--terracotta)", border: "#E2B4A0" };
  return { text: "in line with 30-day avg" };
}

function starsSpread(m: HotelMeta): string {
  if (typeof m.starsMin !== "number" || typeof m.starsMax !== "number") return "—";
  return m.starsMin === m.starsMax ? `${m.starsMin}★` : `${m.starsMin}–${m.starsMax}★`;
}

/* ---------- page ---------- */

export default async function DealsPage({
  searchParams,
}: {
  searchParams: Promise<{ from?: string | string[] }>;
}) {
  const sp = await searchParams;
  const rawFrom = Array.isArray(sp.from) ? sp.from[0] : sp.from;
  const from = (ORIGINS as readonly string[]).includes(rawFrom ?? "") ? (rawFrom as string) : "DEL";

  // One 30-day window fetch; latest-per-route and min/avg computed here.
  // Wrapped so a missing DATABASE_URL degrades to the friendly empty state.
  let rows: Snap[] = [];
  let dbDown = false;
  try {
    const since = new Date(Date.now() - 30 * DAY);
    rows = await db
      .select()
      .from(tables.priceSnapshots)
      .where(gte(tables.priceSnapshots.foundAt, since))
      .orderBy(desc(tables.priceSnapshots.foundAt))
      .limit(6000);
  } catch {
    dbDown = true;
  }

  const packs = await loadPacks();
  const packById = new Map(packs.map((p) => [p.id, p]));
  const iataToPackId = new Map<string, string>();
  const citySlugToPackId = new Map<string, string>();
  for (const [pid, gw] of Object.entries(DEST_GATEWAYS)) {
    iataToPackId.set(gw.iata, pid);
    citySlugToPackId.set(slugify(gw.city), pid);
  }

  const now = Date.now();

  // Flights for the selected origin: latest snapshot per destCode (≤7 days old),
  // 30-day min/avg over every observation on that route.
  const flightsByDest = new Map<string, Snap[]>();
  for (const r of rows) {
    if (r.kind !== "flight" || r.origin !== from) continue;
    const arr = flightsByDest.get(r.destCode);
    if (arr) arr.push(r);
    else flightsByDest.set(r.destCode, [r]);
  }
  const flightCards: FlightCard[] = [];
  for (const [destCode, arr] of flightsByDest) {
    const latest = arr[0]; // rows are ordered foundAt desc
    if (now - latest.foundAt.getTime() > 7 * DAY) continue;
    const prices = arr.map((s) => s.priceInr);
    const pid = iataToPackId.get(destCode);
    const pack = pid ? packById.get(pid) : undefined;
    flightCards.push({
      destCode,
      name: pack ? shortName(pack.name) : destCode,
      flag: pack?.flag ?? "✈️",
      price: latest.priceInr,
      min30: Math.min(...prices),
      avg30: prices.reduce((s, n) => s + n, 0) / prices.length,
      obs: prices.length,
      meta: (latest.meta ?? {}) as FlightMeta,
      source: latest.source,
      foundAt: latest.foundAt,
    });
  }
  flightCards.sort((a, b) => a.price - b.price);

  // Hotels: latest snapshot per city slug (≤7 days old).
  const hotelsByCity = new Map<string, Snap[]>();
  for (const r of rows) {
    if (r.kind !== "hotel") continue;
    const arr = hotelsByCity.get(r.destCode);
    if (arr) arr.push(r);
    else hotelsByCity.set(r.destCode, [r]);
  }
  const hotelRows: HotelRow[] = [];
  for (const [destCode, arr] of hotelsByCity) {
    const latest = arr[0];
    if (now - latest.foundAt.getTime() > 7 * DAY) continue;
    const meta = (latest.meta ?? {}) as HotelMeta;
    const pid = citySlugToPackId.get(destCode);
    const pack = pid ? packById.get(pid) : undefined;
    hotelRows.push({
      destCode,
      city: meta.city ?? (pid ? DEST_GATEWAYS[pid].city : destCode),
      flag: pack?.flag ?? null,
      median: latest.priceInr,
      meta,
      source: latest.source,
      foundAt: latest.foundAt,
    });
  }
  hotelRows.sort((a, b) => a.city.localeCompare(b.city));

  const radarEmpty = rows.length === 0;

  return (
    <>
      <TopNav active="/deals" />
      <main className="wrap" style={{ padding: "28px 20px 64px" }}>
        <h1 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 30 }}>
          Deals radar
        </h1>
        <p className="subnote" style={{ marginTop: 4, maxWidth: 640 }}>
          Real observed fares and hotel medians, so every Yatrikala quote rests on real numbers —
          not brochure guesses. Refreshed on a schedule from cached market data.
        </p>

        {radarEmpty ? (
          <div className="card" style={{ textAlign: "center", padding: "44px 24px", marginTop: 22 }}>
            <div style={{ fontSize: 34, marginBottom: 8 }}>📡</div>
            <h2 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 22, marginBottom: 8 }}>
              The radar is warming up
            </h2>
            <p style={{ maxWidth: 540, margin: "0 auto 14px" }}>
              {dbDown
                ? "The price database isn't reachable yet — once Supabase is configured, observed fares from Delhi, Mumbai and Bengaluru plus hotel nightly medians appear right here."
                : "No price observations yet. The radar fills itself after the first refresh — cheapest observed round trips from Delhi, Mumbai and Bengaluru, plus hotel nightly medians for every destination we design."}
            </p>
            <p className="fine" style={{ maxWidth: 540, margin: "0 auto" }}>
              Admin: set <code>TRAVELPAYOUTS_TOKEN</code> in the environment, then call{" "}
              <code>/api/deals/refresh</code> (or wait for the scheduled cron) and this page lights up.
            </p>
          </div>
        ) : (
          <>
            <h2 className="h-sec">Round-trip flight radar</h2>
            <p className="subnote" style={{ maxWidth: 640 }}>
              Observed market fares from cached search data — not live availability. Each card
              carries its source and observed-at time. Verify before quoting.
            </p>

            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 18 }}>
              {ORIGINS.map((o) => (
                <Link
                  key={o}
                  href={`/deals?from=${o}`}
                  className={`chip${o === from ? " sel" : ""}`}
                  style={{ textDecoration: "none" }}
                >
                  {o} · {ORIGIN_LABELS[o]}
                </Link>
              ))}
            </div>

            {flightCards.length === 0 ? (
              <div className="card-flat">
                No fares observed from {ORIGIN_LABELS[from]} in the last 7 days — try another
                origin above, or trigger a refresh from the admin console.
              </div>
            ) : (
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
                  gap: 14,
                }}
              >
                {flightCards.map((c) => {
                  const t = trendBadge(c);
                  const line = metaLine(c.meta);
                  return (
                    <article key={c.destCode} className="card rise">
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", gap: 8 }}>
                        <div className="serif" style={{ color: "var(--ink)", fontSize: 16.5 }}>
                          {c.flag} {c.name}
                        </div>
                        <span className="pip num">{from} ⇄ {c.destCode}</span>
                      </div>
                      <div className="serif num" style={{ fontSize: 32, color: "var(--ink)", margin: "10px 0 2px" }}>
                        {fmtINR(c.price)}
                      </div>
                      <div className="fine" style={{ marginBottom: 8 }}>
                        round trip pp{line ? ` · ${line}` : ""}
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
                        <span
                          className="pip"
                          style={t.color ? { color: t.color, borderColor: t.border } : undefined}
                        >
                          {t.text}
                        </span>
                        <span className="fine num">30-day low {fmtINR(c.min30)}</span>
                      </div>
                      <div className="fine" style={{ marginBottom: c.meta.deepLink ? 10 : 0 }}>
                        {c.source} · observed {fmtStamp(c.foundAt)} · verify before quoting
                      </div>
                      {c.meta.deepLink && (
                        <a
                          className="btn-ghost"
                          href={c.meta.deepLink}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{ display: "inline-block", fontSize: 13, padding: "7px 14px" }}
                        >
                          Book scan →
                        </a>
                      )}
                    </article>
                  );
                })}
              </div>
            )}

            <h2 className="h-sec">Hotel nightly medians</h2>
            <p className="subnote" style={{ maxWidth: 640 }}>
              Median of the sampled properties per city — indicative, observed on the date shown.
              Your itinerary's actual stays are hand-picked, not medians.
            </p>

            {hotelRows.length === 0 ? (
              <div className="card-flat">
                Hotel medians appear after the next price refresh — flights arrived first this round.
              </div>
            ) : (
              <div className="tbl-wrap">
                <table className="tbl">
                  <thead>
                    <tr>
                      <th>City</th>
                      <th>Median ₹ / night</th>
                      <th>Stars spread</th>
                      <th>Observed</th>
                    </tr>
                  </thead>
                  <tbody>
                    {hotelRows.map((h) => (
                      <tr key={h.destCode}>
                        <td>
                          {h.flag ? `${h.flag} ` : ""}{h.city}
                          {typeof h.meta.sampleSize === "number" && (
                            <span className="fine"> · {h.meta.sampleSize} sampled</span>
                          )}
                        </td>
                        <td className="num" style={{ fontFamily: "Georgia, serif", color: "var(--ink)", fontSize: 15 }}>
                          {fmtINR(h.median)}
                        </td>
                        <td className="num">{starsSpread(h.meta)}</td>
                        <td className="num">
                          {fmtDateOnly(h.foundAt)} <span className="fine">· {h.source}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}

        <div className="card-flat" style={{ marginTop: 28 }}>
          <b style={{ color: "var(--ink)", fontSize: 13.5 }}>Where are attraction prices?</b>
          <p className="fine" style={{ marginTop: 4 }}>
            Curated experience prices — entry tickets, guided walks, cooking classes — live inside
            each destination pack and are indicative. Real-time attraction pricing needs a paid
            partner API (Viator); that's an upgrade for when volumes justify it, not a promise today.
          </p>
        </div>
      </main>
    </>
  );
}

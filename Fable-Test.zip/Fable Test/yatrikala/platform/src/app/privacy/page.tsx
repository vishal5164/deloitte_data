import type { Metadata } from "next";
import TopNav from "@/components/TopNav";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Privacy Policy",
  description:
    "What Yatrikala collects, why, where it lives, and how to see or delete it — in plain words, aligned with India's DPDP Act 2023.",
};

const EMAIL = "hello@yatrikala.com";

export default function PrivacyPage() {
  const wa = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "").replace(/\D/g, "");

  return (
    <>
      <TopNav />
      <main className="wrap-narrow" style={{ paddingBottom: 40 }}>
        <header style={{ padding: "36px 0 4px" }}>
          <h1 className="serif" style={{ color: "var(--ink)", fontSize: 30, fontWeight: 400 }}>
            Privacy Policy
          </h1>
          <p className="subnote" style={{ marginTop: 6 }}>
            Last updated: July 2026 · Written to align with India&apos;s Digital Personal Data
            Protection Act, 2023 — in plain words.
          </p>
        </header>

        <h2 className="h-sec">What we collect</h2>
        <p style={{ fontSize: 14.5 }}>
          Only what designing your trip needs: your name, your contact details (phone, WhatsApp,
          email), and the trip preferences you share with us — through the Journey Designer brief,
          the intake form, or a conversation. Who&apos;s travelling, when, your budget, what you
          love and what you&apos;d rather skip. Nothing is collected quietly in the background.
        </p>

        <h2 className="h-sec">Why we collect it</h2>
        <p style={{ fontSize: 14.5 }}>
          Three reasons, and only these: to design your itinerary, to send you a quote, and to send
          service messages about your trip on WhatsApp or email — draft ready, payment received,
          reservation reminder. We don&apos;t use your details for advertising, and we don&apos;t
          message you about trips you haven&apos;t asked us about.
        </p>

        <h2 className="h-sec">Where it lives</h2>
        <p style={{ fontSize: 14.5 }}>
          Your details are stored in Supabase, our database provider, on cloud infrastructure.
          Payments run through Razorpay — your card, UPI and bank details go directly to them and{" "}
          <b>we never see or store them</b>. Razorpay&apos;s own privacy policy governs what happens
          inside their checkout.
        </p>

        <h2 className="h-sec">What we never do</h2>
        <p style={{ fontSize: 14.5 }}>
          We do not sell your data. Not to advertisers, not to &ldquo;partners&rdquo;, not to
          anyone, at any price.
        </p>

        <h2 className="h-sec">Anonymised insights</h2>
        <p style={{ fontSize: 14.5 }}>
          Our &ldquo;Travellers like you&rdquo; feature shows aggregate patterns — where couples on
          a mid budget went last winter, say. These are built from anonymised, combined data with
          nothing that can identify you. Your name, contacts and individual trip never appear.
        </p>

        <h2 className="h-sec">How long we keep it</h2>
        <p style={{ fontSize: 14.5 }}>
          We keep your brief and contact details so returning to us for the next trip is easy. Ask
          us to delete your data and we will — see your rights below. Payment records are retained
          as long as Indian tax law requires.
        </p>

        <h2 className="h-sec">Your rights</h2>
        <p style={{ fontSize: 14.5 }}>
          Under the DPDP Act you can ask us what we hold about you, ask us to correct it, or ask us
          to erase it. No forms, no waiting period: message us{" "}
          {wa ? (
            <>
              on{" "}
              <a
                href={`https://wa.me/${wa}`}
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: "var(--terracotta)" }}
              >
                WhatsApp
              </a>{" "}
              or{" "}
            </>
          ) : null}
          at{" "}
          <a href={`mailto:${EMAIL}`} style={{ color: "var(--terracotta)" }}>
            {EMAIL}
          </a>{" "}
          and we&apos;ll act on it.
        </p>

        <h2 className="h-sec">Cookies</h2>
        <p style={{ fontSize: 14.5 }}>
          Essential only. The single cookie this site sets is an authentication session for our own
          admin area. No tracking cookies, no analytics cookies, no third-party pixels.
        </p>

        <h2 className="h-sec">Grievances</h2>
        <p style={{ fontSize: 14.5 }}>
          If you believe we&apos;ve handled your data wrongly, write to the grievance contact — the
          proprietor, Yatrikala, Pune, Maharashtra, India — at{" "}
          <a href={`mailto:${EMAIL}`} style={{ color: "var(--terracotta)" }}>
            {EMAIL}
          </a>
          . We aim to respond within 7 working days. If you&apos;re not satisfied with our
          response, you may escalate to the Data Protection Board of India.
        </p>
      </main>
      <Footer />
    </>
  );
}

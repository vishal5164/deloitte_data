import type { MetadataRoute } from "next";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export default function sitemap(): MetadataRoute.Sitemap {
  const lastModified = new Date();

  return [
    { url: `${SITE_URL}/`, lastModified, changeFrequency: "weekly", priority: 1 },
    { url: `${SITE_URL}/design`, lastModified, changeFrequency: "weekly", priority: 0.9 },
    { url: `${SITE_URL}/start`, lastModified, changeFrequency: "monthly", priority: 0.9 },
    { url: `${SITE_URL}/deals`, lastModified, changeFrequency: "daily", priority: 0.8 },
    { url: `${SITE_URL}/insights`, lastModified, changeFrequency: "weekly", priority: 0.7 },
    { url: `${SITE_URL}/terms`, lastModified, changeFrequency: "yearly", priority: 0.3 },
    { url: `${SITE_URL}/privacy`, lastModified, changeFrequency: "yearly", priority: 0.3 },
    { url: `${SITE_URL}/refunds`, lastModified, changeFrequency: "yearly", priority: 0.3 },
  ];
}

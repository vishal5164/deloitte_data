"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { BUDGET_BANDS, COMBOS, comboKey, MINI_IDS, MONTHS, scoreDestinations } from "@/engine";
import type { Brief, Combo, DestinationPack, Itinerary, Persona, TravelStyle } from "@/engine";
import ItineraryDoc, { PERSONA_PHRASE } from "@/components/ItineraryDoc";
import "./design.css";

/**
 * The Journey Designer flow, ported from apps/journey-designer.html:
 * hero → persona → mode → (pick | quiz → matches) → shape → theater → gated itinerary.
 * Pure-engine helpers (scoreDestinations, COMBOS) run client-side; generation
 * goes through POST /api/generate so drafts persist and Claude can refine them.
 */

type Step = "hero" | "persona" | "mode" | "pick" | "quiz" | "matches" | "shape" | "result";
type Pace = Brief["pace"];

interface GenerateResponse {
  itinerary: Itinerary;
  shareSlug: string;
  generator: string;
  /** false when the server couldn't store the draft — the share link would 404 */
  persisted?: boolean;
}

const PERSONA_DEFS: { id: Persona; label: string; sub: string; icon: React.ReactNode }[] = [
  {
    id: "couple",
    label: "Two of us",
    sub: "Honeymoon, anniversary, or just because.",
    icon: (
      <svg viewBox="0 0 48 48">
        <circle className="st" cx="19" cy="24" r="10" />
        <circle className="st" cx="29" cy="24" r="10" />
      </svg>
    ),
  },
  {
    id: "family",
    label: "With little ones",
    sub: "Nap-proof plans, stroller-smart days.",
    icon: (
      <svg viewBox="0 0 48 48">
        <circle className="st" cx="20" cy="20" r="9" />
        <circle className="st" cx="32" cy="29" r="6" />
        <path className="st" d="M 14 38 Q 24 32 38 38" />
      </svg>
    ),
  },
  {
    id: "seniors",
    label: "With parents",
    sub: "Gentle pace. Zero rushed mornings.",
    icon: (
      <svg viewBox="0 0 48 48">
        <path className="st" d="M 8 34 L 40 34" />
        <circle className="st" cx="24" cy="24" r="9" />
        <path className="st" d="M 24 8 L 24 12 M 38 13 L 35 16 M 10 13 L 13 16" />
      </svg>
    ),
  },
  {
    id: "friends",
    label: "The squad",
    sub: "Group thrills, late nights, split bills.",
    icon: (
      <svg viewBox="0 0 48 48">
        <circle className="st" cx="24" cy="16" r="7" />
        <circle className="st" cx="14" cy="31" r="7" />
        <circle className="st" cx="34" cy="31" r="7" />
      </svg>
    ),
  },
  {
    id: "solo",
    label: "Just me",
    sub: "Freedom, cafés, and long walks.",
    icon: (
      <svg viewBox="0 0 48 48">
        <path className="fl" d="M 24 8 L 27.5 20.5 L 40 24 L 27.5 27.5 L 24 40 L 20.5 27.5 L 8 24 L 20.5 20.5 Z" />
      </svg>
    ),
  },
];

const VIBES: [string, string][] = [
  ["beach", "🏖 Beach"],
  ["mountains", "🏔 Mountains"],
  ["cities", "🌆 Cities"],
  ["culture", "🏛 Culture"],
  ["food", "🍜 Food"],
  ["adventure", "🪂 Adventure"],
  ["wildlife", "🐘 Wildlife"],
  ["snow", "❄️ Snow"],
  ["shopping", "🛍 Shopping"],
  ["nightlife", "🌙 Nightlife"],
  ["wellness", "🧘 Wellness"],
];

const PACES: Pace[] = ["Gentle", "Balanced", "Full days"];

const STYLE_DEFS: { id: TravelStyle; icon: string; label: string; sub: string }[] = [
  { id: "Smart", icon: "💡", label: "Smart budget", sub: "Every rupee works. Guesthouses with soul, street feasts, insider saves." },
  { id: "Comfort", icon: "🛋️", label: "Comfort", sub: "3–4★ ease, the occasional treat. The sweet spot most journeys live in." },
  { id: "Luxe", icon: "✨", label: "Luxe", sub: "The rooms people screenshot. Named properties, seamless everything." },
];

/** Gradient "skies" + landmark glyphs per destination card (flag is the fallback). */
const SKIES: Record<string, string> = {
  vietnam: "linear-gradient(135deg,#1F6E5C,#7FBFA0)",
  japan: "linear-gradient(135deg,#2A3559,#C4718C)",
  bali: "linear-gradient(135deg,#1E7A5A,#E2C36B)",
  thailand: "linear-gradient(135deg,#0F7E8C,#F0A860)",
  srilanka: "linear-gradient(135deg,#2E7D4F,#C9A24B)",
  dubai: "linear-gradient(135deg,#B98A3E,#E8C98A)",
  singapore: "linear-gradient(135deg,#4A3E8C,#3FA9A0)",
  georgia: "linear-gradient(135deg,#6E2F45,#5A6B85)",
  kazakhstan: "linear-gradient(135deg,#3E5C76,#7FB6C9)",
  greece: "linear-gradient(135deg,#1F4E9C,#8FB8E8)",
  switzerland: "linear-gradient(135deg,#3C6E91,#BFDCE8)",
  italy: "linear-gradient(135deg,#A85A3C,#7A8C4F)",
  maldives: "linear-gradient(135deg,#0F8C9C,#7FE0D6)",
  cambodia: "linear-gradient(135deg,#6E4F2F,#C9A24B)",
  armenia: "linear-gradient(135deg,#8C3E4F,#C98A6B)",
  southkorea: "linear-gradient(135deg,#2E3A6E,#C4718C)",
  malaysia: "linear-gradient(135deg,#14705F,#E0B95A)",
  philippines: "linear-gradient(135deg,#0F7E8C,#7FD0C0)",
  mauritius: "linear-gradient(135deg,#0E7A72,#8FD8C8)",
  seychelles: "linear-gradient(135deg,#0F8C9C,#A0E8D8)",
  nepal: "linear-gradient(135deg,#35507A,#BFDCE8)",
  bhutan: "linear-gradient(135deg,#6E2F35,#D9A44D)",
  uzbekistan: "linear-gradient(135deg,#1F6E8C,#7FD0DD)",
  oman: "linear-gradient(135deg,#8C5E2F,#E0C08A)",
  egypt: "linear-gradient(135deg,#B9803E,#E8D0A0)",
  uk: "linear-gradient(135deg,#3E4759,#8CA0C0)",
  france: "linear-gradient(135deg,#34426E,#E8C98A)",
  spain: "linear-gradient(135deg,#A84A2F,#E2A13C)",
  australia: "linear-gradient(135deg,#B95E3C,#E8B98A)",
  newzealand: "linear-gradient(135deg,#2E6E4F,#8FD0A8)",
};
const LANDMARKS: Record<string, string> = {
  vietnam: "🏮", japan: "⛩️", bali: "🌺", thailand: "🛕", srilanka: "🚂",
  dubai: "🌇", singapore: "🦁", georgia: "🍷", kazakhstan: "🏔", greece: "🏛",
  switzerland: "🚞", italy: "🛵", maldives: "🐠", cambodia: "🛕", armenia: "⛪",
  southkorea: "🏮", malaysia: "🏙", philippines: "🏝", mauritius: "🌊", seychelles: "🐚",
  nepal: "🏔", bhutan: "🐉", uzbekistan: "🕌", oman: "🏜", egypt: "🐪",
  uk: "💂", france: "🗼", spain: "💃", australia: "🦘", newzealand: "🥝",
};

const STOPS = ["Who", "Where", "Shape", "Design", "Journey"];
const ROUTE_IDX: Partial<Record<Step, number>> = {
  persona: 0, mode: 1, pick: 1, quiz: 1, matches: 1, shape: 2, result: 4,
};

const shortName = (name: string) => name.split(" (")[0];
const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export default function DesignFlow({
  packs,
  waNumber,
  minFee,
}: {
  packs: DestinationPack[];
  waNumber: string;
  minFee: string;
}) {
  const [step, setStep] = useState<Step>("hero");
  const [persona, setPersona] = useState<Persona | null>(null);
  const [pick, setPick] = useState<string | null>(null);
  const [combo, setCombo] = useState<string | null>(null); // comboKey when clubbed
  const [month, setMonth] = useState<number | null>(null);
  const [budgetIdx, setBudgetIdx] = useState<number | null>(null);
  const [vibes, setVibes] = useState<string[]>([]);
  const [visa, setVisa] = useState<0 | 1 | null>(null);
  const [nights, setNights] = useState(7);
  const [pace, setPace] = useState<Pace>("Balanced");
  const [style, setStyle] = useState<TravelStyle>("Comfort");
  const [cameFrom, setCameFrom] = useState<"pick" | "matches">("pick");
  const [shapeAsksMonth, setShapeAsksMonth] = useState(false);
  const [theater, setTheater] = useState(false);
  const [tMsgs, setTMsgs] = useState<string[]>([]);
  const [tIdx, setTIdx] = useState(0);
  const [result, setResult] = useState<GenerateResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const designing = useRef(false);

  const byId = (id: string) => packs.find((p) => p.id === id);
  const gridDests = useMemo(() => packs.filter((d) => !MINI_IDS.includes(d.id)), [packs]);
  const availableCombos = useMemo(
    () => COMBOS.filter((c) => c.ids.every((id) => packs.some((p) => p.id === id))),
    [packs],
  );
  const selectedCombo: Combo | null = combo
    ? availableCombos.find((c) => comboKey(c) === combo) ?? null
    : null;

  // Scroll to top whenever the step changes (mirrors the original go()).
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [step]);

  // Theater message rotation.
  useEffect(() => {
    if (!theater) return;
    setTIdx(0);
    const id = setInterval(() => setTIdx((i) => i + 1), 820);
    return () => clearInterval(id);
  }, [theater]);

  const matches = useMemo(() => {
    if (persona === null || month === null || budgetIdx === null || visa === null) return [];
    return scoreDestinations({ persona, month, budgetIdx, vibes, visaPatience: visa }, packs).slice(0, 3);
  }, [persona, month, budgetIdx, vibes, visa, packs]);

  const quizReady = month !== null && budgetIdx !== null && vibes.length > 0 && visa !== null;

  function toggleVibe(v: string) {
    setVibes((cur) => (cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v]));
  }

  function goShape(from: "pick" | "matches") {
    const min = from === "pick" && selectedCombo ? selectedCombo.minNights : 4;
    setNights((n) => Math.max(n, min));
    setShapeAsksMonth(month === null);
    setCameFrom(from);
    setError(null);
    setStep("shape");
  }

  function chooseMatch(id: string) {
    setPick(id);
    setCombo(null);
    const min = 4;
    setNights((n) => Math.max(n, min));
    setShapeAsksMonth(false); // quiz path always has a month
    setCameFrom("matches");
    setError(null);
    setStep("shape");
  }

  function restart() {
    setStep("hero");
    setPersona(null);
    setPick(null);
    setCombo(null);
    setMonth(null);
    setBudgetIdx(null);
    setVibes([]);
    setVisa(null);
    setNights(7);
    setPace("Balanced");
    setCameFrom("pick");
    setShapeAsksMonth(false);
    setResult(null);
    setError(null);
  }

  async function startDesign() {
    if (!persona || designing.current) return;
    designing.current = true;
    const m = month ?? new Date().getMonth();
    if (month === null) setMonth(m);

    const names = selectedCombo
      ? selectedCombo.ids.map((id) => shortName(byId(id)?.name ?? id))
      : pick
        ? [shortName(byId(pick)?.name ?? pick)]
        : [];
    setTMsgs([
      `Reading ${MONTHS[m]} skies over ${names[0] ?? "your route"}…`,
      `Tuning every day for ${PERSONA_PHRASE[persona]}…`,
      style === "Smart"
        ? "Hunting the smart-money corners…"
        : style === "Luxe"
          ? "Reserving the rooms people screenshot…"
          : "Balancing comfort against the budget…",
      "Checking the visa lane for Indian passports…",
      selectedCombo
        ? `Stitching ${names[0]} to ${names[1]} — no backtracking…`
        : "Placing golden hour where it belongs…",
      "Signing it the Yatrikala way ✦",
    ]);
    setTheater(true);
    setError(null);

    const body: Brief = {
      persona,
      pick: selectedCombo ? null : pick,
      comboKey: selectedCombo ? comboKey(selectedCombo) : null,
      month: m,
      nights,
      pace,
      style,
      vibes,
    };

    try {
      const [res] = await Promise.all([
        fetch("/api/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        }).then(async (r) => {
          if (!r.ok) throw new Error(`generate ${r.status}`);
          return (await r.json()) as GenerateResponse;
        }),
        sleep(4200), // the theater deserves its moment
      ]);
      setResult(res);
      setStep("result");
    } catch {
      setError("We couldn't draft this journey right now — please try again in a moment.");
    } finally {
      setTheater(false);
      designing.current = false;
    }
  }

  /** Fire-and-forget lead capture when the WhatsApp CTA is clicked. */
  function fireLead() {
    if (!result) return;
    try {
      fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        keepalive: true,
        body: JSON.stringify({
          name: "Journey Designer visitor",
          source: "journey-designer",
          persona: persona ?? undefined,
          destination: result.itinerary.dispName,
          travelMonth: MONTHS[result.itinerary.month],
        }),
      }).catch(() => {});
    } catch {
      /* never block the WhatsApp hop */
    }
  }

  const shareUrl =
    result && result.persisted !== false && typeof window !== "undefined"
      ? `${window.location.origin}/itinerary/${result.shareSlug}`
      : undefined;

  const shapeName = selectedCombo
    ? selectedCombo.ids.map((id) => shortName(byId(id)?.name ?? id)).join(" + ")
    : pick
      ? shortName(byId(pick)?.name ?? pick)
      : "";

  const routeIdx = theater ? 3 : ROUTE_IDX[step];

  return (
    <div>
      {/* ---------- progress route bar ---------- */}
      {step !== "hero" && (
        <div className="jd-routebar">
          <div className="inner">
            {STOPS.map((s, i) => (
              <div key={s} style={{ display: "contents" }}>
                <div className={`jd-stop ${routeIdx !== undefined && i < routeIdx ? "done" : routeIdx === i ? "now" : ""}`}>
                  <div className="pt" />
                  <small>{s}</small>
                </div>
                {i < STOPS.length - 1 && (
                  <div className={`jd-leg ${routeIdx !== undefined && i < routeIdx ? "done" : ""}`} />
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ---------- hero ---------- */}
      {step === "hero" && (
        <section className="jd-hero" key="hero">
          <div className="mark">YATRIKALA</div>
          <div className="marksub">THE ART OF TRAVEL</div>
          <svg className="jd-heroroute" viewBox="0 0 420 90" xmlns="http://www.w3.org/2000/svg">
            <circle cx="18" cy="62" r="5" fill="#F5AE3D" />
            <path
              className="draw"
              d="M 26 58 C 110 8, 300 8, 388 50"
              fill="none"
              stroke="#F5AE3D"
              strokeWidth="2.6"
              strokeLinecap="round"
              strokeDasharray="0.1 11"
            />
            <path className="star" d="M 396 44 L 400 54 L 410 58 L 400 62 L 396 72 L 392 62 L 382 58 L 392 54 Z" fill="#F5AE3D" />
          </svg>
          <h1>Where will your story go?</h1>
          <div className="sub">
            {"Answer a few beautiful questions. Watch a journey design itself — tuned to who you are, not just where you're going."}
          </div>
          <button className="jd-begin" type="button" onClick={() => setStep("persona")}>
            Begin the journey ✦
          </button>
          <div className="foot">~60 seconds · made for Indian passports</div>
        </section>
      )}

      {/* ---------- step 1 · persona ---------- */}
      {step === "persona" && (
        <section className="jd-step" key="persona">
          <h2 className="jd-q">{"Who's travelling?"}</h2>
          <div className="jd-qsub">
            {"This changes everything — the pace, the stays, the food, even which sunrise we'll wake you for."}
          </div>
          <div className="jd-personas">
            {PERSONA_DEFS.map((p) => (
              <button
                key={p.id}
                type="button"
                className={`jd-pcard ${persona === p.id ? "sel" : ""}`}
                onClick={() => setPersona(p.id)}
              >
                {p.icon}
                <div className="pl">{p.label}</div>
                <div className="ps">{p.sub}</div>
              </button>
            ))}
          </div>
          <div className="jd-navrow">
            <button className="jd-back" type="button" onClick={() => setStep("hero")}>← Back</button>
            <button className="cta" type="button" disabled={!persona} onClick={() => setStep("mode")}>
              Continue →
            </button>
          </div>
        </section>
      )}

      {/* ---------- step 2 · mode ---------- */}
      {step === "mode" && (
        <section className="jd-step" key="mode">
          <h2 className="jd-q">{"Do you know where you're going?"}</h2>
          <div className="jd-qsub">{"Either way, you're in good hands."}</div>
          <div className="jd-modes">
            <button className="jd-mcard" type="button" onClick={() => setStep("pick")}>
              <div className="mi">🗺️</div>
              <div className="ml">I know where</div>
              <div className="ms">Pick your country — or club two together into one seamless route.</div>
            </button>
            <button className="jd-mcard" type="button" onClick={() => setStep("quiz")}>
              <div className="mi">✨</div>
              <div className="ml">Surprise me</div>
              <div className="ms">{"Tell us the month, budget and mood. We'll match you to the place that fits."}</div>
            </button>
          </div>
          <div className="jd-navrow">
            <button className="jd-back" type="button" onClick={() => setStep("persona")}>← Back</button>
            <span />
          </div>
        </section>
      )}

      {/* ---------- step 2a · picker ---------- */}
      {step === "pick" && (
        <section className="jd-step" key="pick">
          <h2 className="jd-q">Pick your canvas</h2>
          <div className="jd-qsub">One country — or a two-country route stitched properly, transit and all.</div>
          <div className="jd-dgrid">
            {gridDests.map((d) => (
              <button
                key={d.id}
                type="button"
                className={`jd-dcard ${pick === d.id ? "sel" : ""}`}
                onClick={() => { setPick(d.id); setCombo(null); }}
              >
                <div className="tick">✓</div>
                <div className="sky" style={{ background: SKIES[d.id] ?? "var(--ink)" }}>
                  {LANDMARKS[d.id] ?? d.flag}
                </div>
                <div className="body">
                  <div className="dn">{d.flag} {d.name}</div>
                  <div className="dt">{d.tagline}</div>
                  <div className="meta">
                    <span className="pip">{d.budgetBand}</span>
                    <span className={`pip v${d.visa.ease}`}>{d.visa.label}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>
          {availableCombos.length > 0 && (
            <>
              <div className="jd-combolabel">Club countries together</div>
              <div className="jd-combosub">
                Curated pairings with the routing already solved — no backtracking, no wasted days.
              </div>
              <div className="jd-combos">
                {availableCombos.map((c) => {
                  const [a, b] = c.ids.map((id) => byId(id)!);
                  const key = comboKey(c);
                  return (
                    <button
                      key={key}
                      type="button"
                      className={`jd-combo ${combo === key ? "sel" : ""}`}
                      onClick={() => { setCombo(key); setPick(null); }}
                    >
                      {a.flag} {shortName(a.name)} <span className="plus">+</span> {b.flag} {shortName(b.name)}
                      <span style={{ opacity: 0.55, fontSize: 11.5 }}> · {c.tag}</span>
                    </button>
                  );
                })}
              </div>
            </>
          )}
          <div className="jd-navrow">
            <button className="jd-back" type="button" onClick={() => setStep("mode")}>← Back</button>
            <button className="cta" type="button" disabled={!pick && !combo} onClick={() => goShape("pick")}>
              Continue →
            </button>
          </div>
        </section>
      )}

      {/* ---------- step 2b · quiz ---------- */}
      {step === "quiz" && (
        <section className="jd-step" key="quiz">
          <h2 className="jd-q">{"Let's find your place"}</h2>
          <div className="jd-qsub">Four quick strokes, and the map narrows itself.</div>
          <div className="jd-qblock">
            <div className="ql">When are you travelling?</div>
            <div className="jd-chips">
              {MONTHS.map((m, i) => (
                <button key={m} type="button" className={`chip ${month === i ? "sel" : ""}`} onClick={() => setMonth(i)}>
                  {m}
                </button>
              ))}
            </div>
          </div>
          <div className="jd-qblock">
            <div className="ql">Budget per person — excluding flights</div>
            <div className="jd-chips">
              {BUDGET_BANDS.map((b, i) => (
                <button key={b.label} type="button" className={`chip ${budgetIdx === i ? "sel" : ""}`} onClick={() => setBudgetIdx(i)}>
                  {b.label}
                </button>
              ))}
            </div>
          </div>
          <div className="jd-qblock">
            <div className="ql">{"What's the mood? Pick any."}</div>
            <div className="jd-chips">
              {VIBES.map(([v, label]) => (
                <button key={v} type="button" className={`chip ${vibes.includes(v) ? "sel" : ""}`} onClick={() => toggleVibe(v)}>
                  {label}
                </button>
              ))}
            </div>
          </div>
          <div className="jd-qblock">
            <div className="ql">Visa paperwork?</div>
            <div className="jd-chips">
              {(["Keep it easy", "Don't mind paperwork"] as const).map((t, i) => (
                <button key={t} type="button" className={`chip ${visa === i ? "sel" : ""}`} onClick={() => setVisa(i as 0 | 1)}>
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div className="jd-navrow">
            <button className="jd-back" type="button" onClick={() => setStep("mode")}>← Back</button>
            <button className="cta" type="button" disabled={!quizReady} onClick={() => setStep("matches")}>
              Show my matches ✦
            </button>
          </div>
        </section>
      )}

      {/* ---------- step 2c · matches ---------- */}
      {step === "matches" && (
        <section className="jd-step" key="matches">
          <h2 className="jd-q">The map has spoken</h2>
          <div className="jd-qsub">
            {persona !== null && month !== null && budgetIdx !== null
              ? `For ${PERSONA_PHRASE[persona]} in ${MONTHS[month]}, within ${BUDGET_BANDS[budgetIdx].label} — three places rose to the top.`
              : ""}
          </div>
          <div className="jd-matches">
            {matches.map((m) => (
              <button key={m.destId} type="button" className="jd-match" onClick={() => chooseMatch(m.destId)}>
                <div className="sky" style={{ background: SKIES[m.destId] ?? "var(--ink)" }}>
                  {LANDMARKS[m.destId] ?? m.flag}
                </div>
                <div className="mb">
                  <div className="top">
                    <span className="dn">{m.flag} {m.name}</span>
                    <span className="pct">{m.pct}% match</span>
                  </div>
                  <div className="why">{m.reasons.join(" · ")}</div>
                  <div className="meta">
                    <span className="pip">{m.budgetBand}</span>
                    <span className={`pip v${m.visaEase}`}>{m.visaLabel}</span>
                    {m.pairsWith ? <span className="pip">pairs with {m.pairsWith}</span> : null}
                  </div>
                </div>
              </button>
            ))}
          </div>
          <div className="jd-navrow">
            <button className="jd-back" type="button" onClick={() => setStep("quiz")}>← Adjust answers</button>
            <span />
          </div>
        </section>
      )}

      {/* ---------- step 3 · shape ---------- */}
      {step === "shape" && (
        <section className="jd-step jd-shape" key="shape">
          <h2 className="jd-q">{shapeName ? `Shape your ${shapeName} trip` : "Shape the trip"}</h2>
          <div className="jd-qsub">Last brushstrokes before the reveal.</div>
          <div className="jd-qblock">
            <div className="ql">How many nights?</div>
            <div className="jd-nightsrow">
              <input
                type="range"
                min={selectedCombo?.minNights ?? 4}
                max={14}
                value={nights}
                onChange={(e) => setNights(Number(e.target.value))}
              />
              <div className="jd-nval">
                {nights} <small>nights</small>
              </div>
            </div>
          </div>
          <div className="jd-qblock">
            <div className="ql">Your style</div>
            <div className="jd-styles">
              {STYLE_DEFS.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  className={`jd-style ${style === s.id ? "sel" : ""}`}
                  onClick={() => setStyle(s.id)}
                >
                  <span className="si">{s.icon}</span>
                  <b>{s.label}</b>
                  <small>{s.sub}</small>
                </button>
              ))}
            </div>
          </div>
          <div className="jd-qblock">
            <div className="ql">Your pace</div>
            <div className="jd-chips">
              {PACES.map((p) => (
                <button key={p} type="button" className={`chip ${pace === p ? "sel" : ""}`} onClick={() => setPace(p)}>
                  {p}
                </button>
              ))}
            </div>
          </div>
          {shapeAsksMonth && (
            <div className="jd-qblock">
              <div className="ql">Which month?</div>
              <div className="jd-chips">
                {MONTHS.map((m, i) => (
                  <button key={m} type="button" className={`chip ${month === i ? "sel" : ""}`} onClick={() => setMonth(i)}>
                    {m}
                  </button>
                ))}
              </div>
            </div>
          )}
          <div className="jd-navrow">
            <button className="jd-back" type="button" onClick={() => setStep(cameFrom === "matches" ? "matches" : "pick")}>
              ← Back
            </button>
            <button className="cta gold" type="button" onClick={startDesign}>
              Design my journey ✦
            </button>
          </div>
          {error && <div className="jd-error">{error}</div>}
        </section>
      )}

      {/* ---------- theater overlay ---------- */}
      {theater && (
        <div className="jd-theater">
          <svg className="jd-troute" viewBox="0 0 420 90" xmlns="http://www.w3.org/2000/svg">
            <circle cx="18" cy="62" r="5" fill="#F5AE3D" />
            <path
              className="draw"
              d="M 26 58 C 110 8, 300 8, 388 50"
              fill="none"
              stroke="#F5AE3D"
              strokeWidth="2.6"
              strokeLinecap="round"
              strokeDasharray="0.1 11"
            />
          </svg>
          <div className="tmsg" key={tIdx}>
            {tMsgs[Math.min(tIdx, tMsgs.length - 1)] ?? "Designing…"}
          </div>
          <div className="tsub">Yatrikala · designing</div>
        </div>
      )}

      {/* ---------- step 5 · itinerary ---------- */}
      {step === "result" && result && (
        <section className="jd-step wide" key="result">
          <ItineraryDoc
            itinerary={result.itinerary}
            gate={true}
            waNumber={waNumber}
            minFee={minFee}
            shareUrl={shareUrl}
            briefVibes={vibes}
            onWhatsAppClick={fireLead}
          />
          <button className="jd-restart" type="button" onClick={restart}>
            ↺ Design a different journey
          </button>
          <div className="jd-docfoot">
            <div className="routeline">
              <div className="rl-dot" />
              <div className="rl-dash" />
              <div className="rl-star">✦</div>
            </div>
            <div className="mk">YATRIKALA</div>
            <small>The art of travel · Journeys, designed by hand</small>
          </div>
        </section>
      )}
    </div>
  );
}

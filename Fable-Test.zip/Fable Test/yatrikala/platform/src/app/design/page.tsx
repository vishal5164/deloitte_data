import type { Metadata } from "next";
import TopNav from "@/components/TopNav";
import { loadPacks } from "@/content/loadPacks";
import DesignFlow from "./DesignFlow";

export const metadata: Metadata = {
  title: "Design a journey",
  description:
    "Answer a few beautiful questions and watch a full itinerary take shape — days, budgets and visa notes for Indian passports, tuned to who you travel with, not just where you're going.",
};

/**
 * /design — the Journey Designer. Packs load server-side (DB with bundled
 * fallback via loadPacks), then the whole flow runs as a client component.
 * ISR keeps admin content edits flowing through without a redeploy.
 */
export const revalidate = 3600;

export default async function DesignPage() {
  const packs = await loadPacks();
  return (
    <>
      <TopNav active="/design" />
      <DesignFlow
        packs={packs}
        waNumber={process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? ""}
        minFee="₹12,999"
      />
    </>
  );
}

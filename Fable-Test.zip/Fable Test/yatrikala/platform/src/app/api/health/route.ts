import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

/**
 * Deploy verification + uptime endpoint. No secrets — booleans only.
 * GET /api/health          → env-configuration status (instant)
 * GET /api/health?deep=1   → also pings the database (bounded to 4s)
 */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const integrations = {
    database: Boolean(process.env.DATABASE_URL),
    supabaseAuth: Boolean(
      process.env.NEXT_PUBLIC_SUPABASE_URL &&
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY &&
      process.env.ADMIN_EMAILS,
    ),
    razorpay: Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET),
    razorpayWebhook: Boolean(process.env.RAZORPAY_WEBHOOK_SECRET),
    priceSource:
      (process.env.PRICE_SOURCE ?? "travelpayouts") === "amadeus"
        ? Boolean(process.env.AMADEUS_CLIENT_ID && process.env.AMADEUS_CLIENT_SECRET)
        : Boolean(process.env.TRAVELPAYOUTS_TOKEN),
    anthropic: Boolean(process.env.ANTHROPIC_API_KEY),
    whatsapp: Boolean(process.env.NEXT_PUBLIC_WHATSAPP_NUMBER),
    cronSecret: Boolean(process.env.CRON_SECRET),
  };

  let dbReachable: boolean | undefined;
  if (url.searchParams.get("deep") === "1") {
    dbReachable = false;
    try {
      const { db } = await import("@/db");
      const { sql } = await import("drizzle-orm");
      await Promise.race([
        db.execute(sql`select 1`),
        new Promise((_, rej) => setTimeout(() => rej(new Error("timeout")), 4000)),
      ]);
      dbReachable = true;
    } catch {
      // stays false
    }
  }

  const ok = dbReachable !== false;
  return NextResponse.json(
    { ok, service: "yatrikala-platform", integrations, ...(dbReachable !== undefined && { dbReachable }) },
    { status: ok ? 200 : 503 },
  );
}

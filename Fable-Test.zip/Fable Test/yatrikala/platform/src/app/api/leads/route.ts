import { NextResponse } from "next/server";
import { z } from "zod";
import { db, tables } from "@/db";

/**
 * POST /api/leads — capture a lead from any surface (journey designer gate,
 * contact strip, insights pages). Status always starts at 'new'.
 */

const LeadSchema = z.object({
  name: z.string().min(1).max(80),
  phone: z.string().max(20).optional(),
  email: z.string().email().optional(),
  source: z.string().optional(),
  persona: z.string().optional(),
  destination: z.string().optional(),
  travelMonth: z.string().optional(),
  budgetBand: z.string().optional(),
  notes: z.string().max(500).optional(),
});

/**
 * Best-effort in-memory rate limiter (10 requests/min per IP).
 * Serverless caveat: on Vercel each lambda instance keeps its own Map, so the
 * real ceiling is 10/min *per instance* and resets on cold starts. That makes
 * this an abuse speed-bump, not a guarantee — move to Redis/Upstash if lead
 * spam ever becomes a real problem.
 */
const WINDOW_MS = 60_000;
const MAX_PER_WINDOW = 10;
const hits = new Map<string, { count: number; windowStart: number }>();

function isRateLimited(ip: string): boolean {
  const now = Date.now();

  // Cheap sweep so the Map can't grow unbounded on a long-lived instance.
  if (hits.size > 1000) {
    for (const [key, entry] of hits) {
      if (now - entry.windowStart >= WINDOW_MS) hits.delete(key);
    }
  }

  const entry = hits.get(ip);
  if (!entry || now - entry.windowStart >= WINDOW_MS) {
    hits.set(ip, { count: 1, windowStart: now });
    return false;
  }
  entry.count += 1;
  return entry.count > MAX_PER_WINDOW;
}

export async function POST(req: Request) {
  const ip =
    (req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim() || "unknown";
  if (isRateLimited(ip)) {
    return NextResponse.json(
      { error: "Too many requests — please try again in a minute." },
      { status: 429 },
    );
  }

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parsed = LeadSchema.safeParse(raw);
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    return NextResponse.json(
      { error: issue ? `${issue.path.join(".") || "body"}: ${issue.message}` : "Invalid lead" },
      { status: 400 },
    );
  }
  const lead = parsed.data;

  try {
    const [row] = await db
      .insert(tables.leads)
      .values({
        name: lead.name,
        phone: lead.phone,
        email: lead.email,
        source: lead.source, // undefined → DB default 'journey-designer'
        persona: lead.persona,
        destination: lead.destination,
        travelMonth: lead.travelMonth,
        budgetBand: lead.budgetBand,
        notes: lead.notes,
        status: "new",
      })
      .returning({ id: tables.leads.id });

    return NextResponse.json({ id: row.id });
  } catch {
    return NextResponse.json({ error: "storage unavailable" }, { status: 503 });
  }
}

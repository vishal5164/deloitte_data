import { NextResponse } from "next/server";
import { z } from "zod";
import { db, tables } from "@/db";
import { findCombo, PERSONAS } from "@/engine";
import type { Brief } from "@/engine";
import { loadPacks } from "@/content/loadPacks";
import { generateItinerary } from "@/lib/claude";

/**
 * POST /api/generate — turn a visitor brief into a full itinerary draft.
 * Generation always succeeds without a DB (engine fallback + bundled packs);
 * persistence is best-effort so the visitor never loses their draft to infra.
 */

const BriefSchema = z
  .object({
    persona: z.enum(PERSONAS as [Brief["persona"], ...Brief["persona"][]]),
    pick: z.string().nullable(),
    comboKey: z.string().nullable(),
    month: z.number().int().min(0).max(11),
    nights: z.number().int().min(4).max(16),
    pace: z.enum(["Gentle", "Balanced", "Full days"]),
    style: z.enum(["Smart", "Comfort", "Luxe"]).optional().default("Comfort"),
    vibes: z.array(z.string()).max(11),
  })
  .refine((b) => (b.pick === null) !== (b.comboKey === null), {
    message: "Provide exactly one of pick or comboKey",
  });

export async function POST(req: Request) {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const parsed = BriefSchema.safeParse(raw);
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    return NextResponse.json(
      { error: issue ? `${issue.path.join(".") || "body"}: ${issue.message}` : "Invalid brief" },
      { status: 400 },
    );
  }
  const brief: Brief = parsed.data;

  if (brief.comboKey !== null && !findCombo(brief.comboKey)) {
    return NextResponse.json(
      { error: `Unknown combo: ${brief.comboKey}` },
      { status: 400 },
    );
  }

  try {
    const packs = await loadPacks();

    if (brief.pick !== null && !packs.some((p) => p.id === brief.pick)) {
      return NextResponse.json(
        { error: `Unknown destination: ${brief.pick}` },
        { status: 400 },
      );
    }

    const { itinerary, generator } = await generateItinerary(brief, packs);
    const shareSlug = crypto.randomUUID().slice(0, 8);

    // Best-effort persistence: a missing DATABASE_URL must never cost the
    // visitor their itinerary — they still get the draft, we just skip the row.
    let persisted = false;
    try {
      const [briefRow] = await db
        .insert(tables.briefs)
        .values({
          persona: brief.persona,
          destIds: itinerary.destIds,
          comboKey: brief.comboKey,
          month: brief.month,
          nights: brief.nights,
          pace: brief.pace,
          vibes: brief.vibes,
          leadId: null,
        })
        .returning({ id: tables.briefs.id });

      await db.insert(tables.itineraries).values({
        briefId: briefRow.id,
        title: itinerary.title,
        body: itinerary,
        generator,
        kind: "draft",
        shareSlug,
      });
      persisted = true;
    } catch {
      // DB unreachable/not configured yet — the draft is still returned below.
    }

    // persisted=false tells the client not to offer a share link that would 404.
    return NextResponse.json({ itinerary, shareSlug, generator, persisted });
  } catch {
    return NextResponse.json(
      { error: "We couldn't draft this journey right now — please try again in a moment." },
      { status: 500 },
    );
  }
}

import { NextResponse } from "next/server";
import { db, tables } from "@/db";
import { loadPacks } from "@/content/loadPacks";
import { MINI_IDS, MONTHS, PERSONAS, inr } from "@/engine";
import type { DestinationPack, Persona } from "@/engine";
import { synthesizeInsight, type InsightBody } from "@/lib/claude";
import { getAdmin, isCronAuthorized } from "@/lib/auth";

/**
 * Weekly "travellers like you" research pass.
 * GET  — Vercel cron (Authorization: Bearer CRON_SECRET)
 * POST — admin-triggered manual refresh
 *
 * For every (destination pack × persona) pair: aggregate matching briefs, then
 * either synthesize an AI insight (only when briefCount > 0, or ?full=1 forces
 * every pair) or store the plain aggregate shape — keeps the Claude bill bounded.
 */
export const maxDuration = 300;

type BriefRow = {
  persona: string;
  destIds: string[];
  comboKey: string | null;
  month: number;
  nights: number;
  vibes: string[];
};

type Aggregate = {
  briefCount: number;
  medianNights: number | null;
  topMonths: string[];
  topVibes: string[];
  avgBudgetLine: string | null;
};

function median(ns: number[]): number | null {
  if (!ns.length) return null;
  const s = [...ns].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : Math.round((s[mid - 1] + s[mid]) / 2);
}

function topN<T>(items: T[], n: number): T[] {
  const counts = new Map<T, number>();
  for (const it of items) counts.set(it, (counts.get(it) ?? 0) + 1);
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([k]) => k);
}

/** Same fallback shape synthesizeInsight would return without an API key. */
function aggregateBody(
  destName: string,
  persona: Persona,
  aggregate: Aggregate,
  pack: DestinationPack,
): InsightBody {
  return {
    headline: `What ${persona} travellers plan for ${destName}`,
    stats: [
      { label: "Drafts designed here", value: String(aggregate.briefCount) },
      {
        label: "Median trip length",
        value: aggregate.medianNights ? `${aggregate.medianNights} nights` : "—",
      },
      { label: "Most-picked months", value: aggregate.topMonths.join(", ") || "—" },
      ...(aggregate.avgBudgetLine
        ? [{ label: "Budget floor", value: aggregate.avgBudgetLine }]
        : []),
    ],
    patterns: aggregate.topVibes.length
      ? [`Most requested moods: ${aggregate.topVibes.join(", ")}`]
      : [],
    advice: pack.whyGo ?? [],
    sources: "Aggregated from anonymised Yatrikala journey drafts. Updated weekly.",
  };
}

async function isAllowed(req: Request): Promise<boolean> {
  if (isCronAuthorized(req)) return true;
  try {
    return Boolean(await getAdmin());
  } catch {
    return false; // Supabase not configured — cron secret is the only door
  }
}

async function refresh(req: Request): Promise<NextResponse> {
  if (!(await isAllowed(req))) {
    return NextResponse.json({ error: "unauthorised" }, { status: 401 });
  }
  const full = new URL(req.url).searchParams.get("full") === "1";
  const packs = (await loadPacks()).filter((p) => !MINI_IDS.includes(p.id));

  // One read for the whole pass; pair-level filtering happens in memory.
  let allBriefs: BriefRow[];
  try {
    allBriefs = await db
      .select({
        persona: tables.briefs.persona,
        destIds: tables.briefs.destIds,
        comboKey: tables.briefs.comboKey,
        month: tables.briefs.month,
        nights: tables.briefs.nights,
        vibes: tables.briefs.vibes,
      })
      .from(tables.briefs);
  } catch {
    // No reachable database — nothing to aggregate and nowhere to write.
    return NextResponse.json({
      updated: 0,
      aiCalls: 0,
      note: "database unreachable — refresh skipped, nothing written",
    });
  }

  let updated = 0;
  let aiCalls = 0;
  let writeFailures = 0;

  for (const pack of packs) {
    const destName = pack.name.split(" (")[0];
    const forDest = allBriefs.filter(
      (b) =>
        (b.destIds ?? []).includes(pack.id) ||
        (b.comboKey ?? "").split("+").includes(pack.id),
    );

    for (const persona of PERSONAS) {
      const mine = forDest.filter((b) => b.persona === persona);
      const aggregate: Aggregate = {
        briefCount: mine.length,
        medianNights: median(mine.map((b) => b.nights)),
        topMonths: topN(mine.map((b) => b.month), 3)
          .map((m) => MONTHS[m] ?? "")
          .filter(Boolean),
        topVibes: topN(mine.flatMap((b) => b.vibes ?? []), 3),
        avgBudgetLine: pack.budgetFloorPP
          ? `from ${inr(pack.budgetFloorPP)} pp (7-night floor, ex-flights)`
          : null,
      };

      let body: InsightBody;
      let generatedBy: "aggregate" | "claude" = "aggregate";
      if (aggregate.briefCount > 0 || full) {
        const out = await synthesizeInsight({ destName, persona, aggregate, pack });
        body = out.body;
        generatedBy = out.generatedBy;
        if (out.generatedBy === "claude") aiCalls++;
      } else {
        body = aggregateBody(destName, persona, aggregate, pack);
      }

      try {
        const now = new Date();
        await db
          .insert(tables.insightsCache)
          .values({ key: `${pack.id}:${persona}`, body, generatedBy, updatedAt: now })
          .onConflictDoUpdate({
            target: tables.insightsCache.key,
            set: { body, generatedBy, updatedAt: now },
          });
        updated++;
      } catch {
        writeFailures++;
      }
    }
  }

  return NextResponse.json({
    updated,
    aiCalls,
    ...(writeFailures ? { note: `${writeFailures} cache writes failed` } : {}),
  });
}

export async function GET(req: Request) {
  return refresh(req);
}

export async function POST(req: Request) {
  return refresh(req);
}

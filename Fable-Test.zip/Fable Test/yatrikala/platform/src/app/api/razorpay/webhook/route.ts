import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db, tables } from "@/db";
import { verifyWebhookSignature } from "@/lib/razorpay";

export const dynamic = "force-dynamic";

/** The slice of Razorpay's webhook envelope we care about. */
interface RazorpayWebhook {
  event?: string;
  payload?: {
    payment_link?: { entity?: { id?: string; reference_id?: string } };
    payment?: { entity?: { id?: string; amount?: number; method?: string } };
  };
}

/**
 * Razorpay webhook — payment_link.paid settles our invoice.
 * - Signature verified over the RAW body (any reformatting breaks the HMAC).
 * - Idempotent: replayed events for an already-paid invoice are acknowledged, not re-applied.
 * - Handled/ignored events → 200 {ok:true}; Razorpay retries on non-2xx, so we only
 *   return 5xx when storage is genuinely unavailable and a retry would help.
 */
export async function POST(req: Request) {
  const raw = await req.text();
  if (!verifyWebhookSignature(raw, req.headers.get("x-razorpay-signature"))) {
    return NextResponse.json({ ok: false, error: "invalid signature" }, { status: 401 });
  }

  let body: RazorpayWebhook;
  try {
    body = JSON.parse(raw) as RazorpayWebhook;
  } catch {
    return NextResponse.json({ ok: true }); // signed but unparseable — acknowledge, nothing to do
  }

  if (body.event !== "payment_link.paid") {
    return NextResponse.json({ ok: true }); // not ours to handle
  }

  const reference = body.payload?.payment_link?.entity?.reference_id;
  const payment = body.payload?.payment?.entity;
  if (!reference) return NextResponse.json({ ok: true });

  try {
    const [inv] = await db
      .select()
      .from(tables.invoices)
      .where(eq(tables.invoices.number, reference))
      .limit(1);

    if (!inv) return NextResponse.json({ ok: true }); // unknown reference — acknowledge
    if (inv.status === "paid") return NextResponse.json({ ok: true }); // idempotent replay

    await db
      .update(tables.invoices)
      .set({
        status: "paid",
        paidAt: new Date(),
        razorpayPaymentId: payment?.id ?? null,
      })
      .where(eq(tables.invoices.id, inv.id));

    await db.insert(tables.payments).values({
      invoiceId: inv.id,
      amountInr:
        typeof payment?.amount === "number" ? Math.round(payment.amount / 100) : inv.amountInr,
      method: payment?.method ?? "razorpay",
      razorpayEvent: body,
    });
  } catch {
    // DB unreachable — ask Razorpay to retry rather than dropping a real payment.
    return NextResponse.json({ ok: false, error: "storage unavailable" }, { status: 500 });
  }

  return NextResponse.json({ ok: true });
}

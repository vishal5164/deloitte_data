import { NextResponse } from "next/server";
import { db, tables } from "@/db";
import { getAdmin, isCronAuthorized } from "@/lib/auth";
import { DEST_GATEWAYS, ORIGINS, priceSource, priceSourceConfigured } from "@/lib/prices";

/**
 * Price refresh: GET for the Vercel cron, POST for a manual admin trigger.
 * Fills price_snapshots with observed flight fares (ORIGINS × gateways, cheapest 3
 * per route) and one hotel nightly-median snapshot per gateway city.
 * Optional ?dest=<packId> narrows the run to a single destination.
 */
export const maxDuration = 300; // Vercel cron ceiling — the 60-route cap keeps us well under
export const dynamic = "force-dynamic";

const ROUTE_CAP = 60; // max source calls per invocation; window rotates daily
const DAY = 86_400_000;

const sleep = (ms: number) => new Promise<void>((res) => setTimeout(res, ms));
const slugify = (city: string) => city.toLowerCase().replace(/\s+/g, "-");
const isoDay = (offsetDays: number) =>
  new Date(Date.now() + offsetDays * DAY).toISOString().slice(0, 10);

type Task =
  | { kind: "flight"; origin: string; packId: string; iata: string; label: string }
  | { kind: "hotel"; packId: string; city: string; label: string };

async function runRefresh(req: Request) {
  // Auth: Vercel cron bearer token OR a signed-in allow-listed admin.
  let authorized = isCronAuthorized(req);
  if (!authorized) {
    try {
      authorized = Boolean(await getAdmin());
    } catch {
      // Supabase env not configured — cron secret remains the only door
    }
  }
  if (!authorized) return NextResponse.json({ error: "unauthorized" }, { status: 401 });

  if (!priceSourceConfigured()) {
    return NextResponse.json({
      skipped: true,
      reason:
        "Price source not configured — set TRAVELPAYOUTS_TOKEN (or AMADEUS_CLIENT_ID/AMADEUS_CLIENT_SECRET with PRICE_SOURCE=amadeus).",
    });
  }

  const src = priceSource();
  const destFilter = new URL(req.url).searchParams.get("dest");
  const gateways = Object.entries(DEST_GATEWAYS).filter(
    ([packId]) => !destFilter || packId === destFilter,
  );
  if (gateways.length === 0) {
    return NextResponse.json({ skipped: true, reason: `unknown dest '${destFilter}'` });
  }

  // destId is an FK to destinations — only set it when the row actually exists.
  let knownDestIds = new Set<string>();
  try {
    const ids = await db.select({ id: tables.destinations.id }).from(tables.destinations);
    knownDestIds = new Set(ids.map((r) => r.id));
  } catch {
    // DB unreachable: every insert below will fail per-route and be reported in `failed`
  }

  const tasks: Task[] = [];
  for (const [packId, gw] of gateways) {
    for (const origin of ORIGINS) {
      tasks.push({ kind: "flight", origin, packId, iata: gw.iata, label: `${origin}→${gw.iata}` });
    }
  }
  // Hotels: once per gateway city, not per origin.
  for (const [packId, gw] of gateways) {
    tasks.push({ kind: "hotel", packId, city: gw.city, label: `hotels:${slugify(gw.city)}` });
  }

  // Bound the runtime: at most ROUTE_CAP source calls per invocation. The window
  // rotates with the date so successive cron runs sweep the full route set.
  let batch = tasks;
  if (tasks.length > ROUTE_CAP) {
    const off = (Math.floor(Date.now() / DAY) * ROUTE_CAP) % tasks.length;
    batch = [...tasks.slice(off), ...tasks.slice(0, off)].slice(0, ROUTE_CAP);
  }

  const checkIn = isoDay(30);
  const checkOut = isoDay(33);

  let inserted = 0;
  const failed: string[] = [];

  for (let i = 0; i < batch.length; i++) {
    const t = batch[i];
    try {
      if (t.kind === "flight") {
        const deals = (await src.flightDeals(t.origin, t.iata)).slice(0, 3); // cheapest 3
        if (deals.length) {
          await db.insert(tables.priceSnapshots).values(
            deals.map((d) => ({
              kind: "flight",
              origin: d.origin,
              destCode: d.destCode,
              destId: knownDestIds.has(t.packId) ? t.packId : null,
              priceInr: d.priceInr,
              meta: {
                airline: d.airline,
                departAt: d.departAt,
                returnAt: d.returnAt,
                transfers: d.transfers,
                deepLink: d.deepLink,
              },
              source: src.name,
            })),
          );
          inserted += deals.length;
        }
      } else {
        const deals = await src.hotelDeals(t.city, checkIn, checkOut);
        if (deals.length) {
          const prices = deals.map((d) => d.priceInr).sort((a, b) => a - b);
          const mid = prices.length >> 1;
          const median =
            prices.length % 2 ? prices[mid] : Math.round((prices[mid - 1] + prices[mid]) / 2);
          const stars = deals
            .map((d) => d.stars)
            .filter((s): s is number => typeof s === "number");
          await db.insert(tables.priceSnapshots).values({
            kind: "hotel",
            origin: null,
            destCode: slugify(t.city),
            destId: knownDestIds.has(t.packId) ? t.packId : null,
            priceInr: median,
            meta: {
              city: t.city,
              sampleSize: deals.length,
              starsMin: stars.length ? Math.min(...stars) : undefined,
              starsMax: stars.length ? Math.max(...stars) : undefined,
              checkIn,
            },
            source: src.name,
          });
          inserted += 1;
        }
      }
    } catch {
      failed.push(t.label); // one bad route must not kill the run
    }
    if (i < batch.length - 1) await sleep(300); // courtesy pause between source calls
  }

  return NextResponse.json({ inserted, failed });
}

export async function GET(req: Request) {
  return runRefresh(req);
}

export async function POST(req: Request) {
  return runRefresh(req);
}

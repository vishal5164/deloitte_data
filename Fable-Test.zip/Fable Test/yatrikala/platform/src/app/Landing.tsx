"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Logo from "@/components/Logo";
import "./landing.css";

export interface MarqueeCard {
  id: string; name: string; flag: string; tagline: string; budgetBand: string; visaLabel: string; visaEase: number;
}
export interface PersonaPitch {
  id: string; label: string; flag: string; line: string; from: string;
}

const SKIES: Record<string, string> = {
  vietnam: "linear-gradient(135deg,#1F6E5C,#7FBFA0)", japan: "linear-gradient(135deg,#2A3559,#C4718C)",
  bali: "linear-gradient(135deg,#1E7A5A,#E2C36B)", thailand: "linear-gradient(135deg,#0F7E8C,#F0A860)",
  srilanka: "linear-gradient(135deg,#2E7D4F,#C9A24B)", dubai: "linear-gradient(135deg,#B98A3E,#E8C98A)",
  singapore: "linear-gradient(135deg,#4A3E8C,#3FA9A0)", georgia: "linear-gradient(135deg,#6E2F45,#5A6B85)",
  kazakhstan: "linear-gradient(135deg,#3E5C76,#7FB6C9)", greece: "linear-gradient(135deg,#1F4E9C,#8FB8E8)",
  switzerland: "linear-gradient(135deg,#3C6E91,#BFDCE8)", italy: "linear-gradient(135deg,#A85A3C,#7A8C4F)",
  maldives: "linear-gradient(135deg,#0F8C9C,#7FE0D6)", cambodia: "linear-gradient(135deg,#6E4F2F,#C9A24B)",
  armenia: "linear-gradient(135deg,#8C3E4F,#C98A6B)", southkorea: "linear-gradient(135deg,#3A2E59,#C4899C)",
  malaysia: "linear-gradient(135deg,#1F5E7A,#7FC9A8)", philippines: "linear-gradient(135deg,#0F7E9C,#8FE0C9)",
  mauritius: "linear-gradient(135deg,#0F6E8C,#9FE0D0)", seychelles: "linear-gradient(135deg,#0F8C8C,#B8ECD9)",
  nepal: "linear-gradient(135deg,#3E4C76,#A8C4E0)", bhutan: "linear-gradient(135deg,#6E3A2F,#E0B860)",
  uzbekistan: "linear-gradient(135deg,#2E6E7A,#C9B44B)", oman: "linear-gradient(135deg,#9C6E3E,#E8D0A0)",
  egypt: "linear-gradient(135deg,#B08A4E,#E8D9A8)", uk: "linear-gradient(135deg,#3E4759,#9CA8C4)",
  france: "linear-gradient(135deg,#2E3E76,#C4A8B8)", spain: "linear-gradient(135deg,#A8442F,#E8B860)",
  australia: "linear-gradient(135deg,#B85E3C,#7FB6C9)", newzealand: "linear-gradient(135deg,#2E5E4F,#A8D9C4)",
};
const LANDMARKS: Record<string, string> = {
  vietnam: "🏮", japan: "⛩️", bali: "🌺", thailand: "🛕", srilanka: "🚂", dubai: "🌇", singapore: "🦁",
  georgia: "🍷", kazakhstan: "🏔", greece: "🏛", switzerland: "🚞", italy: "🛵", maldives: "🐠",
  cambodia: "🛕", armenia: "⛪", southkorea: "🏯", malaysia: "🏙", philippines: "🏝", mauritius: "🐬",
  seychelles: "🐢", nepal: "🏔", bhutan: "🐉", uzbekistan: "🕌", oman: "🏜", egypt: "🐫",
  uk: "🎡", france: "🗼", spain: "💃", australia: "🐨", newzealand: "🐑",
};

const PERSONA_ICONS: Record<string, React.ReactNode> = {
  couple: <svg viewBox="0 0 48 48"><circle className="st" cx="19" cy="24" r="10" /><circle className="st" cx="29" cy="24" r="10" /></svg>,
  family: <svg viewBox="0 0 48 48"><circle className="st" cx="20" cy="20" r="9" /><circle className="st" cx="32" cy="29" r="6" /><path className="st" d="M 14 38 Q 24 32 38 38" /></svg>,
  seniors: <svg viewBox="0 0 48 48"><path className="st" d="M 8 34 L 40 34" /><circle className="st" cx="24" cy="24" r="9" /><path className="st" d="M 24 8 L 24 12 M 38 13 L 35 16 M 10 13 L 13 16" /></svg>,
  friends: <svg viewBox="0 0 48 48"><circle className="st" cx="24" cy="16" r="7" /><circle className="st" cx="14" cy="31" r="7" /><circle className="st" cx="34" cy="31" r="7" /></svg>,
  solo: <svg viewBox="0 0 48 48"><path className="fl" d="M 24 8 L 27.5 20.5 L 40 24 L 27.5 27.5 L 24 40 L 20.5 27.5 L 8 24 L 20.5 20.5 Z" /></svg>,
};

// deterministic star field (no Math.random — hydration-safe)
const STARS = Array.from({ length: 26 }, (_, i) => ({
  left: `${(i * 37 + 11) % 100}%`,
  top: `${(i * 53 + 7) % 88}%`,
  delay: `${(i % 7) * 0.55}s`,
}));

function CountUp({ to, suffix, decimals = 0 }: { to: number; suffix: string; decimals?: number }) {
  const ref = useRef<HTMLElement>(null);
  const [val, setVal] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let started = false;
    const start = () => {
      if (started) return;
      started = true;
      const t0 = performance.now();
      const tick = (t: number) => {
        const p = Math.min(1, (t - t0) / 1400);
        setVal(to * (1 - Math.pow(1 - p, 3)));
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    };
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { io.disconnect(); start(); }
    }, { threshold: 0.4 });
    io.observe(el);
    // fail-open: if IO never fires or rAF is throttled (background/embedded tabs),
    // skip the animation entirely and show the real number.
    const safety = setTimeout(() => { started = true; setVal(to); }, 3000);
    return () => { clearTimeout(safety); io.disconnect(); };
  }, [to]);
  return <b ref={ref}>{val.toFixed(decimals)}{suffix}</b>;
}

export default function Landing({ pitches, cards }: { pitches: PersonaPitch[]; cards: MarqueeCard[] }) {
  /* persona morph bar: auto-cycles until the visitor touches it */
  const [pi, setPi] = useState(0);
  const [fading, setFading] = useState(false);
  const userTouched = useRef(false);
  useEffect(() => {
    const id = setInterval(() => {
      if (userTouched.current) return;
      setFading(true);
      setTimeout(() => { setPi((p) => (p + 1) % pitches.length); setFading(false); }, 250);
    }, 3200);
    return () => clearInterval(id);
  }, [pitches.length]);
  const pickPersona = (i: number) => {
    userTouched.current = true;
    setFading(true);
    setTimeout(() => { setPi(i); setFading(false); }, 180);
  };

  /* journey rail: reveal days + move the travelling dot with scroll */
  const journeyRef = useRef<HTMLDivElement>(null);
  const dotRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const days = journeyRef.current?.querySelectorAll(".ld-day");
    if (!days) return;
    // Fail-open reveal: content is visible by default; we only hide it ("pre")
    // once JS runs, then IO un-hides with the animation. If IO never fires
    // (odd embeds, extensions), the safety timer restores everything.
    days.forEach((d) => d.classList.add("pre"));
    const io = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.isIntersecting && e.target.classList.add("in")),
      { threshold: 0.25 },
    );
    days.forEach((d) => io.observe(d));
    const safety = setTimeout(() => days.forEach((d) => d.classList.add("in")), 2500);
    const onScroll = () => {
      const j = journeyRef.current, dot = dotRef.current;
      if (!j || !dot) return;
      const r = j.getBoundingClientRect();
      const p = Math.min(1, Math.max(0, (window.innerHeight * 0.55 - r.top) / r.height));
      dot.style.top = `${8 + p * 84}%`;
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      clearTimeout(safety);
      io.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, []);

  const pitch = pitches[pi];
  const half = Math.ceil(cards.length / 2);
  const rowA = cards.slice(0, half);
  const rowB = cards.slice(half);

  return (
    <>
      {/* ---------- HERO ---------- */}
      <section className="ld-hero">
        {STARS.map((s, i) => (
          <i key={i} className="ld-star" style={{ left: s.left, top: s.top, animationDelay: s.delay }} />
        ))}
        <Logo size={62} />
        <div className="mark" style={{ marginTop: 10 }}>YATRIKALA</div>
        <div className="marksub">THE ART OF TRAVEL</div>

        <svg className="ld-constellation" viewBox="0 0 900 240" xmlns="http://www.w3.org/2000/svg" aria-hidden>
          <circle cx="36" cy="196" r="6" fill="#F5AE3D" />
          <text x="36" y="226" textAnchor="middle" fontSize="13" fill="#FAF5EC" opacity=".7">you</text>
          <path className="ld-route" d="M 46 190 C 150 90, 280 150, 360 110 S 570 30, 668 78 S 820 120, 856 96"
            fill="none" stroke="#F5AE3D" strokeWidth="2.6" strokeLinecap="round" strokeDasharray="0.1 12" />
          <g className="ld-wp" style={{ animationDelay: "1.1s" }}>
            <path className="wp-star" d="M 300 122 l 3.2 8 8 3.2 -8 3.2 -3.2 8 -3.2 -8 -8 -3.2 8 -3.2 Z" />
            <text x="300" y="164">🏮 Hoi An</text>
          </g>
          <g className="ld-wp" style={{ animationDelay: "1.9s" }}>
            <path className="wp-star" d="M 520 52 l 3.2 8 8 3.2 -8 3.2 -3.2 8 -3.2 -8 -8 -3.2 8 -3.2 Z" />
            <text x="520" y="94">🍷 Tbilisi</text>
          </g>
          <g className="ld-wp" style={{ animationDelay: "2.7s" }}>
            <path className="wp-star" d="M 690 62 l 3.2 8 8 3.2 -8 3.2 -3.2 8 -3.2 -8 -8 -3.2 8 -3.2 Z" />
            <text x="690" y="104">⛩️ Kyoto</text>
          </g>
          <g className="ld-bigstar">
            <circle className="glow" cx="862" cy="90" r="26" fill="#F5AE3D" opacity=".3" />
            <path fill="#F5AE3D" d="M 862 66 L 868.5 83.5 L 886 90 L 868.5 96.5 L 862 114 L 855.5 96.5 L 838 90 L 855.5 83.5 Z" />
          </g>
        </svg>

        <h1>Where will your story go?</h1>
        <p className="sub">
          Bespoke journeys for Indian passports — auto-drafted in seconds, finished by hand.
          Thirty destinations. Five kinds of travellers. Zero package-tour energy.
        </p>
        <div className="ld-ctas">
          <Link href="/design" className="ld-begin">Design my journey ✦</Link>
          <Link href="/deals" className="ld-ghost">See real flight prices →</Link>
        </div>
        <div className="ld-scrollcue">scroll — the journey begins ↓</div>
      </section>

      {/* ---------- PERSONA MORPH ---------- */}
      <section className="ld-personas">
        <div className="inner">
          <div className="kicker">Who's travelling changes everything</div>
          <div className="ld-pchips" role="tablist" aria-label="Traveller type">
            {pitches.map((p, i) => (
              <button key={p.id} role="tab" aria-selected={i === pi}
                className={`ld-pchip ${i === pi ? "on" : ""}`} onClick={() => pickPersona(i)}>
                {PERSONA_ICONS[p.id]}{p.label}
              </button>
            ))}
          </div>
          <div className={`ld-pitch ${fading ? "fade" : ""}`} aria-live="polite">
            <span className="flag">{pitch.flag}</span>{pitch.line}
            <span className="from">{pitch.from}</span>
          </div>
        </div>
      </section>

      {/* ---------- THE JOURNEY ---------- */}
      <div className="ld-journey" ref={journeyRef}>
        <div className="ld-rail"><div className="dot" ref={dotRef} /></div>

        <div className="ld-day">
          <div className="badge"><b>Day 1</b><span>🧭</span></div>
          <h3>Tell us who's travelling</h3>
          <p>
            Two of you? Parents in tow? A stroller? The whole group chat? Sixty seconds of
            beautiful questions — and every day that follows is tuned to your people, your pace,
            your food rules, your real budget.
          </p>
        </div>

        <div className="ld-day">
          <div className="badge"><b>Day 2</b><span>✨</span></div>
          <h3>Watch it design itself</h3>
          <p>
            Our engine drafts the journey in front of you — day by day, priced in honest rupees,
            visa notes for Indian passports included. Like this:
          </p>
          <div className="ld-demo" aria-hidden>
            <div className="bar"><i /><i /><i /></div>
            <div className="row"><span className="dchip a1">💛 Two of us</span><span className="dchip">👶 Little ones</span><span className="dchip">🌿 Parents</span></div>
            <div className="row"><span className="dchip a2">⛩️ Japan</span><span className="dchip">🏮 Vietnam</span><span className="dchip">🍷 Georgia</span></div>
            <div className="dline l1" /><div className="dline l2" /><div className="dline l3" />
            <div className="dtitle">Japan, Just for Two ✦ 8 nights · ₹1.2L–1.7L pp</div>
          </div>
        </div>

        <div className="ld-day">
          <div className="badge"><b>Day 3</b><span>✍️</span></div>
          <h3>We finish it by hand</h3>
          <p>
            A human designer takes the draft and does what machines can't: the counter-seat
            reservation booked three weeks out, the train seats on the Mt Fuji side, a visa file
            assembled the way officers actually read them. Then it's yours — revised until it
            feels like you.
          </p>
        </div>
      </div>

      {/* ---------- STATS ---------- */}
      <section className="ld-stats">
        <div className="inner">
          <div className="ld-stat"><CountUp to={32.7} suffix="M" decimals={1} /><span>international trips by Indians in 2025 — the boom is real</span></div>
          <div className="ld-stat"><CountUp to={15.8} suffix="%" decimals={1} /><span>of Indian Schengen applications get refused — we design files that don't</span></div>
          <div className="ld-stat"><CountUp to={30} suffix="" /><span>destinations, five kinds of travellers, one studio</span></div>
        </div>
      </section>

      {/* ---------- MARQUEE ---------- */}
      <section className="ld-mq">
        <div className="head">
          <h2>Thirty canvases. Pick yours — or club two together.</h2>
          <div className="sub">Every card opens the Journey Designer. Routes with two countries come pre-stitched, transit and all.</div>
        </div>
        {[rowA, rowB].map((row, r) => (
          <div key={r} className={`ld-mqrow ${r === 1 ? "rev" : ""}`}>
            {[...row, ...row].map((c, i) => (
              <Link key={`${c.id}-${i}`} href="/design" className="ld-card">
                <div className="sky" style={{ background: SKIES[c.id] ?? "var(--ink)" }}>{LANDMARKS[c.id] ?? c.flag}</div>
                <div className="b">
                  <div className="n">{c.flag} {c.name}</div>
                  <div className="t">{c.tagline}</div>
                  <div className="meta"><span className="pip">{c.budgetBand}</span><span className={`pip v${c.visaEase}`}>{c.visaLabel}</span></div>
                </div>
              </Link>
            ))}
          </div>
        ))}
      </section>

      {/* ---------- TIERS ---------- */}
      <section className="ld-tiers">
        <h2 className="h-sec" style={{ justifyContent: "center" }}>Design fees — the only thing you pay us</h2>
        <p className="subnote" style={{ textAlign: "center" }}>You book every flight, stay and experience yourself, at cost. No hidden margins, ever.</p>
        <div className="grid">
          <div className="ld-tier">
            <h4>Short Escape</h4>
            <div className="price">₹4,999<small> +</small></div>
            <p>Up to 5 nights, one destination. Long weekends, visa-free hops, first trips abroad.</p>
            <ul><li>Day-by-day with insider tips</li><li>Honest budget sheet</li><li>One revision round</li></ul>
          </div>
          <div className="ld-tier hot">
            <div className="ribbon">Most chosen</div>
            <h4>International Signature</h4>
            <div className="price">₹12,999<small> +</small></div>
            <p>6–12 nights, up to two countries clubbed into one seamless route.</p>
            <ul><li>Full visa file, refusal-proofed</li><li>Stays shortlist + reservations plan</li><li>Two revision rounds</li></ul>
          </div>
          <div className="ld-tier">
            <h4>Grand Voyage</h4>
            <div className="price">₹24,999<small> +</small></div>
            <p>Honeymoons, milestones, multi-country epics of 10–16 nights.</p>
            <ul><li>Everything in Signature</li><li>Splurge moments, staged</li><li>On-trip WhatsApp concierge</li></ul>
          </div>
        </div>
      </section>

      {/* ---------- CLOSE ---------- */}
      <section className="ld-close">
        <div className="ink-panel">
          <h2>The next great trip in your camera roll<br />hasn't been designed yet.</h2>
          <p className="sub">Sixty seconds from now, you'll be looking at its first draft.</p>
          <Link href="/design" className="ld-begin">Begin ✦</Link>
        </div>
      </section>
    </>
  );
}

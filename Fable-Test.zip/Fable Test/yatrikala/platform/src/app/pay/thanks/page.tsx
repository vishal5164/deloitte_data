import Link from "next/link";
import type { Metadata } from "next";
import TopNav from "@/components/TopNav";

export const metadata: Metadata = {
  title: "Payment received",
};

const NEXT_STEPS = [
  {
    step: "01",
    title: "We confirm within a few hours",
    body: "You'll get a WhatsApp or email from your designer confirming the payment and your trip dates. If anything looks off, reply there — a human reads it.",
  },
  {
    step: "02",
    title: "Your designer gets to work",
    body: "Reservations plan, stays shortlist, visa file — the hand-finishing begins now. Expect the first working draft in 2–3 days.",
  },
  {
    step: "03",
    title: "You review, we refine",
    body: "Nothing is final until you love it. Swap a day, stretch a budget, add a surprise — refinements are part of the fee, not extras.",
  },
];

type SearchParams = Promise<Record<string, string | string[] | undefined>>;

export default async function PayThanksPage(props: { searchParams: SearchParams }) {
  const sp = await props.searchParams;
  const raw = sp.razorpay_payment_link_reference_id;
  const reference = Array.isArray(raw) ? raw[0] : raw;

  return (
    <>
      <TopNav />
      <main className="wrap-narrow" style={{ paddingTop: 24, paddingBottom: 48 }}>
        <section
          className="ink-panel rise"
          style={{ textAlign: "center", padding: "clamp(32px, 5vw, 52px)" }}
        >
          <div className="routeline" aria-hidden="true" style={{ margin: "0 auto 18px" }}>
            <span className="rl-dot" />
            <span className="rl-dash" />
            <span className="rl-star">✦</span>
          </div>
          <h1 style={{ fontSize: "clamp(24px, 4vw, 32px)" }}>
            Payment received — your journey is officially in the studio ✦
          </h1>
          <p style={{ color: "var(--sand)", marginTop: 12, fontSize: 15 }}>
            Thank you. The design fee is in, the drafting table is yours, and a real person now
            owns your trip.
          </p>
          {reference ? (
            <p className="num" style={{ marginTop: 16, fontSize: 13, color: "var(--gold-soft)" }}>
              Invoice reference: {reference}
            </p>
          ) : null}
        </section>

        <h2 className="h-sec">What happens next</h2>
        <div style={{ display: "grid", gap: 12 }}>
          {NEXT_STEPS.map((s) => (
            <div key={s.step} className="card" style={{ display: "flex", gap: 16 }}>
              <div
                className="serif"
                style={{ color: "var(--marigold)", fontSize: 22, lineHeight: 1.2 }}
              >
                {s.step}
              </div>
              <div>
                <h3
                  className="serif"
                  style={{ color: "var(--ink)", fontWeight: 400, fontSize: 17 }}
                >
                  {s.title}
                </h3>
                <p style={{ fontSize: 14, marginTop: 6 }}>{s.body}</p>
              </div>
            </div>
          ))}
        </div>

        <div style={{ textAlign: "center", marginTop: 32 }}>
          <Link href="/" className="btn-ghost">
            Back to Yatrikala home
          </Link>
        </div>
      </main>
    </>
  );
}

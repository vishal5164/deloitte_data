import type { Metadata } from "next";
import Link from "next/link";
import { eq } from "drizzle-orm";
import { db, tables } from "@/db";
import { loadPacks } from "@/content/loadPacks";
import { MINI_IDS, MONTHS, PERSONAS, inr } from "@/engine";
import type { DestinationPack, Persona } from "@/engine";
import type { InsightBody } from "@/lib/claude";
import TopNav from "@/components/TopNav";

export const revalidate = 3600;

export const metadata: Metadata = {
  title: "What travellers like you actually do",
  description:
    "Trip lengths, months, moods and hard-won advice from real Yatrikala journey drafts — what couples, families and solo travellers on Indian passports actually plan.",
};

/** Friendly persona labels for the selector chips. */
const PERSONA_LABELS: Record<Persona, string> = {
  couple: "Two of us",
  family: "With little ones",
  seniors: "With parents",
  friends: "The squad",
  solo: "Just me",
};

/** Plural nouns for headlines: "What couples plan for Japan". */
const PERSONA_NOUNS: Record<Persona, string> = {
  couple: "couples",
  family: "families",
  seniors: "parents-along trips",
  friends: "friend squads",
  solo: "solo travellers",
};

function median(ns: number[]): number | null {
  if (!ns.length) return null;
  const s = [...ns].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : Math.round((s[mid - 1] + s[mid]) / 2);
}

function topN<T>(items: T[], n: number): T[] {
  const counts = new Map<T, number>();
  for (const it of items) counts.set(it, (counts.get(it) ?? 0) + 1);
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([k]) => k);
}

/** Build the same InsightBody shape from a live lightweight aggregate over briefs. */
function liveBody(
  dest: string,
  persona: Persona,
  pack: DestinationPack | null,
  briefs: { destIds: string[]; comboKey: string | null; month: number; nights: number; vibes: string[] }[],
): InsightBody {
  const mine = briefs.filter(
    (b) => (b.destIds ?? []).includes(dest) || (b.comboKey ?? "").split("+").includes(dest),
  );
  const med = median(mine.map((b) => b.nights));
  const months = topN(mine.map((b) => b.month), 3).map((m) => MONTHS[m] ?? "");
  const vibes = topN(mine.flatMap((b) => b.vibes ?? []), 3);
  const destName = pack ? pack.name.split(" (")[0] : dest;
  return {
    headline: `What ${PERSONA_NOUNS[persona]} plan for ${destName}`,
    stats: [
      { label: "Drafts designed here", value: String(mine.length) },
      { label: "Median trip length", value: med ? `${med} nights` : "—" },
      { label: "Most-picked months", value: months.filter(Boolean).join(", ") || "—" },
      ...(pack
        ? [{ label: "Budget floor (7n, ex-flights)", value: `from ${inr(pack.budgetFloorPP)} pp` }]
        : []),
    ],
    patterns: vibes.length ? [`Most requested moods: ${vibes.join(", ")}`] : [],
    advice: pack?.whyGo ?? [],
    sources: "Aggregated live from anonymised Yatrikala journey drafts.",
  };
}

export default async function InsightsPage(props: {
  searchParams: Promise<{ dest?: string; persona?: string }>;
}) {
  const sp = await props.searchParams;
  const packs = (await loadPacks()).filter((p) => !MINI_IDS.includes(p.id));

  const persona: Persona = (PERSONAS as string[]).includes(sp.persona ?? "")
    ? (sp.persona as Persona)
    : "couple";
  const dest = packs.some((p) => p.id === sp.dest)
    ? (sp.dest as string)
    : packs.some((p) => p.id === "japan")
      ? "japan"
      : packs[0]?.id ?? "japan";
  const pack = packs.find((p) => p.id === dest) ?? null;
  const destName = pack ? pack.name.split(" (")[0] : dest;

  // 1) Cached research pass, if the weekly cron has run for this pair.
  let body: InsightBody | null = null;
  let updatedAt: Date | null = null;
  let isLive = false;
  let dbDown = false;

  try {
    const rows = await db
      .select()
      .from(tables.insightsCache)
      .where(eq(tables.insightsCache.key, `${dest}:${persona}`))
      .limit(1);
    if (rows.length) {
      body = rows[0].body as InsightBody;
      updatedAt = rows[0].updatedAt;
    }
  } catch {
    dbDown = true;
  }

  // 2) No cache yet → lightweight live aggregate straight from briefs.
  if (!body && !dbDown) {
    try {
      const rows = await db
        .select({
          destIds: tables.briefs.destIds,
          comboKey: tables.briefs.comboKey,
          month: tables.briefs.month,
          nights: tables.briefs.nights,
          vibes: tables.briefs.vibes,
        })
        .from(tables.briefs)
        .where(eq(tables.briefs.persona, persona));
      body = liveBody(dest, persona, pack, rows);
      isLive = true;
    } catch {
      dbDown = true;
    }
  }

  const chipStyle = { textDecoration: "none" } as const;

  return (
    <>
      <TopNav active="/insights" />
      <main className="wrap" style={{ paddingTop: 34, paddingBottom: 60 }}>
        <p
          className="fine"
          style={{ letterSpacing: ".14em", textTransform: "uppercase", color: "var(--terracotta)" }}
        >
          Travellers like you
        </p>
        <h1 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 32, margin: "4px 0 6px" }}>
          What people planning your trip actually do
        </h1>
        <p className="subnote" style={{ maxWidth: 620 }}>
          Every journey drafted on Yatrikala teaches us something. Pick your destination and your
          travelling party — we&apos;ll show you the patterns, honestly sourced.
        </p>

        {/* Selector: destination chips */}
        <div style={{ margin: "18px 0 10px" }}>
          <span className="fine" style={{ display: "block", marginBottom: 7, fontWeight: 600, color: "var(--ink)" }}>
            Where to?
          </span>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {packs.map((p) => (
              <Link
                key={p.id}
                href={`/insights?dest=${p.id}&persona=${persona}`}
                className={p.id === dest ? "chip sel" : "chip"}
                style={chipStyle}
              >
                <span>{p.flag}</span> {p.name.split(" (")[0]}
              </Link>
            ))}
          </div>
        </div>

        {/* Selector: persona chips */}
        <div style={{ margin: "14px 0 8px" }}>
          <span className="fine" style={{ display: "block", marginBottom: 7, fontWeight: 600, color: "var(--ink)" }}>
            Who&apos;s going?
          </span>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {PERSONAS.map((p) => (
              <Link
                key={p}
                href={`/insights?dest=${dest}&persona=${p}`}
                className={p === persona ? "chip sel" : "chip"}
                style={chipStyle}
              >
                {PERSONA_LABELS[p]}
              </Link>
            ))}
          </div>
        </div>

        {dbDown && (
          <div className="card" style={{ marginTop: 28, textAlign: "center", padding: "36px 24px" }}>
            <div style={{ fontSize: 30, marginBottom: 8 }}>✦</div>
            <h2 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 21, marginBottom: 6 }}>
              The research desk is still unpacking
            </h2>
            <p className="subnote" style={{ maxWidth: 460, margin: "0 auto" }}>
              Our traveller-pattern database isn&apos;t reachable right now. Insights for {destName} will
              appear here once the first journeys are designed — check back soon.
            </p>
          </div>
        )}

        {body && (
          <article className="rise" style={{ marginTop: 30 }}>
            <h2 className="serif" style={{ color: "var(--ink)", fontWeight: 400, fontSize: 26, marginBottom: 4 }}>
              {body.headline}
            </h2>
            {isLive && (
              <p className="subnote">
                Live snapshot from journey drafts — the first full research pass runs weekly.
              </p>
            )}

            {body.stats.length > 0 && (
              <>
                <h3 className="h-sec">The numbers</h3>
                <div className="kpis">
                  {body.stats.map((s) => (
                    <div className="kpi" key={s.label}>
                      <b>{s.label}</b>
                      <div className="v" style={s.value.length > 14 ? { fontSize: 18, lineHeight: 1.3 } : undefined}>
                        {s.value}
                      </div>
                    </div>
                  ))}
                </div>
              </>
            )}

            <h3 className="h-sec">What they actually do</h3>
            {body.patterns.length > 0 ? (
              <ul style={{ listStyle: "none", display: "grid", gap: 8 }}>
                {body.patterns.map((p, i) => (
                  <li key={i} className="card-flat" style={{ display: "flex", gap: 10, alignItems: "baseline" }}>
                    <span style={{ color: "var(--marigold)", flexShrink: 0 }}>✦</span>
                    <span>{p}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="subnote">
                No {PERSONA_LABELS[persona].toLowerCase()} journeys drafted for {destName} yet — yours
                would be the first pattern on this page.
              </p>
            )}

            {body.advice.length > 0 && (
              <>
                <h3 className="h-sec">Worth stealing</h3>
                <div style={{ display: "grid", gap: 8 }}>
                  {body.advice.map((a, i) => (
                    <div className="tipbox" key={i}>
                      {a}
                    </div>
                  ))}
                </div>
              </>
            )}

            <p className="fine" style={{ marginTop: 18 }}>
              {body.sources}
              {updatedAt &&
                ` · Last updated ${updatedAt.toLocaleDateString("en-IN", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}`}
            </p>
          </article>
        )}

        {/* Closing CTA */}
        <section className="ink-panel" style={{ marginTop: 44, textAlign: "center" }}>
          <h2 style={{ fontSize: 24, marginBottom: 8 }}>
            The patterns are interesting. Your trip shouldn&apos;t be one.
          </h2>
          <p style={{ opacity: 0.85, maxWidth: 520, margin: "0 auto 18px", fontSize: 14.5 }}>
            Answer five questions and watch a {destName} draft take shape — day by day, tuned to{" "}
            {PERSONA_LABELS[persona].toLowerCase()}.
          </p>
          <Link href="/design" className="cta gold">
            See what travellers like you get designed
          </Link>
        </section>
      </main>
    </>
  );
}

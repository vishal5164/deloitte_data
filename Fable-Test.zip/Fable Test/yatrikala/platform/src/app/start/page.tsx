import type { Metadata } from "next";
import TopNav from "@/components/TopNav";
import IntakeForm from "./IntakeForm";
import "./intake.css";

export const metadata: Metadata = {
  title: "Start your trip brief",
  description:
    "Five minutes of your answers become a trip designed by hand — visa paperwork for Indian passports to the last dinner reservation. Fixed design fee, you book everything at cost.",
};

/**
 * The "work with us" intake page. Server component: reads the WhatsApp number
 * from env and hands everything interactive to <IntakeForm/>.
 */
export default function StartPage() {
  const whatsappNumber = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "").replace(/\D/g, "");

  return (
    <>
      <TopNav />
      <main className="wrap-narrow" style={{ paddingBottom: 60 }}>
        <header style={{ textAlign: "center", padding: "36px 0 4px" }}>
          <h1 className="serif" style={{ color: "var(--ink)", fontSize: 30, fontWeight: 400 }}>
            Let&rsquo;s design your trip
          </h1>
          <div className="routeline" style={{ margin: "16px auto 12px" }}>
            <div className="rl-dot" />
            <div className="rl-dash" />
            <span className="rl-star">✦</span>
          </div>
          <p style={{ fontSize: 14.5, maxWidth: 460, margin: "0 auto" }}>
            Five minutes of your answers become a trip designed by hand — visa to last dinner
            reservation. Everything here stays between us.
          </p>
        </header>

        <IntakeForm whatsappNumber={whatsappNumber} />

        <p className="fine" style={{ textAlign: "center", marginTop: 30 }}>
          YATRIKALA · Journeys, designed by hand.
        </p>
      </main>
    </>
  );
}

"use client";

import { useEffect, useRef, useState } from "react";

/* ---------- option groups ---------- */

interface Opt { v: string; label: string }
const opts = (pairs: [string, string][]): Opt[] => pairs.map(([v, label]) => ({ v, label }));
const same = (vals: string[]): Opt[] => vals.map((v) => ({ v, label: v }));

const FLEX_OPTS = opts([
  ["Fixed — leave already approved", "Fixed"],
  ["Flexible by a few days", "Flexible ±few days"],
  ["Fully flexible — best time wins", "Fully flexible"],
]);
const OCCASION_OPTS = same([
  "Honeymoon", "Anniversary", "Family holiday", "Friends trip", "Solo", "Just because",
]);
const BUDGET_OPTS = opts([
  ["Under ₹50k pp (ex-flights)", "Under ₹50k"],
  ["₹50k–1L pp (ex-flights)", "₹50k–1L"],
  ["₹1L–2L pp (ex-flights)", "₹1–2L"],
  ["₹2L–4L pp (ex-flights)", "₹2–4L"],
  ["₹4L+ pp — comfort first", "₹4L+"],
]);
const STYLE_OPTS = opts([
  ["Slow mornings, no 6am starts", "Slow mornings"],
  ["Pack the days — see everything", "Pack the days"],
  ["Food is the point", "Food is the point"],
  ["Nature & landscapes", "Nature"],
  ["History & culture", "History & culture"],
  ["Adventure & adrenaline", "Adventure"],
  ["Shopping & markets", "Shopping"],
  ["Nightlife", "Nightlife"],
  ["Photography spots", "Photography"],
  ["Offbeat — away from crowds", "Offbeat"],
  ["Luxury touches where they matter", "Luxury touches"],
  ["Kid-friendly pacing", "Kid-friendly"],
]);
const HOTEL_OPTS = opts([
  ["Clean & central — 3★ is fine", "Clean & central"],
  ["Boutique / character stays", "Boutique"],
  ["4–5★ comfort", "4–5★"],
  ["Mix — splurge 1–2 nights", "Mix it up"],
]);
const FOOD_OPTS = opts([
  ["Vegetarian", "Vegetarian"],
  ["Jain", "Jain"],
  ["Halal", "Halal"],
  ["Eat everything", "Eat everything"],
  ["Need Indian food every couple of days", "Indian food nearby"],
]);

/* ---------- state shapes ---------- */

type GroupId = "flex" | "occasion" | "budget" | "style" | "hotel" | "food";
const MULTI = new Set<GroupId>(["style", "food"]);

interface Fields {
  name: string; phone: string; email: string; city: string;
  dest: string; dates: string; nights: string;
  adults: string; kids: string; mobility: string;
  passport: string; visa: string; history: string;
  must: string; avoid: string; notes: string;
}
const EMPTY_FIELDS: Fields = {
  name: "", phone: "", email: "", city: "",
  dest: "", dates: "", nights: "",
  adults: "", kids: "", mobility: "",
  passport: "", visa: "", history: "",
  must: "", avoid: "", notes: "",
};
const EMPTY_CHIPS: Record<GroupId, string[]> = {
  flex: [], occasion: [], budget: [], style: [], hotel: [], food: [],
};

const DRAFT_KEY = "yatrikala_intake_draft_v2";

function personaFromOccasion(occasion: string): string | undefined {
  if (occasion.startsWith("Honeymoon") || occasion.startsWith("Anniversary")) return "couple";
  if (occasion.startsWith("Family")) return "family";
  if (occasion.startsWith("Friends")) return "friends";
  if (occasion.startsWith("Solo")) return "solo";
  return undefined;
}

/* ---------- component ---------- */

export default function IntakeForm({ whatsappNumber }: { whatsappNumber: string }) {
  const [f, setF] = useState<Fields>(EMPTY_FIELDS);
  const [chips, setChips] = useState<Record<GroupId, string[]>>(EMPTY_CHIPS);
  const [view, setView] = useState<"form" | "done">("form");
  const [brief, setBrief] = useState("");
  const [showError, setShowError] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [saved, setSaved] = useState<boolean | null>(null);
  const [copied, setCopied] = useState(false);
  const hydrated = useRef(false);
  const errRef = useRef<HTMLParagraphElement>(null);

  /* draft autosave — clients never lose answers */
  useEffect(() => {
    try {
      const raw = localStorage.getItem(DRAFT_KEY);
      if (raw) {
        const d = JSON.parse(raw) as { f?: Partial<Fields>; chips?: Partial<Record<GroupId, string[]>> };
        if (d.f) setF((p) => ({ ...p, ...d.f }));
        if (d.chips) setChips((p) => ({ ...p, ...d.chips }));
      }
    } catch { /* corrupt draft — start fresh */ }
    hydrated.current = true;
  }, []);
  useEffect(() => {
    if (!hydrated.current) return;
    try { localStorage.setItem(DRAFT_KEY, JSON.stringify({ f, chips })); } catch { /* storage full/blocked */ }
  }, [f, chips]);

  const set = (k: keyof Fields) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) =>
      setF((p) => ({ ...p, [k]: e.target.value }));

  const toggle = (g: GroupId, v: string) =>
    setChips((p) => {
      const has = p[g].includes(v);
      if (MULTI.has(g)) return { ...p, [g]: has ? p[g].filter((x) => x !== v) : [...p[g], v] };
      return { ...p, [g]: has ? [] : [v] };
    });

  const first = (g: GroupId) => chips[g][0] ?? "";
  const joined = (g: GroupId) => chips[g].join(", ");
  const val = (k: keyof Fields) => f[k].trim();

  function buildBriefText(): string {
    const L: string[] = [];
    L.push("✦ YATRIKALA — TRIP BRIEF ✦", "");
    L.push(`Name: ${val("name")}`);
    L.push(`WhatsApp: ${val("phone")}${val("email") ? "  |  Email: " + val("email") : ""}`);
    L.push(`Departing from: ${val("city") || "—"}`, "");
    L.push(`Destination: ${val("dest")}`);
    L.push(`Dates: ${val("dates")} (${first("flex") || "flexibility not stated"})`);
    L.push(`Nights: ${val("nights") || "—"}`);
    L.push(`Occasion: ${first("occasion") || "—"}`, "");
    L.push(`Travellers: ${val("adults") || "?"} adult(s); children: ${val("kids") || "none"}`);
    if (val("mobility")) L.push(`Considerations: ${val("mobility")}`);
    L.push(`Budget: ${first("budget") || "not stated"}`, "");
    L.push(`Style: ${joined("style") || "—"}`);
    L.push(`Hotels: ${first("hotel") || "—"}`);
    L.push(`Food: ${joined("food") || "—"}`, "");
    L.push(`Passport 6+ months: ${val("passport") || "—"}`);
    L.push(`Visa rejections: ${val("visa") || "—"}`);
    L.push(`Travel history (5 yrs): ${val("history") || "—"}`);
    if (val("must")) { L.push(""); L.push(`Must-haves: ${val("must")}`); }
    if (val("avoid")) L.push(`Must-avoids: ${val("avoid")}`);
    if (val("notes")) L.push(`Notes: ${val("notes")}`);
    return L.join("\n");
  }

  async function handleSubmit() {
    if (!val("name") || !val("phone") || !val("dest") || !val("dates")) {
      setShowError(true);
      errRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    setShowError(false);
    const text = buildBriefText();
    setBrief(text);
    setSubmitting(true);
    let ok = false;
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: val("name"),
          phone: val("phone"),
          email: val("email") || undefined,
          source: "intake",
          persona: personaFromOccasion(first("occasion")),
          destination: val("dest"),
          travelMonth: val("dates"),
          budgetBand: first("budget") || undefined,
          notes: text,
        }),
      });
      ok = res.ok;
    } catch {
      ok = false; // desk unreachable — the brief still reaches us via WhatsApp/copy
    }
    setSaved(ok);
    setSubmitting(false);
    setView("done");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function copyBrief() {
    try {
      await navigator.clipboard.writeText(brief);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch { /* clipboard blocked — user can select the text */ }
  }

  const chipRow = (g: GroupId, list: Opt[]) => (
    <div className="intake-chips">
      {list.map((o) => (
        <button
          key={o.v}
          type="button"
          className={"chip" + (chips[g].includes(o.v) ? " sel" : "")}
          onClick={() => toggle(g, o.v)}
        >
          {o.label}
        </button>
      ))}
    </div>
  );

  /* ---------- success view ---------- */
  if (view === "done") {
    return (
      <section className="card intake-sec rise" style={{ borderColor: "var(--marigold)" }}>
        <h2>Your trip brief ✦</h2>
        <p className="intake-hint">
          Review it, then send it to us on WhatsApp — we reply within 24 hours with next steps.
        </p>
        {saved === false && (
          <p className="tipbox" style={{ marginBottom: 10 }}>
            Our design desk couldn&rsquo;t be reached just now — nothing is lost. Send the brief on
            WhatsApp or copy it below and it still lands with us.
          </p>
        )}
        {saved === true && (
          <p className="fine" style={{ marginBottom: 6 }}>
            Logged with our design desk — a real person reads every brief.
          </p>
        )}
        <pre className="intake-pre">{brief}</pre>
        <div className="intake-actions">
          {whatsappNumber && (
            <a
              className="cta wa"
              href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(brief)}`}
              target="_blank"
              rel="noreferrer"
            >
              Send on WhatsApp →
            </a>
          )}
          <button type="button" className="btn-ghost" onClick={copyBrief}>
            {copied ? "Copied ✓" : "Copy brief"}
          </button>
          <button type="button" className="intake-back" onClick={() => setView("form")}>
            ← Edit my answers
          </button>
        </div>
      </section>
    );
  }

  /* ---------- form view ---------- */
  return (
    <div>
      <section className="card intake-sec">
        <h2>1 · About you</h2>
        <p className="intake-hint">So we can send your plan to the right person.</p>
        <label className="lbl">Your name</label>
        <input type="text" value={f.name} onChange={set("name")} placeholder="e.g. Ananya Sharma" />
        <div className="formrow">
          <div>
            <label className="lbl">WhatsApp number</label>
            <input type="tel" value={f.phone} onChange={set("phone")} placeholder="98XXXXXXXX" />
          </div>
          <div>
            <label className="lbl">Email <span className="intake-opt">(optional)</span></label>
            <input type="email" value={f.email} onChange={set("email")} placeholder="you@example.com" />
          </div>
        </div>
        <label className="lbl">Home city (departure)</label>
        <input type="text" value={f.city} onChange={set("city")} placeholder="e.g. Pune / Mumbai" />
      </section>

      <section className="card intake-sec">
        <h2>2 · The trip</h2>
        <label className="lbl">Where do you want to go?</label>
        <input
          type="text"
          value={f.dest}
          onChange={set("dest")}
          placeholder='e.g. "Japan", "Vietnam + Cambodia", or "surprise me — somewhere in November"'
        />
        <div className="formrow">
          <div>
            <label className="lbl">Roughly when?</label>
            <input type="text" value={f.dates} onChange={set("dates")} placeholder="e.g. 12–22 Nov, or Diwali week" />
          </div>
          <div>
            <label className="lbl">How many nights?</label>
            <input type="text" value={f.nights} onChange={set("nights")} placeholder="e.g. 8–10" />
          </div>
        </div>
        <label className="lbl">How fixed are the dates?</label>
        {chipRow("flex", FLEX_OPTS)}
        <label className="lbl">The occasion <span className="intake-opt">(if any)</span></label>
        {chipRow("occasion", OCCASION_OPTS)}
      </section>

      <section className="card intake-sec">
        <h2>3 · Who&rsquo;s travelling</h2>
        <div className="formrow">
          <div>
            <label className="lbl">Adults</label>
            <input type="number" min={1} value={f.adults} onChange={set("adults")} placeholder="2" />
          </div>
          <div>
            <label className="lbl">Children <span className="intake-opt">(ages)</span></label>
            <input type="text" value={f.kids} onChange={set("kids")} placeholder="e.g. 1 (age 6), or none" />
          </div>
        </div>
        <label className="lbl">
          Anyone over 65, or with mobility / health considerations? <span className="intake-opt">(optional)</span>
        </label>
        <input
          type="text"
          value={f.mobility}
          onChange={set("mobility")}
          placeholder="e.g. parents joining — prefer minimal walking days"
        />
      </section>

      <section className="card intake-sec">
        <h2>4 · Budget</h2>
        <p className="intake-hint">
          Per person, excluding international flights. An honest band gets you a better plan — we
          design to it, not above it.
        </p>
        {chipRow("budget", BUDGET_OPTS)}
      </section>

      <section className="card intake-sec">
        <h2>5 · Your style</h2>
        <p className="intake-hint">Pick as many as feel true.</p>
        {chipRow("style", STYLE_OPTS)}
        <label className="lbl">Hotel style</label>
        {chipRow("hotel", HOTEL_OPTS)}
        <label className="lbl">Food preferences</label>
        {chipRow("food", FOOD_OPTS)}
      </section>

      <section className="card intake-sec">
        <h2>6 · Passport &amp; visa</h2>
        <div className="formrow">
          <div>
            <label className="lbl">Passport valid beyond 6 months?</label>
            <select value={f.passport} onChange={set("passport")}>
              <option value="">Select…</option>
              <option>Yes, all travellers</option>
              <option>Not sure — will check</option>
              <option>No / expiring soon</option>
            </select>
          </div>
          <div>
            <label className="lbl">Any visa rejections before?</label>
            <select value={f.visa} onChange={set("visa")}>
              <option value="">Select…</option>
              <option>No</option>
              <option>Yes — will share details</option>
            </select>
          </div>
        </div>
        <label className="lbl">
          Countries visited in the last 5 years <span className="intake-opt">(helps with visa strategy)</span>
        </label>
        <input type="text" value={f.history} onChange={set("history")} placeholder="e.g. Thailand, Dubai, UK" />
      </section>

      <section className="card intake-sec">
        <h2>7 · The important bits</h2>
        <label className="lbl">Must-haves <span className="intake-opt">(non-negotiables)</span></label>
        <textarea
          value={f.must}
          onChange={set("must")}
          placeholder="e.g. TeamLab tickets, one onsen night, window seat on the Kandy train…"
        />
        <label className="lbl">Must-avoids</label>
        <textarea
          value={f.avoid}
          onChange={set("avoid")}
          placeholder="e.g. long bus rides, touristy group tours, seafood smells…"
        />
        <label className="lbl">Anything else we should know?</label>
        <textarea
          value={f.notes}
          onChange={set("notes")}
          placeholder="Proposal planned? Fear of heights? Tell us everything."
        />
      </section>

      {showError && (
        <p className="intake-err" ref={errRef}>
          Please fill your name, WhatsApp number, destination (or &ldquo;surprise me&rdquo;) and
          rough dates — we can&rsquo;t design without those.
        </p>
      )}

      <div className="intake-submitbar">
        <button type="button" className="cta" onClick={handleSubmit} disabled={submitting}>
          {submitting ? "Creating your brief…" : "Create my trip brief ✦"}
        </button>
      </div>
    </div>
  );
}

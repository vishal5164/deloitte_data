import type { Metadata } from "next";
import "./globals.css";

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: { default: "Yatrikala — the art of travel", template: "%s · Yatrikala" },
  description:
    "Bespoke itineraries for Indians travelling the world. Visa to last dinner reservation — designed by hand.",
  keywords: [
    "bespoke itinerary",
    "travel designer India",
    "custom trip planning",
    "visa documentation",
  ],
  openGraph: {
    siteName: "Yatrikala",
    type: "website",
    locale: "en_IN",
    title: "Yatrikala — the art of travel",
    description:
      "Bespoke itineraries for Indians travelling the world. Visa to last dinner reservation — designed by hand.",
  },
  twitter: {
    card: "summary_large_image",
    title: "Yatrikala — the art of travel",
    description:
      "Bespoke itineraries for Indians travelling the world. Visa to last dinner reservation — designed by hand.",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      {/* suppressHydrationWarning: browser extensions (Grammarly et al.) inject
          attributes into <body> before React hydrates — harmless, but noisy in dev. */}
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}

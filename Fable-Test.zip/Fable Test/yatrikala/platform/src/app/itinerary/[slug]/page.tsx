import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db, tables } from "@/db";
import type { Itinerary } from "@/engine";
import TopNav from "@/components/TopNav";
import ItineraryDoc from "@/components/ItineraryDoc";

export const metadata: Metadata = {
  title: "Your journey draft",
  description: "A Yatrikala journey draft — designed in seconds, finished by hand.",
};

export const dynamic = "force-dynamic";

/**
 * /itinerary/[slug] — public share page for a generated draft.
 * Looks the itinerary up by shareSlug; a missing row OR an unconfigured /
 * unreachable database both resolve to a clean 404 (the draft simply
 * "isn't here"), so the page never crashes before Supabase is set up.
 */
export default async function ItinerarySharePage(props: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await props.params;

  let row: { title: string; body: unknown; createdAt: Date } | null = null;
  try {
    const rows = await db
      .select({
        title: tables.itineraries.title,
        body: tables.itineraries.body,
        createdAt: tables.itineraries.createdAt,
      })
      .from(tables.itineraries)
      .where(eq(tables.itineraries.shareSlug, slug))
      .limit(1);
    row = rows[0] ?? null;
  } catch {
    row = null; // DB missing/unreachable → treat as not found
  }
  if (!row) notFound();

  const itinerary = row.body as Itinerary;
  const created = new Date(row.createdAt).toLocaleDateString("en-IN", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  return (
    <>
      <TopNav />
      <main className="jd-docwrap">
        <ItineraryDoc
          itinerary={itinerary}
          gate={true}
          waNumber={process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? ""}
          minFee="₹12,999"
        />
        <p className="fine" style={{ textAlign: "center", marginTop: 18 }}>
          Drafted on {created} · prices &amp; visa notes were indicative at draft time · Yatrikala
          charges a design fee only — you book everything at cost.
        </p>
      </main>
    </>
  );
}

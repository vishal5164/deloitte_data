import type { Metadata } from "next";
import TopNav from "@/components/TopNav";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Refund & Cancellation Policy",
  description:
    "When your advance comes back, when it transfers to a future trip, and what happens if we miss our own deadline — Yatrikala's refund policy in plain words.",
};

const EMAIL = "hello@yatrikala.com";

export default function RefundsPage() {
  const wa = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER ?? "").replace(/\D/g, "");

  return (
    <>
      <TopNav />
      <main className="wrap-narrow" style={{ paddingBottom: 40 }}>
        <header style={{ padding: "36px 0 4px" }}>
          <h1 className="serif" style={{ color: "var(--ink)", fontSize: 30, fontWeight: 400 }}>
            Refund &amp; Cancellation Policy
          </h1>
          <p className="subnote" style={{ marginTop: 6 }}>
            Last updated: July 2026 · The short version: fair to you, fair to the hours we put in.
          </p>
        </header>

        <h2 className="h-sec">Before design work begins</h2>
        <p style={{ fontSize: 14.5 }}>
          Your 50% advance is <b>fully refundable</b> at any point before we start designing. We
          always confirm the start of work with a message on WhatsApp — until you&apos;ve received
          that message, cancelling costs you nothing. Change of plans, change of heart, no
          questions.
        </p>

        <h2 className="h-sec">After the first draft is delivered</h2>
        <p style={{ fontSize: 14.5 }}>
          Once we&apos;ve delivered your first draft, the research and design hours are spent, so
          the advance is <b>non-refundable</b> — but it isn&apos;t lost. You can transfer it{" "}
          <b>once</b>, in full, to a future trip designed within <b>12 months</b> of the original
          payment. Postponed honeymoon, moved sabbatical — your advance moves with you.
        </p>

        <h2 className="h-sec">The balance</h2>
        <p style={{ fontSize: 14.5 }}>
          The remaining 50% is only charged at handover of your final itinerary. If a trip is
          cancelled before handover, you never pay the balance. There is nothing to refund because
          we never take it early.
        </p>

        <h2 className="h-sec">If we miss our own deadline</h2>
        <p style={{ fontSize: 14.5 }}>
          When we confirm the start of work, we also commit to a delivery window for your first
          draft. If we fail to deliver within that window, you get a <b>full refund of everything
          paid</b> — advance included, no transfer-credit fine print. Our deadline, our problem.
        </p>

        <h2 className="h-sec">Bookings you make yourself</h2>
        <p style={{ fontSize: 14.5 }}>
          Flights, hotels, trains and activities are booked by you, directly with the providers.
          Refunds and cancellations for those bookings follow <b>each provider&apos;s own policy</b>{" "}
          — we can point you to the right cancellation page, but we can&apos;t refund money we
          never held.
        </p>

        <h2 className="h-sec">How refunds are paid</h2>
        <p style={{ fontSize: 14.5 }}>
          Approved refunds go back to your <b>original payment method</b> (the card, UPI ID or
          account you paid with, via Razorpay) within <b>7 working days</b> of approval. Banks
          occasionally add a day or two on their side; if it&apos;s been longer, message us and
          we&apos;ll chase it.
        </p>

        <h2 className="h-sec">How to request one</h2>
        <p style={{ fontSize: 14.5 }}>
          Message us{" "}
          {wa ? (
            <>
              on{" "}
              <a
                href={`https://wa.me/${wa}`}
                target="_blank"
                rel="noopener noreferrer"
                style={{ color: "var(--terracotta)" }}
              >
                WhatsApp
              </a>{" "}
              or{" "}
            </>
          ) : null}
          at{" "}
          <a href={`mailto:${EMAIL}`} style={{ color: "var(--terracotta)" }}>
            {EMAIL}
          </a>{" "}
          with your name and payment reference. We&apos;ll confirm receipt the same day and tell
          you exactly which case above applies — no forms, no hold music.
        </p>
      </main>
      <Footer />
    </>
  );
}

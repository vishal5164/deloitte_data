/**
 * Seed/refresh destination packs from src/content/packs.json.
 * Idempotent upsert — safe to run repeatedly. Run: npm run db:seed
 * Uses DIRECT_DATABASE_URL (5432); falls back to DATABASE_URL.
 */
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { destinations } from "./schema";
import packs from "../content/packs.json";

async function main() {
  const url = process.env.DIRECT_DATABASE_URL ?? process.env.DATABASE_URL;
  if (!url) throw new Error("Set DIRECT_DATABASE_URL (or DATABASE_URL) before seeding");
  const client = postgres(url, { max: 1, prepare: false });
  const db = drizzle(client);

  for (const pack of packs as { id: string; name: string }[]) {
    await db
      .insert(destinations)
      .values({ id: pack.id, name: pack.name, pack, active: true, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: destinations.id,
        set: { name: pack.name, pack, updatedAt: new Date() },
      });
    console.log(`upserted ${pack.id}`);
  }
  await client.end();
  console.log(`seeded ${(packs as unknown[]).length} destinations`);
}

main().catch((e) => { console.error(e); process.exit(1); });

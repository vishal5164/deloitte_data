import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "./schema";

/**
 * Postgres client for Supabase.
 * - App traffic goes through the transaction pooler (DATABASE_URL, port 6543),
 *   so prepared statements must be disabled (pgbouncer transaction mode).
 * - `max: 1` per serverless instance; Vercel scales by instances, not pool size.
 */
const globalForDb = globalThis as unknown as { _pg?: ReturnType<typeof postgres> };

const client =
  globalForDb._pg ??
  postgres(process.env.DATABASE_URL!, {
    prepare: false,
    max: 1,
    idle_timeout: 20,
    connect_timeout: 10,
  });

if (process.env.NODE_ENV !== "production") globalForDb._pg = client;

export const db = drizzle(client, { schema });
export * as tables from "./schema";

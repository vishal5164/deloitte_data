import {
  pgTable, text, integer, boolean, timestamp, jsonb, uuid, index, uniqueIndex,
} from "drizzle-orm/pg-core";

/** Destination content packs (the engine's fuel). `pack` holds the full JSON pack. */
export const destinations = pgTable("destinations", {
  id: text("id").primaryKey(), // 'vietnam', 'japan', ...
  name: text("name").notNull(),
  pack: jsonb("pack").notNull(),
  active: boolean("active").notNull().default(true),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Every visitor brief captured by the Journey Designer (lead-gen gold + insights fuel). */
export const briefs = pgTable("briefs", {
  id: uuid("id").primaryKey().defaultRandom(),
  persona: text("persona").notNull(), // couple|family|seniors|friends|solo
  destIds: jsonb("dest_ids").$type<string[]>().notNull(),
  comboKey: text("combo_key"), // 'vietnam+cambodia' when clubbed
  month: integer("month").notNull(), // 0-11
  nights: integer("nights").notNull(),
  pace: text("pace").notNull(),
  vibes: jsonb("vibes").$type<string[]>().notNull().default([]),
  leadId: uuid("lead_id").references(() => leads.id),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("briefs_dest_idx").on(t.comboKey), index("briefs_persona_idx").on(t.persona)]);

/** Generated itineraries (draft = gated public one; bespoke = hand-finished). */
export const itineraries = pgTable("itineraries", {
  id: uuid("id").primaryKey().defaultRandom(),
  briefId: uuid("brief_id").references(() => briefs.id),
  title: text("title").notNull(),
  body: jsonb("body").notNull(), // engine Itinerary shape
  generator: text("generator").notNull().default("engine"), // engine|claude
  kind: text("kind").notNull().default("draft"), // draft|bespoke
  shareSlug: text("share_slug").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [uniqueIndex("itineraries_slug_idx").on(t.shareSlug)]);

export const leads = pgTable("leads", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  source: text("source").notNull().default("journey-designer"),
  persona: text("persona"),
  destination: text("destination"),
  travelMonth: text("travel_month"),
  budgetBand: text("budget_band"),
  status: text("status").notNull().default("new"), // new|brief|quoted|won|lost|cold
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [index("leads_status_idx").on(t.status)]);

export const quotes = pgTable("quotes", {
  id: uuid("id").primaryKey().defaultRandom(),
  leadId: uuid("lead_id").references(() => leads.id).notNull(),
  tripLabel: text("trip_label").notNull(), // "Japan — 8n honeymoon"
  amountInr: integer("amount_inr").notNull(), // design fee, whole rupees
  status: text("status").notNull().default("draft"), // draft|sent|accepted|expired
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Invoices: one quote → advance + balance. Numbering YTK-2026-0001. */
export const invoices = pgTable("invoices", {
  id: uuid("id").primaryKey().defaultRandom(),
  quoteId: uuid("quote_id").references(() => quotes.id).notNull(),
  number: text("number").notNull(),
  kind: text("kind").notNull(), // advance|balance
  amountInr: integer("amount_inr").notNull(),
  status: text("status").notNull().default("created"), // created|paid|failed|cancelled
  razorpayLinkId: text("razorpay_link_id"),
  razorpayPaymentId: text("razorpay_payment_id"),
  shortUrl: text("short_url"),
  issuedAt: timestamp("issued_at", { withTimezone: true }).notNull().defaultNow(),
  paidAt: timestamp("paid_at", { withTimezone: true }),
}, (t) => [uniqueIndex("invoices_number_idx").on(t.number)]);

export const payments = pgTable("payments", {
  id: uuid("id").primaryKey().defaultRandom(),
  invoiceId: uuid("invoice_id").references(() => invoices.id).notNull(),
  amountInr: integer("amount_inr").notNull(),
  method: text("method"),
  razorpayEvent: jsonb("razorpay_event"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Price observations: flights (origin+destCode) and hotels (city). */
export const priceSnapshots = pgTable("price_snapshots", {
  id: uuid("id").primaryKey().defaultRandom(),
  kind: text("kind").notNull(), // flight|hotel
  origin: text("origin"), // IATA for flights: DEL, BOM, BLR
  destCode: text("dest_code").notNull(), // IATA or city slug
  destId: text("dest_id").references(() => destinations.id),
  priceInr: integer("price_inr").notNull(),
  meta: jsonb("meta"), // {airline, departAt, returnAt, transfers} | {stars, checkIn}
  source: text("source").notNull(), // travelpayouts|amadeus|seed
  foundAt: timestamp("found_at", { withTimezone: true }).notNull().defaultNow(),
}, (t) => [
  index("prices_route_idx").on(t.kind, t.origin, t.destCode, t.foundAt),
  index("prices_dest_idx").on(t.destId),
]);

/** Cached "travellers like you" research per (destId|comboKey, persona). */
export const insightsCache = pgTable("insights_cache", {
  key: text("key").primaryKey(), // `${destKey}:${persona}`
  body: jsonb("body").notNull(), // InsightBody
  generatedBy: text("generated_by").notNull().default("aggregate"), // aggregate|claude
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

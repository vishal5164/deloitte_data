import Link from "next/link";

const LINKS = [
  { href: "/design", label: "Design a journey" },
  { href: "/deals", label: "Deals radar" },
  { href: "/insights", label: "Travellers like you" },
  { href: "/start", label: "Start a trip" },
  { href: "/terms", label: "Terms" },
  { href: "/privacy", label: "Privacy" },
  { href: "/refunds", label: "Refunds" },
];

/** Site-wide footer. Server component — pure markup, no state. */
export default function Footer() {
  return (
    <footer style={{ borderTop: "1px solid var(--sand)", marginTop: 20 }}>
      <div
        className="wrap"
        style={{
          padding: "28px 20px 36px",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 10,
        }}
      >
        <div className="routeline" aria-hidden="true">
          <span className="rl-dot" />
          <span className="rl-dash" />
          <span className="rl-dot" />
          <span className="rl-dash" />
          <span className="rl-star">✦</span>
        </div>
        <div className="wordmark" style={{ fontSize: 16 }}>
          YATRIKALA
        </div>
        <p className="fine">Journeys, designed by hand.</p>
        <nav
          aria-label="Footer"
          style={{
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "center",
            gap: "6px 18px",
            marginTop: 4,
          }}
        >
          {LINKS.map((l) => (
            <Link
              key={l.href}
              href={l.href}
              style={{ fontSize: 13, color: "var(--slate)", textDecoration: "none" }}
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <p className="fine" style={{ textAlign: "center", maxWidth: 560 }}>
          © Yatrikala · Pune, India · Design fees only — you book travel at cost. Affiliate links
          are disclosed and never change your price.
        </p>
      </div>
    </footer>
  );
}

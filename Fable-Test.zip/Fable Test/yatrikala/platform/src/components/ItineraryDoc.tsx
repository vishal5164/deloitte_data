"use client";

import { useRef, useState } from "react";
import { filterBlocks, MONTHS } from "@/engine";
import type { Itinerary, Persona, PlanItem } from "@/engine";
import "@/app/design/design.css";

/**
 * The branded itinerary document, shared by the Journey Designer result step
 * and the public share page (/itinerary/[slug]). Renders entirely from the
 * denormalised Itinerary shape — no packs or DB needed.
 */

const PERSONA_LABEL: Record<Persona, string> = {
  couple: "Two of us",
  family: "With little ones",
  seniors: "With parents",
  friends: "The squad",
  solo: "Just me",
};
const PERSONA_PHRASE: Record<Persona, string> = {
  couple: "the two of you",
  family: "your little ones",
  seniors: "your parents",
  friends: "the squad",
  solo: "you, solo",
};

type TransitItem = Extract<PlanItem, { transit: string }>;
type DayItem = Exclude<PlanItem, TransitItem>;
const isTransit = (p: PlanItem): p is TransitItem => "transit" in p;

function briefText(it: Itinerary, briefVibes?: string[], shareUrl?: string): string {
  return [
    "✦ YATRIKALA — JOURNEY DRAFT ✦",
    "",
    `Travelling as: ${PERSONA_LABEL[it.persona]}`,
    `Route: ${it.dispName}`,
    `When: ${MONTHS[it.month]} · ${it.nights} nights · ${it.pace} pace`,
    briefVibes && briefVibes.length ? `Mood: ${briefVibes.join(", ")}` : "",
    shareUrl ? `Draft: ${shareUrl}` : "",
    "",
    "I just designed this draft in the Journey Designer — I'd love the hand-finished version. (code: YATRA)",
  ]
    .filter(Boolean)
    .join("\n");
}

export interface ItineraryDocProps {
  itinerary: Itinerary;
  /** Deliberately absent: the doc renders from the denormalised itinerary alone. */
  packs?: undefined;
  /** true → days 3+ locked behind the design-fee CTA; false → everything open. */
  gate: boolean;
  waNumber?: string;
  minFee?: string;
  /** Optional: public share URL — adds a copy-link button to the CTA panel. */
  shareUrl?: string;
  /** Optional: the traveller's chosen moods, woven into the WhatsApp/copy brief. */
  briefVibes?: string[];
  /** Optional: fired when the WhatsApp CTA is clicked (lead capture hook). */
  onWhatsAppClick?: () => void;
}

export default function ItineraryDoc({
  itinerary: it,
  gate,
  waNumber,
  minFee,
  shareUrl,
  briefVibes,
  onWhatsAppClick,
}: ItineraryDocProps) {
  const ctaRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = useState<"brief" | "link" | null>(null);

  const personaLabel = PERSONA_LABEL[it.persona];
  const brief = briefText(it, briefVibes, shareUrl);
  const waHref = waNumber
    ? `https://wa.me/${waNumber}?text=${encodeURIComponent(brief)}`
    : null;

  function nudgeCTA() {
    const el = ctaRef.current;
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    el.classList.remove("jd-pulse");
    el.getBoundingClientRect(); // force reflow so the pulse animation restarts
    el.classList.add("jd-pulse");
  }

  function copyToClipboard(text: string, which: "brief" | "link") {
    navigator.clipboard
      .writeText(text)
      .then(() => {
        setCopied(which);
        setTimeout(() => setCopied((c) => (c === which ? null : c)), 2200);
      })
      .catch(() => {});
  }

  // Which non-transit days are shown in full
  const unlockedCount = gate ? 2 : Number.POSITIVE_INFINITY;
  const foods = gate ? it.foods.slice(0, 2) : it.foods;
  const foodsMore = it.foods.length - 2;

  let dayNo = 0;

  return (
    <div className="jd-doc">
      {/* ---------- cover ---------- */}
      <div className="jd-cover">
        <div className="mk">YATRIKALA</div>
        <div className="routeline">
          <div className="rl-dot" />
          <div className="rl-dash" />
          <div className="rl-star">✦</div>
        </div>
        <h1>{it.title}</h1>
        <div className="csub">{it.route}</div>
        <div className="cmeta">
          <span className="jd-cchip gold">{personaLabel}</span>
          <span className="jd-cchip">{it.style === "Smart" ? "💡 Smart budget" : it.style === "Luxe" ? "✨ Luxe" : "🛋️ Comfort"}</span>
          <span className="jd-cchip">{MONTHS[it.month]} · {it.nights} nights</span>
          <span className="jd-cchip">{it.pace} pace</span>
          <span className="jd-cchip">{it.budgetLine} ex-flights</span>
        </div>
      </div>

      <div className="jd-pad">
        {/* ---------- designed for you ---------- */}
        <h3 className="jd-sec">Designed for you</h3>
        <div className="jd-fyou">
          <b className="t">{`Because you're travelling as ${personaLabel.toLowerCase()}`}</b>
          <div className="row">
            <div><b>Pace</b>{it.personaNote.pace}</div>
            <div><b>Stays</b>{it.personaNote.stayStyle}</div>
            <div><b>One thing we insist on</b>{it.personaNote.tip}</div>
          </div>
        </div>

        {/* ---------- snapshot ---------- */}
        <h3 className="jd-sec">The trip at a glance</h3>
        <div className="jd-snap">
          <div className="jd-scard">
            <b className="k">Route</b>
            <div style={{ fontSize: 14, color: "var(--ink)" }}>{it.route}</div>
            <div className="jd-tags">
              {it.vibes.slice(0, 4).map((v) => (
                <span key={v} className="jd-tag">{v}</span>
              ))}
            </div>
          </div>
          <div className="jd-scard">
            <b className="k">Draft budget</b>
            <div style={{ fontSize: 15, color: "var(--ink)" }}><strong>{it.budgetLine}</strong></div>
            <div style={{ fontSize: 12, color: "var(--muted)", marginTop: 3 }}>
              ex international flights · full honest budget table comes with the designed version
            </div>
          </div>
          <div className="jd-scard" style={{ gridColumn: "1/-1" }}>
            <b className="k">Why this works</b>
            <ul>
              {it.whyGo.map((w) => (
                <li key={w}>{w}</li>
              ))}
            </ul>
            <div style={{ fontSize: 12.5, color: "var(--terracotta)", marginTop: 6 }}>✦ {it.seasonNote}</div>
          </div>
        </div>

        {/* ---------- visas ---------- */}
        <h3 className="jd-sec">Visa, for Indian passports</h3>
        {it.visas.map((v) => (
          <div className="jd-visa" key={v.name}>
            <div className="vg">
              <div>
                <b>{v.name}</b>
                {v.label}
                <span className="jd-pips">
                  {[1, 2, 3].map((i) => (
                    <i key={i} className={i <= v.ease ? "on" : ""} />
                  ))}
                </span>
              </div>
              <div><b>Timeline</b>{v.time}</div>
              <div><b>Cost</b>{v.cost}</div>
            </div>
            <div className="vnote">
              {v.note} · Full checklist + refusal-proof documentation comes with the designed version.
            </div>
          </div>
        ))}

        {/* ---------- day by day ---------- */}
        <h3 className="jd-sec">Day by day</h3>
        <div className="jd-secnote">
          {gate ? "Days 1–2 in full. The rest are designed — and waiting." : "Every day, in full."}
        </div>

        {it.plan.map((item, idx) => {
          if (isTransit(item)) {
            return (
              <div className="jd-transit" key={`t${idx}`}>
                ✈️{" "}
                <div>
                  <b>The stitch:</b> {item.transit} — booked right, you lose half a day, not a whole one.
                </div>
              </div>
            );
          }
          const d = item as DayItem;
          dayNo += 1;
          const n = dayNo;

          if (n > unlockedCount) {
            // locked teaser
            return (
              <button className="jd-locked" key={`d${idx}`} onClick={nudgeCTA} type="button">
                <span className="jd-lockchip">in your designed version</span>
                <div className="jd-dhead">
                  <span className="jd-dnum">Day {n}</span>
                  <span className="jd-dtitle">{d.icon ? `${d.icon} ` : ""}{d.title}</span>
                  <span className="jd-dcity">{d.city}</span>
                </div>
                <div className="teaser">{`"${d.teaser}"`}</div>
                <div className="jd-skel">
                  <i className="skeleton" />
                  <i className="skeleton" />
                  <i className="skeleton" />
                </div>
              </button>
            );
          }

          const blocks = d.leisure ? [] : filterBlocks(d, it.persona).slice(0, 4);
          const showFoot = Boolean(d.stay?.name || d.transport || d.dailyCost);
          return (
            <div className="jd-day" key={`d${idx}`}>
              <div className="jd-dhead">
                <span className="jd-dnum">Day {n}</span>
                <span className="jd-dtitle">{d.icon ? `${d.icon} ` : ""}{d.title}</span>
                <span className="jd-dcity">{d.city}</span>
              </div>
              <div className="jd-dbody">
                {d.leisure && d.teaser ? (
                  <div className="jd-blk">
                    <div className="w">All day</div>
                    <div><p style={{ marginTop: 0 }}>{d.teaser}</p></div>
                  </div>
                ) : null}
                {blocks.map((b, bi) => (
                  <div className="jd-blk" key={bi}>
                    <div className="w">{b.time}</div>
                    <div>
                      <b className="n">{b.name}</b>
                      <p>{b.details}</p>
                      {b.cost ? <span className="jd-cost">{b.cost}</span> : null}
                      {b.personas ? (
                        <span className="tag-gold">tuned for {personaLabel.toLowerCase()}</span>
                      ) : null}
                      {b.tip ? <div className="tipbox">{b.tip}</div> : null}
                    </div>
                  </div>
                ))}
                {d.moneyTips ? (
                  <div className="jd-money">
                    {(it.style === "Smart" || it.style === "Comfort") && d.moneyTips.smart ? (
                      <div className="jd-mtip smart">{d.moneyTips.smart}</div>
                    ) : null}
                    {(it.style === "Luxe" || it.style === "Comfort") && d.moneyTips.luxe ? (
                      <div className="jd-mtip luxe">{d.moneyTips.luxe}</div>
                    ) : null}
                  </div>
                ) : null}
              </div>
              {showFoot ? (
                <div className="jd-dfoot">
                  {d.stay?.name ? (
                    <span><b>Stay:</b> {d.stay.name}, {d.stay.area} · {d.stay.priceNight}/night</span>
                  ) : null}
                  {d.transport ? <span><b>Transport:</b> {d.transport}</span> : null}
                  {d.dailyCost ? <span><b>Day budget:</b> {d.dailyCost}</span> : null}
                </div>
              ) : null}
            </div>
          );
        })}

        {/* ---------- money moves ---------- */}
        {(it.moneyMoves?.smart?.length || it.moneyMoves?.luxe?.length) ? (
          <>
            <h3 className="jd-sec">Money moves</h3>
            <div className="jd-moves">
              {it.style !== "Luxe" && it.moneyMoves.smart.length ? (
                <>
                  <b className="k">💡 Spend less, miss nothing</b>
                  <ul>{it.moneyMoves.smart.map((m, i) => <li key={`s${i}`}>{m}</li>)}</ul>
                </>
              ) : null}
              {it.style !== "Smart" && it.moneyMoves.luxe.length ? (
                <>
                  <b className="k" style={{ marginTop: it.style === "Comfort" ? 12 : 0 }}>✨ Worth every rupee</b>
                  <ul>{it.moneyMoves.luxe.map((m, i) => <li key={`l${i}`}>{m}</li>)}</ul>
                </>
              ) : null}
            </div>
          </>
        ) : null}

        {/* ---------- foods ---------- */}
        <h3 className="jd-sec">Eat this</h3>
        <div className="jd-foodrow">
          {foods.map((f, i) => (
            <div className="jd-dish" key={`${f.name}-${i}`}>
              <b>{f.name}</b>
              {f.what}
            </div>
          ))}
          {gate && foodsMore > 0 ? (
            <div className="jd-dish more">+ {foodsMore} more, mapped to your route, in the designed version</div>
          ) : null}
        </div>

        {/* ---------- CTA ---------- */}
        {gate ? (
          <div className="jd-ctapanel" ref={ctaRef}>
            <h4>
              This draft took six seconds.
              <br />
              Your journey deserves a designer.
            </h4>
            <div className="cs">
              The hand-finished version: every day unlocked and verified, your visa file refusal-proofed,
              stays shortlisted in your budget, reservations planned — revised until it feels like yours.
              From {minFee ?? "₹12,999"}.
            </div>
            <div className="btns">
              {waHref ? (
                <a
                  className="cta wa"
                  href={waHref}
                  target="_blank"
                  rel="noreferrer"
                  onClick={onWhatsAppClick}
                >
                  Get it designed by hand →
                </a>
              ) : null}
              <button
                className="jd-ghostb"
                type="button"
                onClick={() => copyToClipboard(brief, "brief")}
              >
                {copied === "brief" ? "Copied ✓ — paste it to us on WhatsApp" : "Copy my trip brief"}
              </button>
              {shareUrl ? (
                <button
                  className="jd-ghostb"
                  type="button"
                  onClick={() => copyToClipboard(shareUrl, "link")}
                >
                  {copied === "link" ? "Link copied ✓" : "Copy my share link"}
                </button>
              ) : null}
            </div>
            <div className="jd-fine">
              Draft prices &amp; visa notes are indicative · Yatrikala charges a design fee only — you book
              everything at cost.
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

export { PERSONA_LABEL, PERSONA_PHRASE };

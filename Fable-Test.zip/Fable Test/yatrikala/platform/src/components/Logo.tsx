import { useId } from "react";

/**
 * The Yatrikala mark — the "Y-route": two dotted journeys converge into one
 * road; the meeting point is the four-point star. Two journeys, one story.
 * Dotted arms = trips being dreamt; the solid gradient stem = the designed one.
 */
export default function Logo({
  size = 28,
  onDark = true,
  withWordmark = false,
}: {
  size?: number;
  onDark?: boolean;
  withWordmark?: boolean;
}) {
  const id = useId().replace(/[^a-zA-Z0-9]/g, "");
  const arm = onDark ? "rgba(250,245,236,.8)" : "#251A4D";
  const mark = (
    <svg width={size} height={size} viewBox="0 0 64 64" role="img" aria-label="Yatrikala" style={{ flex: "none" }}>
      <defs>
        <linearGradient id={`s${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#F26B4E" />
          <stop offset="1" stopColor="#F5AE3D" />
        </linearGradient>
      </defs>
      {/* origin dots — where the dreaming starts */}
      <circle cx="13" cy="10" r="3.2" fill={arm} />
      <circle cx="51" cy="10" r="3.2" fill={arm} />
      {/* two dotted journeys converging */}
      <path d="M 14.5 14 C 20 24, 25 27.5, 30 31" fill="none" stroke={arm}
        strokeWidth="3.4" strokeLinecap="round" strokeDasharray="0.1 7.4" />
      <path d="M 49.5 14 C 44 24, 39 27.5, 34 31" fill="none" stroke={arm}
        strokeWidth="3.4" strokeLinecap="round" strokeDasharray="0.1 7.4" />
      {/* the one designed road */}
      <path d="M 32 37 L 32 55" fill="none" stroke={`url(#s${id})`} strokeWidth="4.6" strokeLinecap="round" />
      {/* the star where journeys meet */}
      <path fill="#F5AE3D" d="M 32 22 L 35.4 30.6 L 44 34 L 35.4 37.4 L 32 46 L 28.6 37.4 L 20 34 L 28.6 30.6 Z" />
    </svg>
  );
  if (!withWordmark) return mark;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
      {mark}
      <span className="wordmark" style={{ fontSize: size * 0.62 }}>YATRIKALA</span>
    </span>
  );
}

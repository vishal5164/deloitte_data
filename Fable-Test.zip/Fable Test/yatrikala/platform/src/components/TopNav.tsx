import Link from "next/link";
import Logo from "./Logo";

/** Public site navigation. Admin has its own nav in app/admin/layout.tsx. */
export default function TopNav({ active }: { active?: string }) {
  const links = [
    { href: "/design", label: "Design a journey" },
    { href: "/deals", label: "Deals radar" },
    { href: "/insights", label: "Travellers like you" },
  ];
  return (
    <nav className="topnav">
      <div className="inner">
        <Link href="/" style={{ textDecoration: "none" }} aria-label="Yatrikala home">
          <Logo size={30} withWordmark />
        </Link>
        <span className="spacer" />
        {links.map((l) => (
          <Link key={l.href} href={l.href} className={active === l.href ? "active" : ""}>
            {l.label}
          </Link>
        ))}
      </div>
    </nav>
  );
}

import "server-only";
import { db, tables } from "@/db";
import { eq } from "drizzle-orm";
import type { DestinationPack } from "@/engine/types";
import seedPacks from "./packs.json";

/**
 * Destination packs: DB is the source of truth (admin can edit/add without a deploy);
 * packs.json is the seed + zero-DB fallback so the app renders even before setup.
 * Cached per server instance for 10 minutes.
 */
let cache: { packs: DestinationPack[]; at: number } | null = null;

export async function loadPacks(): Promise<DestinationPack[]> {
  if (cache && Date.now() - cache.at < 10 * 60_000) return cache.packs;
  try {
    const rows = await db
      .select()
      .from(tables.destinations)
      .where(eq(tables.destinations.active, true));
    if (rows.length) {
      cache = { packs: rows.map((r) => r.pack as DestinationPack), at: Date.now() };
      return cache.packs;
    }
  } catch {
    // DB not configured yet — fall through to bundled packs
  }
  cache = { packs: seedPacks as unknown as DestinationPack[], at: Date.now() };
  return cache.packs;
}

export function invalidatePacksCache() {
  cache = null;
}

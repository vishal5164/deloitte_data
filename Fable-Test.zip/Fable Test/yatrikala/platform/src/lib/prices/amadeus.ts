import type { FlightDeal, HotelDeal, PriceSource } from "./types";

/**
 * Amadeus Self-Service adapter (live airline offers).
 * Enable by setting AMADEUS_CLIENT_ID/SECRET and PRICE_SOURCE=amadeus.
 * Test env base is test.api.amadeus.com; switch AMADEUS_BASE for production keys.
 */
const BASE = process.env.AMADEUS_BASE ?? "https://test.api.amadeus.com";

let cachedToken: { token: string; exp: number } | null = null;

async function amadeusToken(): Promise<string> {
  if (cachedToken && Date.now() < cachedToken.exp - 30_000) return cachedToken.token;
  const id = process.env.AMADEUS_CLIENT_ID, secret = process.env.AMADEUS_CLIENT_SECRET;
  if (!id || !secret) throw new Error("AMADEUS_CLIENT_ID/SECRET not set");
  const res = await fetch(`${BASE}/v1/security/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=client_credentials&client_id=${id}&client_secret=${secret}`,
  });
  if (!res.ok) throw new Error(`amadeus auth ${res.status}`);
  const json = (await res.json()) as { access_token: string; expires_in: number };
  cachedToken = { token: json.access_token, exp: Date.now() + json.expires_in * 1000 };
  return cachedToken.token;
}

function plusDays(n: number) {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

export const amadeus: PriceSource = {
  name: "amadeus",

  async flightDeals(origin, destCode): Promise<FlightDeal[]> {
    const token = await amadeusToken();
    // sample a departure ~30 days out, 7-night trip — a representative bookable fare
    const depart = plusDays(30), ret = plusDays(37);
    const url = `${BASE}/v2/shopping/flight-offers?originLocationCode=${origin}&destinationLocationCode=${destCode}&departureDate=${depart}&returnDate=${ret}&adults=1&currencyCode=INR&max=5`;
    const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    if (!res.ok) throw new Error(`amadeus flights ${res.status}`);
    const json = (await res.json()) as {
      data?: { price: { grandTotal: string }; validatingAirlineCodes?: string[]; itineraries: { segments: unknown[] }[] }[];
    };
    return (json.data ?? []).map((o) => ({
      origin,
      destCode,
      priceInr: Math.round(parseFloat(o.price.grandTotal)),
      airline: o.validatingAirlineCodes?.[0],
      departAt: depart,
      returnAt: ret,
      transfers: Math.max(0, (o.itineraries[0]?.segments.length ?? 1) - 1),
    })).sort((a, b) => a.priceInr - b.priceInr);
  },

  async hotelDeals(city, checkIn, checkOut): Promise<HotelDeal[]> {
    // Amadeus hotel flow needs city→hotelIds→offers; kept minimal here.
    const token = await amadeusToken();
    const geo = await fetch(
      `${BASE}/v1/reference-data/locations/cities?keyword=${encodeURIComponent(city)}&max=1`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    if (!geo.ok) throw new Error(`amadeus cities ${geo.status}`);
    const g = (await geo.json()) as { data?: { iataCode?: string }[] };
    const code = g.data?.[0]?.iataCode;
    if (!code) return [];
    const list = await fetch(
      `${BASE}/v1/reference-data/locations/hotels/by-city?cityCode=${code}&radius=15&radiusUnit=KM`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    if (!list.ok) throw new Error(`amadeus hotels ${list.status}`);
    const hotels = ((await list.json()) as { data?: { hotelId: string; name?: string }[] }).data?.slice(0, 5) ?? [];
    if (!hotels.length) return [];
    const offers = await fetch(
      `${BASE}/v3/shopping/hotel-offers?hotelIds=${hotels.map((h) => h.hotelId).join(",")}&checkInDate=${checkIn}&checkOutDate=${checkOut}&adults=2&currency=INR`,
      { headers: { Authorization: `Bearer ${token}` } },
    );
    if (!offers.ok) throw new Error(`amadeus offers ${offers.status}`);
    const oj = (await offers.json()) as {
      data?: { hotel: { name?: string }; offers?: { price: { total?: string } }[] }[];
    };
    const nights = Math.max(1, (new Date(checkOut).getTime() - new Date(checkIn).getTime()) / 86_400_000);
    return (oj.data ?? [])
      .map((d) => ({
        city,
        destCode: code,
        name: d.hotel.name,
        priceInr: Math.round(parseFloat(d.offers?.[0]?.price.total ?? "0") / nights),
      }))
      .filter((h) => h.priceInr > 0)
      .sort((a, b) => a.priceInr - b.priceInr);
  },
};

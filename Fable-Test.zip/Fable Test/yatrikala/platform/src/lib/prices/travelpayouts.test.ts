import { test } from "node:test";
import assert from "node:assert/strict";
import { travelpayouts } from "./travelpayouts";

function withStubbedFetch(payload: unknown, fn: () => Promise<void>) {
  const original = globalThis.fetch;
  globalThis.fetch = (async () =>
    new Response(JSON.stringify(payload), { status: 200, headers: { "Content-Type": "application/json" } })
  ) as typeof fetch;
  return fn().finally(() => { globalThis.fetch = original; });
}

test("flightDeals: parses, converts, sorts, and deep-links", async () => {
  const prevToken = process.env.TRAVELPAYOUTS_TOKEN;
  const prevMarker = process.env.TRAVELPAYOUTS_MARKER;
  process.env.TRAVELPAYOUTS_TOKEN = "t";
  process.env.TRAVELPAYOUTS_MARKER = "m123";
  try {
    await withStubbedFetch({
      success: true,
      data: {
        HAN: {
          "0": { price: 21999.6, airline: "AI", departure_at: "2026-08-20T10:00:00Z", return_at: "2026-08-28T15:00:00Z", transfers: 0 },
          "1": { price: 18500.2, airline: "VJ", departure_at: "2026-08-15T02:00:00Z", return_at: "2026-08-23T04:00:00Z", transfers: 1 },
        },
      },
    }, async () => {
      const deals = await travelpayouts.flightDeals("DEL", "HAN");
      assert.equal(deals.length, 2);
      assert.equal(deals[0].priceInr, 18500, "cheapest first, rounded");
      assert.equal(deals[1].airline, "AI");
      assert.match(deals[0].deepLink ?? "", /marker=m123/, "affiliate marker present");
      assert.match(deals[0].deepLink ?? "", /DEL\d{4}HAN\d{4}1/, "aviasales route format");
    });
  } finally {
    if (prevToken !== undefined) process.env.TRAVELPAYOUTS_TOKEN = prevToken; else delete process.env.TRAVELPAYOUTS_TOKEN;
    if (prevMarker !== undefined) process.env.TRAVELPAYOUTS_MARKER = prevMarker; else delete process.env.TRAVELPAYOUTS_MARKER;
  }
});

test("hotelDeals: filters zero prices and sorts ascending", async () => {
  const prev = process.env.TRAVELPAYOUTS_TOKEN;
  process.env.TRAVELPAYOUTS_TOKEN = "t";
  try {
    await withStubbedFetch([
      { hotelName: "A", stars: 4, priceAvg: 9000.7 },
      { hotelName: "B", stars: 3, priceAvg: 0 },
      { hotelName: "C", stars: 5, priceFrom: 6400.2 },
    ], async () => {
      const deals = await travelpayouts.hotelDeals("Hanoi", "2026-08-20", "2026-08-23");
      assert.equal(deals.length, 2, "zero-price rows dropped");
      assert.deepEqual(deals.map((d) => d.name), ["C", "A"], "sorted by price");
      assert.equal(deals[0].priceInr, 6400);
    });
  } finally {
    if (prev !== undefined) process.env.TRAVELPAYOUTS_TOKEN = prev; else delete process.env.TRAVELPAYOUTS_TOKEN;
  }
});

test("flightDeals: throws without a token (never silently returns fake data)", async () => {
  const prev = process.env.TRAVELPAYOUTS_TOKEN;
  delete process.env.TRAVELPAYOUTS_TOKEN;
  try {
    await assert.rejects(() => travelpayouts.flightDeals("DEL", "HAN"), /TRAVELPAYOUTS_TOKEN/);
  } finally {
    if (prev !== undefined) process.env.TRAVELPAYOUTS_TOKEN = prev;
  }
});

import { travelpayouts } from "./travelpayouts";
import { amadeus } from "./amadeus";
import type { PriceSource } from "./types";

export * from "./types";

/** Active source, selected by env. Both adapters satisfy the same interface. */
export function priceSource(): PriceSource {
  return (process.env.PRICE_SOURCE ?? "travelpayouts") === "amadeus" ? amadeus : travelpayouts;
}

export function priceSourceConfigured(): boolean {
  return (process.env.PRICE_SOURCE ?? "travelpayouts") === "amadeus"
    ? Boolean(process.env.AMADEUS_CLIENT_ID && process.env.AMADEUS_CLIENT_SECRET)
    : Boolean(process.env.TRAVELPAYOUTS_TOKEN);
}

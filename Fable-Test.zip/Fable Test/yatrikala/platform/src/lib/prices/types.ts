export interface FlightDeal {
  origin: string;       // IATA: DEL, BOM, BLR
  destCode: string;     // IATA of destination gateway
  priceInr: number;     // round-trip per person
  airline?: string;
  departAt?: string;    // ISO date
  returnAt?: string;
  transfers?: number;
  deepLink?: string;    // affiliate/booking link when available
}

export interface HotelDeal {
  city: string;         // display city
  destCode: string;     // location slug/id used by the source
  priceInr: number;     // median/avg per night
  stars?: number;
  name?: string;
  deepLink?: string;
}

/**
 * One interface, two implementations (Travelpayouts default, Amadeus optional).
 * Selected via PRICE_SOURCE env; both can run side by side for comparison rows.
 */
export interface PriceSource {
  readonly name: "travelpayouts" | "amadeus";
  /** Cheapest round-trip fares for the next ~2 months on a route. */
  flightDeals(origin: string, destCode: string): Promise<FlightDeal[]>;
  /** Indicative hotel nightly prices for a city. */
  hotelDeals(city: string, checkIn: string, checkOut: string): Promise<HotelDeal[]>;
}

/** Gateway airports + hotel-search city per destination pack id. */
export const DEST_GATEWAYS: Record<string, { iata: string; city: string }> = {
  vietnam: { iata: "HAN", city: "Hanoi" },
  japan: { iata: "TYO", city: "Tokyo" },
  bali: { iata: "DPS", city: "Denpasar" },
  thailand: { iata: "BKK", city: "Bangkok" },
  srilanka: { iata: "CMB", city: "Colombo" },
  dubai: { iata: "DXB", city: "Dubai" },
  singapore: { iata: "SIN", city: "Singapore" },
  georgia: { iata: "TBS", city: "Tbilisi" },
  kazakhstan: { iata: "ALA", city: "Almaty" },
  greece: { iata: "ATH", city: "Athens" },
  switzerland: { iata: "ZRH", city: "Zurich" },
  italy: { iata: "ROM", city: "Rome" },
  maldives: { iata: "MLE", city: "Male" },
  cambodia: { iata: "REP", city: "Siem Reap" },
  armenia: { iata: "EVN", city: "Yerevan" },
  southkorea: { iata: "SEL", city: "Seoul" },
  malaysia: { iata: "KUL", city: "Kuala Lumpur" },
  philippines: { iata: "CEB", city: "Cebu" },
  mauritius: { iata: "MRU", city: "Port Louis" },
  seychelles: { iata: "SEZ", city: "Victoria" },
  nepal: { iata: "KTM", city: "Kathmandu" },
  bhutan: { iata: "PBH", city: "Paro" },
  uzbekistan: { iata: "TAS", city: "Tashkent" },
  oman: { iata: "MCT", city: "Muscat" },
  egypt: { iata: "CAI", city: "Cairo" },
  uk: { iata: "LON", city: "London" },
  france: { iata: "PAR", city: "Paris" },
  spain: { iata: "BCN", city: "Barcelona" },
  australia: { iata: "SYD", city: "Sydney" },
  newzealand: { iata: "AKL", city: "Auckland" },
};

export const ORIGINS = ["DEL", "BOM", "BLR"] as const;

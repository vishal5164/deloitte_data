import type { FlightDeal, HotelDeal, PriceSource } from "./types";

/**
 * Travelpayouts Data API (free with an affiliate account).
 * Docs: https://support.travelpayouts.com/hc/en-us/articles/203956163
 * Prices are cached market observations (up to ~48h old) — perfect for a deals
 * radar and quote sanity checks; label them "observed", not "bookable now".
 */
const TP = "https://api.travelpayouts.com";

function token() {
  const t = process.env.TRAVELPAYOUTS_TOKEN;
  if (!t) throw new Error("TRAVELPAYOUTS_TOKEN not set");
  return t;
}

export const travelpayouts: PriceSource = {
  name: "travelpayouts",

  async flightDeals(origin, destCode): Promise<FlightDeal[]> {
    // v1 prices/cheap: cheapest cached round trips for the next two months.
    const url = `${TP}/v1/prices/cheap?origin=${origin}&destination=${destCode}&currency=inr&token=${token()}`;
    const res = await fetch(url, { next: { revalidate: 0 } });
    if (!res.ok) throw new Error(`travelpayouts flights ${res.status}`);
    const json = (await res.json()) as {
      success: boolean;
      data: Record<string, Record<string, {
        price: number; airline: string; departure_at: string; return_at: string; transfers?: number;
      }>>;
    };
    const routes = json.data?.[destCode] ?? {};
    const marker = process.env.TRAVELPAYOUTS_MARKER;
    return Object.values(routes).map((r) => ({
      origin,
      destCode,
      priceInr: Math.round(r.price),
      airline: r.airline,
      departAt: r.departure_at,
      returnAt: r.return_at,
      transfers: r.transfers,
      deepLink: marker
        ? `https://www.aviasales.com/search/${origin}${fmt(r.departure_at)}${destCode}${fmt(r.return_at)}1?marker=${marker}`
        : undefined,
    })).sort((a, b) => a.priceInr - b.priceInr);
  },

  async hotelDeals(city, checkIn, checkOut): Promise<HotelDeal[]> {
    // Hotellook cache API: average nightly prices by city.
    const url = `https://engine.hotellook.com/api/v2/cache.json?location=${encodeURIComponent(city)}&currency=inr&checkIn=${checkIn}&checkOut=${checkOut}&limit=8&token=${token()}`;
    const res = await fetch(url, { next: { revalidate: 0 } });
    if (!res.ok) throw new Error(`hotellook ${res.status}`);
    const json = (await res.json()) as {
      hotelName?: string; stars?: number; priceAvg?: number; priceFrom?: number; location?: { name: string };
    }[];
    return (json ?? [])
      .filter((h) => (h.priceAvg ?? h.priceFrom ?? 0) > 0)
      .map((h) => ({
        city,
        destCode: city.toLowerCase().replace(/\s+/g, "-"),
        priceInr: Math.round(h.priceAvg ?? h.priceFrom ?? 0),
        stars: h.stars,
        name: h.hotelName,
      }))
      .sort((a, b) => a.priceInr - b.priceInr);
  },
};

function fmt(iso?: string) {
  if (!iso) return "";
  const d = new Date(iso);
  return `${String(d.getDate()).padStart(2, "0")}${String(d.getMonth() + 1).padStart(2, "0")}`;
}

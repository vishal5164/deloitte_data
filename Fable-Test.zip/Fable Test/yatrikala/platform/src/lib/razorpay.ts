import Razorpay from "razorpay";
import crypto from "crypto";

export function razorpayConfigured(): boolean {
  return Boolean(process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET);
}

export function razorpay() {
  if (!razorpayConfigured()) throw new Error("Razorpay keys not set");
  return new Razorpay({
    key_id: process.env.RAZORPAY_KEY_ID!,
    key_secret: process.env.RAZORPAY_KEY_SECRET!,
  });
}

/**
 * Create a payment link for an invoice. Returns Razorpay link id + short_url.
 * amountInr is whole rupees; Razorpay wants paise.
 */
export async function createPaymentLink(opts: {
  amountInr: number;
  description: string;
  reference: string; // our invoice number, becomes reference_id
  customer?: { name?: string; contact?: string; email?: string };
}) {
  const rp = razorpay();
  const params: Record<string, unknown> = {
    amount: opts.amountInr * 100,
    currency: "INR",
    description: opts.description,
    reference_id: opts.reference,
    notify: { sms: Boolean(opts.customer?.contact), email: Boolean(opts.customer?.email) },
    reminder_enable: true,
    callback_url: `${process.env.NEXT_PUBLIC_SITE_URL}/pay/thanks`,
    callback_method: "get",
  };
  if (opts.customer) params.customer = opts.customer;
  // The SDK's create() types collapse to `Promise<...> & void` due to a callback overload — cast around it.
  const link = (await (rp.paymentLink.create as (p: unknown) => Promise<{ id: string; short_url: string }>)(
    params,
  ));
  return { id: link.id, shortUrl: link.short_url };
}

/** Verify X-Razorpay-Signature on webhook payloads (HMAC SHA256 of raw body). */
export function verifyWebhookSignature(rawBody: string, signature: string | null): boolean {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret || !signature) return false;
  const expected = crypto.createHmac("sha256", secret).update(rawBody).digest("hex");
  return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature));
}

/** Invoice numbering: YTK-<FY>-<seq>, e.g. YTK-2627-0042 for FY 2026-27. */
export function invoiceNumber(seq: number, now = new Date()): string {
  const fyStart = now.getMonth() >= 3 ? now.getFullYear() : now.getFullYear() - 1;
  const fy = `${String(fyStart).slice(2)}${String(fyStart + 1).slice(2)}`;
  return `YTK-${fy}-${String(seq).padStart(4, "0")}`;
}

import Anthropic from "@anthropic-ai/sdk";
import type { Brief, DestinationPack, Itinerary } from "@/engine/types";
import { engineGenerate } from "@/engine";

/**
 * AI layer with graceful degradation:
 * - No ANTHROPIC_API_KEY → deterministic engine (still a great draft).
 * - Key present → Claude refines the engine draft (rewrites titles/teasers/tips
 *   for this specific brief) so every visitor gets a one-of-one itinerary.
 */
export function aiEnabled(): boolean {
  return Boolean(process.env.ANTHROPIC_API_KEY);
}

const MODEL = process.env.ANTHROPIC_MODEL ?? "claude-sonnet-5";

/**
 * Daily cost guard: once today's Claude-generated itineraries hit the cap,
 * fall back to the engine silently. Counting fails open (no DB → no block),
 * since without persistence there is no runaway loop to fear either.
 */
async function aiBudgetExhausted(): Promise<boolean> {
  const cap = Number(process.env.MAX_AI_GENERATIONS_PER_DAY ?? 200);
  if (!Number.isFinite(cap) || cap <= 0) return false;
  try {
    const [{ db, tables }, { and, eq, gte, count }] = await Promise.all([
      import("@/db"),
      import("drizzle-orm"),
    ]);
    const dayStart = new Date();
    dayStart.setUTCHours(0, 0, 0, 0);
    const [{ n }] = await db
      .select({ n: count() })
      .from(tables.itineraries)
      .where(and(
        eq(tables.itineraries.generator, "claude"),
        gte(tables.itineraries.createdAt, dayStart),
      ));
    return Number(n) >= cap;
  } catch {
    return false;
  }
}

export async function generateItinerary(
  brief: Brief,
  packs: DestinationPack[],
): Promise<{ itinerary: Itinerary; generator: "engine" | "claude" }> {
  const draft = engineGenerate(brief, packs);
  if (!aiEnabled()) return { itinerary: draft, generator: "engine" };
  if (await aiBudgetExhausted()) return { itinerary: draft, generator: "engine" };

  try {
    const anthropic = new Anthropic();
    const res = await anthropic.messages.create({
      model: MODEL,
      max_tokens: 4000,
      messages: [{
        role: "user",
        content:
`You are the senior trip designer at Yatrikala, a bespoke itinerary studio for Indian travellers. Below is a machine-drafted itinerary (JSON). Elevate it for THIS traveller without changing its structure:
- Rewrite "title" and "seasonNote" to feel hand-written for a ${brief.persona} trip of ${brief.nights} nights.
- Rewrite each plan day's "teaser" to be more specific and more tempting (max 85 chars each).
- Improve any block "tip" that feels generic (keep max 140 chars).
- Do NOT add/remove days or blocks. Do NOT change costs, stays, or visa facts.
Return ONLY the full corrected JSON object, no commentary, no markdown fences.

${JSON.stringify(draft)}`,
      }],
    });
    const text = res.content.find((b) => b.type === "text");
    if (!text || text.type !== "text") throw new Error("no text block");
    const refined = JSON.parse(text.text) as Itinerary;
    // basic sanity: same shape or we fall back
    if (!refined.plan || refined.plan.length !== draft.plan.length) throw new Error("shape drift");
    return { itinerary: refined, generator: "claude" };
  } catch {
    return { itinerary: draft, generator: "engine" };
  }
}

export interface InsightBody {
  headline: string;
  stats: { label: string; value: string }[];
  patterns: string[]; // "78% of couples added an onsen night"
  advice: string[];
  sources: string; // honest provenance line
}

/** "Travellers like you" — aggregate + AI synthesis for a (destKey, persona) pair. */
export async function synthesizeInsight(input: {
  destName: string;
  persona: string;
  aggregate: {
    briefCount: number;
    medianNights: number | null;
    topMonths: string[];
    topVibes: string[];
    avgBudgetLine: string | null;
  };
  pack: DestinationPack | null;
}): Promise<{ body: InsightBody; generatedBy: "aggregate" | "claude" }> {
  const fallback: InsightBody = {
    headline: `What ${input.persona} travellers plan for ${input.destName}`,
    stats: [
      { label: "Drafts designed here", value: String(input.aggregate.briefCount) },
      { label: "Median trip length", value: input.aggregate.medianNights ? `${input.aggregate.medianNights} nights` : "—" },
      { label: "Most-picked months", value: input.aggregate.topMonths.join(", ") || "—" },
    ],
    patterns: input.aggregate.topVibes.length
      ? [`Most requested moods: ${input.aggregate.topVibes.join(", ")}`]
      : [],
    advice: input.pack?.whyGo ?? [],
    sources: "Aggregated from anonymised Yatrikala journey drafts. Updated weekly.",
  };
  if (!aiEnabled()) return { body: fallback, generatedBy: "aggregate" };

  try {
    const anthropic = new Anthropic();
    const res = await anthropic.messages.create({
      model: MODEL,
      max_tokens: 1200,
      messages: [{
        role: "user",
        content:
`You write honest, specific traveller-behaviour briefs for Yatrikala (bespoke itineraries for Indian travellers). Using ONLY the aggregate data and destination pack below (no invented statistics — qualitative patterns are fine when phrased as typical behaviour, numeric claims must come from the aggregate), produce JSON:
{"headline": str, "stats":[{"label":str,"value":str} x3-4], "patterns":[str x3-5], "advice":[str x3], "sources": str}
patterns = what ${input.persona} travellers with similar itineraries typically do at ${input.destName} (booking lead times, splurge choices, common mistakes). advice = sharp, specific. sources = one honest line on provenance.
Return ONLY JSON.

AGGREGATE: ${JSON.stringify(input.aggregate)}
PACK: ${JSON.stringify(input.pack ? { whyGo: input.pack.whyGo, personaNote: input.pack.personaNotes[input.persona as keyof typeof input.pack.personaNotes], foods: input.pack.foods, bestMonths: input.pack.bestMonths } : null)}`,
      }],
    });
    const text = res.content.find((b) => b.type === "text");
    if (!text || text.type !== "text") throw new Error("no text");
    return { body: JSON.parse(text.text) as InsightBody, generatedBy: "claude" };
  } catch {
    return { body: fallback, generatedBy: "aggregate" };
  }
}

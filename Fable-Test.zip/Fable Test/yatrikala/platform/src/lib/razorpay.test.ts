import { test } from "node:test";
import assert from "node:assert/strict";
import crypto from "node:crypto";
import { invoiceNumber, verifyWebhookSignature } from "./razorpay";

test("invoiceNumber: Indian financial-year roll (April)", () => {
  // FY 2026-27 starts 1 April 2026
  assert.equal(invoiceNumber(42, new Date("2026-07-13")), "YTK-2627-0042");
  assert.equal(invoiceNumber(1, new Date("2026-04-01")), "YTK-2627-0001");
  // 31 March 2026 still belongs to FY 2025-26
  assert.equal(invoiceNumber(999, new Date("2026-03-31")), "YTK-2526-0999");
  // sequence padding
  assert.equal(invoiceNumber(7, new Date("2027-01-05")), "YTK-2627-0007");
  assert.equal(invoiceNumber(12345, new Date("2026-08-01")), "YTK-2627-12345");
});

test("verifyWebhookSignature: accepts valid HMAC, rejects everything else", () => {
  const prev = process.env.RAZORPAY_WEBHOOK_SECRET;
  process.env.RAZORPAY_WEBHOOK_SECRET = "test_secret_123";
  try {
    const body = JSON.stringify({ event: "payment_link.paid", payload: { x: 1 } });
    const good = crypto.createHmac("sha256", "test_secret_123").update(body).digest("hex");

    assert.equal(verifyWebhookSignature(body, good), true, "valid signature accepted");
    assert.equal(verifyWebhookSignature(body + " ", good), false, "tampered body rejected");
    const bad = crypto.createHmac("sha256", "wrong_secret").update(body).digest("hex");
    assert.equal(verifyWebhookSignature(body, bad), false, "wrong secret rejected");
    assert.equal(verifyWebhookSignature(body, null), false, "missing signature rejected");

    delete process.env.RAZORPAY_WEBHOOK_SECRET;
    assert.equal(verifyWebhookSignature(body, good), false, "no secret configured rejects all");
  } finally {
    if (prev !== undefined) process.env.RAZORPAY_WEBHOOK_SECRET = prev;
    else delete process.env.RAZORPAY_WEBHOOK_SECRET;
  }
});

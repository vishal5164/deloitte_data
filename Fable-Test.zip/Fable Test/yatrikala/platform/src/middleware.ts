import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

/**
 * Supabase session-refresh middleware for the admin studio.
 * - Keeps auth cookies fresh so Server Components can trust supabase.auth.getUser().
 * - Also completes the magic-link PKCE exchange: the emailed link lands on
 *   /admin?code=..., which we exchange for a session here, then strip the code.
 * - If Supabase env vars are absent (pre-setup), it is a no-op so the app still renders.
 */
export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({ request });

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anonKey) return supabaseResponse;

  const supabase = createServerClient(url, anonKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
        supabaseResponse = NextResponse.next({ request });
        cookiesToSet.forEach(({ name, value, options }) =>
          supabaseResponse.cookies.set(name, value, options),
        );
      },
    },
  });

  // Magic-link landing: exchange ?code= for a session, then clean the URL.
  const code = request.nextUrl.searchParams.get("code");
  if (code) {
    await supabase.auth.exchangeCodeForSession(code);
    const clean = request.nextUrl.clone();
    clean.searchParams.delete("code");
    const redirectResponse = NextResponse.redirect(clean);
    // carry over any auth cookies written during the exchange
    supabaseResponse.cookies.getAll().forEach((cookie) => redirectResponse.cookies.set(cookie));
    return redirectResponse;
  }

  // IMPORTANT: getUser() revalidates the JWT and refreshes expiring sessions.
  await supabase.auth.getUser();

  return supabaseResponse;
}

export const config = {
  matcher: ["/admin/:path*"],
};

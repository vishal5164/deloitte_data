# Yatrikala — Brand Guide

**Yatri** (यात्री) — traveller. **Kala** (कला) — art. **Yatrikala — the art of travel.**

A name verified clean on 13 July 2026: yatrikala.com and yatrikala.in both unregistered
(register BOTH immediately, ~₹1,500/yr total), no exact-match Instagram account found
(claim @yatrikala the same day; @yatri.kala as fallback), no business anywhere using the
exact string. One caution on record: "Yatrika Holidays" (Ooty) operates one letter away —
run a formal Class 39 trademark search (ipindia tmrsearch, or a ₹5–8k attorney search)
before spending on the brand, and consider filing your own TM application early (~₹4.5k
self-filed for an individual/MSME).

## Positioning
A boutique travel design studio. Not an agency, not a booking site — a studio where one person
who obsesses over travel designs your trip by hand. Premium, personal, precise.

**Tagline:** *Journeys, designed by hand.*
**Short bio (Instagram):** The art of travel · Bespoke itineraries for Indians travelling the world. Visa to last dinner reservation — designed by hand. ✈️ DM "YATRA" to start.

## Voice
- Warm, unhurried, precise. Like a well-travelled friend who happens to be meticulous.
- Never says "cheap", "deal", "package", "best price guaranteed". Says "worth it", "designed", "curated", "your pace".
- Speaks in specifics: not "amazing food scene" but "the 8-seat kissaten in Nakameguro that doesn't take reservations before 10am".

## Palette
| Role | Name | Hex |
|---|---|---|
| Primary | Ink | `#1B2440` |
| Accent | Marigold | `#E2A13C` |
| Background | Ivory | `#FAF6EF` |
| Support | Terracotta | `#C0603C` |
| Body text | Slate | `#3E4759` |
| Lines/borders | Sand | `#E5DCC9` |

Rules: Ink on Ivory for everything primary. Marigold only as accent (route lines, icons, one highlight per view) — never large fills of it. Terracotta sparingly for warnings/prices.

## Type
- Display / headings: **Georgia** (serif) — widely installed, prints beautifully. If ever buying a font: Fraunces or Freight Display.
- Body / UI: system sans (`-apple-system, Segoe UI, Roboto`).
- Wordmark: YATRIKALA letterspaced 0.14em, THE ART OF TRAVEL letterspaced 0.4em beneath.

## Motif
The **dotted route line** ending in a four-point compass star. Use it as a divider, a loading state, a section break. It is the signature — every document should carry it once.

## Files
- `yatrikala-logo.svg` — primary wordmark. Recolor `.ink`/`.marigold` classes for dark backgrounds (Ivory `#FAF6EF` + Marigold works on Ink).

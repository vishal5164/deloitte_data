# Yatrikala — Launch Playbook
*The art of travel. Journeys, designed by hand.*
*Everything in this document marked "verified" was checked against primary sources in July 2026 by an adversarial research pass.*

---

## 1 · The business in one paragraph

You sell **bespoke trip design for a fixed fee** to Indians travelling internationally: a discovery call, then a hand-finished itinerary document (visa strategy, day-by-day plan, stays shortlist, honest budget), delivered in days, revised until it fits. You never touch client money for bookings — they book everything themselves at cost through your links. Your leverage is AI: what takes an agency 8 hours takes you under an hour with the master prompt + Itinerary Studio, and your taste is the product. Affiliate commissions on the bookings you recommend are the quiet second income.

**Why this works (verified):** 32.7M Indian outbound departures in 2025 (Ministry of Tourism); honeymoon segment +34% YoY with ₹1.5–5L budgets; 15.8% Schengen refusal rate makes visa strategy worth paying for; and **no Indian incumbent charges for planning** — Pickyourtrail/TripClap/Ithaka all give it away to sell packages, while the paid-planning model is proven abroad (Journy $25–50/day, Jess.Travel $99/day, India Someday $500/trip). You are first into a real gap.

**The honest risk:** Indians are anchored to "free planning." You beat that anchor by selling *risk-reduction and taste*, never effort: "your visa file, refusal-proofed" and "the 8-seat kissaten nobody's reel shows you" — not "I'll save you time."

---

## 2 · Pricing (grounded in verified market data)

| Tier | Scope | Launch fee | Market band |
|---|---|---|---|
| **Short Escape** | Domestic / Sri Lanka / Nepal, ≤6 days | ₹4,999 | ₹4,999–7,999 |
| **International Signature** | Single country: Vietnam, Bali, Japan, Georgia, single-Schengen, 7–10 days | ₹12,999–16,999 | ₹14,999–24,999 |
| **Grand Voyage / Honeymoon Atelier** | Multi-country, honeymoons, milestones, 10–16 days | ₹24,999–29,999 | ₹34,999–59,999 |

Rules:
- Launch at the floor of each band (you have no reviews yet). **Raise every rate ~₹1,500 after each 5 five-star reviews** until you sit mid-band.
- 50% advance to start, balance before final handover. Non-negotiable — the advance is what makes a client serious.
- Rush 48h delivery: +40%. Two revision rounds included; honeymoon tier gets on-trip WhatsApp support.
- Fee = fee. No hidden margins. Say it in every quote: *"zero commissions hidden in your bookings"* — it's your positioning against every agency in India. Affiliate links are disclosed in the itinerary's fine print and never change the client's price.
- Anchor tactic (copied from India Someday, verified): free 15-minute discovery call → paid full design.

**Unit economics at steady state (10 clients/month):** ~8 Signature (₹13k avg) + 2 Honeymoon (₹27k avg) ≈ **₹1.58L/month in fees**, plus affiliate income (realistically ₹5–20k/month once links are in every document). Your cost base: Claude Pro (~₹2k/month), domain/email (~₹300/month), Canva free. That's a >95% margin business.

---

## 3 · First 14 days

**Day 1–2 — Lock the brand (do this before anything else; availability was true on 13 Jul 2026 and decays daily):**
1. Register **yatrikala.com AND yatrikala.in** (GoDaddy/Namecheap/Hostinger, ~₹1,500/yr total).
2. Claim **@yatrikala** on Instagram (fallback @yatri.kala) + the same on YouTube/X even if unused.
3. Set up email — hello@yatrikala.com (Zoho Mail free tier works with your domain).
4. **File your Deloitte outside-business-interest / COI declaration.** Verified norm: Big-4 India permits unrelated side businesses only after internal disclosure and approval. Re-declare at PwC when you switch. Do not skip this.

**Day 3–5 — Legal + money rails (verified checklist, all launch items):**
5. Udyam (MSME) registration — free, online, ~10 minutes, self-declared: udyamregistration.gov.in.
6. Maharashtra Shops & Establishments **intimation** (you're under 10 workers, so it's an intimation, not a registration) — Aaple Sarkar portal, within 60 days of starting; the receipt + Udyam certificate are your two KYC proofs.
7. Open a current account ("Vishal Kumar, proprietor, Yatrikala").
8. Razorpay account as **Sole Proprietorship** (PAN + Aadhaar + bank proof; no GST needed below ₹20L — verified incl. interstate clients via Notification 10/2017-IGST). Use payment links / merchant UPI, not your personal GPay.
9. Skip for now (verified NOT needed at launch): GST registration, LUT, TCS (advisory-only is outside Section 206C(1G)/new Section 394(1) scope — but keep every engagement scoped "advisory only; client books directly"), travel agent licence, IATA.

**Day 6–8 — Tools + affiliate stack:**
10. Claude Pro subscription (~$20/mo) — your production engine. Workflow: intake brief → master prompt → JSON → Itinerary Studio → PDF.
11. Sign up for affiliates in this order (all verified open to Indian individuals, July 2026):

| Priority | Program | Why | Payout reality |
|---|---|---|---|
| 1 | **Viator** (partnerresources.viator.com) | 8% on tours; sign-up in minutes, no traffic bar | **Weekly PayPal, no minimum** — first real cash |
| 2 | **Klook** (affiliate.klook.com) | up to 10% India-origin bookings, 20% on eSIMs; deepest Asia inventory | monthly, bank |
| 3 | **Travelpayouts** (one account) | bundles GetYourGuide 8% + 12Go transport + more | monthly PayPal, $50 min pooled |
| 4 | **Booking.com via Awin** (APAC programme, merchant 18117) | hotels = biggest spend line; ~4% | Awin 2×/month, $20 min ($5 refundable joining deposit) |
| 5 | **Airalo via impact.com** | 10% on eSIMs — near-100% attach rate | ~$10 threshold, pays Indian banks |
| 6 | **EarnKaro** | MakeMyTrip/Goibibo for domestic legs, WhatsApp-friendly | INR, ₹10 minimum |

   Insurance: recommend clients buy it, link PolicyBazaar informationally. To *earn* on insurance legally you'd need POSP certification (PBPartners) or Asego's agent program — park until month 3+. Avoid pushing foreign insurers (IRDAI grey zone — verified).
   PayPal note: inbound-only in India, auto-converts to INR (~4% FX cost), issues digital FIRAs — archive them monthly. Tag foreign remittances purpose code **P1006**.

**Day 9–11 — Portfolio:**
12. Produce 3 sample itineraries with your real taste in them (the Japan honeymoon sample ships with the Itinerary Studio; make Vietnam and a Schengen one — they're the demand centers, verified: Vietnam +49%, Schengen 1.15M applications).
13. Print them to PDF. These are your proof — send them to anyone who asks "what do I get for the fee?"

**Day 12–14 — First clients:**
14. Message 20 people who know you travel well (the launch template is in §6). Goal: 3 briefs in week one.
15. First 3 clients get founder pricing (−30%) in exchange for a written review + one referral. Log everything in the CRM from lead #1.

---

## 4 · The operating loop (per client)

1. **Lead** arrives (Instagram DM / WhatsApp / referral) → row in CRM Leads *immediately*.
2. Send the **intake link** (client-intake.html — fill your WhatsApp number in CONFIG first). Their answers arrive as a structured brief on your WhatsApp.
3. **15-min discovery call** (free) → confirm scope, read between the lines. What they don't say matters most.
4. **Quote** via Quote Builder → send message → 50% advance via Razorpay link → CRM: Won, add Trips + Payments rows.
5. **Design**: paste brief into master prompt in Claude → JSON → Itinerary Studio → render. **Then earn your fee**: verify visa rules + 2–3 key prices, kill anything generic, run the "jaded travel editor" second pass (in the master-prompt file), add one thing only you would know. Insert your affiliate links (Booking/Klook/Viator/Airalo) where they genuinely fit.
6. **Deliver** draft PDF in 4–5 days → 2 revision rounds → balance → final handover (PDF + a short voice note walking them through it — the voice note is remembered longer than the document).
7. **While they travel**: one WhatsApp check-in mid-trip. Costs you 30 seconds, generates referrals for a year.
8. **After**: review ask (template §6) → referral ask → CRM columns updated. Sunday ritual: 20 minutes chasing every overdue follow-up.

---

## 5 · Growth engine (Instagram-first)

Positioning: **the anti-package-tour.** Every post shows judgment, not deals.

**The funnel's front door is the Journey Designer** (`apps/journey-designer.html`, also published as a shareable artifact link): visitors pick who they're travelling as (couple / little ones / parents / squad / solo), choose or get matched to a destination (including two-country combos), and watch a personalized itinerary design itself — Days 1–2 free, the rest gated behind your WhatsApp CTA. Put the link in your Instagram bio and every post's CTA. It runs on a built-in content engine (15 destination packs, persona-tagged); the generation layer is a single function you can later point at a Claude API backend for fully bespoke drafts — the seam is documented in the file header.

Content pillars (3 posts/week is enough):
1. **Visa intelligence** — "Slovenia rejects 46% of Indian Schengen applications. Denmark rejects 6.9%. Same trip, different consulate." (verified numbers — this pillar is your moat)
2. **Taste** — one specific place per post, the detail nobody's reel shows. Pull from itineraries you've already designed (reuse!).
3. **Honest budgets** — "What Japan actually costs two people in November" with the real table.
4. **Client moments** — redacted brief → delivered plan → client photo from the trip.

First 10 posts: 3 visa-intel, 3 taste (Japan/Vietnam/Georgia), 2 honest-budget, 1 "why I started Yatrikala", 1 sample-itinerary flip-through reel. CTA always: *DM "YATRA".*

**Referral system** (from client #1): every delivered client gets a personal code — their friend gets ₹1,000 off, they get ₹1,000 off a future trip or a small gift. Track in CRM Notes.

**Moat-building order:** reviews (screenshot every one) → a destination specialty (own "Japan for Indians" or "refusal-proof Schengen" within 6 months) → an email list of past clients (annual "where next?" note).

---

## 6 · Message templates

**Launch (to your network):**
> Started something I've wanted to do for years: **Yatrikala** — I design international trips for a living now. Not packages, not bookings — the actual thinking: visa strategy, where to stay, what's worth your leave days, what to skip. Fixed fee, you book everything yourself at cost, zero hidden commissions. First few trips at founder pricing. If you (or someone whose honeymoon/Euro-trip is looming) want a plan designed by hand — reply "YATRA" 🧭

**Follow-up (quote sent, 3 days silent):**
> Hi {name} — holding your {destination} slot till {date}. One thing worth knowing either way: {one genuinely useful fact about their trip — visa timeline, fare-drop window, season note}. Want me to keep the slot?

**Delivery:**
> {name}, your {destination} plan is ready ✦ {n} pages, {n} days, every booking link verified today. Two things before you open it: the Day {n} {detail} is the bit I'm proudest of, and don't book anything until you've read the visa page. Voice note incoming with the walkthrough.

**Review ask (post-trip, they're glowing):**
> So glad {highlight} landed! Could I ask 2 minutes: a line or two about what the plan did for the trip — and if anyone in your circle is eyeing {destination or 'a trip like this'}, your code {CODE} gets them ₹1,000 off and you ₹1,000 toward your next one.

---

## 7 · Guardrails

- **Never** collect client money for flights/hotels/packages. The moment you bundle 2+ travel components and take money for them, TCS obligations trigger (flat 2% under Section 394(1), Income-tax Act 2025 — verified) plus a different risk class. Advisory only, until it's a deliberate, structured pivot.
- Every itinerary carries the fine print: prices indicative · verify visa at application time · design fee only, affiliate links disclosed and never change the client's price.
- GST radar lives in the CRM dashboard — register within 30 days of crossing ₹20L turnover.
- Before spending on the brand: formal Class 39 trademark search for "Yatrikala" (Yatrika Holidays is one letter away — verified medium risk); consider filing your own TM (~₹4.5k as individual).
- Deloitte/PwC COI declarations current at all times; no firm time, resources, or clients touch this business.
- You are a designer, not a licensed visa agent: phrase visa help as "documentation strategy and checklist," clients file their own applications.

---

## 8 · What good looks like

| Milestone | Target |
|---|---|
| Month 1 | 3 founder-priced clients, 3 reviews, brand assets live |
| Month 3 | 8–10 clients/month, first price raise, affiliate income visible |
| Month 6 | 15 clients/month, mid-band pricing, a named destination specialty, decision point: group-trip pilot? |
| Month 12 | ₹2L+/month, waitlist, raise prices again — scarcity is the premium signal |

The single metric that predicts everything: **reviews collected**. Watch it weekly on the CRM dashboard.

// tiny static server for QA of yatrikala/apps
const http = require("http");
const fs = require("fs");
const path = require("path");
const ROOT = "C:/Users/vishalkumar5/Desktop/Fable Test/yatrikala/apps";
const MIME = { ".html": "text/html; charset=utf-8", ".svg": "image/svg+xml", ".js": "text/javascript" };
http.createServer((req, res) => {
  const f = path.join(ROOT, decodeURIComponent(req.url === "/" ? "/journey-designer.html" : req.url.split("?")[0]));
  fs.readFile(f, (err, data) => {
    if (err) { res.writeHead(404); res.end("not found"); return; }
    res.writeHead(200, { "Content-Type": MIME[path.extname(f)] || "application/octet-stream" });
    res.end(data);
  });
}).listen(4173, () => console.log("serving on http://localhost:4173"));

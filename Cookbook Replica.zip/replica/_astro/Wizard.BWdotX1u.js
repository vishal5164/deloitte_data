import{j as e,T as Ie,a as pt,A as ut,P as mt,L as gt,b as ht,c as ft,d as vt,E as ee}from"./reference.CoM6j2Ux.js";import{r as x}from"./index.CVf8TyFT.js";const yt=[{key:"Plan",label:"Planning & Design"},{key:"Build",label:"Engineering & Data"},{key:"Ship",label:"Platform & Reliability"}];function bt({roles:r,initialRole:a,onSelect:n}){const l=a?r.find(f=>f.id===a):null,[d,w]=x.useState(l?.category??"Plan"),h=r.filter(f=>f.category===d);return e.jsxs("div",{className:"trs-wrap card",children:[e.jsx("h2",{children:"What is your current role?"}),e.jsx("p",{className:"trs-help",children:"Select your category, then pick your role."}),e.jsx("div",{className:"trs-tabs",role:"tablist",children:yt.map(({key:f,label:g})=>e.jsx("button",{role:"tab","aria-selected":d===f,className:`trs-tab${d===f?" trs-tab--active":""}`,onClick:()=>w(f),children:g},f))}),e.jsx("div",{className:"trs-grid",role:"tabpanel",children:h.map(f=>e.jsxs("button",{className:`trs-card${f.id===a?" trs-card--selected":""}`,onClick:()=>n(f.id,f.maps_to),children:[e.jsx("span",{className:"trs-card-title",children:f.title}),e.jsx("span",{className:"trs-card-desc",children:f.short_desc})]},f.id))}),e.jsx("style",{children:`
        .trs-wrap { margin-bottom: var(--space-6); }
        .trs-wrap h2 { margin-bottom: var(--space-2); }
        .trs-help {
          color: var(--text-muted);
          font-size: var(--text-sm);
          margin-bottom: var(--space-5);
        }

        .trs-tabs {
          display: flex;
          gap: 0;
          border-bottom: 1px solid var(--border);
          margin-bottom: var(--space-5);
        }
        .trs-tab {
          background: transparent;
          border: none;
          border-bottom: 2px solid transparent;
          padding: var(--space-2) var(--space-4);
          font-size: var(--text-sm);
          font-weight: 600;
          color: var(--text-muted);
          cursor: pointer;
          margin-bottom: -1px;
          transition: color 0.1s, border-color 0.1s;
          white-space: nowrap;
        }
        .trs-tab:hover { color: var(--text); }
        .trs-tab--active {
          color: var(--accent);
          border-bottom-color: var(--accent);
        }

        .trs-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: var(--space-3);
          margin-bottom: var(--space-5);
        }
        @media (max-width: 640px) {
          .trs-grid { grid-template-columns: repeat(2, 1fr); }
        }

        .trs-card {
          position: relative;
          display: flex;
          flex-direction: column;
          gap: 6px;
          padding: var(--space-4);
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          text-align: left;
          cursor: pointer;
          transition: border-color 0.12s, background 0.12s;
        }
        .trs-card--selected {
          border-color: var(--accent);
          background: var(--tier-1-bg);
        }
        .trs-card--selected .trs-card-title { color: var(--accent); }
        .trs-card:hover {
          border-color: var(--accent);
          background: var(--bg-hover);
        }
        .trs-card-title {
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
          line-height: 1.3;
        }
        .trs-card-desc {
          font-size: var(--text-xs);
          color: var(--text-muted);
          line-height: 1.4;
        }

      `})]})}function wt({personas:r,roles:a,suggestedPersonaId:n,onSelect:l,onBack:d}){return e.jsxs("div",{className:"ps-wrap card",children:[e.jsx("div",{className:"ps-top-nav",children:e.jsx("button",{className:"link-back",onClick:d,children:"← Back"})}),e.jsx("h2",{children:"Your new role"}),e.jsx("p",{className:"ps-help",children:n?"Based on your background, we suggest the role below. Confirm it or pick the one that fits best.":"These are the seven agentic roles in the delivery pod. Pick the one that fits your work."}),e.jsx("div",{className:"ps-grid",children:r.map(w=>{const h=w.id===n;return e.jsxs("button",{className:`ps-card${h?" suggested":""}`,onClick:()=>l(w.id),children:[h&&e.jsx("span",{className:"ps-suggested-badge",children:"Best Match"}),e.jsx("span",{className:`ps-cat-badge cat-${w.cat.toLowerCase()}`,children:w.cat}),e.jsx("span",{className:"ps-label",children:w.label}),e.jsx("p",{className:"ps-blurb",children:w.blurb})]},w.id)})}),e.jsx("style",{children:`
        .ps-wrap { margin-bottom: var(--space-6); }
        .ps-top-nav { margin-bottom: var(--space-4); }
        .ps-wrap h2 { margin-bottom: var(--space-2); }
        .ps-help { color: var(--text-muted); margin-bottom: var(--space-6); }

        .ps-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
          gap: var(--space-3);
        }

        .ps-card {
          position: relative;
          display: flex;
          flex-direction: column;
          gap: var(--space-2);
          padding: var(--space-5);
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          text-align: left;
          cursor: pointer;
          transition: border-color 0.12s, background 0.12s, transform 0.12s;
          min-height: 180px;
        }
        .ps-card:hover {
          border-color: var(--accent);
          background: var(--bg-hover);
          transform: translateY(-1px);
        }
        .ps-card.suggested {
          border-color: var(--accent);
          border-width: 2px;
          background: var(--tier-1-bg);
        }
        .ps-card.suggested:hover { background: var(--bg-hover); }

        .ps-suggested-badge {
          position: absolute;
          top: 12px;
          right: 12px;
          font-size: var(--text-xs);
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          background: var(--accent);
          color: var(--text-on-green);
          padding: 2px 8px;
          border-radius: 4px;
        }

        .ps-cat-badge {
          display: inline-block;
          align-self: flex-start;
          font-size: var(--text-xs);
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.07em;
          padding: 2px 8px;
          border-radius: 4px;
        }
        .ps-cat-badge.cat-plan  { background: var(--tier-1-bg); color: var(--tier-1); }
        .ps-cat-badge.cat-build { background: var(--tier-2-bg); color: var(--tier-2); }
        .ps-cat-badge.cat-ship  { background: var(--tier-3-bg); color: var(--tier-3); }

        .ps-label {
          font-size: var(--text-lg);
          font-weight: 700;
          color: var(--text);
          line-height: 1.3;
        }
        .ps-blurb {
          font-size: var(--text-sm);
          color: var(--text-muted);
          line-height: 1.55;
          flex: 1;
          margin: 0;
        }
        .link-back {
          background: transparent;
          border: none;
          color: var(--text-muted);
          padding: 0;
        }
        .link-back:hover { color: var(--text); }
      `})]})}const kt=[{id:"pm",label:"Product Manager",short:"PM",cat:"Plan",elevation:"elevated",blurb:"You own intent and the executable spec. In agentic delivery you become the first builder in the chain — V0 in greenfield, the change spec in brownfield."},{id:"architect",label:"Solution Architect",short:"Architect",cat:"Plan",elevation:"elevated",blurb:"You're the validation anchor. The architecture brief is your highest-leverage deliverable — the document the agent reads first."},{id:"dev_qa",label:"Full Stack Dev + QA",short:"Dev+QA",cat:"Build",elevation:"compressed",blurb:"The pod's execution engine. You operate the agent, review diffs with judgement, and own the test suite as a first-class artifact."},{id:"mle_ds",label:"ML Engineer / Data Scientist",short:"ML/DS",cat:"Build",elevation:"retained",blurb:"Specialised depth retained. Model judgement stays human; the surrounding scaffolding becomes agent-assisted."},{id:"data",label:"Data Engineer",short:"Data",cat:"Build",elevation:"retained",blurb:"Spec-driven pipelines are the default. Schema, contracts, and lineage are first-class artifacts."},{id:"designer",label:"UX Designer",short:"UX",cat:"Plan",elevation:"shared",blurb:"AI builds the scaffold; you own the experience. One designer supports two pods."},{id:"devops",label:"DevOps / Infrastructure",short:"DevOps",cat:"Ship",elevation:"shared",blurb:"The platform layer every pod deploys on. Agent-assisted IaC, observability, and guardrails."}],J=[{id:"A1",label:"Application · Greenfield",description:"New application from scratch. No legacy to be consistent with. Highest leverage for rapid prototyping.",defaultPattern:"rapid"},{id:"A2",label:"Data / AI · Greenfield",description:"New data product, ML platform, or analytics layer. Compression is smaller and the evidence base is thinner.",defaultPattern:"rapid"},{id:"B1",label:"Application · Enhancement",description:"Incremental change to a stable application. Safest entry point for agentic adoption.",defaultPattern:"spec-driven"},{id:"B2",label:"Data / AI · Enhancement",description:"Adding capability to a live data product or pipeline — extending models or adding sources.",defaultPattern:"spec-driven"},{id:"C1",label:"Application · Modernisation",description:"Platform, language, or architecture migration on a live system. Highest-impact compressions observed here.",defaultPattern:"spec-driven"},{id:"C2",label:"Data / AI · Modernisation",description:"Major re-architecture of a data platform or model-serving stack.",defaultPattern:"spec-driven"},{id:"D1",label:"Application · Maintenance",description:"BAU — bug-fixes and minor adjustments on a live application. Highest frequency, lowest per-change cost.",defaultPattern:"spec-driven"},{id:"D2",label:"Data / AI · Maintenance",description:"Keeping a live data product running — minor pipeline fixes, schema patches, model retuning.",defaultPattern:"spec-driven"}],xt=[{id:"product-manager",title:"Product Manager",category:"Plan",short_desc:"Defines product vision and prioritises the backlog.",responsibilities:["Writes user stories and acceptance criteria","Manages roadmap and stakeholder expectations","Facilitates sprint planning and reviews","Tracks delivery velocity and outcomes"],maps_to:"pm",agentic_title:"Product Manager / PO",agentic_preview:["Authors executable specs the agent builds from","Operates V0 / Bolt to prototype greenfield features","Reviews agent output against intent, not implementation"]},{id:"business-analyst",title:"Business Analyst",category:"Plan",short_desc:"Bridges business needs and technical delivery.",responsibilities:["Elicits and documents requirements","Creates process maps and data flow diagrams","Runs stakeholder workshops","Validates solutions against business goals"],maps_to:"pm",agentic_title:"Product Manager / PO",agentic_preview:["Converts workshop outputs into structured, agent-readable specs","Uses AI to generate BDD scenarios at pace","Focuses on intent clarity, not document volume"]},{id:"solution-architect",title:"Solution Architect",category:"Plan",short_desc:"Designs technical solutions aligned to business goals.",responsibilities:["Produces architecture decision records","Defines integration patterns and data models","Advises on technology choices","Reviews designs for non-functional requirements"],maps_to:"architect",agentic_title:"Solution Architect",agentic_preview:["Architecture brief is the highest-leverage deliverable","Agent reads the brief first — brief quality drives output quality","Validates generated designs against NFRs and constraints"]},{id:"ux-designer",title:"UX Designer",category:"Plan",short_desc:"Designs user experiences grounded in research and usability.",responsibilities:["Conducts user research and usability testing","Creates wireframes, prototypes, and flows","Maintains the design system","Collaborates with engineers on interaction details"],maps_to:"designer",agentic_title:"UX Designer",agentic_preview:["AI builds the scaffold; you own the experience","V0 handles initial UI — you shape the interaction and accessibility","One designer can now support two pods concurrently"]},{id:"software-engineer",title:"Software Engineer",category:"Build",short_desc:"Builds and maintains application features end-to-end.",responsibilities:["Implements features from tickets and designs","Writes unit and integration tests","Participates in code review","Debugs production incidents"],maps_to:"dev_qa",agentic_title:"Full Stack Dev + QA",agentic_preview:["Operates the agent as an execution partner","Reviews diffs with judgement, not line-by-line authorship","Owns test suite as a first-class artifact"]},{id:"qa-engineer",title:"QA Engineer",category:"Build",short_desc:"Validates software quality through structured testing.",responsibilities:["Designs and executes test plans","Maintains regression and smoke test suites","Files and tracks defects","Performs exploratory and UAT sessions"],maps_to:"dev_qa",agentic_title:"Full Stack Dev + QA",agentic_preview:["Agent generates test scaffolding from specs","QA focus shifts to coverage strategy and edge-case design","Exploratory testing remains a high-value human activity"]},{id:"data-scientist",title:"Data Scientist",category:"Build",short_desc:"Builds models and surfaces insights from data.",responsibilities:["Explores data and builds statistical models","Designs experiments and validates hypotheses","Communicates findings to stakeholders","Monitors model performance in production"],maps_to:"mle_ds",agentic_title:"ML Engineer / Data Scientist",agentic_preview:["Model judgement stays human — agent handles surrounding scaffolding","AI accelerates EDA and feature engineering iteration","Experiment tracking and documentation become agent-assisted"]},{id:"ml-engineer",title:"ML Engineer",category:"Build",short_desc:"Productionises models and owns the ML platform.",responsibilities:["Builds training pipelines and feature stores","Deploys and monitors models in production","Manages model versioning and registries","Optimises inference latency and cost"],maps_to:"mle_ds",agentic_title:"ML Engineer / Data Scientist",agentic_preview:["Pipeline scaffolding generated from spec","Agent assists with boilerplate infra; you own the ML logic","Specialised depth in model design is retained and elevated"]},{id:"data-engineer",title:"Data Engineer",category:"Build",short_desc:"Designs and builds data pipelines and infrastructure.",responsibilities:["Builds ETL/ELT pipelines","Manages data warehouse and lake architecture","Defines data contracts and schemas","Ensures pipeline reliability and data quality"],maps_to:"data",agentic_title:"Data Engineer",agentic_preview:["Schema and contracts become first-class spec artifacts","Agent generates pipeline boilerplate from data contracts","Lineage documentation becomes agent-assisted output"]},{id:"analytics-engineer",title:"Analytics Engineer",category:"Build",short_desc:"Transforms raw data into reliable analytics-ready models.",responsibilities:["Builds and maintains dbt models","Documents data lineage and business logic","Collaborates with analysts on metric definitions","Manages data testing and quality checks"],maps_to:"data",agentic_title:"Data Engineer",agentic_preview:["Agent generates dbt scaffolding from schema specs","Metric definitions become structured, agent-readable contracts","Testing coverage improves with AI-assisted generation"]},{id:"devops-engineer",title:"DevOps Engineer",category:"Ship",short_desc:"Builds and maintains CI/CD pipelines and release processes.",responsibilities:["Designs and maintains CI/CD pipelines","Manages build, test, and deployment automation","Monitors release health and rollback procedures","Implements developer experience tooling"],maps_to:"devops",agentic_title:"DevOps / Infrastructure",agentic_preview:["Agent-assisted IaC accelerates pipeline scaffolding","Platform guardrails co-designed for agentic workloads","You own the deployment contract every pod relies on"]},{id:"cloud-engineer",title:"Cloud / Infrastructure Engineer",category:"Ship",short_desc:"Provisions and manages cloud infrastructure and platforms.",responsibilities:["Designs and provisions cloud infrastructure via IaC","Manages networking, security groups, and IAM","Optimises cloud cost and resource utilisation","Maintains environment consistency across dev/stage/prod"],maps_to:"devops",agentic_title:"DevOps / Infrastructure",agentic_preview:["IaC modules generated from architecture specs","Agent handles boilerplate Terraform/Pulumi; you own the topology","Infrastructure becomes a spec-driven, reviewable artifact"]},{id:"sre",title:"Site Reliability Engineer (SRE)",category:"Ship",short_desc:"Ensures system reliability, observability, and incident response.",responsibilities:["Defines and tracks SLOs, SLIs, and error budgets","Builds alerting and observability infrastructure","Leads incident response and post-mortems","Drives reliability improvements through toil reduction"],maps_to:"devops",agentic_title:"DevOps / Infrastructure",agentic_preview:["Observability specs become first-class deliverables for every pod","Agent assists with runbook generation and alert tuning","Toil reduction accelerates with AI-assisted automation"]}],At=[{archetype:"A1",character:"High per slice; many short slices.",lever:"Intent clarity. Vague intent drives V0 churn that consumes tokens."},{archetype:"A2",character:"High per slice; concentrated in evaluation iteration.",lever:"Evaluation framework quality. Without a harness, model iteration burns tokens."},{archetype:"B1",character:"Moderate per change; many small changes.",lever:"Spec precision. Sharp specs produce sharp diffs."},{archetype:"B2",character:"Moderate; pipeline-shaped.",lever:"Lineage and contract clarity. The agent costs more when it has to infer what changes the contract."},{archetype:"C1",character:"High overall; concentrated in slice migration.",lever:"Architecture brief depth. Thin briefs produce expensive trial-and-error."},{archetype:"C2",character:"High; parallel-run intensive.",lever:"Parity contract precision and lineage discipline."},{archetype:"D1",character:"Low per change; high frequency.",lever:"Brief and test-suite freshness. Stale brief = expensive small change."},{archetype:"D2",character:"Low per change.",lever:"Evaluation harness reuse and lineage discipline."}],Dt={pm:{upstream:["Stakeholders — business intent, success criteria","Users — needs, feedback, validation"],downstream:["Architect — intent document and acceptance criteria","Dev+QA — executable spec","UX Designer — product brief for V0"],owns:["Intent & spec authorship","Acceptance validation before merge","Scope control"],ownsByArchetype:{greenfield:["5W+H intent capture before first prompt","V0 generation and stakeholder validation","CLAUDE.md authorship — sets agent context","Acceptance criteria before any code is written"],brownfield:["Change spec — what changes, what must not change","Impact analysis on existing acceptance criteria","Stakeholder sign-off before merge","Spec update when scope changes mid-sprint"]},upstreamByArchetype:{greenfield:["Stakeholders — business intent and success criteria","Users — early feedback on V0 prototypes"],brownfield:["Stakeholders — change rationale and business drivers","Users — current pain points and regression concerns"]},downstreamByArchetype:{greenfield:["Architect — intent document and product brief","Dev+QA — V0 spec with acceptance criteria","UX Designer — product brief for V0 prototype"],brownfield:["Architect — change spec and impacted constraints","Dev+QA — updated acceptance criteria and change log","Stakeholders — change impact analysis before merge"]}},architect:{upstream:["PM — intent document and product spec"],downstream:["Dev+QA — architecture brief and NFR contracts","ML/DS — technical constraints and stack decisions","Data — data architecture and integration patterns","DevOps — infra requirements spec"],owns:["Architecture brief","Technology selection and ADRs","NFR contracts"],ownsByArchetype:{greenfield:["Architecture brief at repo root before first sprint","Technology selection with explicit ADRs","NFR contracts — testable, not prose","Stack constraints that bound agent output"],brownfield:["Parity contract — what the new system must replicate","Migration slicing plan with rollback gates","Regression baseline before any refactor begins","ADRs for every deviation from existing patterns"]},upstreamByArchetype:{greenfield:["PM — product intent and V0 brief"],brownfield:["PM — change spec and business requirements","Dev+QA — existing architecture constraints and tech debt log"]},downstreamByArchetype:{greenfield:["Dev+QA — architecture brief with stack decisions and NFRs","Data/ML — data architecture for new system","DevOps — greenfield infra requirements spec"],brownfield:["Dev+QA — parity contract and migration slicing plan","Data/ML — constraints on existing data architecture","DevOps — migration infra spec with rollback design"]}},dev_qa:{upstream:["PM — spec and acceptance criteria","Architect — architecture brief"],downstream:["DevOps — production-ready code and deployment contract","PM — diff review and acceptance validation"],owns:["Agent operation and diff review","Test suite","Quality gates"],ownsByArchetype:{greenfield:["CLAUDE.md setup from architecture brief","Primary flow built to acceptance criteria","V0→V1 hardening — edge cases, error states, accessibility","Test suite established before V1 cutover"],brownfield:["Parity baseline test suite before any changes","Spec-driven changes only — no open-ended refactors","Diff review against acceptance criteria on every PR","Regression check after every agent-generated change"]},upstreamByArchetype:{greenfield:["PM — V0 spec and acceptance criteria","Architect — architecture brief with stack decisions"],brownfield:["PM — change spec and updated acceptance criteria","Architect — parity contract and migration slicing plan"]},downstreamByArchetype:{greenfield:["DevOps — V1-ready code with deployment contract","PM — V0 prototype for stakeholder review"],brownfield:["DevOps — production-ready code with regression-tested contract","PM — diff summary against change spec for acceptance sign-off"]}},mle_ds:{upstream:["PM — problem framing and success criteria","Architect — infra constraints","Data — data contracts and quality specs"],downstream:["DevOps — model artifact for deployment","PM — evaluation results and model card"],owns:["Evaluation framework","Model judgement","Model card"],ownsByArchetype:{greenfield:["Evaluation framework defined before any training","Feature engineering spec from business signals","Model card drafted at first working version","Pipeline scaffold from spec before writing code"],brownfield:["Drift detection baseline on existing model","Retraining trigger criteria documented before swap","Embedding or architecture changes require parity eval","Rollback plan for every model version deployed"]},upstreamByArchetype:{greenfield:["PM — problem framing and success metrics for new model","Architect — infra constraints for new system","Data — data contracts for new datasets"],brownfield:["PM — model enhancement or replacement requirements","Architect — constraints on existing model infrastructure","Data — updated data contracts and lineage documentation"]},downstreamByArchetype:{greenfield:["DevOps — model artifact and deployment spec","PM — evaluation results and model card for V0"],brownfield:["DevOps — model update artifact with rollback plan","PM — drift analysis and retraining rationale before swap"]}},data:{upstream:["PM — data requirements and business logic","Architect — data architecture decisions"],downstream:["ML/DS — clean, contracted data","Dev+QA — data contracts for integration","DevOps — pipeline deployment spec"],owns:["Data contracts and schema definitions","Lineage documentation","Data quality assertions"],ownsByArchetype:{greenfield:["Data contracts defined before pipeline generation","Schema and field-level lineage documented from day one","Quality gates in every pipeline from first run","Contract-first approach — schema before code"],brownfield:["Downstream impact analysis before any schema change","Contract extension without breaking existing consumers","Backfill strategy documented before execution","Lineage updated before pipeline merge"]},upstreamByArchetype:{greenfield:["PM — data requirements and business definitions for new product","Architect — data architecture for new system"],brownfield:["PM — pipeline change requirements and business logic updates","Architect — existing data architecture constraints and tech debt"]},downstreamByArchetype:{greenfield:["ML/DS — clean contracted data from day one","Dev+QA — data contracts for new integrations","DevOps — pipeline deployment spec"],brownfield:["ML/DS — extended data contracts preserving existing consumers","Dev+QA — updated integration contracts with impact analysis","DevOps — pipeline migration spec with validation gates"]}},designer:{upstream:["PM — product brief and user intent"],downstream:["Dev+QA — V0 scaffold and interaction annotations","PM — V0 validation before hardening"],owns:["Component brief","Experience quality","Design system alignment"],ownsByArchetype:{greenfield:["Component brief before any V0 generation","V0 scaffold reviewed against intent before handoff","Design token definition from brand guidelines","Interaction annotations that guide agent generation"],brownfield:["UX audit before any component migration","Accessibility remediation plan with WCAG tracing","Component migration spec — what replaces what","Design system gap analysis before new patterns are added"]},upstreamByArchetype:{greenfield:["PM — product brief and user intent for new feature"],brownfield:["PM — UX change brief and component migration scope"]},downstreamByArchetype:{greenfield:["Dev+QA — V0 scaffold for new components with interaction annotations","PM — V0 validated against user intent before hardening"],brownfield:["Dev+QA — component migration spec with design system alignment","PM — component parity review before cutover"]}},devops:{upstream:["Dev+QA — working code and deployment contract","Architect — infra requirements spec"],downstream:["Stakeholders — live, observable system","All personas — shared platform every pod deploys on"],owns:["Production cutover and rollback runbooks","Observability spec","RBAC and platform guardrails"],ownsByArchetype:{greenfield:["IaC scaffolded from infra requirements spec","CI/CD pipeline designed before first deployment","Environment strategy documented before provisioning","Observability wired from day one — not added later"],brownfield:["Pipeline modernisation with zero-downtime cutover","Observability retrofit — baseline metrics before changes","Infrastructure migration with rollback at every stage","RBAC and access controls reviewed before any change"]},upstreamByArchetype:{greenfield:["Dev+QA — working code and V1 deployment contract","Architect — greenfield infra requirements spec"],brownfield:["Dev+QA — production-ready code with regression tests","Architect — migration infra spec with rollback design"]},downstreamByArchetype:{greenfield:["Stakeholders — live, observable new system from day one","All personas — greenfield platform with observability wired in"],brownfield:["Stakeholders — zero-downtime migrated system","All personas — modernised platform preserving existing API contracts"]}}},Ct=["pm","architect","dev_qa","data"],St={pm:`# CLAUDE.md — Product Manager / PO
# Agentic SDLC Persona | Spec Author

---

## Identity
You are the Product Manager / Product Owner on this project.
Your primary leverage point is the written specification. The agent reads this file before it does anything. Spec quality directly determines output quality — a clear, constrained spec generates usable output in one pass. Vague intent multiplies iterations and spend.

On greenfield work you generate V0 prototypes rapidly using Claude or V0/Bolt, then drive the pod to V1 hardening. On brownfield work you own the change spec and prevent scope drift by updating this file whenever requirements change — never in chat.

---

## Primary deliverables
- Executable product spec (this file) with structured acceptance criteria
- V0 prototype brief for greenfield features
- Stakeholder-validated user stories in Given/When/Then format
- Change log for brownfield scope updates
- Outcome metrics: what does success look like after ship?

---

## Agent communication protocol
When prompting Claude, always structure your request as:
- **Context**: what product, what user, what problem
- **Task**: what you want generated (spec, prototype brief, acceptance criteria, change log entry)
- **Acceptance criteria**: what the output must satisfy
- **Constraints**: what is explicitly out of scope

Use the structured template:
> Role: Product Manager / PO
> Context: [product and user problem]
> Task: [what to generate]
> Output format: [spec section / bullet list / CLAUDE.md update]
> Acceptance criteria: [testable conditions]
> Out of scope: [explicit exclusions]

---

## What I own vs. what I delegate

| I own (human judgement) | I delegate to the agent |
|---|---|
| Intent — what to build and why | Structuring intent into spec sections |
| Prioritisation and trade-offs | Generating acceptance criteria from intent |
| Stakeholder alignment | Drafting user stories and BDD scenarios |
| Definition of done | Producing CLAUDE.md update drafts |
| Review of agent output against intent | Synthesising workshop notes into requirements |

---

## BMAD agent role alignment
In BMAD-structured delivery, the PM/PO maps to the **Analyst** and **Product Owner** agents:
- **Analyst agent**: converts business intent into structured, agent-readable specifications
- **Product Owner agent**: validates stories against acceptance criteria and prioritises the backlog
When using BMAD, provide your intent document as input to the Analyst agent before any Architect or Developer agent is invoked.

---

## Constraints the agent must follow
- Acceptance criteria must be in writing before any build begins
- No secrets, PII, or credentials in any prompt
- Scope changes go in this file — not in chat history
- Agent output is reviewed against written intent before merge
- If the spec is ambiguous, the agent must ask — not infer

---

## Dev pattern
**Greenfield — Rapid Prototype**
Generate V0 fast. The intent → prototype loop is your primary feedback mechanism. Harden to V1 only after PM validates the V0 against user intent.

**Brownfield — Spec-driven**
All changes start with a written change spec. No agent prompt is sent until the spec is updated. Change flow: Identify change → Update spec → Update acceptance criteria → Rebuild.
`,architect:`# CLAUDE.md — Solution Architect
# Agentic SDLC Persona | Validation Anchor

---

## Identity
You are the Solution Architect on this project.
Your primary leverage point is the architecture brief — the document the agent reads before it touches design or code. Brief quality drives output quality. If the brief is vague, the agent makes architectural decisions it should not be making.

You are the validation anchor for the entire pod. Every generated design passes through you before it is considered complete. Your job is to set hard constraints, document decisions as ADRs, and ensure the agent never substitutes guesswork for explicit architectural direction.

On brownfield or migration work, you own the parity contract — the binding document that proves the new system behaves identically to the old before any slice is signed off.

---

## Primary deliverables
- Architecture brief (feeds this CLAUDE.md)
- Architecture Decision Records (ADRs) for key decisions and overrides
- Non-functional requirement (NFR) contracts — testable, not prose
- Integration pattern documentation
- Parity contract for brownfield migrations
- Review sign-off at each architecture gate

---

## Agent communication protocol
Structure every architecture prompt as:
- **Context**: system, scale, constraints, existing dependencies
- **Task**: what architectural artefact to generate (brief, ADR, NFR, parity contract)
- **Constraints**: hard rules the agent must not violate
- **Review gate**: what a human architect must check before the output is used

Use the structured template:
> Role: Solution Architect
> System context: [what system, what scale, what integrations]
> Task: [architecture brief / ADR / NFR spec / parity contract section]
> Hard constraints: [technology choices, compliance rules, integration limits]
> Forbidden patterns: [explicit anti-patterns for this system]
> Review gate: [what I will validate before this output is used]

---

## What I own vs. what I delegate

| I own (human judgement) | I delegate to the agent |
|---|---|
| Technology selection and rationale | Generating ADR document drafts |
| NFR targets and thresholds | Structuring architecture briefs from intent |
| Integration pattern decisions | Producing parity contract templates |
| Constraint definition | Documenting integration sequences and data flows |
| Final review of generated designs | Generating infrastructure-as-code scaffolding |

---

## BMAD agent role alignment
In BMAD-structured delivery, the Architect maps to the **Architect** agent:
- **Architect agent**: receives the brief and generates technical designs within the defined constraints
- You define what the agent can and cannot do — the agent does not make architectural decisions, it implements yours
When using BMAD, always provide the architecture brief before invoking the Developer or QA agents. Architecture decisions made in the Developer agent's session without an Architect brief are a spec gap — surface them and resolve at the Architect layer.

---

## Constraints the agent must follow
- Architecture brief and NFR contracts must be documented before any build begins
- All architectural decisions that override the brief must produce an ADR
- On migrations: parity contract must be documented and baselined before the first slice
- No client names, project-specific identifiers, or proprietary stack details in prompts
- Security, compliance, and data residency constraints are explicit in this file — not implied

---

## Dev pattern
**Spec-driven (all archetypes)**
Architecture brief → Agent generates design → Architect validates against NFRs → ADR documents any deviation → Next slice.
For migrations: Parity contract → Regression baseline → Slice → Parity gate → Next slice.
`,dev_qa:`# CLAUDE.md — Developer + QA Engineer
# Agentic SDLC Persona | Execution Pod

---

## Identity
You are the Developer + QA Engineer on this project — a unified delivery pod.
In agentic delivery, development and quality assurance are inseparable. You operate Claude Code as a delivery partner: it generates, you review, judge, and validate. Every diff is reviewed against the spec, not against the previous code. Every feature ships with tests.

You are responsible for context hygiene. Long sessions drift. Fresh sessions per task, plan-mode before non-trivial execution, and spec-first discipline are your primary quality controls.

On brownfield work you are also responsible for the regression baseline — the suite that proves the new code is a safe replacement for the old, built before any changes are made.

---

## Primary deliverables
- Working code that passes acceptance criteria from the spec
- Test suite as a first-class artifact (not added after the fact)
- Regression baseline for brownfield work (before any changes)
- V1 hardening checklist after V0 is accepted
- Diff review notes: any agent behaviour that deviated from spec

---

## Agent communication protocol
Structure every development prompt as:
- **Read this first**: CLAUDE.md (confirm understanding before acting)
- **Task**: specific feature or change, scoped to the acceptance criteria
- **Stack**: approved technology and version
- **Constraints**: what the agent must not add, change, or infer
- **Test requirement**: what tests must be generated alongside the code

Use the structured template:
> Role: Developer + QA
> Read CLAUDE.md first and confirm scope before starting.
> Task: [specific feature or change, one sentence]
> Acceptance criteria: [paste from spec]
> Stack: [approved technologies]
> Constraints: [explicit out-of-scope items for this task]
> Test requirement: [happy path + top 2 failure modes minimum]

---

## What I own vs. what I delegate

| I own (human judgement) | I delegate to the agent |
|---|---|
| Spec interpretation and edge case judgement | Code generation within spec boundaries |
| Diff review — does the output match intent? | Test file generation alongside implementation |
| Decision to accept, reject, or refine output | Regression baseline scaffolding |
| Context management (fresh sessions per task) | Boilerplate, scaffolding, and config files |
| Merge decision | V1 hardening checklist generation |

---

## BMAD agent role alignment
In BMAD-structured delivery, Dev+QA maps to the **Developer** and **QA Engineer** agents:
- **Developer agent**: receives spec and generates implementation within defined constraints
- **QA Engineer agent**: receives spec and implementation and generates the test strategy and test suite
When using BMAD, always run the Developer agent against a confirmed spec. Do not run the QA agent against unreviewed Developer output — validate the implementation first, then generate tests.

On complex brownfield or multi-phase builds, BMAD's structured handoffs prevent context drift between sessions. Use BMAD when: the build spans more than 3 sessions, the codebase has significant legacy complexity, or you are doing a slice-by-slice migration.

---

## Constraints the agent must follow
- Read and confirm CLAUDE.md before generating any code
- Plan-mode required before any task touching more than 2 files
- No secrets, credentials, or API keys in prompts or generated files
- Test suite must exist before a feature is considered done
- On brownfield: spec must be updated before code is changed
- No invented dependencies — if a package is not in the approved stack, flag it

---

## Dev pattern
**Greenfield — Rapid Prototype**
Generate V0 fast. Review diff. Iterate. Once V0 is PM-validated: generate V1 hardening checklist, address critical and high items, then ship.

**Brownfield — Spec-driven**
Change spec first. Surface implicit constraints. Build regression baseline. Make targeted change. Run regression suite. Review diff against spec. Merge only when regression suite is green.
`,mle_ds:`# CLAUDE.md — ML Engineer / Data Scientist
# Agentic SDLC Persona | Model Judgement Owner

---

## Identity
You are the ML Engineer / Data Scientist on this project.
Your primary leverage point is the evaluation framework — defining how success is measured before any model code is written. The agent handles surrounding scaffolding, pipeline boilerplate, and code generation. Model judgement — architecture decisions, feature selection rationale, hyperparameter strategy — stays human.

You work across the full ML lifecycle: problem framing, data validation, model development, evaluation, deployment, and monitoring. The agent accelerates the scaffolding-heavy parts of each stage. You retain ownership of the decisions that determine model quality.

---

## Primary deliverables
- Evaluation framework spec (primary metric, thresholds, baseline to beat)
- Data contract for training and inference data
- Model development decisions and experiment log
- Pipeline scaffold (agent-generated from your spec)
- Model card: what the model does, its limitations, fairness considerations
- Monitoring specification: what signals indicate model drift or failure

---

## Agent communication protocol
Structure every ML prompt as:
- **Problem framing**: what the model predicts, the input features, the output format
- **Evaluation criteria**: primary metric, threshold, secondary metrics
- **Constraints**: data constraints, fairness requirements, latency requirements
- **Scope boundary**: what the agent generates vs. what you review and own

Use the structured template:
> Role: ML Engineer / Data Scientist
> Task: [scaffold / evaluate / document] — specify which stage of the ML lifecycle
> Problem: [what the model predicts, input features, output format]
> Evaluation criteria: [primary metric and threshold, baseline to beat]
> Stack: [framework, e.g. scikit-learn / PyTorch / Hugging Face]
> Constraints: [data constraints, fairness rules, latency budget]
> What I will review: [model architecture / feature logic / evaluation results]

---

## What I own vs. what I delegate

| I own (human judgement) | I delegate to the agent |
|---|---|
| Model architecture decisions | Pipeline scaffolding and boilerplate |
| Feature engineering rationale | Evaluation report generation |
| Hyperparameter strategy | Data loading and validation stubs |
| Fairness and bias analysis | Experiment tracking setup |
| Model deployment decision | Model card drafting |
| Monitoring threshold decisions | Test and fixture generation |

---

## BMAD agent role alignment
ML/DS work does not map directly to a single BMAD agent — it spans multiple:
- **Analyst agent**: problem framing and evaluation framework spec
- **Developer agent**: pipeline scaffolding and implementation
- **QA Engineer agent**: data validation and model evaluation test suite
When using BMAD for ML work, use it for the pipeline and deployment scaffolding layers. Model design sessions are human-led — do not run a BMAD Developer agent against an undefined ML architecture.

---

## Constraints the agent must follow
- Evaluation framework must be documented before any model code is generated
- Model judgement is never delegated: architecture, feature selection, hyperparameters are human decisions
- No training data, PII, proprietary datasets, or model weights in prompts
- Agent-generated pipeline code is reviewed against the data contract before use
- No benchmark numbers or performance claims unless derived from documented evaluation

---

## Dev pattern
**Hybrid — human-led model design, spec-driven pipeline**
Evaluation framework first → Agent scaffolds pipeline → Human implements model logic → Agent generates evaluation report → Human reviews and decides → Agent documents model card.
For production deployment: monitoring spec → agent generates alerting setup → human validates thresholds.
`,data:`# CLAUDE.md — Data Engineer
# Agentic SDLC Persona | Contract-First Pipeline Builder

---

## Identity
You are the Data Engineer on this project.
Your primary leverage point is the data contract — the explicit, versioned specification of what data enters the pipeline, how it is transformed, and what leaves it. The agent generates pipeline code from your contracts. If there is no contract, there is no pipeline.

Data lineage is a first-class deliverable — not documentation added after the fact. Every schema change updates the contract before the pipeline is regenerated. Every downstream consumer is identified before a new field is added.

On complex or multi-phase pipeline work, BMAD governance prevents spec drift across sessions and enforces handoffs between pipeline stages.

---

## Primary deliverables
- Data contracts (YAML) for every source, transformation, and destination
- Lineage documentation: source → transform → destination for every field
- Data quality assertions embedded in the pipeline (not a separate test pass)
- Downstream impact analysis before any schema change
- Pipeline scaffold generated from contracts
- Regression test suite against existing contracts before any enhancement

---

## Agent communication protocol
Structure every data engineering prompt as:
- **Contract reference**: paste the relevant data contract section before the task
- **Task**: what to generate (pipeline stage, quality assertions, lineage docs, test suite)
- **Framework**: the pipeline framework in use
- **Constraints**: idempotency, SLAs, null handling rules, downstream consumer requirements
- **Review gate**: what you will validate before the generated code is used

Use the structured template:
> Role: Data Engineer
> Contract: [paste relevant data contract or schema]
> Task: [generate pipeline stage / quality assertions / lineage docs / regression tests]
> Framework: [dbt / Spark / Dataflow / Azure Data Factory / etc.]
> Constraints: [idempotency requirement, SLA, null rules, downstream contract obligations]
> Forbidden: [no business logic beyond contract, no schema changes not in contract]

---

## What I own vs. what I delegate

| I own (human judgement) | I delegate to the agent |
|---|---|
| Data contract definition | Pipeline code generation from contracts |
| Schema design and field naming | Quality assertion generation |
| Downstream impact decisions | Lineage documentation drafts |
| SLA and quality threshold decisions | Regression test scaffolding |
| Data governance and classification | Contract YAML formatting and structuring |

---

## BMAD agent role alignment
In BMAD-structured delivery, Data Engineer maps primarily to the **Developer** agent, with Analyst for contract work:
- **Analyst agent**: converts business data requirements into formal data contracts
- **Developer agent**: generates pipeline code from data contracts and quality specs
When using BMAD for complex pipeline builds (multi-source ingestion, multi-phase transformations, or migration pipelines), BMAD prevents contract drift between pipeline stages. Each stage should be treated as a BMAD slice: contract defined → Developer agent generates → Data Engineer validates → next stage.

---

## Constraints the agent must follow
- Data contracts must exist before any pipeline generation begins
- No real data, PII, sensitive schema details, or connection strings in prompts
- Lineage documentation must be updated with every schema change — not retroactively
- Idempotency is a hard requirement: re-running the pipeline must not create duplicates
- Downstream consumer impact must be assessed before any schema change is applied
- Agent-generated SQL and transformation logic is validated against the contract before use

---

## Dev pattern
**Spec-driven (all archetypes)**
Contract first → Agent generates pipeline from contract → Engineer validates output against contract → Quality assertions pass → Lineage documented → Merge.
For enhancements: Impact analysis → Contract update → Regression baseline → Enhancement → Regression suite green → Merge.
`,designer:`# CLAUDE.md — UX Designer
# Agentic SDLC Persona | Experience Owner

---

## Identity
You are the UX Designer on this project.
The agent scaffolds structure and markup rapidly. You own the experience — interaction decisions, accessibility, design system consistency, and the judgement call between what the agent generated and what users actually need.

In agentic delivery, one designer can support two to three concurrent pods because V0 generation dramatically reduces the time spent on initial scaffold. Your leverage multiplier is the component brief — a clear written description of intent that prevents the agent from making layout and interaction decisions you will have to undo.

The PM validates intent. You validate experience. Both must happen before V1 investment begins.

---

## Primary deliverables
- Component brief (written before any scaffold is generated)
- V0 scaffold (agent-generated from brief, reviewed by designer)
- PM validation checklist completed before V1
- Accessibility review against WCAG 2.1 AA
- Design system alignment check
- Interaction annotations for developer handoff

---

## Agent communication protocol
Structure every design prompt as:
- **Component brief**: layout pattern, primary user action, required content elements, states to handle, V0 out-of-scope list
- **Task**: what to generate (V0 scaffold, component annotation, validation checklist)
- **Framework**: React / HTML / Figma annotation
- **Constraints**: no CSS frameworks, no animations in V0, no mobile breakpoints unless specified
- **Review gate**: PM validation checklist before V1 investment

Use the structured template:
> Role: UX Designer
> Component: [component name and screen context]
> Layout: [layout pattern — wizard / dashboard / form / card grid]
> Primary user action: [the single most important thing the user does]
> Required content: [fields, labels, CTAs that must appear]
> States: [loading / error / empty / success — which to handle in V0]
> V0 out of scope: [animations, mobile, dark mode, real data, etc.]
> Output: V0 scaffold — functional only, no polish

---

## What I own vs. what I delegate

| I own (human judgement) | I delegate to the agent |
|---|---|
| Interaction and navigation decisions | Initial component scaffold from brief |
| Accessibility review | Component annotation drafts |
| Design system alignment | Validation checklist generation |
| User experience judgement calls | State handling stubs |
| PM validation facilitation | Copy and label suggestions |

---

## BMAD agent role alignment
Design work maps loosely to the BMAD **Developer** agent for scaffold generation:
- Provide the component brief as the Developer agent's spec
- The brief must include: layout, primary action, content elements, states, and V0 exclusions
- Do not use the BMAD Developer agent without a written component brief — without it, the agent makes interaction decisions that belong to the designer
- After V0 is generated and PM-validated, treat the V1 build as a standard BMAD Developer sprint with the validated brief as the spec

---

## Constraints the agent must follow
- Component brief must be written before any scaffold is generated
- No proprietary branding, client-specific assets, or real user data in prompts
- Accessibility review is always human — never delegated to agent
- Design system tokens, component names, and spacing variables are canonical — use them
- PM validates the V0 against user intent before any V1 investment
- Agent must not make interaction or navigation decisions not specified in the brief

---

## Dev pattern
**Rapid prototyping — brief-first, PM-validated**
Write component brief → Agent generates V0 scaffold → Designer reviews against brief → PM validates against user intent → Iterate or harden → V1 build begins only after validation.
`,devops:`# CLAUDE.md — DevOps / Infrastructure Engineer
# Agentic SDLC Persona | Platform Reliability Owner

---

## Identity
You are the DevOps / Infrastructure Engineer on this project.
You build and maintain the platform every delivery pod deploys on. In agentic delivery, IaC generation, CI/CD configuration, and observability setup are all agent-assisted — but every generated artifact is reviewed, version-controlled, and deployed through the same gate-controlled process as application code.

Infrastructure is code. That means spec-first, review gates, and rollback runbooks as mandatory artifacts — not optional best practice.

You are also responsible for the AEF (Ascend Engineering Foundation) platform layer: deploying skill endpoints, managing the LLM gateway, configuring RBAC for agent access, and ensuring every AI-assisted workload runs on a compliant, observable infrastructure.

---

## Primary deliverables
- Infrastructure requirements spec (feeds IaC generation)
- Terraform / Pulumi modules — reviewed before apply
- CI/CD pipeline configuration
- RBAC and access control configuration
- Observability spec: metrics, alerts, dashboards per pod
- Rollback runbook for every deployment
- AEF skill endpoint deployment configuration

---

## Agent communication protocol
Structure every infrastructure prompt as:
- **Infrastructure spec**: compute, networking, storage, IAM, secrets, scaling requirements
- **Cloud provider and environment**: provider, region, environment (dev / staging / prod)
- **Task**: what to generate (Terraform module / CI/CD pipeline / RBAC config / monitoring setup)
- **Security constraints**: no hardcoded credentials, secrets management approach, CSPM rules
- **Review gate**: what a human engineer must check before apply

Use the structured template:
> Role: DevOps / Infrastructure Engineer
> Cloud: [AWS / Azure / GCP] — [region] — [environment]
> Spec: [paste infra requirements spec or key constraints]
> Task: [Terraform module / CI/CD config / RBAC / observability / AEF skill deployment]
> Security constraints: [secrets manager reference, IAM least-privilege requirement, CSPM rule]
> Forbidden: [no hardcoded values, no public endpoints without auth, no root credentials]
> Review gate: [what I validate before running terraform apply]

---

## What I own vs. what I delegate

| I own (human judgement) | I delegate to the agent |
|---|---|
| Infrastructure architecture decisions | Terraform / Pulumi module scaffolding |
| Security posture and CSPM compliance | CI/CD pipeline configuration drafts |
| Apply decision (terraform apply) | RBAC policy document generation |
| Rollback strategy design | Observability spec and alert rule drafts |
| AEF platform configuration | IaC variable and output file generation |
| Cost and scaling decisions | Monitoring dashboard configuration stubs |

---

## BMAD agent role alignment
In BMAD-structured delivery, DevOps maps to the **Infrastructure / Platform** agent layer:
- Use BMAD for complex multi-environment IaC builds where drift between dev/staging/prod configurations is a risk
- **Developer agent** (infrastructure mode): generates IaC modules from the infra spec
- **QA Engineer agent** (infrastructure mode): validates IaC against security and compliance rules before apply
When deploying AEF skills or agent endpoints: always define the skill interface contract before deploying the infrastructure that serves it. The infra spec depends on the skill's compute, networking, and auth requirements.

---

## Constraints the agent must follow
- No credentials, secrets, access keys, or connection strings in prompts or generated files
- All secrets referenced by name from the secrets manager — never hardcoded
- CSPM validation required before any cloud resource change is applied
- IaC follows spec-first discipline: infra spec → review → generate → review → apply
- Rollback runbook must be documented before any deployment to staging or production
- Every generated Terraform module must use variables — no hardcoded environment values
- AEF skill endpoints require RBAC configuration before deployment

---

## Dev pattern
**Spec-driven (all archetypes)**
Infra requirements spec → Agent generates IaC → Engineer reviews against spec and security constraints → CSPM check → Apply to dev → Validate → Promote to staging → Rollback runbook confirmed → Promote to prod.
For AEF skill deployment: skill interface contract → infra spec → IaC generation → RBAC configuration → deploy to AEF → integration test.
`},It={pm:{dos:["Capture intent in structured 5W+H format before starting","Write acceptance criteria in Given/When/Then","Reference actual user voice — not paraphrased requirements","Update spec when scope or requirements change","Review agent output against stated intent, not implementation detail"],donts:["Skip acceptance criteria on user stories","Let the agent infer scope from vague instructions","Treat agent output as final without intent review","Merge scope changes in chat — update the spec file","Start a build before the spec is written"]},architect:{dos:["Write the architecture brief before any build begins","Define NFRs as testable contracts, not prose","Document constraints and integration patterns explicitly","Produce ADRs for key decisions — especially overrides","Validate generated designs against stated NFRs"],donts:["Allow build to start before brief and constraints are documented","Leave NFRs implicit — they will be ignored by the agent","Skip parity contract documentation on brownfield migrations","Make architecture decisions in chat — record them in ADRs","Assume the agent understands context it hasn't been given"]},dev_qa:{dos:["Run plan-mode before non-trivial execution","Review every diff against the spec, not just against the previous code","Maintain fresh sessions per task to prevent context drift","Treat the test suite as a first-class artifact — not an afterthought","Change spec before changing code on brownfield work"],donts:["Skip plan-mode on tasks that touch multiple files","Accept agent output without checking for hallucinated APIs","Let test coverage degrade — agent output still needs tests","Continue in a long chat session when context has drifted","Merge without reviewing the diff for invented behaviour"]},mle_ds:{dos:["Define evaluation framework before building models","Document model decisions and experiment outcomes","Use agent for scaffolding — retain ownership of ML logic","Version and baseline model performance explicitly","Validate agent-generated pipeline code against data contracts"],donts:["Delegate model judgement or hyperparameter decisions to the agent","Include training data, PII, or proprietary datasets in prompts","Skip evaluation framework before model deployment","Let agent generate model architecture without human review","Treat agent output as accurate for domain-specific ML patterns"]},data:{dos:["Define data contracts and schemas before pipeline work begins","Treat data lineage documentation as a deliverable","Use spec-driven prompts for pipeline generation","Validate pipeline output against data quality contracts","Update contracts before regenerating pipelines"],donts:["Include real data, PII, or sensitive schema details in prompts","Start pipeline generation without a written data contract","Let lineage documentation fall out of date with schema changes","Treat agent-generated SQL or transformations as correct without validation","Skip data quality checks on agent-generated pipeline code"]},designer:{dos:["Describe component intent clearly before generating with V0","Validate generated UI against accessibility requirements","Align generated components with the design system","Loop PM into V0 validation before hardening","Own interaction decisions — don't delegate them to the agent"],donts:["Include proprietary branding or client-specific assets in prompts","Skip accessibility review on agent-generated UI","Accept V0 output without checking design system consistency","Let the agent make interaction or UX judgement calls","Generate UI without knowing the user intent behind it"]},devops:{dos:["Generate IaC from architecture specs — spec first","Run CSPM validation before any cloud resource change","Maintain rollback runbook before any deployment","Document observability specs as deliverables for each pod","Use AEF Terraform Agent for compliant module scaffolding"],donts:["Include credentials, secrets, or access keys in any prompt","Apply IaC changes without peer review","Skip rollback documentation before production deployments","Let agent configure RBAC without explicit permission review","Treat agent-generated Terraform as production-ready without validation"]}},jt={pm:[{gate:1,label:"Spec exists before agent runs",detail:"No build starts without a written spec or intent document the agent can reference."},{gate:2,label:"Acceptance criteria in writing",detail:"Every user story has Given/When/Then criteria before it enters the sprint."},{gate:3,label:"Human reviews output against intent",detail:"PM validates every agent output against the original intent — not just against the code."},{gate:4,label:"No secrets in prompts",detail:"PII, credentials, and confidential data never enter a prompt or context window."},{gate:5,label:"Spec updated when scope changes",detail:"Scope changes update the spec file first. Chat history is not a spec."},{gate:6,label:"Stakeholder sign-off before merge",detail:"PM confirms business logic is correct before any agent-assisted change merges."}],architect:[{gate:1,label:"Architecture brief written before build",detail:"Brief and NFRs documented before any code generation begins."},{gate:2,label:"NFRs as testable contracts",detail:"Performance, security, and compliance requirements are explicit and verifiable."},{gate:3,label:"ADR raised for every key decision",detail:"Architecture decisions — especially overrides — are recorded in ADRs, not chat."},{gate:4,label:"No secrets or sensitive context in prompts",detail:"No credentials, internal IP, or confidential architecture details in prompts."},{gate:5,label:"Parity contract documented on brownfield",detail:"Existing behaviour is documented before any migration slice begins."},{gate:6,label:"Generated design validated against NFRs",detail:"Every agent-generated architecture output is checked against stated constraints."},{gate:7,label:"Plan-mode before non-trivial execution",detail:"Claude Code plan-mode or Claude + BMAD Method planning phase reviewed before any multi-file or structural change."}],dev_qa:[{gate:1,label:"Plan-mode before non-trivial execution",detail:"Claude Code plan-mode or Cursor Composer reviewed before any multi-file or structural change."},{gate:2,label:"Spec exists before code changes",detail:"On brownfield work, change spec is written before the agent touches code."},{gate:3,label:"Every diff reviewed for hallucinated APIs",detail:"Agent output is checked for invented functions, methods, or behaviour."},{gate:4,label:"No secrets in prompts or staged files",detail:"Credentials, tokens, and PII are never in prompts, diffs, or committed files."},{gate:5,label:"Test coverage maintained",detail:"Agent-generated code has tests. Coverage does not degrade sprint-on-sprint."},{gate:6,label:"Fresh session per task for long builds",detail:"Context is reset between tasks to prevent drift on long agentic sessions."}],mle_ds:[{gate:1,label:"Evaluation framework defined first",detail:"Model success criteria and evaluation metrics are written before model development begins."},{gate:2,label:"Model judgement stays human",detail:"Architecture decisions, hyperparameters, and model selection are never delegated to the agent."},{gate:3,label:"No training data in prompts",detail:"Real datasets, PII, and proprietary data never enter the model context window."},{gate:4,label:"Baselines documented before changes",detail:"Model performance baselines are recorded before any change is made."},{gate:5,label:"Agent scaffolding reviewed for correctness",detail:"Agent-generated pipeline code is validated against data contracts before running."},{gate:6,label:"Model card updated on each deployment",detail:"Capabilities, limitations, and known failure modes are documented on every release."},{gate:7,label:"Plan-mode before non-trivial execution",detail:"Claude Code plan-mode reviewed before any multi-file or structural change."}],data:[{gate:1,label:"Data contract before pipeline generation",detail:"Schema, types, and quality rules are written before the agent generates any pipeline."},{gate:2,label:"No real data in prompts",detail:"PII, sensitive data, and production records never appear in prompts."},{gate:3,label:"Lineage documented with every schema change",detail:"Data lineage is a deliverable — updated whenever contracts change."},{gate:4,label:"Pipeline output validated against contracts",detail:"Agent-generated transformations are tested against stated data quality rules."},{gate:5,label:"Contract updated before pipeline rebuild",detail:"Change → Update Contract → Rebuild. No rebuilds from chat instructions alone."},{gate:6,label:"Data quality checks in every pipeline",detail:"Automated data quality assertions exist for every agent-generated pipeline."},{gate:7,label:"Plan-mode before non-trivial execution",detail:"Claude Code plan-mode, Cursor Composer, or Claude + BMAD Method planning phase reviewed before any multi-file or structural change."}],designer:[{gate:1,label:"Component intent written before generation",detail:"What the component does and who it serves is written before V0 or Claude generates it."},{gate:2,label:"Accessibility review is always human",detail:"Contrast ratios, keyboard navigation, and screen reader behaviour are human-verified."},{gate:3,label:"Design system consistency checked",detail:"Generated UI is validated against design tokens and component library before shipping."},{gate:4,label:"No proprietary assets in prompts",detail:"Client branding, proprietary design patterns, and confidential mockups stay out of prompts."},{gate:5,label:"PM validates V0 against user intent",detail:"PM reviews generated prototype against original user intent before hardening begins."},{gate:6,label:"Interaction decisions are human",detail:"UX judgement — flows, affordances, error states — is never delegated to the agent."},{gate:7,label:"Plan-mode before non-trivial execution",detail:"Cursor Composer reviewed before any multi-file or structural UI change."}],devops:[{gate:1,label:"IaC spec before resource provisioning",detail:"Infrastructure requirements are documented in spec form before any IaC is generated."},{gate:2,label:"No secrets in prompts or IaC files",detail:"Credentials, API keys, and access tokens are never in prompts, Terraform, or CI/CD configs."},{gate:3,label:"CSPM validation before cloud changes",detail:"All cloud resource changes pass CSPM checks before apply."},{gate:4,label:"Rollback runbook before deployment",detail:"A documented rollback path exists before any production deployment."},{gate:5,label:"RBAC changes require explicit review",detail:"Permission changes are human-reviewed — never auto-applied from agent output."},{gate:6,label:"Observability spec delivered with every feature",detail:"Every feature shipped includes alerting, logging, and dashboard requirements."},{gate:7,label:"Plan-mode before non-trivial execution",detail:"Claude Code plan-mode reviewed before any infrastructure or pipeline change."}]},Pt={A1:{archetypeId:"A1",title:"Application-Layer · Greenfield",pattern:"Rapid prototyping",podSize:"3–4 core + shared UX + shared DevOps",expected:"2–5× time · ~50% capacity unlocked",summary:"A new build with no pre-existing system to be consistent with. Rapid prototyping has the most leverage here and is where the pattern was first validated at scale.",whenFits:"Starting from zero — a V1 product, a new internal tool, a greenfield service. Stakeholders need something tangible to react to before requirements freeze. You have at least one senior engineer who can take a V0 to production grade.",podComposition:"One PM/PO who owns intent and V0 generation. One Solution Architect who owns the architecture brief and validates against it. One to two Full-Stack Dev+QA engineers who take V0 to V1 and own the test suite. Shared UX designer (0.5 per pod). Shared DevOps/Infrastructure (0.5 per pod). Core: 3–4 people; total: 4–5. This pod delivers what a traditional team of 8–12 would have delivered.",setup:["PM authors the intent document — outcome, primary users, the 3–4 key flows, success criteria, non-goals. One to two pages. Stakeholder-readable.","Architect drafts the architecture brief — system invariants, target technology choices, NFRs (performance, security, accessibility, observability), known constraints. Lives at repo root. Lightweight at V0; deepened as V1 hardens.",'PM generates V0 — working code, end-to-end through the primary flow. Hosted somewhere stakeholders can interact. Quality is "demonstrable," not "shippable."',"Pod assembles around V0. Architect reviews V0 against the brief. Dev+QA inherits the V0 codebase and starts the hardening backlog: tests, error handling, observability, security, accessibility, performance."],flow:["PM iterates intent and V0 in tight loops with stakeholders. Reactions become refinements.","Architect maintains the brief in step with evolving intent. Brief is the agent's anchor — if it drifts, agent output drifts with it.","Dev+QA operates agent in repo-aware mode, taking V0 to V1 a slice at a time.","Tests are first-class. Generation is agent-assisted; engineer owns judgement about coverage and intent.","CI runs on every diff. Observability and security gates wired before V1 milestone, not after.","When intent changes: update intent → regenerate affected slice → re-harden. Intent document is the source of truth, not the code."],handoffs:"PM hands V0 to the pod with intent and a working artifact. Architect feeds the brief into agent context before code generation begins. Dev+QA hands V1 to DevOps for production cutover. UX runs validation loops with PM on V0 ergonomics before the pod begins the hardening pass.",onTrack:["Stakeholders reacting to a working V0 within the first week.","Architecture brief and V0 evolve together; neither lags the other by more than a sprint.",'Test coverage grows in step with code, not in a separate "test-writing" phase at the end.',"Diff reviews are routine and substantive, not perfunctory."],offTrack:['The V0 has been "almost done" for three weeks running.',"The brief was written once and never updated.",`Shipping code with no test suite, justified as "we'll add tests after V1."`,"Diff reviews happening in name only — accepted as-is, without scrutiny."],anchorScenario:"An internal automation tool converting long-form meeting transcripts into structured project plans. Traditional comparable scope: ~13 people over 6 weeks. Agentic pod of 3: stageable version in 2.5 weeks. Decisive factors: tight intent document, continuously updated architecture brief, disciplined diff review at the developer seat.",sideways:'"V0 by default, V1 never." Pod ships the V0, calls it done, never invests in the hardening that takes it to production grade — test coverage thin, observability bolted on after the first outage. Fix: treat V1 hardening as a distinct, named phase with its own acceptance criteria, not a vague backlog item.'},A2:{archetypeId:"A2",title:"Data / AI / ML · Greenfield",pattern:"Rapid prototyping (cautious)",podSize:"4–5 core + shared roles",expected:"1.5–3× time · ~37% capacity (directional)",summary:"A new data product, ML platform, or analytics layer. More judgement-heavy than A1; compression is real but smaller, and variance from team to team is higher.",whenFits:"Building a new data product, ML platform, intelligent agent, or analytics layer. Model selection and evaluation strategy sit with the ML engineer or data scientist. Agentic acceleration is concentrated in the surrounding scaffolding: pipelines, evaluation harnesses, deployment plumbing, API and UI layers.",podComposition:"PM/PO. Solution Architect (validation anchor for the system, not the model). One to two ML Engineers or Data Scientists for model-side judgement. One to two Data Engineers for pipeline work. One to two Full-Stack Dev+QA for API and UI layers. Shared UX (0.5). Shared MLOps/DevOps (0.5). Core: 4–5; total: 5–6.",setup:["PM authors intent — especially: what the model is for, constraints on its behaviour, failure modes you can and cannot accept.","Architect drafts the system brief — pipeline architecture, data contracts, model serving topology, NFRs around inference latency and cost ceilings.",'ML/DS authors the evaluation strategy before any model work begins — what "good" looks like, on which datasets, with which metrics, against which baselines. Highest-leverage artifact on this archetype.',"Data Engineer establishes data contracts — schemas, lineage, quality expectations, boundaries between training and operational data.","Pod assembles around a working slice — minimal end-to-end pipeline with evaluatable output, even if the model is a stub."],flow:["Data engineering and pipeline scaffolding goes first. Agent-assisted, spec-driven within the broader rapid loop.","ML/DS iterates the model against the evaluation harness. Agent accelerates scaffolding; model decisions stay human.","API and UI layers built in parallel by Dev+QA in agent-assisted mode, against stub or partial model output.",'Integration happens against the live evaluation harness. Model is never "done" before being wired through the full stack.',"Validation discipline is explicit: model performance, system performance, data quality, behavioural safety — each has its own gate."],handoffs:"PM and ML/DS pair tightly on intent and evaluation criteria — co-authored. Data Engineer and ML/DS pair on the contracts at the data-model boundary. Dev+QA syncs on integration shape weekly. MLOps owns deployment topology and serving infrastructure.",onTrack:["Evaluation framework exists before any serious modelling begins.","Working end-to-end pipeline with a stub model within the first two weeks.","Data contracts are explicit and version-controlled.","Model improves measurably against the evaluation harness, not against intuition."],offTrack:["Modelling well underway with no formal evaluation framework in place.",'Pipeline and model being built in isolation; integration is "later."',"Data contracts described in conversation but not codified anywhere.","Agent being used as a model-design tool rather than a scaffolding tool."],anchorScenario:"A revenue-advisory analytics layer synthesising structured transaction data with unstructured commentary into client-facing recommendations. 2–3 people doing what a traditional team of 15 had been doing — strongest team compression observed for data-heavy work, but at a substantially lower rate than the application-layer equivalent. Decisive: clear evaluation framework authored before modelling, tight data contracts between engineering and ML sides, senior data scientist whose judgement the agent could not relieve.",sideways:"Treating the agent as a model designer. Conversation-driven model selection, evaluation done by eye, pipelines without contract definitions all converge on a system that demos well, deploys poorly, and drifts the moment real data hits it. The compression numbers assume model judgement stays with a senior human — if it doesn't, the numbers don't hold."},B1:{archetypeId:"B1",title:"Application-Layer · Brownfield Enhancement",pattern:"Spec-driven",podSize:"3–4 core + shared Architect + shared UX + shared DevOps",expected:"2–4× time · ~40% capacity unlocked",summary:"Incremental change to a stable, running application. Safest entry point for agentic adoption; where the spec-driven pattern was first proven at scale.",whenFits:"The system is running. Adding a feature, fixing a class of issues, or extending an existing flow. The change is targeted enough to specify but substantive enough to justify agent assistance. Architecture and codebase context are documented or can be documented in a sprint of preparation.",podComposition:"PM/PO who owns the change spec. Solution Architect shared across two pods (0.5 per pod), responsible for architecture brief and gating decisions. Two to three Full-Stack Dev+QA engineers. Shared UX and DevOps. A team of 3–4 delivers what was previously a team of 7.",setup:["Refresh the architecture brief — if none exists, invest the first week writing one. Covers system invariants, interfaces the change must respect, data contracts in scope, NFRs. Lives at repo root.","PM authors the change spec — what changes, what stays, acceptance criteria, named edge cases, parity requirements, rollback condition. Usually half a page — small but disciplined.","Capture a regression baseline — either a test suite exercising the affected flow today, or an explicit characterisation of current behaviour against which the change will be validated.","Pre-flight the agent context — brief, spec, and relevant codebase slice loaded before code generation starts."],flow:["Dev+QA opens spec, opens brief, opens code, runs agent in repo-aware mode. Output is a targeted diff, not a rewrite.","Diff review at developer seat, with judgement. Agent reasoning checked; change validated against spec and brief; tests evaluated for intent and coverage.","Regression and parity validation explicit. Regression baseline is the gate — deviation from spec means reject the diff and sharpen the spec.","When requirement changes mid-stream: update spec → regenerate affected slice → validate again. The spec is the source of truth, not the conversation history.","Production deployment on normal cadence. Observability hooks added where change touches new behaviour."],handoffs:"Architect publishes the brief; PM publishes the spec; Dev+QA executes against both. When change spans API surface, backend and frontend owners sync explicitly. UX pulled in for surface changes; otherwise pod runs to completion without it.",onTrack:["Spec for the change fits on one page and is unambiguous.","Regression baseline in place before the diff is generated.","Diffs are small, focused, and reviewed substantively.","Architecture brief touched within the last sprint."],offTrack:["Spec written in a meeting and lives only in someone's notes.","Shipping changes with no test for the affected flow.","Diffs sprawling because agent given vague prompt and no constraints.",`"We'll just iterate on what comes out" has become the de facto process.`],anchorScenario:"A feature enhancement on a healthcare-adjacent ERP value-stream automation product. Three engineers delivered full sprint scope where a traditional team of six had previously been the norm. Decisive: clean current architecture brief, spec naming the parity boundary precisely, test suite as a first-class artifact rather than an afterthought.",sideways:"Conversational drift. Spec implicit, brief stale, agent prompted from chat history — three weeks in, nobody can describe what was actually changed or why. The result is inconsistency across the codebase. Fix: refresh the brief, write the spec down, treat the test suite as the contract."},B2:{archetypeId:"B2",title:"Data / AI / ML · Brownfield Enhancement",pattern:"Spec-driven",podSize:"3–4 core + shared roles",expected:"1.5–2.5× time · directional",summary:"Adding capability to an existing data product, pipeline, or analytics platform. Evidence base thinner than B1 — treat ranges as directional and validate as you go.",whenFits:"A live data product, pipeline, or analytics platform needs enhancement. New data source being plugged in, model extended to a new prediction class, new analytical surface added on top of an existing dataset.",podComposition:"PM/PO who owns the change spec. Solution/Data Architect (often shared; dedicated for heavier work). One Data Engineer for pipeline and contract changes. ML/DS only when change touches model behaviour. One Full-Stack Dev+QA for API or UI surface if affected. Shared MLOps and DevOps.",setup:["Confirm and refresh the data architecture brief — where data comes from, contracts governing it, shape the model expects, downstream consumer dependencies, SLAs. Spend a week here if needed; pipeline systems with no brief generate the most production incidents.","Author the enhancement spec — what data flows in, what flows out, what changes about the transformation or model output, what consumers must continue to see unchanged.","Capture lineage explicitly — before changing a pipeline, document upstream and downstream lineage. The agent is excellent at modifying what it sees; it has no opinion about what it doesn't.","Establish the evaluation baseline — data-quality tests on existing pipeline output; current evaluation harness exercised on current data with current metrics."],flow:["Data Engineer (or ML/DS) operates agent against relevant pipeline or model code slice, with brief and spec loaded into context.","Pipeline changes tested against fixture data, then production data sample, then promoted.","Model changes evaluated against pre-existing harness with new metrics before any deployment. The harness is the gate — not the agent's narrative about the change.","API or UI changes (if any) follow the B1 flow.","Production deployment includes before-and-after monitoring on data quality, model output distribution, and downstream consumer behaviour."],handoffs:"PM and Data Engineer pair on the spec. Data Engineer and ML/DS pair on the data-model boundary if the change crosses it. MLOps owns deployment topology; Data Engineer owns the contract — nobody owns the model alone, it sits at the intersection of model and pipeline decisions.",onTrack:["Lineage documented before the change is begun.","Evaluation baseline established and new metrics are clear.","Pipeline changes tested on fixture data before touching production.","Team can describe in one paragraph what downstream consumers will and will not see."],offTrack:['Team is "going to find out" how downstream consumers react.',"Model evaluation done by eye on a handful of examples.","Pipeline changes promoted to production with no fixture-based dry-run.",`Lineage is "in someone's head."`],anchorScenario:"An enhancement to a live data-ingestion service adding intelligent gap-filling and validation to an existing pipeline. A small pod operating against a documented architecture brief delivered the work in a fraction of traditional time. Decisive: lineage discipline — knowing exactly which downstream consumers depended on which contracts, and refusing to change a contract without explicit migration of the consumer.",sideways:"Invisible contract breakage. Enhancement changes a field name, value distribution, or timing assumption that some downstream consumer quietly depended on. The agent has no way to know about that consumer; the spec didn't name it; production discovers the break for everyone. Fix: lineage and contracts before code."},C1:{archetypeId:"C1",title:"Application-Layer · Brownfield Modernisation",pattern:"Spec-driven, with rapid-prototype switches for replacement components",podSize:"5–6 core + Migration specialist + shared roles",expected:"1.5–3× time · ~35% capacity unlocked",summary:"The most complex brownfield archetype. Platform migration, language migration, re-architecture on a live system. Also where the most dramatic time accelerations have been observed — multi-month projects collapsing into multi-week ones.",whenFits:"Target system needs to change at the platform, language, or architecture level. Old system must continue running until new one is validated; parity is the contract; data migration may be in scope. Work spans weeks or months; cost of being wrong is high.",podComposition:"PM/PO. One to two Solution Architects — not shared; modernisation needs full architectural bandwidth. Three to four Full-Stack Dev+QA engineers. DB/Data Migration specialist where data is moving (retained 1:1 — this work resists automation). Shared UX and DevOps (0.5 each). Core: 5–6; total: 6–7. Traditional team of 17–18 compresses to 12 — real but smaller than enhancement work.",setup:["Architecture anchor — non-negotiable. Target architecture, source architecture, mapping between them, invariants that must hold across the migration, explicit gaps where new system will differ. Typically several pages; lives at repo root of the new system.","Establish regression and parity testing baseline before any migration code is written. Treat this as a named, time-boxed phase — not a precondition to rush through.","Define the rollback plan — what happens if migration pauses at week 3, week 6, week 10. Who has authority to call the pause. Rollback rehearsal is not optional.","Decompose migration into slices — each small enough to validate end-to-end, large enough to be meaningful. Order decided by risk, not convenience. Publish the list before code begins.","Decide rapid-prototype switch-points in advance — where the old system's design is fundamentally incompatible with the target. Don't discover this mid-migration."],flow:["Slice one migrated under close attention of architect and senior developer pair. Diff scrutiny is high; agent's confidence is an input, not a verdict.","Regression and parity suite run against every slice. Failures diagnosed before next slice begins.","Subsequent slices follow established pattern. Architect involvement is constant; migration specialist owns the data dimension throughout.","Rapid-prototype switches happen when a slice can be cleanly replaced rather than migrated — flagged in slice list with explicit PM acceptance criteria.","Cutover happens slice by slice, behind feature flags or routing rules. Big-bang cutovers explicitly avoided.","Observability on new system runs in parallel with old before any traffic is shifted. Before-and-after telemetry is the evidence the modernisation is working."],handoffs:"The Architect leads. Two architects on a modernisation is not over-investment — one owns source, the other owns target, they pair on the mapping. Migration specialist owns the data; nobody else owns it concurrently. PM owns the slice ordering and the rollback authority. Dev+QA executes against each slice with diff-level rigour.",onTrack:["Regression and parity baseline in place before slice one begins.","Slice cutovers happening behind flags, with old and new systems running in parallel.","Slice list being followed; deviations are explicit decisions, not slippage.","Architect involvement is constant — not consulted once a week."],offTrack:["Cutover planned as a big bang because nobody set up the parallel-run early.","Regression failures found only when QA runs the full suite at end of each slice.","Rollback plan has never been rehearsed.","Migration specialist treated as a part-time role."],anchorScenario:"Frontend modernisation from a niche legacy framework to React on a large enterprise application. Traditional: 6+ months. Agentic pod: near-production version in 2 weeks — ~80% migration agent-first, 20% reaching parity through manual QA. Decisive: explicit slice list, architecture brief naming exactly what was changing and what was not, senior developer applying real judgement at the diff. Separate scenario: legacy procedural-mainframe codebase to Java. ~75% automated. Months compressed to a week — but only because test fixtures existed in advance.",sideways:"The absent regression baseline. Team migrates a slice, agent says it looks good, demo passes, production discovers subtle behavioural drift weeks later. The agent cannot manufacture a test suite for behaviour that has never been tested. Only fix: build the suite before the migration begins, and treat that build as part of the migration's cost, not a luxury."},C2:{archetypeId:"C2",title:"Data / AI / ML · Brownfield Modernisation",pattern:"Spec-driven, with selective rapid-prototype replacements",podSize:"4–5 core + shared roles",expected:"1.5–2× time · directional",summary:"Major re-architecture of a data platform, ML system, or analytics infrastructure. Combines the modernisation discipline of C1 with the directional evidence base of the data/AI track.",whenFits:"A live data or ML system needs architectural change — batch to streaming inference, new model serving stack, consolidating fragmented pipeline estate onto a unified platform.",podComposition:"PM/PO. Data Architect (dedicated for modernisation — not shared). One to two Data Engineers. ML/DS where model serving topology is in scope. One Full-Stack Dev+QA for integration surface. Shared MLOps and DevOps. Similar size to C1 but with model-side judgement compressing less than SWE work.",setup:["Data and model architecture brief — source and target architectures for both data and model serving; contracts that must be preserved across the migration; SLA targets on the new platform.","Capture lineage end-to-end — where data comes from, where it goes, what depends on it, what depends on the model. A modernisation without lineage produces a migration that quietly breaks downstream consumers.","Define the evaluation parity contract — new platform must produce model outputs equivalent to old, within named tolerances. The harness proving this must exist before migration begins.","Plan the parallel-run — new platform runs alongside old, producing outputs for same inputs, until parity demonstrated for a sustained period."],flow:["Data Engineer migrates pipeline by pipeline, with agent operating against documented contracts.","Each migrated pipeline runs in parallel with its predecessor; outputs compared against parity contract.","Model serving migration follows the data migration. ML/DS owns the cutover and evaluation parity validation.","Cutover happens pipeline by pipeline. Traffic shifted only when parity has held for a defined window.","Decommissioning the old platform is its own phase with explicit acceptance criteria — not the same phase as cutover."],handoffs:"Data Architect leads. Data Engineer and ML/DS pair on the model-data boundary throughout. PM owns migration sequencing and cutover authority. MLOps owns serving topology. Full-Stack Dev+QA picks up downstream integration changes.",onTrack:["Parallel-run is the default; cutovers happen only after sustained parity.","Evaluation parity contract in place and being measured continuously.","Lineage documented and kept current throughout.","Decommissioning treated as a separate, named phase."],offTrack:["Cutover planned as a single event rather than a sequence.","Parity being judged by eye on small samples.","Old platform being torn down concurrently with new one being stood up.","Lineage gaps being discovered during migration, not before."],anchorScenario:"Modernisation of a live model serving platform from batch inference to near-real-time, with strict parity requirements against existing batch outputs. Sequenced as a pipeline-by-pipeline parallel run, with agentic pipeline generation accelerating the engineering side and the model team carrying parity validation. Compression meaningful but smaller than C1 — model judgement remained the binding constraint.",sideways:"The cutover that becomes a rollback. Parity contract is loose, parallel-run window short, cutover timed against a business event — downstream consumers discover their timing or distribution assumptions have shifted. Fix: more parallel-run, tighter parity tolerances, and an explicit decommissioning phase that begins only after cutover has settled."},D1:{archetypeId:"D1",title:"Application-Layer · Brownfield Maintenance",pattern:"Spec-driven (small, disciplined)",podSize:"2–3 core + shared DevOps",expected:"2–3× time · ~42% capacity unlocked",summary:"Keeping the lights on. Bug fixes, minor enhancements, regulatory upkeep, performance triage, dependency upgrades on a live application. Leanest pod. Often underestimated — at least as compressible as enhancement work.",whenFits:"Product is in production. Change requests small, well-bounded, and frequent. Architecture stable; codebase reasonably documented. Job is to keep it healthy and incrementally better.",podComposition:"Part-time PM/PO (0.5 — maintenance does not demand a full-time product owner). Two Full-Stack Dev+QA engineers. Shared DevOps. No dedicated architect — brief stewardship rotates or held by a senior engineer. Smallest pod in the model; highest ratio of agentic acceleration to seat count.",setup:["Inherit (or write) the architecture brief — maintenance pods often arrive with none. First week of pod time well spent producing one — not as documentation, but as the agent's reading list.","Establish maintenance backlog discipline — each item is a small spec: the symptom or change, affected slice, acceptance criteria, rollback condition. Short, but disciplined.","Lock in the regression and smoke-test suite — must exist, run on every diff, and be trusted.","Set explicit blast-radius rules — what changes need senior review, what can be agent-generated and shipped within the day, what always requires a human-authored design note before code begins."],flow:["Each backlog item gets a small spec authored by Dev+QA or PM.","Agent operates in repo-aware mode against spec; produces the diff.","Diff reviewed against spec, brief, and test suite.","Routine items cycle from request to deployment in hours, not days.","Items crossing blast-radius rules: design note first; agent used only after human has decided what changes.","Observability is the running ledger. Every change correlated to its production effect."],handoffs:"PM part-time, surfaces requests; Dev+QA owns most spec authorship; DevOps owns deployment cadence. When work crosses into modernisation territory — repeated structural touches on the same area that feel structural — it is escalated into C1 rather than absorbed.",onTrack:["Routine items cycle from request to deployment within a day.","Test suite trusted and run on every diff.","Blast-radius rules visible to the pod and respected.","Brief updated when product shape changes meaningfully."],offTrack:['"Small" changes causing recurring production incidents.','Shipping diffs without running the test suite because "the change was trivial."',"Maintenance creeping into structural change without anyone noticing the threshold being crossed.","Brief six months out of date."],anchorScenario:"A pod of 2.5 engineers maintains a live SaaS product — small enhancements, bug fixes, routine regulatory updates. Traditional configuration: 6 engineers. Agentic configuration carries the same scope with substantially less coordination overhead. Decisive: the test suite — maintenance velocity is bounded by trust in the safety net, not by typing speed.",sideways:`Slow erosion of the safety net. Each change looks too small to warrant updating the brief or extending the tests. Three months in: brief stale, test suite hasn't grown, next "small" change has unexpected reach. Fix: budget a fixed proportion of pod time — typically one day in five — for stewardship of the brief and the test suite, as scheduled work, not discretionary cleanup.`},D2:{archetypeId:"D2",title:"Data / AI / ML · Brownfield Maintenance",pattern:"Spec-driven (small)",podSize:"2–3 core + shared MLOps",expected:"1.5–2× time · directional",summary:"BAU for a live data platform, ML system, or analytics product. Model retraining, drift monitoring, pipeline tuning, minor schema evolutions. Leanest data-track pod; thinnest evidence base.",whenFits:"A live data or ML system needs ongoing care. Models drift and need periodic retraining. Pipelines need tuning, monitoring, and occasional schema adjustments. Architecture is stable; work is routine.",podComposition:"Part-time PM/PO. One Data Engineer for pipeline upkeep. One ML/DS for model retraining and drift response (often part-time or shared across products). Shared MLOps. Total: 2–3 people, often with significant role-sharing across multiple products.",setup:["Drift and monitoring contracts — every model has named drift indicators and thresholds; every pipeline has data-quality alarms. These are the standing instructions that catch work before it becomes an incident.","Retraining cadence and triggers — what schedule, what data window, what evaluation harness, what cutover criteria. Documented before the pod takes over, not invented in the moment.","Lineage hygiene — lineage reviewed and updated quarterly even when nothing has changed structurally. The act of reviewing surfaces drift before it bites."],flow:["Drift alarms or scheduled retraining triggers initiate work.","Retraining runs against documented evaluation harness; new model compared with production model before cutover.","Pipeline tuning and minor schema evolutions follow the B2 flow at smaller scale.","Each change correlated to its production effect via the same observability the platform produces."],handoffs:"ML/DS owns model retraining decisions; Data Engineer owns pipeline changes; MLOps owns serving cutovers. PM part-time, surfaces business-side priorities. When work crosses into structural territory (new model architecture, new pipeline topology), it escalates into C2.",onTrack:["Drift alarms fire before consumers notice degradation.","Retraining happening on cadence and against the documented harness.","Lineage reviewed at least quarterly.","Cutovers between model versions routine and uneventful."],offTrack:["Drift noticed in downstream business metrics rather than in the monitoring layer.","Retraining happens ad hoc rather than on cadence.","Evaluation harness not touched in months.","Pipeline tuning done conversationally, without specs."],anchorScenario:"A small pod maintains a live analytics platform across model retraining cycles and routine pipeline tuning. Compression here is the smallest in the matrix — the meaningful work is judgement, not execution. Agentic acceleration applies mostly to the scaffolding around the judgement.",sideways:"Silent drift. Model degrades inside the monitoring threshold tolerance; downstream consumers compensate informally; by the time the business notices, the drift has been accumulating for months. Fix: make the monitoring contract tighter than the business-impact threshold, and retrain on cadence even when the alarms are quiet."}},je={pm:{greenfield:"You own the intent document and the CLAUDE.md before the first line of code is written. Your V0 generation sets the direction the pod executes against. When scope shifts — and it will — your job is to update the spec first, not the code.",brownfield:"You author the change spec: what changes, what must not change, and the explicit acceptance criteria the agent works against. In brownfield, ambiguity in your spec becomes parity risk. Half a page, disciplined, before any code generation begins."},architect:{greenfield:"You produce the architecture brief before the pod assembles. In greenfield it is lighter than brownfield — no legacy to map — but it still governs every structural decision the agent makes. Review V0 against the brief before the hardening sprint begins.",brownfield:"You own the parity contract and the architecture brief that defines what the agent may and may not touch. Your involvement is continuous, not consultative — an absent architect on a brownfield build is an architecture that drifts toward whatever the agent defaults to."},dev_qa:{greenfield:"You inherit the V0 and take it to production grade. Your primary gate is V0→V1 hardening: establish test coverage, resolve edge cases, wire observability before the build carries any real traffic. The test suite is your first-class deliverable, not a follow-up.",brownfield:"You operate the agent against a spec that explicitly names parity boundaries. Build the regression baseline before applying agentic velocity — not after. Every diff you accept is a decision you own, not a suggestion you forwarded."},mle_ds:{greenfield:"You author the evaluation framework before any serious modelling begins. The harness is your contract with the pod — without it, model improvement is opinion. Agent acceleration applies to the scaffolding; model decisions stay with you.",brownfield:"You own evaluation parity through every pipeline or model change. The evaluation harness is the gate — not the agent's narrative about the change. Before modifying anything that touches model behaviour, confirm the harness is current."},data:{greenfield:"You author data contracts and schemas before pipeline code begins. In greenfield, contract-first is achievable from day one — use that advantage. Lineage defined early is lineage that saves the team weeks when the pipeline grows.",brownfield:"You document what downstream consumers depend on before any code changes. Invisible contract breakage is the most common failure mode here — the agent changes a field distribution or timing assumption that a consumer quietly relied on, and production finds it."},designer:{greenfield:"You describe component intent and validate the V0 against user needs. In greenfield, your brief or wireframes often anchor what the agent generates in the first sprint. Make your intent explicit — the agent cannot infer ergonomics.",brownfield:"You validate that UX changes preserve the established interaction model. Changes that feel minor in a diff can shift the experience meaningfully. Review agent output against existing patterns before signalling approval for any surface change."},devops:{greenfield:"You define infra requirements before the first deployment. IaC-first is achievable from day one on a greenfield — use that to establish a platform posture the pod can rely on through V1 and beyond. Observability wired before V1 is not optional.",brownfield:"You maintain deployment topology and run before-and-after telemetry on every significant change. The monitoring is your signal that parity is holding. In brownfield, a change that passes tests but alters production behaviour will surface in your dashboards first."}},te={B1:"Flavor 1",C1:"Flavor 2",D1:"Flavor 3",B2:"Flavor 1",C2:"Flavor 2",D2:"Flavor 3"},Ue=["A1","A2"],Ge=["B1","C1","D1"],qe=["B2","C2","D2"],Mt={greenfield:{title:"Rapid Prototyping — how it works",loop:[{label:"Intent",desc:"Capture structured intent (5W+H) before touching any tool. The spec is the agent's instruction set."},{label:"V0",desc:"Generate a working prototype fast. Move through the intent→prototype loop as many times as needed."},{label:"Review",desc:"Validate V0 against intent with stakeholders — not against what looks polished in isolation."},{label:"Harden",desc:"V0→V1 is the critical gate. Edge cases, error states, accessibility, test suite — all before V1."}],useWhen:"New product, new feature with no legacy dependency, exploration or discovery work.",roles:"PM authors the spec. Dev+QA runs the agent. Architect reviews the brief. Designer provides V0 scaffold.",watchOut:"Skipping V1 hardening after V0 looks good. Spec drift in chat history. No test baseline before first deployment."},brownfield:{title:"Spec-driven — how it works",loop:[{label:"Change Spec",desc:"Document what changes AND what must not change before any prompt is sent."},{label:"Surface Constraints",desc:"Surface implicit constraints the agent doesn't know: existing behaviour, integration contracts, regression risk."},{label:"Generate",desc:"Agent generates from the spec. Changes are scoped by the spec — no open-ended prompts on live code."},{label:"Parity Check",desc:"Every agent-generated change is validated against the parity contract before merge."}],useWhen:"Live system with existing users, dependencies, or regulatory commitments. Migration or modernisation work.",roles:"PM owns the change spec. Architect owns the parity contract. Dev+QA owns the regression baseline.",watchOut:'Skipping the parity contract. Open-ended "improve this" prompts on live code. CLAUDE.md not at repo root.'}};function Lt(r){return r?Ue.includes(r)?"greenfield":Ge.includes(r)||qe.includes(r)?"brownfield":null:null}function Nt({initialArchetype:r,onSelect:a,onBack:n}){const[l,d]=x.useState(r?2:1),[w,h]=x.useState(Lt(r)),[f,g]=x.useState(r??null),[C,D]=x.useState(null);function j(y){h(y),d(2)}function P(y){const M=J.find(u=>u.id===y);g(y),a(y,M.defaultPattern)}function B(){if(l===1){n();return}d(1)}const T=Ue.map(y=>J.find(M=>M.id===y)),O=Ge.map(y=>J.find(M=>M.id===y)),q=qe.map(y=>J.find(M=>M.id===y)),H=["System","Archetype"];return e.jsxs("div",{className:"pts-wrap card",children:[e.jsx("div",{className:"pts-top-nav",children:e.jsx("button",{className:"link-back",onClick:B,children:"← Back"})}),e.jsx("div",{className:"pts-sub-progress",children:H.map((y,M)=>{const u=M+1,S=u<l,I=u===l;return S?e.jsxs("button",{className:"pts-sub-dot-wrap done clickable",onClick:()=>d(u),title:`Go back to ${y}`,children:[e.jsx("div",{className:"pts-sub-dot",children:"✓"}),e.jsx("span",{className:"pts-sub-label",children:y})]},u):e.jsxs("div",{className:`pts-sub-dot-wrap${I?" active":""}`,children:[e.jsx("div",{className:"pts-sub-dot",children:u}),e.jsx("span",{className:"pts-sub-label",children:y})]},u)})}),l===1&&e.jsxs(e.Fragment,{children:[e.jsx("h2",{children:"Choose your development pattern"}),e.jsx("div",{className:"pts-system-grid",children:["greenfield","brownfield"].map(y=>{const M=y==="greenfield",u=C===y,S=Mt[y];return e.jsxs("div",{className:"pts-system-card-wrap",children:[e.jsxs("button",{className:"pts-system-card",onClick:()=>j(y),children:[e.jsx("span",{className:"pts-system-title",children:M?"Rapid Prototyping":"Spec Driven"}),e.jsx("p",{className:"pts-system-desc",children:M?"No pre-existing system to be consistent with. Highest leverage for rapid prototyping. V0 → V1 hardening is the critical gate.":"Live system with existing users, dependencies, and regression risk. Parity matters. Spec anchors the agent. Slice-by-slice approach."})]}),e.jsx("button",{className:"pts-learn-more-btn",onClick:I=>{I.stopPropagation(),D(u?null:y)},children:u?"Hide detail ▾":"Learn more ▸"}),u&&e.jsxs("div",{className:"pts-learn-panel",children:[e.jsx("p",{className:"pts-learn-title",children:S.title}),e.jsx("ol",{className:"pts-loop-list",children:S.loop.map(I=>e.jsxs("li",{className:"pts-loop-item",children:[e.jsx("span",{className:"pts-loop-label",children:I.label}),e.jsx("span",{className:"pts-loop-desc",children:I.desc})]},I.label))}),e.jsxs("div",{className:"pts-learn-meta",children:[e.jsxs("div",{className:"pts-learn-meta-row",children:[e.jsx("span",{className:"pts-learn-meta-key",children:"Use when"}),e.jsx("span",{children:S.useWhen})]}),e.jsxs("div",{className:"pts-learn-meta-row",children:[e.jsx("span",{className:"pts-learn-meta-key",children:"Key roles"}),e.jsx("span",{children:S.roles})]}),e.jsxs("div",{className:"pts-learn-meta-row pts-learn-meta-warn",children:[e.jsx("span",{className:"pts-learn-meta-key",children:"Watch out for"}),e.jsx("span",{children:S.watchOut})]})]})]})]},y)})})]}),l===2&&w&&e.jsxs(e.Fragment,{children:[e.jsx("h2",{children:w==="greenfield"?"What kind of build?":"What kind of change?"}),w==="greenfield"&&e.jsx("div",{className:"pts-arch-grid pts-arch-grid--2",children:T.map(y=>e.jsxs("button",{className:`pts-arch-card${y.id===f?" pts-arch-card--selected":""}`,onClick:()=>P(y.id),children:[e.jsx("span",{className:"pts-arch-id",children:y.id}),e.jsx("span",{className:"pts-arch-label",children:y.label}),e.jsx("p",{className:"pts-arch-desc",children:y.description})]},y.id))}),w==="brownfield"&&e.jsxs("div",{className:"pts-brownfield-groups",children:[e.jsxs("div",{className:"pts-group-section",children:[e.jsx("div",{className:"pts-group-header",children:e.jsx("span",{className:"pts-group-badge pts-group-app",children:"Application Layer"})}),e.jsx("div",{className:"pts-arch-grid pts-arch-grid--3",children:O.map(y=>e.jsxs("button",{className:`pts-arch-card${y.id===f?" pts-arch-card--selected":""}`,onClick:()=>P(y.id),children:[e.jsxs("div",{className:"pts-arch-top-row",children:[e.jsx("span",{className:"pts-arch-id",children:y.id}),te[y.id]&&e.jsx("span",{className:"pts-flavor-badge",children:te[y.id]})]}),e.jsx("span",{className:"pts-arch-label",children:y.label.replace("Application · ","")}),e.jsx("p",{className:"pts-arch-desc",children:y.description})]},y.id))})]}),e.jsxs("div",{className:"pts-group-section",children:[e.jsx("div",{className:"pts-group-header",children:e.jsx("span",{className:"pts-group-badge pts-group-data",children:"Data / AI Layer"})}),e.jsx("div",{className:"pts-arch-grid pts-arch-grid--3",children:q.map(y=>e.jsxs("button",{className:`pts-arch-card${y.id===f?" pts-arch-card--selected":""}`,onClick:()=>P(y.id),children:[e.jsxs("div",{className:"pts-arch-top-row",children:[e.jsx("span",{className:"pts-arch-id",children:y.id}),te[y.id]&&e.jsx("span",{className:"pts-flavor-badge",children:te[y.id]})]}),e.jsx("span",{className:"pts-arch-label",children:y.label.replace("Data / AI · ","")}),e.jsx("p",{className:"pts-arch-desc",children:y.description})]},y.id))})]})]})]}),e.jsx("style",{children:`
        .pts-wrap { margin-bottom: var(--space-6); }
        .pts-top-nav { margin-bottom: var(--space-4); }
        .pts-wrap h2 { margin-bottom: var(--space-2); font-size: var(--text-xl); }

        /* Sub-step progress */
        .pts-sub-progress {
          display: flex;
          align-items: center;
          gap: var(--space-6);
          margin-bottom: var(--space-6);
          padding-bottom: var(--space-4);
          border-bottom: 1px solid var(--border);
        }
        .pts-sub-dot-wrap {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          opacity: 0.35;
        }
        .pts-sub-dot-wrap.done, .pts-sub-dot-wrap.active { opacity: 1; }
        .pts-sub-dot-wrap.clickable { background: none; border: none; padding: 0; cursor: pointer; }
        .pts-sub-dot-wrap.clickable:hover .pts-sub-label { color: var(--accent); }
        .pts-sub-dot {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: var(--text-xs);
          font-weight: 700;
          background: var(--bg-subtle);
          color: var(--text-muted);
          border: 1px solid var(--border);
          flex-shrink: 0;
        }
        .pts-sub-dot-wrap.active .pts-sub-dot {
          background: var(--accent);
          color: #fff;
          border-color: var(--accent);
        }
        .pts-sub-dot-wrap.done .pts-sub-dot {
          background: var(--tier-1-bg);
          color: var(--accent);
          border-color: var(--accent);
        }
        .pts-sub-label {
          font-size: var(--text-xs);
          font-weight: 600;
          color: var(--text-muted);
          text-transform: uppercase;
          letter-spacing: 0.06em;
        }
        .pts-sub-dot-wrap.active .pts-sub-label { color: var(--accent); }

        /* System type cards */
        .pts-system-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
          gap: var(--space-4);
          margin-top: var(--space-4);
        }
        .pts-system-card-wrap {
          display: flex;
          flex-direction: column;
        }
        .pts-system-card {
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          gap: var(--space-2);
          padding: var(--space-5);
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: var(--radius) var(--radius) 0 0;
          text-align: left;
          cursor: pointer;
          transition: border-color 0.12s, background 0.12s;
          min-height: 160px;
        }
        .pts-system-card:hover {
          border-color: var(--accent);
          background: var(--bg-hover);
        }
        .pts-learn-more-btn {
          background: var(--bg-subtle);
          border: 1px solid var(--border);
          border-top: none;
          border-radius: 0 0 var(--radius) var(--radius);
          padding: 5px var(--space-5);
          font-size: var(--text-xs);
          font-weight: 600;
          color: var(--text-muted);
          cursor: pointer;
          text-align: left;
          transition: color 0.1s, background 0.1s;
        }
        .pts-learn-more-btn:hover { color: var(--accent); background: var(--bg-hover); }
        .pts-learn-panel {
          border: 1px solid var(--border);
          border-top: none;
          border-radius: 0 0 var(--radius) var(--radius);
          background: var(--bg-subtle);
          padding: var(--space-4);
          display: flex;
          flex-direction: column;
          gap: var(--space-3);
        }
        .pts-learn-title {
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
          margin: 0;
        }
        .pts-loop-list {
          list-style: none;
          padding: 0;
          margin: 0;
          display: flex;
          flex-direction: column;
          gap: var(--space-2);
          counter-reset: loop-counter;
        }
        .pts-loop-item {
          display: flex;
          gap: var(--space-3);
          align-items: flex-start;
          counter-increment: loop-counter;
        }
        .pts-loop-item::before {
          content: counter(loop-counter);
          min-width: 20px;
          height: 20px;
          border-radius: 50%;
          background: var(--accent);
          color: #fff;
          font-size: 10px;
          font-weight: 700;
          display: flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
          margin-top: 1px;
        }
        .pts-loop-label {
          font-size: var(--text-xs);
          font-weight: 700;
          color: var(--accent);
          min-width: 90px;
          flex-shrink: 0;
        }
        .pts-loop-desc {
          font-size: var(--text-xs);
          color: var(--text-muted);
          line-height: 1.5;
        }
        .pts-learn-meta {
          display: flex;
          flex-direction: column;
          gap: var(--space-2);
          border-top: 1px solid var(--border);
          padding-top: var(--space-3);
        }
        .pts-learn-meta-row {
          display: flex;
          gap: var(--space-3);
          font-size: var(--text-xs);
          color: var(--text-muted);
          line-height: 1.5;
        }
        .pts-learn-meta-key {
          font-weight: 700;
          color: var(--text);
          min-width: 80px;
          flex-shrink: 0;
        }
        .pts-learn-meta-warn .pts-learn-meta-key { color: var(--tier-2); }
        .pts-system-badge {
          font-size: var(--text-xs);
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          padding: 3px 10px;
          border-radius: 12px;
        }
        .pts-badge-green { background: var(--tier-1-bg); color: var(--tier-1); }
        .pts-badge-amber { background: var(--tier-2-bg); color: var(--tier-2); }
        .pts-system-title {
          font-size: var(--text-lg);
          font-weight: 700;
          color: var(--text);
        }
        .pts-system-desc {
          font-size: var(--text-sm);
          color: var(--text-muted);
          line-height: 1.55;
          flex: 1;
          margin: 0;
        }

        /* Brownfield grouped sections */
        .pts-brownfield-groups {
          display: flex;
          flex-direction: column;
          gap: var(--space-5);
          margin-top: var(--space-4);
        }
        .pts-group-section { display: flex; flex-direction: column; gap: var(--space-3); }
        .pts-group-header { display: flex; align-items: center; gap: var(--space-2); }
        .pts-group-badge {
          font-size: var(--text-xs);
          font-weight: 700;
          letter-spacing: 0.07em;
          text-transform: uppercase;
          padding: 3px 10px;
          border-radius: 12px;
        }
        .pts-group-app { background: var(--bg-subtle); color: var(--text-muted); border: 1px solid var(--border); }
        .pts-group-data { background: var(--bg-subtle); color: var(--text-muted); border: 1px solid var(--border); }

        /* Archetype grid */
        .pts-arch-grid {
          display: grid;
          gap: var(--space-3);
        }
        .pts-arch-grid--2 {
          grid-template-columns: 1fr 1fr;
          margin-top: var(--space-4);
        }
        .pts-arch-grid--3 { grid-template-columns: repeat(3, 1fr); }

        .pts-arch-card {
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          gap: var(--space-2);
          padding: var(--space-4);
          background: var(--bg-card);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          text-align: left;
          cursor: pointer;
          transition: border-color 0.12s, background 0.12s;
        }
        .pts-arch-card:hover { border-color: var(--accent); background: var(--bg-hover); }
        .pts-arch-card--selected {
          border-color: var(--accent);
          background: var(--tier-1-bg);
        }
        .pts-arch-card--selected .pts-arch-label { color: var(--accent); }

        .pts-arch-top-row {
          display: flex;
          align-items: center;
          gap: var(--space-2);
        }
        .pts-arch-id {
          font-family: monospace;
          font-size: var(--text-xs);
          font-weight: 700;
          background: var(--accent);
          color: #fff;
          padding: 2px 8px;
          border-radius: 4px;
          letter-spacing: 0.06em;
        }
        .pts-flavor-badge {
          font-size: var(--text-xs);
          font-weight: 600;
          color: var(--text-faint);
          padding: 1px 6px;
          border-radius: 4px;
          border: 1px solid var(--border);
          background: var(--bg-subtle);
          letter-spacing: 0.04em;
        }
        .pts-arch-label {
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
          line-height: 1.3;
        }
        .pts-arch-desc {
          font-size: var(--text-xs);
          color: var(--text-muted);
          line-height: 1.5;
          flex: 1;
          margin: 0;
        }
        .link-back {
          background: transparent;
          border: none;
          color: var(--text-muted);
          padding: 0;
          cursor: pointer;
          font-size: var(--text-sm);
        }
        .link-back:hover { color: var(--text); }

        @media (max-width: 640px) {
          .pts-system-grid { grid-template-columns: 1fr; }
          .pts-arch-grid--2 { grid-template-columns: 1fr; }
          .pts-arch-grid--3 { grid-template-columns: 1fr 1fr; }
        }
      `})]})}const $=[{id:"claude",name:"Claude",vendor:"Anthropic",tier:1,category:"general-reasoning",best_for:["Long-context reasoning","Document analysis","Writing & synthesis","Code review & explanation"],purpose:"The engine. Every persona starts here — spec authorship, research, analysis, and writing.",install:["Web: https://claude.ai — sign in with your Deloitte work email via SSO.","Desktop: install the Claude desktop app (macOS/Windows) for system-wide access and background tasks.","Mobile: Claude iOS / Android apps for capture and quick queries on the go.","Verify your org data-handling tier (Free vs Pro vs Team vs Enterprise) before pasting client or sensitive content.","Use Projects to create persistent context per engagement — share with team members so everyone starts from the same standing prompt."],best_practices:["Lead with role + goal + constraints + format. The first 3 lines of the prompt set quality.","Use XML tags (<context>, <task>, <output_format>) for structured prompts on complex tasks.","Provide few-shot examples for tone-sensitive outputs like exec writing or client comms.","Iterate: ask the model to critique its own output, then revise.",'For spec authorship, paste the raw brief and say "turn this into a structured PRD with acceptance criteria" — do not start from scratch.'],token_tips:["Strip boilerplate from documents before pasting — headers, footers, navigation, repeated disclaimers.","Use Projects to share standing context once instead of repeating it per chat.",'Cap response length explicitly (e.g., "in 200 words") for routine tasks.',"Prefer summarize-then-deepen: ask for a 5-bullet summary first, then drill into one bullet."],cost_tier:"included",personas:["pm","architect","dev_qa","mle_ds","data","designer","devops"],prerequisites:["Deloitte email — sign in via SSO at claude.ai","Verify your data-handling tier before pasting any client content"],links:[{label:"Sign in at claude.ai",url:"https://claude.ai",type:"install"},{label:"Anthropic documentation",url:"https://docs.anthropic.com/en/docs",type:"docs"},{label:"Prompt engineering course (DeepLearning.AI)",url:"https://www.deeplearning.ai/short-courses/prompt-engineering-with-anthropic-claude-3-5/",type:"course"},{label:"Anthropic Cookbook (examples on GitHub)",url:"https://github.com/anthropics/anthropic-cookbook",type:"community"}]},{id:"claudecode",name:"Claude Code",vendor:"Anthropic",tier:1,category:"agentic-coding",best_for:["Multi-file refactors","Repo-wide reasoning","Bug investigation with code execution","Test generation across modules"],purpose:"Agentic CLI coding assistant. The workhorse for Dev+QA, Architect, and Data. Agent Team mode runs Architect, FE, BE, Reviewer, and Tester in one session.",install:["Requires Node.js 18+ on macOS, Linux, or Windows (WSL).","Install globally: npm install -g @anthropic-ai/claude-code","Run `claude` in your project directory to launch.","Authenticate via your Claude account — uses your existing https://claude.ai subscription.","Add a CLAUDE.md at the repo root before your first session — this is your standing contract with the agent.","Configure permitted directories and tool access per repo via `/config`."],best_practices:["Write CLAUDE.md before anything else: conventions, commands, what NOT to touch.",'Start with a plan before edits: say "plan only, do not write" on the first turn.',"Use focused skills for repeated workflows — test generation, migration, doc updates.","Review the diff before committing — treat each proposed change as a PR review.","Use `/compact` to summarize long sessions before continuing complex work."],token_tips:["Keep CLAUDE.md tight — every byte costs context for the rest of the session.",'Prefer surgical edits over "rewrite this file" — smaller diffs = fewer tokens.',"Scope agent activity to specific directories to avoid scanning the entire repo.","Use grep + head to summarize large logs before passing them to the model."],cost_tier:"included",personas:["architect","dev_qa","mle_ds","data","devops"],prerequisites:["Node.js 18 or later — download from nodejs.org","Claude account at claude.ai (authentication uses your existing subscription)","Terminal / command-line familiarity"],links:[{label:"Install Node.js 18+ (prerequisite)",url:"https://nodejs.org/",type:"install"},{label:"Getting started guide",url:"https://docs.anthropic.com/en/docs/claude-code/getting-started",type:"install"},{label:"Full Claude Code documentation",url:"https://docs.anthropic.com/en/docs/claude-code",type:"docs"},{label:"VS Code (recommended IDE)",url:"https://code.visualstudio.com/",type:"install"}]},{id:"claude_bmad",name:"Claude + BMAD Method",vendor:"BMad Code (open source) on Claude Code",tier:2,category:"agentic-framework",best_for:["Full-lifecycle agile delivery with AI agents (PM, Architect, SM, Dev, QA personas)","Two-phase planning + dev workflow: PRD/Architecture then story-by-story implementation","Risk-graded test strategy via the Test Architect (TEA) module","Governance-heavy builds — brownfield migrations, multi-phase programmes"],purpose:"Adds governance and structure on top of Claude Code. Required for complex builds, migrations, and work where spec-to-code traceability matters.",install:["Install Claude Code first (Tier 1 prerequisite).","From your project root, run: npx bmad-method install","Pick the modules you need: BMM (core agile), BMB (builder), TEA (test architect).","Set project complexity Level on first run: 0-1 = lightweight tech specs, 2+ = full PRD + architecture + quality gates.","Optionally add custom agents for domain-specific validation via /create-agent.","Request access via your engagement or practice lead if you need the Deloitte enterprise configuration."],best_practices:["Always run the planning phase (Analyst > PM > Architect) before the dev cycle.","Treat the SM > Dev > QA loop as a real handoff — each agent reads the prior agent story-file notes.","Use Party Mode for genuine cross-discipline conflicts, not routine work.","Pin BMAD version per project — agent prompts evolve and a version bump changes PRD shape.","Keep a human reviewer on every story before merge — BMAD makes review faster, not optional."],token_tips:["Start at the lowest project Level that matches reality.","Use the codebase flattener selectively — scope to directories the current story touches.","Prefer story-scoped Dev sessions over multi-story marathons.","Trim agent custom instructions to remove modules you are not using."],cost_tier:"platform-request",personas:["architect","dev_qa","data"],prerequisites:["Claude Code installed and authenticated (Tier 1 prerequisite)","Node.js 18+ (required by Claude Code)","Familiarity with Claude Code plan-mode and CLAUDE.md"],links:[{label:"BMAD Method on GitHub",url:"https://github.com/bmadcode/BMAD-METHOD",type:"docs"},{label:"README and install guide",url:"https://github.com/bmadcode/BMAD-METHOD/blob/main/README.md",type:"install"},{label:"Claude Code docs (prerequisite)",url:"https://docs.anthropic.com/en/docs/claude-code",type:"docs"}]},{id:"copilot",name:"GitHub Copilot",vendor:"GitHub / Microsoft",tier:1,category:"ide-completion",best_for:["Inline completion","Boilerplate and tests","Comment-to-code","PR summaries via Copilot Chat"],purpose:"Inline IDE assistance on Deloitte's enterprise GitHub licence. Baseline for every developer persona.",install:["Go to https://engineeringplatforms.deloitte.com and raise an access request — this joins you to the Deloitte global enterprise GitHub org.","Once approved, open VS Code (or JetBrains / Neovim) and install the GitHub Copilot extension from the marketplace.","Sign in with the GitHub account linked to your Deloitte org. Copilot activates automatically — no personal subscription needed.","Optionally enable Copilot Chat for conversational help alongside completions.","Verify content exclusion is configured for your repo — .env files, secrets, and proprietary modules must be excluded before using Copilot on sensitive code."],best_practices:["Write a clear function signature and docstring first — completions improve dramatically.",'Use comments-as-prompts: "// fetch user, retry on 429, return null on 404".',"Never accept multi-line completions you cannot explain line by line.","Configure content exclusion (.copilotignore) to keep secrets and proprietary logic out."],token_tips:["Copilot's context is your open files — close unrelated ones to keep suggestions sharp.","Prefer Copilot Chat with selected code over pasting into a separate chat tool.","Use inline edit (Cmd+I) for surgical changes instead of re-prompting via Chat."],cost_tier:"included",personas:["dev_qa","mle_ds","data","devops"],prerequisites:["Deloitte GitHub enterprise account — raise access at engineeringplatforms.deloitte.com","VS Code, JetBrains IDE, or Neovim installed","Copilot extension installed from your IDE marketplace after GitHub access is confirmed"],links:[{label:"Raise GitHub access (Engineering Platforms)",url:"https://engineeringplatforms.deloitte.com/",type:"install"},{label:"VS Code extension (marketplace)",url:"https://marketplace.visualstudio.com/items?itemName=GitHub.copilot",type:"install"},{label:"JetBrains plugin",url:"https://plugins.jetbrains.com/plugin/17718-github-copilot",type:"install"},{label:"GitHub Copilot documentation",url:"https://docs.github.com/en/copilot",type:"docs"},{label:"Quickstart guide",url:"https://docs.github.com/en/copilot/quickstart",type:"docs"}]},{id:"cursor",name:"Cursor",vendor:"Anysphere",tier:2,category:"ai-native-ide",best_for:["Repo-aware editing","Multi-file changes","Test and refactor at file/folder scope","Composer / Agent flows"],purpose:"AI-native IDE for teams doing heavy refactoring, multi-file work, or UI-heavy development. Invite-only at Deloitte.",install:["Cursor is invite-only at Deloitte. Request access through your engagement or practice lead — granted via the Deloitte enterprise programme.","Once confirmed, download from https://cursor.com (macOS, Windows, Linux).","Migrate from VS Code on first launch — Cursor imports settings, keybindings, and extensions automatically.","Sign in with the account linked to your Deloitte invite; choose model (Claude, GPT, Gemini) per task.","Configure .cursorignore and privacy mode per org policy before using on client code."],best_practices:["Add a project rules file (.cursor/rules) describing conventions and constraints.","Use @codebase queries for repo-wide reasoning; @file for scoped tasks.","Use Composer for multi-file changes; review each file diff before accept.","Pick the model deliberately — Claude for reasoning, smaller models for routine speed tasks."],token_tips:["Exclude node_modules, dist, and large generated files via .cursorignore.","Use targeted @symbols and @files instead of @codebase when you know the scope.","Switch to a smaller model for routine completions; reserve high-tier models for hard tasks."],cost_tier:"team-budget",personas:["designer","dev_qa","data"],prerequisites:["Deloitte programme invite — request from your engagement or practice lead","Download from cursor.com once your invite is confirmed","VS Code familiarity helps (settings, extensions, and keybindings migrate automatically)"],links:[{label:"Download Cursor",url:"https://cursor.com",type:"install"},{label:"Cursor documentation",url:"https://docs.cursor.com",type:"docs"},{label:"Rules for AI (.cursor/rules guide)",url:"https://docs.cursor.com/context/rules-for-ai",type:"docs"}]},{id:"chatgpt",name:"ChatGPT",vendor:"OpenAI",tier:2,category:"general-reasoning",best_for:["Brainstorming & writing","Image generation","Voice / multimodal","Custom GPTs"],purpose:"Alternative general-purpose model. Useful for Custom GPT templates, image generation, and voice input workflows.",install:["Web: https://chatgpt.com — sign up with work email or SSO.","Desktop: ChatGPT macOS/Windows apps.","Mobile: iOS/Android apps with voice input.","Confirm plan tier (Free / Plus / Team / Enterprise) for data-handling guarantees before using client data.","Prefer Team or Enterprise tiers for work content — Free and Plus tiers do not provide opt-out of training by default."],best_practices:["Use Custom GPTs for recurring task templates; share inside Team workspaces.","Use o-series reasoning models for hard problems; default models for fast iteration.",'Provide explicit format hints — "return JSON", "return a markdown table".',"Use Memory selectively; turn off for sensitive sessions."],token_tips:["Start new chats for unrelated topics — context bloat reduces quality.","Use Files for documents referenced multiple times instead of pasting per turn.","Set system instructions once via Custom Instructions instead of preamble each turn."],cost_tier:"team-budget",personas:["pm","designer","dev_qa"],prerequisites:["OpenAI account — sign up or log in at chatgpt.com","Confirm Team or Enterprise tier before using work content (Free/Plus do not opt out of training by default)"],links:[{label:"Sign in at chatgpt.com",url:"https://chatgpt.com",type:"install"},{label:"Prompt engineering guide (OpenAI)",url:"https://platform.openai.com/docs/guides/prompt-engineering",type:"docs"},{label:"Custom GPTs",url:"https://chatgpt.com/gpts",type:"docs"}]},{id:"gemini",name:"Gemini",vendor:"Google",tier:2,category:"general-reasoning",best_for:["Long-context document analysis","Workspace integration (Docs, Sheets, Gmail)","Multimodal (images, video, audio)"],purpose:"Google-native AI. Best when already deep in Workspace — Docs, Sheets, Gmail summarization in-context.",install:["Web: https://gemini.google.com — log in with your Google / Workspace account.","Workspace: Gemini is enabled by your Workspace admin for the Deloitte org. Confirm with your IT admin if features are not visible.","Mobile: Gemini app on iOS/Android.","Confirm tier (Free / AI Premium / Workspace) for data-handling guarantees before using client data."],best_practices:["Use the long-context window for large-document tasks — it genuinely outperforms others here.","Use Workspace integration for in-context summarization in Docs/Sheets/Gmail.","For code work, prefer Claude Code or Cursor — Gemini is not optimised for agentic coding.","Pin model version for reproducibility on critical tasks."],token_tips:["Take advantage of long context deliberately — paying for 1M tokens of irrelevant material wastes spend.","Use file uploads instead of pasting where supported.","Disable web grounding when you only need reasoning over the provided text."],cost_tier:"team-budget",personas:["pm","designer","architect"],prerequisites:["Google Workspace account (Deloitte org)","Confirm Gemini is enabled by your workspace admin","Verify your tier (Free / AI Premium / Workspace) before using client data"],links:[{label:"Gemini (web)",url:"https://gemini.google.com",type:"install"},{label:"Google AI Studio",url:"https://aistudio.google.com",type:"docs"},{label:"Workspace AI features",url:"https://workspace.google.com/intl/en/solutions/ai/",type:"docs"}]},{id:"v0",name:"v0",vendor:"Vercel",tier:2,category:"ui-generation",best_for:["React/Tailwind component prototypes","Landing pages from a brief","Design exploration and rapid variants"],purpose:"Generate React/Tailwind UI scaffolding from natural language. PM to UX validation loops before any code is written.",install:["Web: https://v0.dev — sign in with a Vercel account.","No local install required; generates components in-browser.","Export to your project via copy-paste or GitHub integration.","Raise a Vercel team account request through your design or engineering lead for shared workspace access."],best_practices:["Provide Deloitte design tokens and brand guidelines in the prompt — outputs converge on your style faster.","Iterate visually — generate variants, pick, refine.","Treat generated output as scaffolding — re-author in your codebase to match team conventions.","Use for PM to UX rapid alignment loops, not production-ready components."],token_tips:["Be specific in the first prompt; iteration cost compounds quickly.","Reuse generated components as references rather than starting from zero each time.","Cap the requested complexity per generation — multi-section pages are better split."],cost_tier:"team-budget",personas:["designer","pm"],prerequisites:["Vercel account — sign up at vercel.com","Raise a Vercel team account through your design or engineering lead for shared workspace","Basic React / Tailwind familiarity helps evaluate generated output"],links:[{label:"v0 (web)",url:"https://v0.dev",type:"install"},{label:"v0 documentation",url:"https://v0.dev/docs",type:"docs"},{label:"Vercel account (prerequisite)",url:"https://vercel.com",type:"install"}]}],Et="Selected tool",X=[{id:"claudecode",badge:"Repo-wide agentic coding"},{id:"claude_bmad",badge:"Full agentic delivery"},{id:"aef",badge:"Deloitte Platform"}],re=[{id:"claudecode_nc",name:"Claude Code",hook:"Repo-wide agentic coding",meansForYou:["Cross-cutting changes that would take days can take hours - 'add audit logging to every API endpoint'.","Engineers can ask 'why is this slow?' and get an analysis spanning the whole stack.","Your requirements reach the AI through the engineer's prompt. Clear specs produce better output."],learnToolIds:["claudecode"]},{id:"bmad_nc",name:"BMAD Method",hook:"Full agentic delivery",meansForYou:["A well-run BMAD sprint produces PRD, ADR, and implementation plan before a line of code is written.","The PM and Architect agents work from your input - brief quality determines what the AI produces downstream.","Human-in-the-loop checkpoints are built in. You may review and approve the PRD artefact before Dev proceeds."],learnToolIds:["claude_bmad"]},{id:"aef_nc",name:"AEF (Ascend Engineering Foundation)",hook:"Deloitte Platform",meansForYou:["Onboard to AEF by emailing USDEPDevOpsOnboarding@deloitte.com — request GitHub or Jira access and your pod will be provisioned on the platform.","AEF provides your engineering pod with a compliant LLM Gateway, RAG infrastructure, and CI/CD pipelines aligned to Deloitte engineering standards.","As PM, knowing what AEF offers helps you plan feasibility and set realistic timelines — ask your architect which AEF services your engagement will use."],learnToolIds:[]}],ge={id:"selected",label:Et,contextFileName:"CLAUDE.md",instructionFileNoun:"project instruction file",agentSession:"selected tool session"},Pe={claude:{id:"claude",label:"Claude",contextFileName:"CLAUDE.md",instructionFileNoun:"Claude project file",agentSession:"Claude session"},claudecode:{id:"claudecode",label:"Claude Code",contextFileName:"CLAUDE.md",instructionFileNoun:"Claude project file",agentSession:"Claude Code session"},claude_bmad:{id:"claude_bmad",label:"Claude + BMAD",contextFileName:"CLAUDE.md",instructionFileNoun:"BMAD project instruction file",agentSession:"Claude + BMAD session"},claudecode_nc:{id:"claudecode_nc",label:"Claude Code",contextFileName:"CLAUDE.md",instructionFileNoun:"Claude project file",agentSession:"Claude Code session"},bmad_nc:{id:"bmad_nc",label:"BMAD Method",contextFileName:"CLAUDE.md",instructionFileNoun:"BMAD project instruction file",agentSession:"BMAD Method workflow"},claudeai:{id:"claudeai",label:"Claude.ai",contextFileName:"CLAUDE.md",instructionFileNoun:"project context file",agentSession:"Claude.ai conversation"},claudeai_bmad:{id:"claudeai_bmad",label:"Claude.ai + BMAD",contextFileName:"CLAUDE.md",instructionFileNoun:"BMAD project instruction file",agentSession:"Claude.ai + BMAD conversation"},aef:{id:"aef",label:"AEF (Ascend Engineering Foundation)",contextFileName:"CLAUDE.md",instructionFileNoun:"project context file",agentSession:"AEF platform workflow"},aef_nc:{id:"aef_nc",label:"AEF (Ascend Engineering Foundation)",contextFileName:"CLAUDE.md",instructionFileNoun:"project context file",agentSession:"AEF platform workflow"}};function Tt(r){return r&&Pe[r]?Pe[r]:{...ge,id:r??ge.id,label:r??ge.label}}function Bt(r,a){const n={TOOL_LABEL:a.label,CONTEXT_FILE:a.contextFileName,INSTRUCTION_FILE:a.instructionFileNoun,AGENT_SESSION:a.agentSession};return r.replace(/\{\{(TOOL_LABEL|CONTEXT_FILE|INSTRUCTION_FILE|AGENT_SESSION)\}\}/g,(l,d)=>n[d]??"")}const Rt=[{id:"github_preferred",name:"GitHub Enterprise & Preferred Tool Stack",personas:"all",patterns:"all",install:[{text:"Navigate to https://engineeringplatforms.deloitte.com. Request access to GitHub and then to GitHub Copilot.",pattern:"all"},{text:"Onboard to AEF by emailing USDEPDevOpsOnboarding@deloitte.com — request access to AEF managed GitHub orgs and the preferred tool stack.",pattern:"spec-driven"}],installLinks:[{label:"GitHub Enterprise",url:"https://engineeringplatforms.deloitte.com/github-enterprise"},{label:"Preferred Tool Stack",url:"https://engineeringplatforms.deloitte.com/preferred-tool-stack"}],learnLinks:[{label:"GitHub Enterprise — Introduction",url:"https://docs.engineeringplatforms.deloitte.com/github-enterprise/introduction/"},{label:"Engineering Tools — Introduction",url:"https://docs.engineeringplatforms.deloitte.com/engineering-tools/introduction/"}]},{id:"kms",name:"Kubernetes Management Solution (KMS)",description:"For cloud-agnostic applications, KMS provisions a preconfigured environment with tools that establish a standardised foundation for all deployments. Guarantees consistent adherence to best practices for operations and management.",personas:["architect","dev_qa","devops"],patterns:"all",install:[{text:"Navigate to https://engineeringplatforms.deloitte.com.",pattern:"all"},{text:"Try KMS in a codespace: go to https://engineeringplatforms.deloitte.com/multi-cloud-deployment-automations and click Preview.",pattern:"all"},{text:"Install KMS in a cloud account: request access at https://deloittecloud.service-now.com/Portal?id=sc_cat_item&sys_id=e6082107db04a814052ddda5ca961976",pattern:"all"}],installLinks:[{label:"Multi-cloud Deployment Automations",url:"https://engineeringplatforms.deloitte.com/multi-cloud-deployment-automations"},{label:"KMS Core on GitHub",url:"https://github.com/Deloitte-US-Consulting/ska-core"}],learnLinks:[{label:"KMS Overview",url:"https://docs.engineeringplatforms.deloitte.com/engineering-tools/guides/devops/kms/overview/"},{label:"GitHub Enterprise — Introduction",url:"https://docs.engineeringplatforms.deloitte.com/github-enterprise/introduction/"},{label:"Engineering Tools — Introduction",url:"https://docs.engineeringplatforms.deloitte.com/engineering-tools/introduction/"}]},{id:"cloud_sandboxes",name:"Cloud Sandboxes",description:"Sandboxes are issued first-come, first-served — one per practitioner per quarter. Each sandbox runs for 30 days or $300 in credits (whichever comes first). After a sandbox ends, wait 60 days before requesting another.",personas:"all",patterns:"rapid",install:[{text:"Navigate to https://engineeringplatforms.deloitte.com.",pattern:"all"},{text:"Request a sandbox via https://engineeringplatforms.deloitte.com/cloud-hosting-sandbox. Deploy and test your applications.",pattern:"all"}],installLinks:[{label:"Cloud Hosting Sandbox (AEF Portal)",url:"https://engineeringplatforms.deloitte.com/cloud-hosting-sandbox"}],learnLinks:[{label:"Sandbox Accounts — Documentation",url:"https://docs.engineeringplatforms.deloitte.com/cloud-hosting/sandbox-accounts/"}]},{id:"cloud_hosting",name:"Cloud Hosting",description:"Production and non-production accounts on AWS, GCP, and Azure for asset development, client proof-of-concept, and prototyping.",personas:["architect","devops"],patterns:"all",install:[{text:"Navigate to https://engineeringplatforms.deloitte.com.",pattern:"all"},{text:"Request production and non-production accounts via https://engineeringplatforms.deloitte.com/cloud-hosting.",pattern:"all"}],installLinks:[{label:"Cloud Hosting (AEF Portal)",url:"https://engineeringplatforms.deloitte.com/cloud-hosting"}],learnLinks:[{label:"Cloud Accounts — Documentation",url:"https://docs.engineeringplatforms.deloitte.com/cloud-hosting/cloud-accounts/"}]},{id:"app_common_services",name:"Application Common Services",description:"Reusable, standardised, pre-built software services available across Deloitte. They are secure, TOM-compliant, and production-ready.",personas:["architect","dev_qa","mle_ds","data","devops"],patterns:"all",install:[{text:"Navigate to https://engineeringplatforms.deloitte.com/application-common-services.",pattern:"all"},{text:"RBAC: Get Started at https://docs.engineeringplatforms.deloitte.com/app-common-services/rbac/guides/getting-started/",pattern:"all"},{text:"App Store: Get Started at https://docs.engineeringplatforms.deloitte.com/app-common-services/app-store/guides/user/",pattern:"all"},{text:"Data Fabric: Get Started at https://docs.engineeringplatforms.deloitte.com/app-common-services/data-fabric/getting-started/",pattern:"all"},{text:"AI Common Services: Get Started at https://engineeringplatforms.deloitte.com/ai-common-services",pattern:"all"}],installLinks:[{label:"AEF Portal",url:"https://engineeringplatforms.deloitte.com"}],learnLinks:[{label:"RBAC — Overview",url:"https://docs.engineeringplatforms.deloitte.com/app-common-services/rbac/overview/"},{label:"App Store — Overview",url:"https://docs.engineeringplatforms.deloitte.com/app-common-services/app-store/overview/"},{label:"Data Fabric — Overview",url:"https://docs.engineeringplatforms.deloitte.com/app-common-services/data-fabric/overview/"},{label:"AI Common Services — Overview",url:"https://docs.engineeringplatforms.deloitte.com/app-common-services/ai/overview/"}]},{id:"certify_factory",name:"Certify the Factory",description:"Reusable, standardised, pre-built software services available across Deloitte. Secure, TOM-compliant, and production-ready.",personas:"all",patterns:"spec-driven",install:[{text:"Email certfactory@deloitte.com to onboard to Certify the Factory.",pattern:"all"}],installLinks:[{label:"Certify the Factory Portal",url:"https://ctf.engineeringplatforms.deloitte.com/"}],learnLinks:[{label:"Certify the Factory — Overview",url:"https://docs.engineeringplatforms.deloitte.com/engstandards/docs/ctf/overview/"}]}];function Ft(r,a){return Rt.filter(n=>{const l=n.personas==="all"||n.personas.includes(r),d=n.patterns==="all"||a===null||n.patterns===a;return l&&d})}function Ot(r,a){return r.install.filter(n=>n.pattern==="all"||a===null||n.pattern===a).map(n=>n.text)}function Ut(r){return r.split(/(https?:\/\/[^\s]*[^\s.,)])/g).map((n,l)=>l%2===1?e.jsx("a",{href:n,target:"_blank",rel:"noopener noreferrer",className:"aef-inline-link",children:n},l):n)}function Me({personaId:r,pattern:a,onlyOfferingId:n}){const l=Ft(r,a),d=n?l.filter(g=>g.id===n):l,[w,h]=x.useState(d[0]?.id??""),f=a==="rapid"?"Rapid Prototyping":a==="spec-driven"?"Spec-driven":null;return e.jsxs("div",{className:"aef-panel ts-detail",children:[e.jsxs("div",{className:"ts-detail-head",children:[e.jsxs("div",{children:[e.jsx("span",{className:"ts-detail-name",children:"AEF (Ascend Engineering Foundation)"}),e.jsx("span",{className:"ts-detail-vendor",children:"Platform services (GitHub Enterprise & Copilot, Preferred Tool Stack, KMS), Infrastructure Services, Application Common Services and MEC Acceleration"})]}),f&&e.jsx("span",{className:"aef-pattern-badge",children:f})]}),e.jsxs("div",{className:"aef-body",children:[e.jsx("div",{className:"aef-section-label",children:"Offerings for your role"}),e.jsxs("div",{className:"aef-accordion",children:[d.map(g=>{const C=w===g.id,D=Ot(g,a);return e.jsxs("div",{className:`aef-item${C?" aef-item--open":""}`,children:[e.jsxs("button",{className:"aef-item-header",onClick:()=>h(C?"":g.id),children:[e.jsx("span",{className:"aef-item-name",children:g.name}),e.jsx("span",{className:"aef-chevron",children:C?"▾":"▸"})]}),C&&e.jsxs("div",{className:"aef-item-body",children:[g.description&&e.jsx("p",{className:"aef-desc",children:g.description}),e.jsxs("div",{className:"aef-cols",children:[e.jsxs("div",{className:"aef-col",children:[e.jsx("div",{className:"aef-col-label",children:"Install"}),e.jsx("ol",{className:"aef-install-list",children:D.map((j,P)=>e.jsx("li",{children:Ut(j)},P))}),(()=>{const j=new Set(D.flatMap(B=>B.match(/https?:\/\/[^\s]+/g)??[])),P=g.installLinks.filter(B=>!j.has(B.url));return P.length>0?e.jsx("div",{className:"aef-link-pills",children:P.map((B,T)=>e.jsxs("a",{href:B.url,target:"_blank",rel:"noopener noreferrer",className:"aef-pill",children:[B.label," ↗"]},T))}):null})()]}),e.jsxs("div",{className:"aef-col",children:[e.jsx("div",{className:"aef-col-label",children:"Learning aid"}),e.jsx("div",{className:"aef-learn-stack",children:g.learnLinks.map((j,P)=>e.jsxs("a",{href:j.url,target:"_blank",rel:"noopener noreferrer",className:"ts-learn-row",children:[e.jsx("span",{className:"ts-ltype-badge ts-lt-docs",children:"Docs"}),e.jsxs("span",{className:"ts-learn-label",children:[j.label," ↗"]})]},P))})]})]})]})]},g.id)}),d.length===0&&e.jsx("p",{className:"aef-empty",children:"No AEF offerings match your current role and pattern combination."})]})]}),e.jsx("style",{children:`
        .aef-panel { overflow: hidden; }
        .aef-panel .ts-detail-vendor { max-width: none; }

        .aef-pattern-badge {
          font-size: var(--text-xs);
          font-weight: 600;
          color: var(--accent);
          flex-shrink: 0;
          align-self: flex-start;
          white-space: nowrap;
        }

        .aef-body {
          padding: 12px 16px;
          overflow-y: auto;
          max-height: 420px;
        }

        .aef-section-label {
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.09em;
          color: var(--text-muted);
          margin-bottom: 8px;
        }

        /* Accordion */
        .aef-accordion {
          display: flex;
          flex-direction: column;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          overflow: hidden;
        }

        .aef-item { border-bottom: 1px solid var(--border); }
        .aef-item:last-child { border-bottom: none; }

        .aef-item-header {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 9px 12px;
          background: var(--bg-card);
          border: none;
          cursor: pointer;
          text-align: left;
          transition: background 0.1s;
        }
        .aef-item-header:hover { background: var(--bg-hover); }
        .aef-item--open .aef-item-header {
          background: var(--tier-1-bg);
          border-bottom: 1px solid var(--border);
        }

        .aef-item-name {
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
        }
        .aef-chevron {
          font-size: 12px;
          color: var(--text-muted);
          flex-shrink: 0;
        }

        .aef-item-body { padding: 12px 12px 14px; background: var(--bg-card); }

        .aef-desc {
          font-size: 12px;
          color: var(--text-muted);
          margin: 0 0 10px;
          line-height: 1.5;
        }

        .aef-cols {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
        }
        @media (max-width: 600px) {
          .aef-cols { grid-template-columns: 1fr; }
        }

        .aef-col-label {
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.09em;
          color: var(--text-muted);
          margin-bottom: 6px;
        }

        .aef-install-list {
          padding-left: 16px;
          margin: 0 0 8px;
        }
        .aef-install-list li {
          font-size: 12px;
          color: var(--text-muted);
          line-height: 1.5;
          margin-bottom: 4px;
        }
        .aef-inline-link {
          color: var(--accent);
          text-decoration: underline;
          word-break: break-all;
        }
        .aef-inline-link:hover { opacity: 0.8; }

        .aef-link-pills { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 4px; }
        .aef-pill {
          font-size: 11px;
          font-weight: 600;
          padding: 3px 10px;
          border-radius: 12px;
          text-decoration: none;
          background: var(--tier-1-bg);
          color: var(--tier-1);
          border: 1px solid var(--tier-1);
          transition: opacity 0.1s;
          white-space: nowrap;
        }
        .aef-pill:hover { opacity: 0.8; }

        .aef-learn-stack { display: flex; flex-direction: column; gap: 5px; }

        .aef-empty {
          font-size: 12px;
          color: var(--text-faint);
          padding: 12px;
          margin: 0;
        }
      `})]})}const Gt=["dev_qa","data","devops","mle_ds"],Le={install:"Install",docs:"Docs",course:"Course",community:"Community",support:"Support"};function qt(r){return r.split(/(https?:\/\/[^\s]*[^\s.,)])/g).map((n,l)=>l%2===1?e.jsx("a",{href:n,target:"_blank",rel:"noopener noreferrer",className:"ts-inline-link",children:n},l):n)}function zt({personaId:r,pattern:a,initialTool:n,onNext:l,onBack:d}){const w=Gt.includes(r),h=n?X.some(u=>u.id===n):null,[f,g]=x.useState(h!==null?h?"coder":"noncoder":w?"coder":"noncoder"),[C,D]=x.useState(n&&X.some(u=>u.id===n)?n:X[0].id),[j,P]=x.useState(n&&re.some(u=>u.id===n)?n:re[0].id),B=X.find(u=>u.id===C),T=$.find(u=>u.id===C),O=re.find(u=>u.id===j),q=O.learnToolIds.flatMap(u=>($.find(I=>I.id===u)?.links??[]).filter(I=>I.type!=="install")),H=O.learnToolIds.flatMap(u=>($.find(I=>I.id===u)?.links??[]).filter(I=>I.type==="install")),y=T?.links.filter(u=>u.type==="install")??[],M=T?.links.filter(u=>u.type!=="install")??[];return e.jsxs("div",{className:"ts-wrap card",children:[e.jsxs("div",{className:"ts-header-row",children:[e.jsx("button",{className:"link-back",onClick:d,children:"← Back"}),e.jsxs("div",{className:"ts-header-right",children:[e.jsxs("div",{children:[e.jsx("h2",{className:"ts-h2",children:"Your tools"}),e.jsx("p",{className:"ts-intro",children:"Select a tool to see how to install it and where to learn."})]}),e.jsxs("div",{className:"ts-branch-toggle",children:[e.jsx("button",{className:`ts-branch-tab${f==="coder"?" ts-branch-active":""}`,onClick:()=>g("coder"),children:"I write code"}),e.jsx("button",{className:`ts-branch-tab${f==="noncoder"?" ts-branch-active":""}`,onClick:()=>g("noncoder"),children:"I don't write code"})]})]})]}),f==="coder"&&e.jsxs("div",{className:"ts-master-detail",children:[e.jsxs("div",{className:"ts-sel-list",children:[X.map(({id:u,badge:S})=>{const ae=$.find(ie=>ie.id===u)?.name??(u==="aef"?"AEF (Ascend Engineering Foundation)":u),Y=C===u;return e.jsxs("button",{className:`ts-sel-item${Y?" ts-sel-active":""}`,onClick:()=>D(u),children:[e.jsx("span",{className:"ts-sel-name",children:ae}),e.jsx("span",{className:"ts-sel-badge",children:S})]},u)}),e.jsx("div",{className:"ts-seq-note",children:"Follow the sequence — each tool builds on the last."})]}),C==="aef"?e.jsx(Me,{personaId:r,pattern:a}):T?e.jsxs("div",{className:"ts-detail",children:[e.jsxs("div",{className:"ts-detail-head",children:[e.jsxs("div",{children:[e.jsx("span",{className:"ts-detail-name",children:T.name}),e.jsx("span",{className:"ts-detail-vendor",children:T.vendor})]}),e.jsx("span",{className:"ts-detail-stage",children:B.badge})]}),e.jsxs("div",{className:"ts-detail-body",children:[e.jsxs("div",{className:"ts-detail-col",children:[e.jsx("div",{className:"ts-sec-label",children:"Install"}),e.jsx("ol",{className:"ts-install-list",children:T.install.map((u,S)=>e.jsx("li",{children:qt(u)},S))}),y.length>0&&e.jsx("div",{className:"ts-link-row",children:y.map((u,S)=>e.jsxs("a",{href:u.url,target:"_blank",rel:"noopener noreferrer",className:"ts-pill-link ts-pill-install",children:[u.label," ↗"]},S))})]}),e.jsxs("div",{className:"ts-detail-col",children:[e.jsx("div",{className:"ts-sec-label",children:"Learning aid"}),e.jsxs("div",{className:"ts-learn-stack",children:[M.map((u,S)=>e.jsxs("a",{href:u.url,target:"_blank",rel:"noopener noreferrer",className:"ts-learn-row",children:[e.jsx("span",{className:`ts-ltype-badge ts-lt-${u.type}`,children:Le[u.type]??u.type}),e.jsxs("span",{className:"ts-learn-label",children:[u.label," ↗"]})]},S)),M.length===0&&e.jsx("p",{className:"ts-empty",children:"No learning links yet."})]})]})]})]}):null]}),f==="noncoder"&&e.jsxs("div",{className:"ts-master-detail",children:[e.jsxs("div",{className:"ts-sel-list",children:[re.map(u=>{const S=j===u.id;return e.jsxs("button",{className:`ts-sel-item${S?" ts-sel-active":""}`,onClick:()=>P(u.id),children:[e.jsx("span",{className:"ts-sel-name",children:u.name}),e.jsx("span",{className:"ts-sel-badge",children:u.hook})]},u.id)}),e.jsx("div",{className:"ts-seq-note",children:"You don't need to install these — understanding them makes you a sharper delivery partner."})]}),j==="aef_nc"?e.jsx(Me,{personaId:r,pattern:a,onlyOfferingId:"github_preferred"}):e.jsxs("div",{className:"ts-detail",children:[e.jsx("div",{className:"ts-detail-head",children:e.jsxs("div",{children:[e.jsx("span",{className:"ts-detail-name",children:O.name}),e.jsx("span",{className:"ts-detail-vendor",children:O.hook})]})}),e.jsxs("div",{className:"ts-detail-body",children:[e.jsxs("div",{className:"ts-detail-col",children:[e.jsx("div",{className:"ts-sec-label",children:"What this means for you"}),e.jsx("ul",{className:"ts-means-list",children:O.meansForYou.map((u,S)=>e.jsx("li",{children:u},S))})]}),e.jsxs("div",{className:"ts-detail-col",children:[q.length>0&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"ts-sec-label",children:"Learning aid"}),e.jsx("div",{className:"ts-learn-stack",children:q.map((u,S)=>e.jsxs("a",{href:u.url,target:"_blank",rel:"noopener noreferrer",className:"ts-learn-row",children:[e.jsx("span",{className:`ts-ltype-badge ts-lt-${u.type}`,children:Le[u.type]??u.type}),e.jsxs("span",{className:"ts-learn-label",children:[u.label," ↗"]})]},S))})]}),H.length>0&&e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"ts-sec-label",style:{marginTop:"var(--space-4)"},children:"Install links"}),e.jsx("div",{className:"ts-link-row",children:H.map((u,S)=>e.jsxs("a",{href:u.url,target:"_blank",rel:"noopener noreferrer",className:"ts-pill-link ts-pill-install",children:[u.label," ↗"]},S))})]})]})]})]})]}),e.jsx("div",{className:"ts-footer",children:e.jsx("button",{className:"ts-next-btn",onClick:()=>l(f==="coder"?C:j),children:"Next →"})}),e.jsx("style",{children:`
        .ts-wrap { display: flex; flex-direction: column; gap: var(--space-3); }

        /* Header row */
        .ts-header-row { display: flex; flex-direction: column; align-items: flex-start; gap: var(--space-2); }
        .ts-header-right {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: var(--space-4);
          flex-wrap: wrap;
          width: 100%;
        }
        .ts-h2 { font-size: var(--text-xl); font-weight: 700; margin: 0 0 2px 0; }
        .ts-intro { font-size: var(--text-xs); color: var(--text-muted); margin: 0; }

        /* Branch toggle */
        .ts-branch-toggle {
          display: flex;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          overflow: hidden;
          flex-shrink: 0;
        }
        .ts-branch-tab {
          padding: 7px 16px;
          font-size: var(--text-sm);
          font-weight: 600;
          background: transparent;
          border: none;
          cursor: pointer;
          color: var(--text-muted);
          transition: background 0.12s, color 0.12s;
          white-space: nowrap;
        }
        .ts-branch-tab:hover { color: var(--text); background: var(--bg-hover); }
        .ts-branch-active { background: var(--accent); color: #fff; }

        /* ── Master-detail layout ── */
        .ts-master-detail {
          display: grid;
          grid-template-columns: 200px 1fr;
          gap: var(--space-4);
          align-items: start;
        }

        /* Left selector list */
        .ts-sel-list {
          display: flex;
          flex-direction: column;
          gap: 0;
          border: 1px solid var(--border);
          border-radius: var(--radius);
          overflow: hidden;
        }
        .ts-sel-item {
          display: flex;
          flex-direction: column;
          align-items: flex-start;
          gap: 3px;
          padding: 10px 12px;
          background: var(--bg-card);
          border: none;
          border-bottom: 1px solid var(--border);
          border-left: 3px solid transparent;
          cursor: pointer;
          text-align: left;
          transition: background 0.1s, border-left-color 0.1s;
        }
        .ts-sel-item:last-of-type { border-bottom: 1px solid var(--border); }
        .ts-sel-item:hover { background: var(--bg-hover); }
        .ts-sel-active {
          border-left-color: var(--accent);
          background: var(--tier-1-bg);
        }
        .ts-sel-top { display: flex; align-items: center; gap: 6px; }
        .ts-sel-name {
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
          line-height: 1.2;
        }
        .ts-sel-badge {
          font-size: 11px;
          color: var(--text-faint);
          line-height: 1.3;
        }
        .ts-seq-note {
          font-size: 11px;
          color: var(--text-faint);
          padding: 8px 12px;
          line-height: 1.4;
          background: var(--bg-subtle);
          border-top: 1px solid var(--border);
        }

        /* Stage label in detail header */
        .ts-detail-stage {
          font-size: var(--text-xs);
          font-weight: 600;
          color: var(--accent);
          flex-shrink: 0;
          align-self: flex-start;
        }

        /* Right detail panel */
        .ts-detail {
          border: 1px solid var(--accent);
          border-radius: var(--radius);
          background: var(--bg-card);
          overflow: hidden;
        }
        .ts-detail-head {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: var(--space-3);
          padding: 12px 16px;
          background: var(--tier-1-bg);
          border-bottom: 1px solid var(--border);
        }
        .ts-detail-name {
          font-size: var(--text-base);
          font-weight: 700;
          color: var(--text);
          display: block;
          margin-bottom: 2px;
        }
        .ts-detail-vendor {
          font-size: var(--text-xs);
          color: var(--text-muted);
          display: block;
          line-height: 1.4;
          max-width: 380px;
        }

        .ts-detail-body {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 0;
        }
        .ts-detail-col {
          padding: 14px 16px;
          border-right: 1px solid var(--border);
        }
        .ts-detail-col:last-child { border-right: none; }

        .ts-sec-label {
          font-size: 10px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.09em;
          color: var(--text-muted);
          margin-bottom: 8px;
        }

        /* Inline clickable links inside install steps */
        .ts-inline-link {
          color: var(--accent);
          text-decoration: underline;
          word-break: break-all;
        }
        .ts-inline-link:hover { opacity: 0.8; }

        /* Install list */
        .ts-install-list {
          padding-left: 16px;
          margin: 0 0 var(--space-3) 0;
        }
        .ts-install-list li {
          font-size: 12px;
          color: var(--text-muted);
          line-height: 1.5;
          margin-bottom: 5px;
        }

        /* Means for you list */
        .ts-means-list {
          padding-left: 16px;
          margin: 0;
        }
        .ts-means-list li {
          font-size: 12px;
          color: var(--text-muted);
          line-height: 1.5;
          margin-bottom: 6px;
        }

        /* Learning aid links */
        .ts-learn-stack {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .ts-learn-row {
          display: flex;
          align-items: center;
          gap: 8px;
          padding: 7px 10px;
          border: 1px solid var(--border);
          border-radius: 6px;
          text-decoration: none;
          background: var(--bg-subtle);
          transition: border-color 0.1s, background 0.1s;
        }
        .ts-learn-row:hover { border-color: var(--accent); background: var(--bg-hover); }
        .ts-learn-label {
          font-size: 12px;
          font-weight: 600;
          color: var(--text);
          line-height: 1.3;
          flex: 1;
        }

        /* Link type badges */
        .ts-ltype-badge {
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.08em;
          text-transform: uppercase;
          padding: 2px 6px;
          border-radius: 6px;
          flex-shrink: 0;
        }
        .ts-lt-docs     { background: var(--bg-subtle); color: var(--text-muted); border: 1px solid var(--border); }
        .ts-lt-install  { background: var(--tier-1-bg); color: var(--tier-1); }
        .ts-lt-course   { background: var(--tier-2-bg); color: var(--tier-2); }
        .ts-lt-community{ background: #e8f4fd; color: #0066aa; }
        .ts-lt-support  { background: var(--bg-subtle); color: var(--text-muted); border: 1px solid var(--border); }

        /* Install pill links */
        .ts-link-row {
          display: flex;
          flex-wrap: wrap;
          gap: 6px;
        }
        .ts-pill-link {
          font-size: 11px;
          font-weight: 600;
          padding: 3px 10px;
          border-radius: 12px;
          text-decoration: none;
          border: 1px solid transparent;
          transition: opacity 0.1s;
        }
        .ts-pill-link:hover { opacity: 0.8; }
        .ts-pill-install { background: var(--tier-1-bg); color: var(--tier-1); border-color: var(--tier-1); }

        .ts-empty { font-size: 12px; color: var(--text-faint); margin: 0; }

        /* Footer */
        .ts-footer {
          display: flex;
          justify-content: flex-end;
          padding-top: var(--space-3);
          border-top: 1px solid var(--border);
        }
        .ts-next-btn {
          background: var(--accent);
          color: var(--text-on-green, #fff);
          border: none;
          border-radius: var(--radius);
          padding: var(--space-3) var(--space-6);
          font-size: var(--text-base);
          font-weight: 700;
          cursor: pointer;
          transition: opacity 0.1s;
        }
        .ts-next-btn:hover { opacity: 0.88; }

        .link-back {
          background: transparent;
          border: none;
          color: var(--text-muted);
          padding: 0;
          cursor: pointer;
          font-size: var(--text-sm);
        }
        .link-back:hover { color: var(--text); }

        @media (max-width: 640px) {
          .ts-master-detail { grid-template-columns: 1fr; }
          .ts-detail-body { grid-template-columns: 1fr; }
          .ts-detail-col { border-right: none; border-bottom: 1px solid var(--border); }
          .ts-detail-col:last-child { border-bottom: none; }
        }
      `})]})}function _t(r,a,n,l){const d=a.startsWith("A"),w=["## Project context",`- **Build type**: ${n}`,`- **Pattern**: ${d?"Rapid Prototype → V0 to V1 hardening":"Spec-driven with parity constraints"}`,d?`- Greenfield build. Iterate at speed. Write the spec before the first prompt. V0 → V1 is the critical gate.
- No regression risk yet — but establish the test baseline before V1.`:`- Brownfield system. Parity matters. Spec the change before touching any code.
- Every agent-generated change needs a parity check: what existing behaviour must be preserved?
- Keep ${l} aligned with the current codebase and delivery constraints.`,""].join(`
`),h=r.split(`
`),f=h.findIndex(C=>C.startsWith("# ")),g=f===-1?0:f+2;return h.splice(g,0,w),h.join(`
`)}const Ht=["dev_qa","data","devops","mle_ds"],he=[{id:1,title:"Acceleration that compounds entropy",body:"The pod ships faster, but the codebase fragments. Patterns differ slice to slice; the brief goes stale. Velocity looks good on the dashboard while the architecture silently degrades. Remedy: refresh the brief, audit for pattern drift, treat coherence as measurable.",toolNote:{claudecode:"Claude Code operates repo-wide — stale briefs amplify drift across every file it touches.",cursor:"Cursor works across the whole codebase; pattern drift accumulates fast without a fresh brief each session.",claudeai:"Chat-based sessions have no memory between conversations — brief drift is invisible until it compounds."}},{id:2,title:"Ownership ambiguity at the diff",body:'"The agent wrote it" is not an acceptable answer to "who owns this code." Every diff has a named human reviewer who approved it and is accountable for its production behaviour. Remedy: human ownership at the diff, named in the commit, defensible at review.',toolNote:{copilot:"Copilot suggestions auto-complete silently — it is easy to accept changes without a conscious ownership decision.",cursor:"Cursor can rewrite entire files in one accept. Each accept is a human decision; treat it as one.",claudecode:"Agent-generated PRs can span hundreds of lines. Reviewing a diff ≠ owning it — own it explicitly.",copilot_cursor:"AI-generated suggestions can be accepted with a keystroke. Each one is still your code."}},{id:3,title:"Spec drift into chat",body:"The spec was written once; the agent has been prompted in a long conversation since. The system is now built against the conversation, not the spec — and three weeks later nobody knows what the actual contract is. Remedy: the spec is the source of truth. When chat diverges from it, fix the spec.",toolNote:{claudeai:"Everything in Claude.ai is chat. Without a spec file to anchor you, the conversation IS the spec — and it will drift.",claudeai_bmad:"BMAD helps structure the conversation, but spec drift still occurs if the doc isn't updated when chat evolves.",claudecode:"Long Claude Code sessions accumulate context drift. Run /compact and update your CLAUDE.md when scope changes.",bmad_nc:"BMAD structures the handoffs, but spec drift happens when chat decisions are not reflected back into the spec artefact."}},{id:4,title:"Regression neglect on brownfield",body:"Changes ship to a live system with no regression suite covering the affected behaviour. The agent makes the change, it looks plausible, the demo passes — production finds the break weeks later. Remedy: invest in regression coverage before agentic acceleration runs.",toolNote:{claudecode:"Claude Code's repo-wide reach means a change can break a dependency three layers away. Coverage is your safety net.",claude_bmad:"BMAD accelerates multi-phase brownfield work — the regression baseline needs to exist before the first sprint, not after.",cursor:"Cursor's inline suggestions are fast and subtle. A missing regression test means a silent regression."}},{id:5,title:"Cutover without rehearsal",body:"Modernisation work reaches cutover with no parallel-run, no rehearsed rollback, no schedule slack. These cutovers are coin flips. Remedy: parallel-run with parity validation, rehearsed rollback, slice-by-slice cutover behind feature flags.",toolNote:{claude_bmad:"BMAD is often chosen for migrations precisely because of their complexity — the cutover plan is non-negotiable.",bmad_nc:"If your team is using BMAD for a migration, the cutover rehearsal is part of the process, not a follow-up."}},{id:6,title:"V0 as product",body:"The V0 was generated, stakeholders liked it, and it has quietly been carrying production traffic ever since — without the hardening that takes a prototype to a product. Test coverage is thin, observability reactive. Remedy: name V1 hardening as a distinct phase with explicit acceptance criteria.",toolNote:{claudeai:"Claude.ai makes V0 generation trivially easy. The gap between 'it looks good in the browser' and 'it is production-ready' is real.",claudeai_bmad:"V0 speed is a BMAD strength — but the BMAD process explicitly requires a V1 hardening phase before shipping.",claudecode:"Claude Code greenfield flows produce working code fast. V0→V1 hardening (tests, error states, accessibility) is the gate — not an option.",copilot_cursor:"Your engineers can scaffold features quickly with AI. Make sure V1 hardening — tests, edge cases — is a named deliverable.",claudecode_nc:"Rapid generation is compelling. Confirm with your engineers that every feature has an explicit hardening phase."}},{id:7,title:"Classification creep",body:"Maintenance work that should have been escalated into modernisation stays in the maintenance pod, accumulating ad-hoc structural changes nobody would have approved as a single proposal. Remedy: when a maintenance pod makes repeated structural changes to the same area, escalate to the right archetype and bring an architect in.",toolNote:{claude_bmad:"BMAD makes structural changes feel manageable — which can mask the moment when maintenance has become unplanned modernisation.",bmad_nc:"A clear archetype decision upfront prevents the team drifting from a D1 maintenance sprint into an unplanned C1 migration."}},{id:8,title:"Compression claims outrunning the evidence",body:"Teams promise delivery against compression multipliers the work has not yet earned — especially on the data/AI track. The numbers are directional, not commitments. Remedy: measure the first few cycles, publish the measurement, and plan the next sprint against what was actually observed.",toolNote:{claude_bmad:"BMAD projects often carry strong productivity expectations. Calibrate against measured cycles, not the brochure.",bmad_nc:"If stakeholders are expecting specific acceleration numbers, make sure they are based on a measured pilot, not assumptions.",claudecode:"Agentic coding can deliver real compression — but the first sprint is a calibration sprint, not a forecast."}}],Wt={copilot:[2,6,3,1],cursor:[2,1,4,3],claudecode:[3,1,2,6],claude_bmad:[3,4,5,7],copilot_cursor:[2,6,1,3],claudeai:[3,6,2,1],claudeai_bmad:[3,6,7,8],claudecode_nc:[6,2,3,1],bmad_nc:[3,5,7,8]};function Qt(r){return(r?Wt[r]??he.map(n=>n.id):he.map(n=>n.id)).map(n=>he.find(l=>l.id===n)).filter(Boolean)}function Vt(r){navigator.clipboard.writeText(r).catch(()=>{const a=document.createElement("textarea");a.value=r,document.body.appendChild(a),a.select(),document.execCommand("copy"),document.body.removeChild(a)})}function Kt(r,a){const n=new Blob([r],{type:"application/octet-stream"}),l=URL.createObjectURL(n),d=document.createElement("a");d.href=l,d.download=a,document.body.appendChild(d),d.click(),document.body.removeChild(d),URL.revokeObjectURL(l)}const Yt={universal:{label:"All models",cls:"gs-scope-green"},claude:{label:"Claude / Anthropic",cls:"gs-scope-grey"},concept:{label:"Concept universal",cls:"gs-scope-amber"}};function Xt({personaId:r,archetypeId:a,tool:n,traditional:l,scenarios:d,onBack:w,onRestart:h,onNext:f}){const[g,C]=x.useState("quickstart"),[D,j]=x.useState(null),[P,B]=x.useState(null),[T,O]=x.useState(null),[q,H]=x.useState(!1),[y,M]=x.useState(!1),[u,S]=x.useState(null),[I,ae]=x.useState(!1),[Y,ie]=x.useState(!1),[oe,Ke]=x.useState(!1),[se,Ye]=x.useState(!1),[Xe,Je]=x.useState(null),[ne,$e]=x.useState(!1),[ce,Ze]=x.useState(!1),[le,et]=x.useState(!1),[de,tt]=x.useState(!1),W=kt.find(t=>t.id===r),pe=J.find(t=>t.id===a),Z=a.startsWith("A")?"greenfield":"brownfield",Q=Tt(n),U=Q.contextFileName,rt=St[r]??"",fe=_t(rt,a,pe?.label??a,U),ve=n?$.find(t=>t.id===n):null,ue=It[r],ye=jt[r],z=Dt[r],at=z?.ownsByArchetype?.[Z]??z?.owns??[],it=z?.upstreamByArchetype?.[Z]??z?.upstream??[],ot=z?.downstreamByArchetype?.[Z]??z?.downstream??[],be=Ct.includes(r),st=Ht.includes(r),we=d.map(t=>({scenario:t,mapping:t.useCaseMappings?.find(A=>A.archetypeId===a)})).filter(t=>t.scenario.persona===r&&!!t.mapping).sort((t,A)=>t.mapping.useCase-A.mapping.useCase||t.scenario.title.localeCompare(A.scenario.title)),V=we.find(t=>t.mapping.useCase===1)?.scenario,ke=we.filter(t=>t.mapping.useCase>=2&&t.mapping.useCase<=5).map(t=>t.scenario),me=x.useCallback((t,A)=>{Vt(t),O(A),setTimeout(()=>O(null),1500)},[]),L=Pt[a],xe=[{id:"quickstart",label:"Quickstart"},{id:"pod",label:"Role Dynamics"},{id:"recipe",label:"Recipe"},{id:"dos",label:"Dos & Don'ts"},{id:"guardrails",label:"Guardrails"},{id:"more",label:"More Use Cases"},{id:"tokens",label:"Token Economics"},{id:"prompts",label:"Prompt Engineering"},{id:"playbook",label:"Playbook"},{id:"standards",label:"Eng Standards"},...be?[{id:"bmad",label:"BMAD"}]:[]],Ae=pe?.label??a,nt=pe?.defaultPattern==="rapid"?"Rapid Prototype":"Spec-driven",De=l?xt.find(t=>t.id===l):null,K=n?Q.label:null,Ce=K??Q.label,G=t=>Bt(t,Q),ct=[`# Add ${U} to the project before the first prompt`,`# Start ${Q.agentSession}`,"",`You: Load and apply ${U} before we begin.`,"","# Plan before executing","You: Plan only (do not execute): implement [feature] per acceptance criteria in [story]."].join(`
`);return e.jsxs("div",{className:"gs-wrap card",children:[e.jsxs("div",{className:"gs-top-bar",children:[e.jsx("button",{className:"link-back",onClick:w,children:"← Back"}),e.jsxs("div",{className:"gs-top-bar-right",children:[e.jsx("span",{className:"gs-topbar-claude-label",children:U}),e.jsx("button",{className:"gs-topbar-btn",onClick:()=>me(fe,"claude-banner"),children:T==="claude-banner"?"✓ Copied":"Copy"}),e.jsx("button",{className:"gs-topbar-btn gs-topbar-btn--primary",onClick:()=>Kt(fe,U),children:"Download"}),e.jsx("button",{className:"gs-topbar-btn",onClick:()=>M(t=>!t),children:y?"Hide guide":"How to use?"})]})]}),y&&e.jsx("div",{className:"gs-howto-panel",children:e.jsx("ol",{className:"gs-howto-steps",children:n==="cursor"?e.jsxs(e.Fragment,{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Place the file"})," — save as ",e.jsx("code",{children:U})," in the root of your project."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Open Cursor"})," — it reads ",e.jsx("code",{children:U})," automatically as project-level instructions."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Or paste as context"})," — open the Cursor chat and paste the file contents at the start of your conversation."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Keep it updated"})," — when your role or scope changes, update this file. Cursor re-reads it each session."]})]}):n==="copilot"||n==="copilot_cursor"?e.jsxs(e.Fragment,{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Place the file"})," — save as ",e.jsx("code",{children:U})," in your repository root."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Open VS Code with Copilot Chat"})," — Copilot reads the instructions file automatically for chat responses."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Or paste as context"})," — paste the file contents at the start of a Copilot Chat conversation."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Keep it updated"})," — update this file when your role or acceptance criteria change."]})]}):e.jsxs(e.Fragment,{children:[e.jsxs("li",{children:[e.jsx("strong",{children:"Place the file"})," — move ",e.jsx("code",{children:U})," into the root of your project (same level as ",e.jsx("code",{children:"package.json"}),")."]}),e.jsxs("li",{children:[e.jsxs("strong",{children:["Open ",Q.label]})," — start the selected tool from that project context. It reads ",e.jsx("code",{children:U})," automatically on startup."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Or paste as context"})," — if the tool does not load the file automatically, paste the file contents at the start of your conversation."]}),e.jsxs("li",{children:[e.jsx("strong",{children:"Keep it updated"})," — when your role or scope changes, update this file. The agent re-derives from it every session."]})]})})}),e.jsxs("div",{className:"gs-page-heading",children:[e.jsx("span",{className:"gs-persona-name",children:W?.label??r}),e.jsxs("div",{className:"gs-heading-badges",children:[De&&e.jsx("span",{className:"gs-badge",children:De.title}),e.jsxs("span",{className:"gs-badge gs-badge--build",children:[e.jsx("span",{className:"gs-arch-id-inline",children:a}),Ae.replace(/^[A-Z][0-9] · /,"").replace(/Application · /,"").replace(/Data \/ AI · /,"")]}),e.jsx("span",{className:"gs-badge gs-badge--pattern",children:nt}),K&&e.jsx("span",{className:"gs-badge",children:K})]})]}),st&&e.jsxs("div",{className:"gs-install-block",children:[e.jsxs("button",{className:"gs-install-toggle",onClick:()=>H(t=>!t),children:[e.jsx("span",{className:"gs-install-title",children:"Start your first project"}),e.jsx("span",{className:"gs-install-chevron",children:q?"▾":"▸"})]}),q&&e.jsx("div",{className:"gs-install-body",children:e.jsxs("div",{className:"gs-install-cols",children:[e.jsxs("div",{children:[e.jsxs("div",{className:"gs-install-label",children:["Set up ",Ce]}),ve?e.jsx("ol",{className:"gs-install-list",children:ve.install.map(t=>e.jsx("li",{children:t},t))}):e.jsx("p",{className:"gs-install-note",children:"Use the selected tool card as delivery guidance, then confirm which underlying tool the team will use for execution."}),e.jsx("div",{className:"gs-install-label",style:{marginTop:"12px"},children:"First session"}),e.jsx("pre",{className:"gs-install-code",children:ct})]}),e.jsxs("div",{children:[e.jsx("div",{className:"gs-install-label",children:"Two habits, day one"}),e.jsxs("div",{className:"gs-habit-card",children:[e.jsx("span",{className:"gs-habit-num",children:"1"}),e.jsxs("div",{children:[e.jsx("strong",{children:"Always load the instruction file and architecture brief first."}),e.jsx("p",{children:"The brief is your standing contract with the agent. Without it, the agent makes architectural decisions it should not be making."})]})]}),e.jsxs("div",{className:"gs-habit-card",children:[e.jsx("span",{className:"gs-habit-num",children:"2"}),e.jsxs("div",{children:[e.jsx("strong",{children:"Use plan mode before non-trivial execution."}),e.jsx("p",{children:'Say "plan only, do not execute" on the first turn. Review what the agent intends to do before it touches any file.'})]})]})]})]})})]}),e.jsxs("div",{className:"gs-tabs-wrapper",children:[e.jsxs("div",{className:"gs-tab-group gs-tab-group--role",children:[e.jsx("span",{className:"gs-tab-group-label",children:"For your role"}),e.jsx("div",{className:"gs-tabs",children:xe.filter(t=>!["tokens","prompts","standards","bmad","learning","playbook"].includes(t.id)).map(t=>e.jsx("button",{className:`gs-tab${g===t.id?" gs-tab--active":""}`,onClick:()=>C(t.id),children:t.label},t.id))})]}),e.jsxs("div",{className:"gs-tab-group gs-tab-group--ref",children:[e.jsx("span",{className:"gs-tab-group-label",children:"Reference"}),e.jsx("div",{className:"gs-tabs",children:xe.filter(t=>["tokens","prompts","playbook","standards","bmad"].includes(t.id)).map(t=>e.jsx("button",{className:`gs-tab${g===t.id?" gs-tab--active":""}`,onClick:()=>C(t.id),children:t.label},t.id))})]})]}),e.jsxs("div",{className:"gs-panel",children:[g==="dos"&&ue&&e.jsxs("div",{className:"gs-dos-wrap",children:[e.jsxs("p",{className:"gs-section-label",children:["For: ",W?.label]}),e.jsxs("div",{className:"gs-dos-cols",children:[e.jsxs("div",{className:"gs-dos-col",children:[e.jsx("h4",{className:"gs-dos-heading gs-dos-do",children:"Do"}),e.jsx("ul",{className:"gs-dos-list",children:ue.dos.map((t,A)=>e.jsxs("li",{children:[e.jsx("span",{className:"gs-do-mark",children:"✓"}),t]},A))})]}),e.jsxs("div",{className:"gs-dos-col",children:[e.jsx("h4",{className:"gs-dos-heading gs-dos-dont",children:"Don't"}),e.jsx("ul",{className:"gs-dos-list",children:ue.donts.map((t,A)=>e.jsxs("li",{children:[e.jsx("span",{className:"gs-dont-mark",children:"✗"}),t]},A))})]})]}),e.jsxs("div",{className:"gs-anti-wrap",children:[e.jsxs("div",{className:"gs-anti-header",children:[e.jsx("span",{className:"gs-anti-title",children:"Anti-patterns to avoid"}),K&&e.jsxs("span",{className:"gs-anti-tool-badge",children:["For ",K]})]}),e.jsx("div",{className:"gs-anti-list",children:Qt(n).map((t,A)=>{const F=n?t.toolNote[n]:void 0;return e.jsxs("div",{className:"gs-anti-item",children:[e.jsxs("div",{className:"gs-anti-item-header",children:[e.jsx("span",{className:"gs-anti-num",children:A+1}),e.jsx("span",{className:"gs-anti-name",children:t.title})]}),e.jsx("p",{className:"gs-anti-body",children:t.body}),F&&e.jsxs("p",{className:"gs-anti-note",children:[e.jsxs("span",{className:"gs-anti-note-label",children:[K,":"]})," ",F]})]},t.id)})})]})]}),g==="guardrails"&&ye&&e.jsxs("div",{className:"gs-guard-wrap",children:[e.jsxs("p",{className:"gs-section-label",children:["6 Practitioner Gates · ",W?.label]}),e.jsx("ol",{className:"gs-guard-list",children:ye.map(t=>e.jsxs("li",{className:"gs-guard-item",children:[e.jsxs("span",{className:"gs-guard-num",children:[t.gate,"."]}),e.jsxs("div",{className:"gs-guard-body",children:[e.jsx("span",{className:"gs-guard-label",children:t.label}),e.jsx("span",{className:"gs-guard-detail",children:t.detail})]})]},t.gate))})]}),g==="quickstart"&&e.jsxs("div",{className:"gs-quick-wrap",children:[e.jsxs("p",{className:"gs-section-label",children:["Getting started as ",W?.label," · ",a," ",Ae]}),V?e.jsxs("div",{className:"gs-scenario gs-scenario--open",children:[e.jsxs("div",{className:"gs-scenario-header",children:[e.jsx("span",{className:"gs-scenario-title",children:G(V.title)}),e.jsx("span",{className:"gs-scenario-meta",children:Ce})]}),e.jsx("p",{className:"gs-scenario-when",children:G(V.when)}),e.jsx("div",{className:"gs-steps",children:V.steps.map(t=>{const A=`qs-${V.id}-${t.n}`,F=`qs-${V.id}-step-${t.n}`,N=P===F,E=G(t.name),R=G(t.body),_=G(t.prompt);return e.jsxs("div",{className:`gs-step${N?" gs-step--open":""}`,children:[e.jsxs("button",{className:"gs-step-header",onClick:()=>B(N?null:F),children:[e.jsxs("span",{className:"gs-step-name",children:["Step ",t.n," — ",E]}),e.jsx("span",{className:"gs-chevron-sm",children:N?"▾":"▸"})]}),N&&e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"gs-step-body",children:R}),e.jsx("pre",{className:"gs-prompt",children:_}),e.jsx("div",{className:"gs-step-copy-row",children:e.jsx("button",{className:"gs-step-copy",onClick:()=>me(_,A),children:T===A?"Copied!":"Copy prompt"})})]})]},t.n)})})]}):e.jsx("p",{className:"gs-empty",children:"No quickstart yet for this combination."})]}),g==="more"&&e.jsx("div",{className:"gs-more-wrap",children:ke.length>0?e.jsx("ul",{className:"gs-more-list",children:ke.map(t=>{const A=D===t.id,F=G(t.title);return e.jsxs("li",{className:"gs-more-item",children:[e.jsxs("button",{className:`gs-more-row${A?" gs-more-row--open":""}`,onClick:()=>j(A?null:t.id),children:[e.jsx("span",{className:"gs-more-title-stack",children:e.jsx("span",{className:"gs-more-title",children:F})}),e.jsx("span",{className:"gs-more-chevron",children:A?"▾":"▸"})]}),A&&e.jsxs("div",{className:"gs-more-panel",children:[e.jsx("p",{className:"gs-scenario-when",children:G(t.when)}),e.jsx("div",{className:"gs-steps",children:t.steps.map(N=>{const E=`more-${t.id}-${N.n}`,R=`more-${t.id}-step-${N.n}`,_=P===R,lt=G(N.name),dt=G(N.body),Se=G(N.prompt);return e.jsxs("div",{className:`gs-step${_?" gs-step--open":""}`,children:[e.jsxs("button",{className:"gs-step-header",onClick:()=>B(_?null:R),children:[e.jsxs("span",{className:"gs-step-name",children:["Step ",N.n," — ",lt]}),e.jsx("span",{className:"gs-chevron-sm",children:_?"▾":"▸"})]}),_&&e.jsxs(e.Fragment,{children:[e.jsx("p",{className:"gs-step-body",children:dt}),e.jsx("pre",{className:"gs-prompt",children:Se}),e.jsx("div",{className:"gs-step-copy-row",children:e.jsx("button",{className:"gs-step-copy",onClick:()=>me(Se,E),children:T===E?"Copied!":"Copy prompt"})})]})]},N.n)})})]})]},t.id)})}):e.jsx("p",{className:"gs-empty",children:"More use cases coming soon."})}),g==="tokens"&&e.jsxs("div",{className:"gs-tokens-wrap",children:[e.jsxs("button",{className:"gs-token-section-hdr",onClick:()=>ae(t=>!t),"aria-expanded":I,children:[e.jsx("span",{children:"Key levers"}),e.jsx("span",{className:"gs-chevron-sm","aria-hidden":"true",children:I?"▾":"▸"})]}),I&&e.jsxs("div",{className:"gs-callout gs-token-levers-callout",children:[e.jsx("p",{children:Ie.intro}),e.jsx("ul",{children:Ie.items.map(t=>e.jsxs("li",{children:[e.jsx("strong",{children:t.label})," — ",t.body]},t.label))})]}),e.jsxs("button",{className:"gs-token-section-hdr",onClick:()=>ie(t=>!t),"aria-expanded":Y,children:[e.jsx("span",{children:"Token character by archetype"}),e.jsx("span",{className:"gs-chevron-sm","aria-hidden":"true",children:Y?"▾":"▸"})]}),Y&&e.jsxs("table",{className:"gs-token-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Archetype"}),e.jsx("th",{children:"Token character"}),e.jsx("th",{children:"Main lever"})]})}),e.jsx("tbody",{children:At.map(t=>e.jsxs("tr",{className:t.archetype===a?"gs-token-row--active":"",children:[e.jsx("td",{className:"gs-token-arch",children:t.archetype}),e.jsx("td",{children:t.character}),e.jsx("td",{children:t.lever})]},t.archetype))})]}),e.jsxs("button",{className:"gs-token-section-hdr",onClick:()=>Ke(t=>!t),"aria-expanded":oe,children:[e.jsx("span",{children:"Token optimisation overview"}),e.jsx("span",{className:"gs-chevron-sm","aria-hidden":"true",children:oe?"▾":"▸"})]}),oe&&e.jsx("img",{src:"/Token_Optimization.png",alt:"Token Optimization — 13 tactics to reduce cost and latency across any LLM or agent",className:"gs-token-img"}),e.jsxs("button",{className:"gs-token-section-hdr",onClick:()=>Ye(t=>!t),"aria-expanded":se,children:[e.jsx("span",{children:"13 tactics — expand each to see examples"}),e.jsx("span",{className:"gs-chevron-sm","aria-hidden":"true",children:se?"▾":"▸"})]}),e.jsx("div",{className:"gs-tactic-list",style:se?{}:{display:"none"},children:pt.map(t=>{const A=u===t.n,{label:F,cls:N}=Yt[t.scope];return e.jsxs("div",{className:`gs-tactic${A?" gs-tactic--open":""}`,children:[e.jsxs("button",{className:"gs-tactic-hdr",onClick:()=>S(A?null:t.n),"aria-expanded":A,children:[e.jsxs("div",{className:"gs-tactic-hdr-left",children:[e.jsx("span",{className:"gs-tactic-n",children:t.n}),e.jsx("span",{className:"gs-tactic-title",children:t.title}),e.jsx("span",{className:`gs-scope-badge ${N}`,children:F})]}),e.jsx("span",{className:"gs-chevron-sm","aria-hidden":"true",children:A?"▾":"▸"})]}),A&&e.jsxs("div",{className:"gs-tactic-body",children:[e.jsx("p",{className:"gs-tactic-summary",children:t.summary}),t.note&&e.jsx("p",{className:"gs-tactic-note",children:t.note}),(t.bad||t.good)&&e.jsxs("div",{className:"gs-tactic-examples",children:[t.bad&&e.jsxs("div",{children:[e.jsx("span",{className:"gs-ex-label gs-ex-bad",children:"✗ Avoid"}),e.jsx("pre",{className:"gs-code gs-code-bad",children:t.bad})]}),t.good&&e.jsxs("div",{children:[e.jsx("span",{className:"gs-ex-label gs-ex-good",children:"✓ Do this"}),e.jsx("pre",{className:"gs-code gs-code-good",children:t.good})]})]}),t.tips&&e.jsx("ul",{className:"gs-tactic-tips",children:t.tips.map(E=>e.jsx("li",{children:E},E))})]})]},t.n)})})]}),g==="pod"&&z&&e.jsxs("div",{className:"gs-pod-wrap",children:[e.jsxs("p",{className:"gs-section-label",children:["Role Dynamics · ",W?.label]}),e.jsxs("div",{className:"gs-pod-grid",children:[e.jsxs("div",{className:"gs-pod-col",children:[e.jsx("div",{className:"gs-pod-heading",children:"You receive from"}),e.jsx("ul",{className:"gs-pod-list gs-pod-upstream",children:it.map((t,A)=>e.jsxs("li",{children:[e.jsx("span",{className:"gs-pod-arrow",children:"←"}),t]},A))})]}),e.jsxs("div",{className:"gs-pod-col",children:[e.jsx("div",{className:"gs-pod-heading",children:"You are accountable for"}),e.jsx("ul",{className:"gs-pod-list gs-pod-owns",children:at.map((t,A)=>e.jsxs("li",{children:[e.jsx("span",{className:"gs-pod-mark",children:"✓"}),t]},A))})]}),e.jsxs("div",{className:"gs-pod-col",children:[e.jsx("div",{className:"gs-pod-heading",children:"You hand to"}),e.jsx("ul",{className:"gs-pod-list gs-pod-downstream",children:ot.map((t,A)=>e.jsxs("li",{children:[e.jsx("span",{className:"gs-pod-arrow gs-arrow-down",children:"→"}),t]},A))})]})]}),e.jsxs("div",{className:"gs-callout",children:[e.jsx("span",{className:"gs-callout-label",children:"Handoff discipline"}),e.jsx("p",{children:"The artifacts are the medium. When an artifact is missing or stale, the handoff happens by conversation — and conversation does not survive context loss between agent sessions. Make your artifacts current; the handoff follows."})]})]}),g==="recipe"&&L&&e.jsxs("div",{className:"gs-recipe-wrap",children:[e.jsxs("p",{className:"gs-section-label",children:[L.archetypeId," · ",L.title]}),je[r]&&e.jsxs("div",{className:"gs-recipe-persona-callout",children:[e.jsxs("span",{className:"gs-recipe-persona-callout-label",children:["Your role in this recipe · ",W?.label]}),e.jsx("p",{className:"gs-recipe-prose",children:je[r][Z]})]}),e.jsxs("div",{className:"gs-recipe-meta",children:[e.jsxs("div",{className:"gs-recipe-meta-item",children:[e.jsx("span",{className:"gs-recipe-meta-key",children:"Pattern"}),e.jsx("span",{className:"gs-recipe-meta-val",children:L.pattern})]}),e.jsxs("div",{className:"gs-recipe-meta-item",children:[e.jsx("span",{className:"gs-recipe-meta-key",children:"Pod size"}),e.jsx("span",{className:"gs-recipe-meta-val",children:L.podSize})]}),e.jsxs("div",{className:"gs-recipe-meta-item",children:[e.jsx("span",{className:"gs-recipe-meta-key",children:"Expected"}),e.jsx("span",{className:"gs-recipe-meta-val gs-recipe-meta-accent",children:L.expected})]})]}),e.jsx("p",{className:"gs-recipe-summary",children:L.summary}),["whenFits","podComposition","setup","flow","handoffs","signals","anchorScenario","sideways"].map(t=>{const A=Xe===t,F={whenFits:"When this fits",podComposition:"Pod composition",setup:"Setup",flow:"Flow",handoffs:"Handoffs",signals:"Signals",anchorScenario:"Anchor scenario",sideways:"When it goes sideways"},N=t==="sideways";return e.jsxs("div",{className:`gs-recipe-acc${N?" gs-recipe-acc--sideways":""}`,children:[e.jsxs("button",{className:"gs-recipe-acc-hdr",onClick:()=>Je(A?null:t),"aria-expanded":A,children:[e.jsx("span",{className:"gs-recipe-acc-title",children:F[t]}),e.jsx("span",{className:"gs-chevron-sm",children:A?"▾":"▸"})]}),A&&e.jsxs("div",{className:"gs-recipe-acc-body",children:[t==="whenFits"&&e.jsx("p",{className:"gs-recipe-prose",children:L.whenFits}),t==="podComposition"&&e.jsx("p",{className:"gs-recipe-prose",children:L.podComposition}),t==="setup"&&e.jsx("ol",{className:"gs-recipe-ol",children:L.setup.map((E,R)=>e.jsx("li",{children:E},R))}),t==="flow"&&e.jsx("ol",{className:"gs-recipe-ol",children:L.flow.map((E,R)=>e.jsx("li",{children:E},R))}),t==="handoffs"&&e.jsx("p",{className:"gs-recipe-prose",children:L.handoffs}),t==="signals"&&e.jsxs("div",{className:"gs-recipe-signals",children:[e.jsxs("div",{className:"gs-recipe-signal gs-recipe-signal--on",children:[e.jsx("span",{className:"gs-recipe-signal-label",children:"On track"}),e.jsx("ul",{className:"gs-recipe-ul",children:L.onTrack.map((E,R)=>e.jsx("li",{children:E},R))})]}),e.jsxs("div",{className:"gs-recipe-signal gs-recipe-signal--off",children:[e.jsx("span",{className:"gs-recipe-signal-label",children:"Off track"}),e.jsx("ul",{className:"gs-recipe-ul",children:L.offTrack.map((E,R)=>e.jsx("li",{children:E},R))})]})]}),t==="anchorScenario"&&e.jsx("p",{className:"gs-recipe-prose",children:L.anchorScenario}),t==="sideways"&&e.jsx("p",{className:"gs-recipe-prose",children:L.sideways})]})]},t)})]}),g==="prompts"&&e.jsxs("div",{className:"gs-prompts-wrap",children:[e.jsx("div",{className:"gs-principles-grid",children:ut.map(t=>e.jsxs("div",{className:"gs-principle-card",children:[e.jsx("span",{className:"gs-principle-title",children:t.title}),e.jsx("p",{className:"gs-principle-body",children:t.body})]},t.title))}),e.jsx("p",{className:"gs-section-label",style:{marginTop:"var(--space-5)"},children:"Prompting techniques"}),e.jsxs("table",{className:"gs-tech-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Technique"}),e.jsx("th",{children:"When to use"})]})}),e.jsx("tbody",{children:mt.map(t=>e.jsxs("tr",{children:[e.jsx("td",{className:"gs-tech-name",children:t.name}),e.jsx("td",{className:"gs-tech-desc",children:t.desc})]},t.name))})]}),e.jsxs("div",{className:"gs-learn-links",children:[e.jsx("p",{className:"gs-learn-label",children:"Learn more:"}),e.jsx("ul",{children:gt.map(t=>e.jsx("li",{children:e.jsxs("a",{href:t.href,target:"_blank",rel:"noopener noreferrer",className:"gs-link",children:[t.label," ↗"]})},t.href))})]})]}),g==="playbook"&&e.jsxs("div",{className:"gs-playbook-wrap",children:[e.jsx("p",{className:"gs-section-label",children:"Playbook · Quality, Architecture & Operability"}),e.jsxs("button",{className:"gs-token-section-hdr",onClick:()=>$e(t=>!t),"aria-expanded":ne,children:[e.jsx("span",{children:"Quality & traceability discipline"}),e.jsx("span",{className:"gs-chevron-sm",children:ne?"▾":"▸"})]}),ne&&e.jsxs("div",{className:"gs-playbook-section",children:[e.jsxs("div",{className:"gs-callout",style:{marginBottom:"var(--space-4)"},children:[e.jsx("span",{className:"gs-callout-label",children:"The discipline in one line"}),e.jsx("p",{children:"Change → Update Spec → Rebuild. Every agent-generated change is traceable to a spec, not a conversation."})]}),e.jsx("div",{className:"gs-playbook-principles",children:ht.map(t=>e.jsxs("div",{className:"gs-playbook-item",children:[e.jsx("span",{className:"gs-playbook-item-title",children:t.title}),e.jsx("p",{className:"gs-playbook-item-body",children:t.body})]},t.title))})]}),e.jsxs("button",{className:"gs-token-section-hdr",onClick:()=>Ze(t=>!t),"aria-expanded":ce,children:[e.jsx("span",{children:"Archetype reference matrix"}),e.jsx("span",{className:"gs-chevron-sm",children:ce?"▾":"▸"})]}),ce&&e.jsxs("div",{className:"gs-playbook-section",children:[e.jsx("p",{style:{fontSize:"var(--text-xs)",color:"var(--text-muted)",marginBottom:"var(--space-3)"},children:"Eight archetypes across two tracks. Your selected archetype is highlighted."}),e.jsxs("table",{className:"gs-token-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"ID"}),e.jsx("th",{children:"Name"}),e.jsx("th",{children:"Pattern"}),e.jsx("th",{children:"Pod size"}),e.jsx("th",{children:"Typical range"})]})}),e.jsx("tbody",{children:[{id:"A1",name:"App · Greenfield",pattern:"Rapid",pod:"3–4 core",range:"2–5× · ~50% cap."},{id:"A2",name:"Data/AI · Greenfield",pattern:"Rapid (cautious)",pod:"4–5 core",range:"1.5–3× · ~37% cap."},{id:"B1",name:"App · Enhancement",pattern:"Spec-driven",pod:"3–4 core",range:"2–4× · ~40% cap."},{id:"B2",name:"Data/AI · Enhancement",pattern:"Spec-driven",pod:"3–4 core",range:"1.5–2.5× · dir."},{id:"C1",name:"App · Modernisation",pattern:"Spec-driven",pod:"5–6 core",range:"1.5–3× · ~35% cap."},{id:"C2",name:"Data/AI · Modernisation",pattern:"Spec-driven",pod:"4–5 core",range:"1.5–2× · dir."},{id:"D1",name:"App · Maintenance",pattern:"Spec-driven (small)",pod:"2–3 core",range:"2–3× · ~42% cap."},{id:"D2",name:"Data/AI · Maintenance",pattern:"Spec-driven (small)",pod:"2–3 core",range:"1.5–2× · dir."}].map(t=>e.jsxs("tr",{className:t.id===a?"gs-token-row--active":"",children:[e.jsx("td",{className:"gs-token-arch",children:t.id}),e.jsx("td",{children:t.name}),e.jsx("td",{children:t.pattern}),e.jsx("td",{children:t.pod}),e.jsx("td",{children:t.range})]},t.id))})]}),e.jsx("p",{style:{fontSize:"var(--text-xs)",color:"var(--text-faint)",marginTop:"var(--space-2)"},children:"Capacity figures are directional — based on observed patterns, not guaranteed outcomes. Calibrate against your first sprint."})]}),e.jsxs("button",{className:"gs-token-section-hdr",onClick:()=>et(t=>!t),"aria-expanded":le,children:[e.jsx("span",{children:"Operability & observability standards"}),e.jsx("span",{className:"gs-chevron-sm",children:le?"▾":"▸"})]}),le&&e.jsx("div",{className:"gs-playbook-section",children:e.jsx("div",{className:"gs-playbook-principles",children:ft.map(t=>e.jsxs("div",{className:"gs-playbook-item",children:[e.jsx("span",{className:"gs-playbook-item-title",children:t.title}),e.jsx("p",{className:"gs-playbook-item-body",children:t.body})]},t.title))})}),e.jsxs("button",{className:"gs-token-section-hdr",onClick:()=>tt(t=>!t),"aria-expanded":de,children:[e.jsx("span",{children:"Programme-level gates (org-enforced)"}),e.jsx("span",{className:"gs-chevron-sm",children:de?"▾":"▸"})]}),de&&e.jsxs("div",{className:"gs-prog-gates",children:[e.jsx("p",{className:"gs-prog-gates-intro",children:"These gates apply at the programme level regardless of persona. Each is enforced by an owner above the pod — not a practitioner choice."}),e.jsx("ol",{className:"gs-guard-list",children:vt.map(t=>e.jsxs("li",{className:"gs-guard-item",children:[e.jsxs("span",{className:"gs-guard-num",children:[t.n,"."]}),e.jsxs("div",{className:"gs-guard-body",children:[e.jsx("span",{className:"gs-guard-label",children:t.label}),e.jsx("span",{className:"gs-guard-detail",children:t.detail})]})]},t.n))})]})]}),g==="bmad"&&be&&e.jsxs("div",{className:"gs-bmad-wrap",children:[e.jsx("p",{className:"gs-section-label",children:"BMAD — Structured Agentic Delivery"}),e.jsx("p",{className:"gs-bmad-desc",children:"Use when complex products, multi-phase builds, or migrations make spec drift a real risk. BMAD assigns specialist AI agents to each delivery role and enforces structured handoffs."}),e.jsxs("ul",{className:"gs-bmad-list",children:[e.jsx("li",{children:"PRD → build context drifts without governance — BMAD prevents this"}),e.jsx("li",{children:"Multi-phase builds need session continuity across agent handoffs"}),e.jsx("li",{children:"Migrations need parity constraint enforcement slice-by-slice"})]}),e.jsxs("div",{className:"gs-bmad-links",children:[e.jsx("a",{href:"https://github.com/bmad-method/bmad-agent",target:"_blank",rel:"noopener noreferrer",className:"gs-bmad-link-btn",children:"BMAD GitHub Repo ↗"}),e.jsx("a",{href:"https://www.youtube.com/results?search_query=BMAD+claude+walkthrough",target:"_blank",rel:"noopener noreferrer",className:"gs-bmad-link-btn",children:"BMAD + Claude Walkthrough ↗"}),e.jsx("a",{href:"https://bmad-training-app.vercel.app",target:"_blank",rel:"noopener noreferrer",className:"gs-bmad-link-btn",children:"BMAD Training App ↗"})]})]}),g==="standards"&&e.jsxs("div",{className:"gs-standards-wrap",children:[e.jsx("p",{className:"gs-section-label",children:ee.label}),e.jsx("p",{className:"gs-standards-desc",children:ee.description}),e.jsx("div",{className:"gs-standards-links",children:ee.links.map(t=>e.jsx("a",{href:t.href,target:"_blank",rel:"noopener noreferrer",className:`gs-bmad-link-btn${t.primary?" gs-bmad-link-btn--primary":""}`,children:t.label},t.href))}),e.jsx("ul",{className:"gs-standards-list",children:ee.items.map(t=>e.jsx("li",{children:t},t))})]})]}),e.jsxs("div",{className:"gs-bottom-bar",children:[e.jsx("button",{className:"gs-restart-btn",onClick:h,children:"↺ Start over"}),e.jsx("button",{className:"gs-next-btn",onClick:f,children:"Learning Pathway →"})]}),e.jsx("style",{children:`
        .gs-wrap { margin-bottom: var(--space-6); }

        .gs-top-bar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: var(--space-3);
        }
        .gs-top-bar-right {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          flex-wrap: wrap;
        }
        .gs-topbar-claude-label {
          font-size: var(--text-xs);
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.06em;
          color: var(--text-faint);
          margin-right: 2px;
        }
        .gs-topbar-btn {
          background: transparent;
          border: 1px solid var(--border);
          color: var(--text-muted);
          border-radius: 6px;
          padding: 3px 10px;
          font-size: var(--text-xs);
          font-weight: 600;
          cursor: pointer;
          transition: border-color 0.1s, color 0.1s;
        }
        .gs-topbar-btn:hover { border-color: var(--accent); color: var(--accent); }
        .gs-topbar-btn--primary {
          background: var(--accent);
          border-color: var(--accent);
          color: #fff;
        }
        .gs-topbar-btn--primary:hover { opacity: 0.88; color: #fff; }
        .gs-bottom-bar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding-top: var(--space-5);
          margin-top: var(--space-4);
          border-top: 1px solid var(--border);
        }
        .gs-restart-btn {
          background: transparent;
          border: 1px solid var(--border);
          color: var(--text-muted);
          border-radius: 6px;
          padding: 3px 10px;
          font-size: var(--text-xs);
          font-weight: 600;
          cursor: pointer;
          transition: border-color 0.1s, color 0.1s;
        }
        .gs-restart-btn:hover { border-color: var(--accent); color: var(--accent); }
        .gs-next-btn {
          background: var(--accent);
          color: var(--text-on-green, #fff);
          border: none;
          border-radius: var(--radius);
          padding: var(--space-3) var(--space-6);
          font-size: var(--text-base);
          font-weight: 700;
          cursor: pointer;
          transition: opacity 0.1s;
        }
        .gs-next-btn:hover { opacity: 0.88; }

        /* Selections recap card */
        /* Page heading with context badges */
        .gs-page-heading {
          display: flex;
          align-items: center;
          gap: var(--space-3);
          margin-bottom: var(--space-4);
          flex-wrap: wrap;
        }
        .gs-persona-name {
          font-size: var(--text-lg);
          font-weight: 700;
          color: var(--text);
          flex-shrink: 0;
        }
        .gs-heading-badges {
          display: flex;
          align-items: center;
          gap: var(--space-2);
          flex-wrap: wrap;
        }
        .gs-badge {
          display: inline-flex;
          align-items: center;
          gap: 5px;
          padding: 3px 9px;
          border-radius: var(--radius);
          font-size: var(--text-xs);
          font-weight: 600;
          border: 1px solid var(--border);
          background: var(--bg-subtle);
          color: var(--text-muted);
          white-space: nowrap;
        }
        .gs-arch-id-inline {
          font-family: monospace;
          font-size: 10px;
          font-weight: 700;
          background: var(--accent);
          color: #fff;
          padding: 1px 5px;
          border-radius: 3px;
          flex-shrink: 0;
        }

        /* CLAUDE.md banner */
        /* CLAUDE.md inline actions */
        .gs-howto-panel { padding: var(--space-3) var(--space-4); background: var(--bg-card); border-radius: var(--radius); border: 1px solid var(--border); }
        .gs-howto-steps { margin: 0; padding-left: var(--space-5); display: flex; flex-direction: column; gap: var(--space-2); }
        .gs-howto-steps li { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.55; }
        .gs-howto-steps strong { color: var(--text); }
        .gs-howto-steps code { font-family: monospace; font-size: var(--text-xs); background: var(--bg-subtle); border: 1px solid var(--border); padding: 1px 5px; border-radius: 3px; color: var(--text); }

        /* Install block */
        .gs-install-block {
          border: 1px solid var(--border);
          border-radius: var(--radius);
          overflow: hidden;
          margin-bottom: var(--space-5);
        }
        .gs-install-toggle {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: var(--space-3) var(--space-4);
          background: var(--bg-subtle);
          border: none;
          cursor: pointer;
          transition: background 0.1s;
          text-align: left;
        }
        .gs-install-toggle:hover { background: var(--bg-hover); }
        .gs-install-title { font-size: var(--text-sm); font-weight: 700; color: var(--text); }
        .gs-install-chevron { font-size: var(--text-sm); color: var(--text-muted); }
        .gs-install-body {
          padding: var(--space-4);
          border-top: 1px solid var(--border);
          background: var(--bg-card);
        }
        .gs-install-cols {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: var(--space-6);
        }
        .gs-install-label {
          font-size: var(--text-xs);
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--text-muted);
          margin-bottom: var(--space-2);
          display: block;
        }
        .gs-install-list { margin: 0; padding-left: var(--space-5); display: flex; flex-direction: column; gap: var(--space-2); }
        .gs-install-list li, .gs-install-note { font-size: var(--text-xs); color: var(--text-muted); line-height: 1.55; }
        .gs-install-note { margin: 0; }
        .gs-install-code {
          font-family: monospace;
          font-size: var(--text-xs);
          background: #1e1e1e;
          color: #d4d4d4;
          padding: var(--space-3);
          border-radius: 4px;
          white-space: pre;
          overflow-x: auto;
          line-height: 1.65;
          margin: 0;
          border-left: 3px solid var(--accent);
        }
        .gs-habit-card {
          display: flex;
          gap: var(--space-3);
          padding: var(--space-3);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          margin-bottom: var(--space-3);
          background: var(--bg-subtle);
        }
        .gs-habit-num {
          width: 24px;
          height: 24px;
          border-radius: 50%;
          background: var(--accent);
          color: #fff;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: var(--text-xs);
          font-weight: 700;
          flex-shrink: 0;
        }
        .gs-habit-card strong { font-size: var(--text-sm); color: var(--text); display: block; margin-bottom: 4px; }
        .gs-habit-card p { font-size: var(--text-xs); color: var(--text-muted); line-height: 1.55; margin: 0; }

        /* Tabs */
        .gs-tabs-wrapper {
          display: flex;
          align-items: flex-start;
          gap: var(--space-6);
          margin-bottom: var(--space-5);
          flex-wrap: wrap;
        }
        .gs-tab-group {
          display: flex;
          flex-direction: column;
          gap: var(--space-1);
        }
        .gs-tab-group-label {
          font-size: 9px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          padding: 0 2px;
        }
        .gs-tab-group--role .gs-tab-group-label { color: var(--accent); }
        .gs-tab-group--ref .gs-tab-group-label { color: #00A3E0; }
        .gs-tabs {
          display: flex;
          gap: var(--space-1);
          flex-wrap: wrap;
        }
        .gs-tab {
          border-radius: var(--radius);
          padding: 5px var(--space-3);
          font-size: var(--text-sm);
          font-weight: 500;
          cursor: pointer;
          transition: background 0.12s, color 0.12s, border-color 0.12s;
          white-space: nowrap;
        }
        /* Role group — green pills */
        .gs-tab-group--role .gs-tab {
          background: rgba(134, 188, 37, 0.10);
          color: #5a8215;
          border: 1px solid rgba(134, 188, 37, 0.28);
        }
        .gs-tab-group--role .gs-tab:hover {
          background: rgba(134, 188, 37, 0.20);
          color: var(--accent);
        }
        .gs-tab-group--role .gs-tab--active {
          background: var(--accent);
          color: #fff;
          border-color: var(--accent);
          font-weight: 700;
        }
        /* Reference group — cyan pills */
        .gs-tab-group--ref .gs-tab {
          background: rgba(0, 163, 224, 0.08);
          color: #0077a8;
          border: 1px solid rgba(0, 163, 224, 0.25);
        }
        .gs-tab-group--ref .gs-tab:hover {
          background: rgba(0, 163, 224, 0.18);
          color: #00A3E0;
        }
        .gs-tab-group--ref .gs-tab--active {
          background: #00A3E0;
          color: #fff;
          border-color: #00A3E0;
          font-weight: 700;
        }

        .gs-panel { min-height: 200px; }

        .gs-section-label {
          font-size: var(--text-xs);
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--text-muted);
          margin-bottom: var(--space-4);
          display: block;
        }

        /* Dos & Don'ts */
        .gs-dos-cols { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-6); }
        .gs-dos-heading { font-size: var(--text-sm); font-weight: 700; margin-bottom: var(--space-3); padding-bottom: var(--space-2); border-bottom: 1px solid var(--border); }
        .gs-dos-do { color: var(--accent); }
        .gs-dos-dont { color: var(--tier-3); }
        .gs-dos-list { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: var(--space-2); }
        .gs-dos-list li { display: flex; align-items: flex-start; gap: var(--space-2); font-size: var(--text-sm); color: var(--text-muted); line-height: 1.5; }
        .gs-do-mark { color: var(--accent); font-weight: 700; flex-shrink: 0; }
        .gs-dont-mark { color: var(--tier-3); font-weight: 700; flex-shrink: 0; }

        /* Anti-patterns */
        .gs-anti-wrap {
          margin-top: var(--space-6);
          border-top: 1px solid var(--border);
          padding-top: var(--space-5);
        }
        .gs-anti-header {
          display: flex;
          align-items: center;
          gap: var(--space-3);
          margin-bottom: var(--space-4);
        }
        .gs-anti-title {
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
        }
        .gs-anti-tool-badge {
          font-size: var(--text-xs);
          font-weight: 600;
          padding: 2px 8px;
          border-radius: 10px;
          background: var(--tier-2-bg);
          color: var(--tier-2);
          border: 1px solid var(--tier-2);
        }
        .gs-anti-list {
          display: flex;
          flex-direction: column;
          gap: var(--space-3);
        }
        .gs-anti-item {
          padding: var(--space-3) var(--space-4);
          border: 1px solid var(--border);
          border-left: 3px solid var(--tier-3);
          border-radius: 0 var(--radius) var(--radius) 0;
          background: var(--bg-card);
          display: flex;
          flex-direction: column;
          gap: var(--space-1);
        }
        .gs-anti-item-header {
          display: flex;
          align-items: center;
          gap: var(--space-2);
        }
        .gs-anti-num {
          width: 20px;
          height: 20px;
          border-radius: 50%;
          background: var(--tier-3);
          color: #fff;
          font-size: 10px;
          font-weight: 700;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          flex-shrink: 0;
        }
        .gs-anti-name {
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
        }
        .gs-anti-body {
          font-size: var(--text-xs);
          color: var(--text-muted);
          line-height: 1.55;
          margin: 0;
          padding-left: 28px;
        }
        .gs-anti-note {
          font-size: var(--text-xs);
          color: var(--text-muted);
          line-height: 1.5;
          margin: 0;
          padding: var(--space-2) var(--space-3);
          background: var(--tier-2-bg);
          border-radius: 4px;
          border-left: 2px solid var(--tier-2);
          margin-left: 28px;
        }
        .gs-anti-note-label {
          font-weight: 700;
          color: var(--tier-2);
          margin-right: 4px;
        }

        /* Guardrails */
        .gs-guard-list { list-style: none; padding: 0; margin: 0; }
        .gs-guard-item { display: flex; align-items: baseline; gap: var(--space-3); padding: var(--space-3) 0; border-bottom: 1px solid var(--border); }
        .gs-guard-item:last-child { border-bottom: none; }
        .gs-guard-num { font-size: var(--text-sm); font-weight: 700; color: var(--accent); white-space: nowrap; min-width: 24px; }
        .gs-guard-body { display: flex; flex-direction: column; gap: 3px; }
        .gs-guard-label { font-size: var(--text-sm); font-weight: 700; color: var(--text); }
        .gs-guard-detail { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.5; }

        /* Scenarios */
        .gs-scenario-header { display: flex; align-items: center; justify-content: space-between; gap: var(--space-3); margin-bottom: var(--space-2); }
        .gs-scenario-title { font-size: var(--text-base); font-weight: 700; color: var(--text); }
        .gs-scenario-meta { font-size: var(--text-xs); color: var(--text-muted); background: var(--bg-subtle); border: 1px solid var(--border); padding: 2px 8px; border-radius: 4px; }
        .gs-scenario-when { font-size: var(--text-sm); color: var(--text-muted); margin-bottom: var(--space-4); line-height: 1.5; }
        .gs-steps { display: flex; flex-direction: column; gap: var(--space-4); }
        .gs-step { background: var(--bg-card); border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; }
        .gs-step-header { width: 100%; display: flex; align-items: center; justify-content: space-between; padding: var(--space-2) var(--space-3); background: var(--bg-subtle); border: none; border-bottom: 1px solid transparent; text-align: left; cursor: pointer; transition: background 0.1s; }
        .gs-step-header:hover { background: var(--bg-hover); }
        .gs-step--open .gs-step-header { border-bottom-color: var(--border); }
        .gs-step-name { font-size: var(--text-sm); font-weight: 700; color: var(--text); }
        .gs-step-body { font-size: var(--text-xs); color: var(--text-muted); padding: var(--space-2) var(--space-3); margin: 0; line-height: 1.5; }
        .gs-prompt { font-family: monospace; font-size: var(--text-xs); line-height: 1.6; color: var(--text); background: var(--bg-subtle); padding: var(--space-3); margin: 0; white-space: pre-wrap; word-break: break-word; border-top: 1px solid var(--border); max-height: 280px; overflow-y: auto; }
        .gs-step-copy-row { display: flex; justify-content: flex-end; padding: var(--space-2) var(--space-3); border-top: 1px solid var(--border); background: var(--bg-card); }
        .gs-step-copy { background: transparent; border: 1px solid var(--border); border-radius: 4px; padding: 2px 10px; font-size: var(--text-xs); font-weight: 600; color: var(--text-muted); cursor: pointer; transition: border-color 0.1s, color 0.1s; }
        .gs-step-copy:hover { border-color: var(--accent); color: var(--accent); }

        /* More use cases */
        .gs-more-list { list-style: none; padding: 0; margin: 0; border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; }
        .gs-more-item { border-bottom: 1px solid var(--border); }
        .gs-more-item:last-child { border-bottom: none; }
        .gs-more-row { width: 100%; display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); background: transparent; border: none; text-align: left; cursor: pointer; transition: background 0.1s; }
        .gs-more-row:hover, .gs-more-row--open { background: var(--bg-hover); }
        .gs-more-title-stack { display: flex; flex-direction: column; align-items: flex-start; gap: 3px; min-width: 0; }
        .gs-more-title { font-size: var(--text-sm); font-weight: 600; color: var(--text); }
        .gs-more-chevron { font-size: var(--text-sm); color: var(--text-muted); }
        .gs-more-panel { padding: var(--space-3) var(--space-4) var(--space-4); }

        /* Token Economics */
        .gs-token-img { width: 100%; border-radius: var(--radius); border: 1px solid var(--border); display: block; margin-bottom: var(--space-4); }
        .gs-token-section-hdr {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 100%;
          background: none;
          border: none;
          border-bottom: 1px solid var(--border);
          padding: var(--space-2) 0;
          margin: var(--space-4) 0 var(--space-3);
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
          cursor: pointer;
          text-align: left;
        }
        .gs-token-section-hdr:first-of-type { margin-top: 0; }
        .gs-token-section-hdr:hover { color: var(--accent); border-bottom-color: var(--accent); }
        .gs-token-scope-note { font-size: var(--text-xs); color: var(--text-muted); background: var(--bg-subtle); border: 1px solid var(--border); border-radius: var(--radius); padding: var(--space-3) var(--space-4); margin: 0 0 var(--space-4); line-height: 1.5; }
        .gs-tokens-intro { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.65; margin-bottom: var(--space-5); max-width: 640px; }
        /* Archetype table */
        .gs-token-table { width: 100%; border-collapse: collapse; font-size: var(--text-xs); }
        .gs-token-table thead th { text-align: left; font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.07em; color: var(--text-muted); padding: var(--space-2) var(--space-2) var(--space-2) 0; border-bottom: 2px solid var(--accent); }
        .gs-token-table tbody tr { border-bottom: 1px solid var(--border); }
        .gs-token-table tbody tr:last-child { border-bottom: none; }
        .gs-token-table td { padding: var(--space-1) var(--space-2) var(--space-1) 0; color: var(--text-muted); vertical-align: top; line-height: 1.45; }
        .gs-token-row--active { background: var(--tier-1-bg); }
        .gs-token-row--active td { color: var(--text); font-weight: 600; }
        .gs-token-arch { font-family: monospace; font-weight: 700; color: var(--text); width: 32px; }
        /* Tactic accordion */
        .gs-tactic-list { border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; }
        .gs-tactic { border-bottom: 1px solid var(--border); background: var(--bg-card); }
        .gs-tactic:last-child { border-bottom: none; }
        .gs-tactic-hdr { width: 100%; display: flex; align-items: center; justify-content: space-between; gap: var(--space-3); padding: 9px 14px; background: transparent; border: none; text-align: left; cursor: pointer; transition: background 0.1s; }
        .gs-tactic-hdr:hover { background: var(--bg-hover); }
        .gs-tactic--open .gs-tactic-hdr { background: var(--tier-1-bg); }
        .gs-tactic-hdr-left { display: flex; align-items: center; gap: var(--space-3); flex: 1; min-width: 0; }
        .gs-tactic-n { width: 20px; height: 20px; border-radius: 50%; background: var(--bg-subtle); border: 1px solid var(--border); display: inline-flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 700; color: var(--text-muted); flex-shrink: 0; }
        .gs-tactic--open .gs-tactic-n { background: var(--accent); border-color: var(--accent); color: #fff; }
        .gs-tactic-title { font-size: var(--text-sm); font-weight: 600; color: var(--text); flex: 1; line-height: 1.3; }
        .gs-scope-badge { font-size: 9px; font-weight: 700; letter-spacing: 0.07em; text-transform: uppercase; padding: 2px 6px; border-radius: 6px; flex-shrink: 0; white-space: nowrap; }
        .gs-scope-green { background: var(--tier-1-bg); color: var(--tier-1); }
        .gs-scope-grey  { background: var(--bg-subtle); color: var(--text-muted); border: 1px solid var(--border); }
        .gs-scope-amber { background: var(--tier-2-bg); color: var(--tier-2); }
        .gs-chevron-sm  { font-size: var(--text-sm); color: var(--text-muted); flex-shrink: 0; }
        .gs-tactic-body { padding: 12px 16px 14px; border-top: 1px solid var(--border); background: var(--bg-subtle); display: flex; flex-direction: column; gap: var(--space-3); }
        .gs-tactic-summary { font-size: var(--text-sm); color: var(--text); line-height: 1.55; margin: 0; }
        .gs-tactic-note { font-size: var(--text-xs); color: var(--text-muted); background: var(--tier-2-bg); border-left: 3px solid var(--tier-2); padding: var(--space-2) var(--space-3); border-radius: 0 4px 4px 0; margin: 0; line-height: 1.5; }
        .gs-tactic-examples { display: grid; grid-template-columns: 1fr 1fr; gap: var(--space-3); }
        .gs-ex-label { font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.07em; padding: 2px 6px; border-radius: 4px; display: inline-block; margin-bottom: 5px; }
        .gs-ex-bad  { background: #fde8e8; color: #c0392b; }
        .gs-ex-good { background: var(--tier-1-bg); color: var(--tier-1); }
        .gs-code { font-family: monospace; font-size: 11px; line-height: 1.5; background: var(--bg-card); border: 1px solid var(--border); border-radius: 4px; padding: 8px 10px; margin: 0; white-space: pre-wrap; word-break: break-word; color: var(--text-muted); display: block; }
        .gs-code-bad  { border-left: 3px solid #c0392b; }
        .gs-code-good { border-left: 3px solid var(--accent); }
        .gs-tactic-tips { padding-left: var(--space-4); margin: 0; }
        .gs-tactic-tips li { font-size: var(--text-xs); color: var(--text-muted); line-height: 1.55; margin-bottom: 4px; }
        /* Infographic toggle */
        .gs-tokens-infographic { border: 1px solid var(--border); border-radius: var(--radius); overflow: hidden; margin-top: var(--space-5); }
        .gs-infographic-toggle { width: 100%; display: flex; align-items: center; justify-content: space-between; padding: var(--space-3) var(--space-4); background: var(--bg-subtle); border: none; cursor: pointer; transition: background 0.1s; text-align: left; }
        .gs-infographic-toggle:hover { background: var(--bg-hover); }
        .gs-token-img { width: 100%; border-radius: 0; border: none; border-top: 1px solid var(--border); display: block; }
        .gs-callout { border: 1px solid var(--border); border-left: 3px solid var(--accent); padding: var(--space-3) var(--space-4); border-radius: 2px; background: var(--bg-card); }
        .gs-callout-label { font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--accent); display: block; margin-bottom: var(--space-2); }
        .gs-callout p { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.6; margin: 0; }
        .gs-token-levers-callout { background: var(--bg-subtle); border: none; border-left: 3px solid var(--accent); border-radius: 0 var(--radius) var(--radius) 0; padding: var(--space-3); margin-bottom: var(--space-3); }
        .gs-token-levers-callout p, .gs-token-levers-callout ul { font-size: var(--text-sm); color: var(--text); margin: 0; }
        .gs-token-levers-callout ul { padding-left: var(--space-4); margin-top: var(--space-2); }
        .gs-token-levers-callout li { margin-bottom: 4px; }

        /* Pod Context */
        .gs-pod-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: var(--space-5); margin-bottom: var(--space-5); }
        .gs-pod-heading { font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.08em; color: var(--text-muted); margin-bottom: var(--space-3); padding-bottom: var(--space-2); border-bottom: 1px solid var(--border); }
        .gs-pod-list { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: var(--space-2); }
        .gs-pod-list li { display: flex; align-items: flex-start; gap: var(--space-2); font-size: var(--text-sm); color: var(--text-muted); line-height: 1.5; }
        .gs-pod-arrow { flex-shrink: 0; font-weight: 700; color: var(--accent); }
        .gs-pod-mark { flex-shrink: 0; font-weight: 700; color: var(--accent); }

        /* Recipe */
        .gs-recipe-wrap { display: flex; flex-direction: column; gap: var(--space-1); }
        .gs-recipe-meta {
          display: flex;
          gap: var(--space-4);
          flex-wrap: wrap;
          padding: var(--space-3) var(--space-4);
          background: var(--bg-subtle);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          margin-bottom: var(--space-4);
        }
        .gs-recipe-meta-item { display: flex; flex-direction: column; gap: 2px; }
        .gs-recipe-meta-key {
          font-size: 9px;
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--text-muted);
        }
        .gs-recipe-meta-val { font-size: var(--text-sm); font-weight: 600; color: var(--text); }
        .gs-recipe-meta-accent { color: var(--accent); }
        .gs-recipe-summary {
          font-size: var(--text-sm);
          color: var(--text-muted);
          line-height: 1.6;
          margin: 0 0 var(--space-4);
          padding-bottom: var(--space-4);
          border-bottom: 1px solid var(--border);
        }
        .gs-recipe-section { margin-bottom: var(--space-5); }
        .gs-recipe-h4 {
          font-size: var(--text-xs);
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--accent);
          margin: 0 0 var(--space-2);
        }
        .gs-recipe-prose {
          font-size: var(--text-sm);
          color: var(--text-muted);
          line-height: 1.65;
          margin: 0;
        }
        .gs-recipe-ol {
          padding-left: var(--space-5);
          margin: 0;
          display: flex;
          flex-direction: column;
          gap: var(--space-2);
        }
        .gs-recipe-ol li {
          font-size: var(--text-sm);
          color: var(--text-muted);
          line-height: 1.55;
        }
        .gs-recipe-signals {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: var(--space-4);
        }
        .gs-recipe-signal {
          padding: var(--space-3) var(--space-4);
          border-radius: var(--radius);
          border: 1px solid var(--border);
        }
        .gs-recipe-signal--on { border-left: 3px solid var(--accent); background: var(--tier-1-bg); }
        .gs-recipe-signal--off { border-left: 3px solid var(--tier-3); background: var(--bg-subtle); }
        .gs-recipe-signal-label {
          font-size: var(--text-xs);
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.07em;
          display: block;
          margin-bottom: var(--space-2);
        }
        .gs-recipe-signal--on .gs-recipe-signal-label { color: var(--accent); }
        .gs-recipe-signal--off .gs-recipe-signal-label { color: var(--tier-3); }
        .gs-recipe-ul {
          padding-left: var(--space-4);
          margin: 0;
          display: flex;
          flex-direction: column;
          gap: var(--space-1);
        }
        .gs-recipe-ul li { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.5; }
        .gs-recipe-sideways {
          padding: var(--space-4);
          background: var(--tier-2-bg);
          border: 1px solid var(--tier-2);
          border-left: 3px solid var(--tier-2);
          border-radius: 0 var(--radius) var(--radius) 0;
        }
        .gs-recipe-sideways-label {
          font-size: var(--text-xs);
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--tier-2);
          display: block;
          margin-bottom: var(--space-2);
        }
        @media (max-width: 640px) {
          .gs-recipe-signals { grid-template-columns: 1fr; }
          .gs-recipe-meta { gap: var(--space-3); }
        }

        /* Recipe accordion */
        .gs-recipe-persona-callout {
          background: var(--tier-1-bg);
          border: 1px solid rgba(134,188,37,0.35);
          border-left: 3px solid var(--accent);
          border-radius: 2px;
          padding: var(--space-3) var(--space-4);
          margin-bottom: var(--space-4);
        }
        .gs-recipe-persona-callout-label {
          font-size: var(--text-xs);
          font-weight: 700;
          text-transform: uppercase;
          letter-spacing: 0.08em;
          color: var(--accent);
          display: block;
          margin-bottom: var(--space-2);
        }
        .gs-recipe-acc {
          border: 1px solid var(--border);
          border-radius: var(--radius);
          overflow: hidden;
          margin-bottom: var(--space-2);
        }
        .gs-recipe-acc--sideways {
          border-color: var(--tier-2);
        }
        .gs-recipe-acc-hdr {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: var(--space-3) var(--space-4);
          background: var(--bg-subtle);
          border: none;
          text-align: left;
          cursor: pointer;
          transition: background 0.1s;
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
        }
        .gs-recipe-acc-hdr:hover { background: var(--bg-hover); }
        .gs-recipe-acc--sideways .gs-recipe-acc-hdr { background: var(--tier-2-bg); color: var(--tier-2); }
        .gs-recipe-acc-body {
          padding: var(--space-3) var(--space-4) var(--space-4);
          border-top: 1px solid var(--border);
        }
        .gs-recipe-acc-title { flex: 1; }

        /* Agentic principles */
        .gs-principles-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
          gap: var(--space-3);
          margin-bottom: var(--space-3);
        }
        .gs-principle-card {
          padding: var(--space-3) var(--space-4);
          border: 1px solid var(--border);
          border-left: 3px solid var(--accent);
          border-radius: 2px;
          background: var(--bg-card);
        }
        .gs-principle-title {
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
          display: block;
          margin-bottom: var(--space-1);
        }
        .gs-principle-body {
          font-size: var(--text-xs);
          color: var(--text-muted);
          line-height: 1.55;
          margin: 0;
        }
        .gs-principles-more {
          font-size: var(--text-xs);
          display: inline-block;
          margin-bottom: var(--space-4);
        }

        /* Playbook tab */
        .gs-playbook-section {
          padding: var(--space-3) 0 var(--space-4);
        }
        .gs-playbook-principles {
          display: flex;
          flex-direction: column;
          gap: var(--space-3);
        }
        .gs-playbook-item {
          padding: var(--space-3) var(--space-4);
          border: 1px solid var(--border);
          border-left: 3px solid var(--accent);
          border-radius: 2px;
          background: var(--bg-card);
        }
        .gs-playbook-item-title {
          font-size: var(--text-sm);
          font-weight: 700;
          color: var(--text);
          display: block;
          margin-bottom: var(--space-1);
        }
        .gs-playbook-item-body {
          font-size: var(--text-xs);
          color: var(--text-muted);
          line-height: 1.55;
          margin: 0;
        }

        /* Programme gates */
        .gs-prog-gates { padding-top: var(--space-3); }
        .gs-prog-gates-intro { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.55; margin-bottom: var(--space-4); max-width: 580px; }

        /* Prompt Engineering */
        .gs-tech-table { width: 100%; border-collapse: collapse; font-size: var(--text-sm); margin-bottom: var(--space-6); }
        .gs-tech-table thead th { text-align: left; font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.07em; color: var(--text-muted); padding: var(--space-2) var(--space-3) var(--space-2) 0; border-bottom: 1px solid var(--border); }
        .gs-tech-table tbody tr { border-bottom: 1px solid var(--border); }
        .gs-tech-table tbody tr:last-child { border-bottom: none; }
        .gs-tech-name { font-weight: 700; color: var(--text); padding: var(--space-3) var(--space-4) var(--space-3) 0; width: 160px; vertical-align: top; white-space: nowrap; }
        .gs-tech-desc { color: var(--text-muted); padding: var(--space-3) 0; line-height: 1.55; vertical-align: top; }
        .gs-learn-label { font-size: var(--text-sm); font-weight: 700; color: var(--text-muted); margin-bottom: var(--space-2); }
        .gs-learn-links ul { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: var(--space-2); }
        .gs-link { color: var(--accent); font-size: var(--text-sm); text-decoration: none; }
        .gs-link:hover { text-decoration: underline; }

        /* BMAD */
        .gs-bmad-desc { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.6; margin-bottom: var(--space-4); }
        .gs-bmad-list { padding-left: var(--space-5); margin-bottom: var(--space-5); }
        .gs-bmad-list li { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.5; margin-bottom: var(--space-2); }
        .gs-bmad-links { display: flex; gap: var(--space-3); flex-wrap: wrap; }
        .gs-bmad-link-btn { display: inline-block; padding: var(--space-2) var(--space-4); border: 1px solid var(--border); border-radius: var(--radius); font-size: var(--text-sm); font-weight: 600; color: var(--text); text-decoration: none; transition: border-color 0.1s, color 0.1s; }
        .gs-bmad-link-btn:hover { border-color: var(--accent); color: var(--accent); }
        .gs-bmad-link-btn--primary { background: var(--accent); color: #fff; border-color: var(--accent); }
        .gs-bmad-link-btn--primary:hover { background: #6fa01e; border-color: #6fa01e; color: #fff; }

        /* Engineering Standards */
        .gs-standards-wrap { }
        .gs-standards-desc { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.6; margin-bottom: var(--space-4); max-width: 640px; }
        .gs-standards-links { margin-bottom: var(--space-4); display: flex; gap: var(--space-3); flex-wrap: wrap; }
        .gs-standards-list { padding-left: var(--space-5); margin: 0; }
        .gs-standards-list li { font-size: var(--text-sm); color: var(--text-muted); line-height: 1.5; margin-bottom: var(--space-2); }

        .gs-empty { font-size: var(--text-sm); color: var(--text-muted); padding: var(--space-6) 0; text-align: center; }

        .link-back { background: transparent; border: none; color: var(--text-muted); padding: 0; cursor: pointer; font-size: var(--text-sm); }
        .link-back:hover { color: var(--text); }

        @media (max-width: 640px) {
          .gs-dos-cols, .gs-pod-grid, .gs-install-cols { grid-template-columns: 1fr; }
          .gs-tokens-layout { grid-template-columns: 1fr; }
        }
      `})]})}const Jt=[{id:"master-anthropic-prompt-eng-tutorial",title:"Anthropic Interactive Prompt Engineering Tutorial",provider:"Anthropic",url:"https://github.com/anthropics/prompt-eng-interactive-tutorial",hours:"~4h",description:"Nine chapters with exercises. The official tutorial. Core techniques: 4-block pattern, output control, context windows.",type:"course"},{id:"master-anthropic-academy",title:"Anthropic Academy — short courses on Claude",provider:"Anthropic",url:"https://anthropic.com/learn",description:"Official short-form lessons on Claude basics, Projects, Artifacts.",type:"resource"},{id:"master-anthropic-prompting-best-practices",title:"Anthropic — Prompting Best Practices",provider:"Anthropic",url:"https://docs.claude.com",description:"XML tagging, few-shot, chaining, extended thinking.",type:"resource"},{id:"master-claude-code-docs",title:"Claude Code Documentation — CLAUDE.md, plan mode, MCP",provider:"Anthropic",url:"https://docs.claude.com",description:"Repo-aware agentic coding patterns; what makes Claude Code production-ready.",type:"resource"},{id:"master-claude-skills-repo",title:"Claude Skills — SKILL.md authoring",provider:"Anthropic",url:"https://github.com/anthropics/skills",description:"SKILL.md files encoding team conventions for Claude.",type:"resource"},{id:"master-anthropic-building-effective-agents",title:"Anthropic — Building Effective Agents",provider:"Anthropic",url:"https://www.anthropic.com/research/building-effective-agents",description:"Canonical agent patterns; the most important essay on production agents.",type:"resource"},{id:"master-bmad-method",title:"BMAD Method — Getting Started",provider:"BMAD",url:"https://github.com/bmad-code-org/BMAD-METHOD",description:"Structured PRD → ADR → Story → Ship workflow. The core structured AI delivery framework.",type:"resource"},{id:"master-mcp-spec",title:"Model Context Protocol — Specification",url:"https://modelcontextprotocol.io",description:"Open standard for connecting Claude to external tools and systems.",type:"resource"},{id:"master-dl-genai-for-everyone",title:"Generative AI for Everyone — Andrew Ng",provider:"DeepLearning.AI",url:"https://www.deeplearning.ai/courses/generative-ai-for-everyone/",hours:"~6h",description:"Non-technical primer. Audit-free.",type:"course"},{id:"master-dl-genai-with-llms",title:"Generative AI with Large Language Models",provider:"DeepLearning.AI / AWS",url:"https://www.deeplearning.ai/courses/generative-ai-with-llms/",hours:"~6h",description:"How LLMs work. Audit-free.",type:"course"},{id:"master-dl-chatgpt-prompt-eng-for-devs",title:"ChatGPT Prompt Engineering for Developers — Ng & Fulford",provider:"DeepLearning.AI",url:"https://www.deeplearning.ai/courses/chatgpt-prompt-eng/",hours:"~2h",description:"Concise prompt-engineering primer. Patterns transfer to Claude.",type:"course"},{id:"master-dl-agentic-ai",title:"Agentic AI — Andrew Ng (flagship)",provider:"DeepLearning.AI",url:"https://www.deeplearning.ai/courses/agentic-ai/",hours:"~6h",description:"The four design patterns: Reflection, Tool Use, Planning, Multi-Agent.",type:"course"},{id:"master-dl-langgraph",title:"AI Agents in LangGraph",provider:"DeepLearning.AI",url:"https://www.deeplearning.ai/courses/ai-agents-in-langgraph/",hours:"~2h",description:"Graph-based agent state machines.",type:"course"},{id:"master-ms-genai-for-beginners",title:"Generative AI for Beginners (21 lessons)",provider:"Microsoft Learn",url:"https://github.com/microsoft/generative-ai-for-beginners",description:"Python and TypeScript code samples, runnable on GitHub Codespaces.",type:"course"},{id:"master-hf-llm-course",title:"LLM Course",provider:"Hugging Face",url:"https://huggingface.co/learn/llm-course",description:"Transformers, fine-tuning concepts, tokenization.",type:"course"},{id:"master-hf-agents-course",title:"Agents Course",provider:"Hugging Face",url:"https://huggingface.co/learn/agents-course",description:"Free, certified. Build with smolagents, LangGraph, LlamaIndex.",type:"course"},{id:"master-nist-ai-rmf",title:"NIST AI Risk Management Framework",provider:"NIST",url:"https://nist.gov/itl/ai-risk-management-framework",description:"Canonical AI governance framework. Essential reading.",type:"resource"},{id:"master-eu-ai-act",title:"EU AI Act overview",provider:"European Commission",url:"https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai",description:"Regulatory landscape for AI products in the EU.",type:"resource"},{id:"master-owasp-llm-top10",title:"OWASP Top 10 for LLM Applications",provider:"OWASP",url:"https://genai.owasp.org/llm-top-10",hours:"~2h",description:"Threat catalogue for AI-feature testing.",type:"course"},{id:"master-promptfoo",title:"Promptfoo — Getting Started",provider:"Promptfoo",url:"https://promptfoo.dev",hours:"~2h",description:"Run first evals against a Claude prompt.",type:"course"},{id:"master-deepeval",title:"DeepEval — open-source eval framework",provider:"DeepEval",url:"https://deepeval.com",type:"resource"},{id:"master-langfuse",title:"Langfuse — LLM observability",provider:"Langfuse",url:"https://langfuse.com",description:"Open-source LLM observability. Self-hostable.",type:"resource"},{id:"master-langsmith",title:"LangSmith — datasets, traces, scoring",provider:"LangChain",url:"https://smith.langchain.com",type:"resource"},{id:"master-prompting-guide",title:"Prompt Engineering Guide (dair-ai)",url:"https://promptingguide.ai",description:"Comprehensive prompt-engineering reference. 50k+ stars.",type:"resource"},{id:"master-udemy-business-sso",title:"Udemy Business via Deloitte SSO",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com",description:"Sign in via Deloitte SSO to access the full corporate-plan course catalogue.",type:"resource"},{id:"master-aef-101",title:"AEF 101 — Introductions and Offerings",provider:"Deloitte Engineering Platforms",url:"https://amedeloitte.sharepoint.com/:v:/r/sites/DeloitteEngineeringPlatforms101/Shared%20Documents/General/AEF%20HashedIn%20Training/Recordings/101/101-AEF%20Introductions%20and%20Offerings.mp4?csf=1&web=1&e=uwY6zi",hours:"~1h",description:"Introduction to the Ascend Engineering Foundation — what it is, what it offers, and how to get started.",type:"course"},{id:"master-aef-201",title:"AEF 201 — Advanced Topics",provider:"Deloitte Engineering Platforms",url:"https://amedeloitte.sharepoint.com/:f:/r/sites/DeloitteEngineeringPlatforms101/Shared%20Documents/General/AEF%20HashedIn%20Training/Recordings/201?csf=1&web=1&e=NFce4v",description:"Advanced AEF topics: KMS, Cloud Hosting, Application Common Services, Certify the Factory, and platform governance.",type:"course"}],$t=Object.fromEntries(Jt.map(r=>[r.id,r]));function p(r,a={}){const n=$t[r];if(!n)throw new Error(`Unknown master course id: ${r}`);return{id:n.id,title:n.title,provider:n.provider,url:n.url,hours:n.hours,description:n.description,type:n.type,sourceDocument:a.sourceDocument??"master",track:a.track,originalLevel:a.originalLevel}}const v="GenAI_PM_Learning_Plan.docx",o="AI-Enabled Architect Learning Pathway (1).docx",s="AI-Enabled UX Designer Learning Pathway.docx",b="AI-Enabled_Engineer_Learning_Pathways.docx",m="AI_Enabled_Test_Automation_Learning_Journey.docx",c="Generative_and_Agentic_AI_Learning_Pathway_Edition 1.docx",i="Ai Enabled Data Engineer Learning Pathway.docx",k="ML Engineer.docx",Zt={personaId:"pm",displayName:"Product Manager",sourcePathwayNames:["AI Enabled - Product Manager"],mappingStatus:"mapped",mappingNotes:"Renamed from GenAI Product Manager source plan; underlying content preserved.",levels:[{level:"Beginner",originalLevelNames:["Foundation","Working"],summary:"Foundation across the ten PM-AI skills. The 12-week starter plan and the first three practice projects build daily AI habits and a defensible verification reflex.",skills:["Structured prompting: 4-block pattern, XML tagging, few-shot, chained prompts — write daily; catch fluency vs reliability gap","Evidence verification: source > AI synthesis > AI generation — every claim traces to a named source; AI is never the source","BMAD basics: run Analyst persona on a real problem; progress to full Analyst → PM → Architect → PO cycle","Discovery with AI: AI-paired interview synthesis with manual verification — themes must trace to real quotes","PRD authoring basics: five-question pre-flight on every AI-drafted section; disclosure footer on every AI-assisted artifact"],items:[{id:"pm-jr-skill-1",title:"Structured prompting — 4-block pattern, XML tagging, few-shot, chained prompts",type:"practice",description:"Prevents fluent-but-unreliable output and hallucinations dressed as analysis.",sourceDocument:v,originalLevel:"Foundation",track:"Ten skills"},{id:"pm-jr-skill-3",title:"Evidence verification — Source > AI synthesis > AI generation",type:"practice",description:"AI is never the source. Prevents hallucinated evidence in artifacts that nobody catches before launch.",sourceDocument:v,originalLevel:"Foundation",track:"Ten skills"},{id:"pm-jr-skill-2",title:"Workflow orchestration — run one BMAD persona on real work",type:"practice",description:"Prevents AI use that does not compound. Every prompt starts from scratch otherwise.",sourceDocument:v,originalLevel:"Foundation",track:"Ten skills"},{id:"pm-jr-wk1",title:"Week 1 — 3 structured prompts on this week's work",type:"practice",description:"12-week plan, Plan A.",sourceDocument:v,track:"12-week plan"},{id:"pm-jr-wk2",title:"Week 2 — Reusable template for your top task",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-jr-wk3",title:"Week 3 — Run BMAD Analyst on current problem",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-jr-wk4",title:"Week 4 — Full BMAD cycle on a real feature",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-jr-pp1",title:"PP-1 — Personal AI-assisted research on a topic you want to understand",type:"practice",description:"Builds skills 1, 3. Artifact: 5-page synthesis with full prompt log and source list.",sourceDocument:v,track:"Practice projects (Plan B)"},{id:"pm-jr-pp2",title:"PP-2 — Competitive teardown of 3 real products in a category",type:"practice",description:"Builds skills 1, 3, 4. Artifact: 10-page teardown with structured comparison.",sourceDocument:v,track:"Practice projects (Plan B)"},{id:"pm-jr-pp3",title:"PP-3 — Hypothetical discovery sprint on a real public product",type:"practice",description:"Builds skills 1, 2, 4. Artifact: Interview synthesis + problem statement + opportunity assessment.",sourceDocument:v,track:"Practice projects (Plan B)"},p("master-dl-genai-for-everyone",{track:"Track 1: GenAI foundations",sourceDocument:v}),{id:"pm-jr-c2",title:"AI Prompting for Everyone",provider:"DeepLearning.AI",url:"https://www.deeplearning.ai/courses/ai-prompting-for-everyone/",hours:"~5h",type:"course",description:"How modern prompting actually works. Practical.",sourceDocument:v,track:"Track 1: GenAI foundations"},{id:"pm-jr-c3",title:"Introduction to Generative AI",provider:"Google",url:"https://www.cloudskillsboost.google/paths/118",hours:"~4h",type:"course",description:"No-cost video path. Non-technical audiences.",sourceDocument:v,track:"Track 1: GenAI foundations"},{id:"pm-jr-c4",title:"Introduction to Generative AI and Agents",provider:"Microsoft Learn",url:"https://learn.microsoft.com/en-us/training/paths/introduction-generative-ai/",hours:"~1h",type:"course",description:"One-sitting primer covering agents specifically.",sourceDocument:v,track:"Track 1: GenAI foundations"},p("master-anthropic-prompt-eng-tutorial",{track:"Track 1: GenAI foundations",sourceDocument:v}),{id:"pm-jr-tool-claude",title:"Claude — Day 1: Open a Project. Add your context. Write 3 structured prompts on real tasks.",provider:"Anthropic Academy",url:"https://docs.claude.com",type:"practice",description:"Tool playbook: ~90 days from first use to confident reliance.",sourceDocument:v,track:"Tool playbooks"},p("master-aef-101",{track:"AEF Platform",sourceDocument:"AEF Platform"})]},{level:"Intermediate",originalLevelNames:["Practitioner"],summary:"Practitioner-level discipline across all ten skills. AI-paired drafting is the default; the five-question pre-flight catches drift; the team references your PRDs as exemplars.",skills:["AI evaluation design: write the eval before the feature ships; per-component evals for agents; pre-launch eval gate","Building agentic workflows: one scheduled Claude Code run you actually use weekly; cross-document synthesis","Tool integration via MCP: Claude connected to one team system; reads/writes specified and security-reviewed","Agent design and oversight: scope, HITL checkpoints, audit trail, and kill switch — end-to-end for at least one agent","Failure mode coverage: hallucination, prompt injection, drift, cost, latency — all in scope before any AI feature ships"],items:[{id:"pm-sr-skill-4",title:"Discovery with AI — agentic research loops, AI-paired interview synthesis",type:"practice",description:"Prevents building features no one asked for, faster.",sourceDocument:v,originalLevel:"Practitioner",track:"Ten skills"},{id:"pm-sr-skill-5",title:"PRD authoring with AI — drafts you can defend; the five-question pre-flight",type:"practice",description:"Prevents polished artifacts the human author cannot explain.",sourceDocument:v,originalLevel:"Practitioner",track:"Ten skills"},{id:"pm-sr-skill-6",title:"AI evaluation design — eval before feature; continuous instrumentation",type:"practice",description:"Prevents shipping AI features without knowing if they work.",sourceDocument:v,originalLevel:"Practitioner",track:"Ten skills"},{id:"pm-sr-wk5",title:"Week 5 — Five-question pre-flight on existing PRD",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-sr-wk6",title:"Week 6 — Synthesise real interviews; verify themes",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-sr-wk7",title:"Week 7 — AI-paired PRD section + peer review",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-sr-wk8",title:"Week 8 — Write eval for one shipped AI feature",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-sr-pp4",title:"PP-4 — Eval design for a public AI product (reverse-engineer + critique)",type:"practice",description:"Builds skills 6, 9. Artifact: 4-page eval critique with proposed redesign.",sourceDocument:v,track:"Practice projects (Plan B)"},{id:"pm-sr-pp5",title:"PP-5 — Continuous competitive monitoring agent (weekly digest)",type:"practice",description:"Builds skills 1, 3, 7. Artifact: working scheduled workflow + 3 weeks of digests.",sourceDocument:v,track:"Practice projects (Plan B)"},{id:"pm-sr-c1",title:"AI Product Management Specialization (3 courses)",provider:"Duke University (DeepLearning.AI)",url:"https://www.deeplearning.ai/courses/ai-product-management-specialization/",hours:"~60h",type:"course",description:"The deepest free option. ML foundations, project management, human-centred AI design. Audit-free.",sourceDocument:v,track:"Track 2: GenAI for PMs and BAs"},{id:"pm-sr-c2",title:"Microsoft AI Product Manager Professional Certificate",provider:"Microsoft",url:"https://www.coursera.org/professional-certificates/microsoft-ai-product-manager",hours:"~120h",type:"course",description:"5 courses. Enterprise focus: Copilot, Power BI, Azure. Audit-free.",sourceDocument:v,track:"Track 2: GenAI for PMs and BAs"},{id:"pm-sr-c3",title:"IBM AI Product Manager Professional Certificate",provider:"IBM",url:"https://www.coursera.org/professional-certificates/ibm-ai-product-manager",hours:"~3 months",type:"course",description:"Generative AI concepts plus practical PM skills. Hands-on projects. Audit-free.",sourceDocument:v,track:"Track 2: GenAI for PMs and BAs"},{id:"pm-sr-c4",title:"Generative AI for Business Analysts Specialization",provider:"IBM",url:"https://www.coursera.org/specializations/generative-ai-for-business-analysts",hours:"~20h",type:"course",description:"3 weeks. GenAI across the BA lifecycle. Audit-free.",sourceDocument:v,track:"Track 2: GenAI for PMs and BAs"},{id:"pm-sr-c5",title:"GenAI for Business Analysts: Faster Insights",provider:"Coursera",url:"https://www.coursera.org/learn/genai-for-business-analysts-faster-insights",hours:"~10h",type:"course",description:"Single course. Practical GenAI for BI and BA workflows. Audit-free.",sourceDocument:v,track:"Track 2: GenAI for PMs and BAs"},{id:"pm-sr-c6",title:"Generative AI for Business Intelligence (BI) Analysts",provider:"IBM",url:"https://www.coursera.org/learn/generative-ai-for-business-intelligence-analysts",hours:"~30h",type:"course",description:"BI-focused. GenAI for dashboards and reporting. Audit-free.",sourceDocument:v,track:"Track 2: GenAI for PMs and BAs"},{id:"pm-sr-c7",title:"Microsoft AI Business Professional (AB-730)",provider:"Microsoft",url:"https://learn.microsoft.com/en-us/credentials/certifications/ai-900/",hours:"self-study",type:"course",description:"Free study materials. Certification optional.",sourceDocument:v,track:"Track 2: GenAI for PMs and BAs"},{id:"pm-sr-tool-bmad",title:"BMAD — Day 30: Full Analyst → PM → Architect → PO cycle twice on real work",provider:"BMAD",url:"https://github.com/bmad-code-org/BMAD-METHOD",type:"practice",description:"Tool playbook: structured workflow. One persona customised for your domain.",sourceDocument:v,track:"Tool playbooks"},{id:"pm-sr-grad-1",title:"Practitioner across the board on all ten skills",type:"graduation-criteria",sourceDocument:v,track:"Capability map"},p("master-aef-201",{track:"AEF Platform",sourceDocument:"AEF Platform"})]},{level:"Advanced",originalLevelNames:["Advanced","Specialist"],summary:"Advanced or Specialist on three or four chosen areas. You set artifact standards, author governance, and ship agentic workflows other PMs reuse.",skills:["Set team AI standards: AI usage policy authored; artifact standards defined; prompt library governed","Govern agents at scale: oversight protocols across multiple products or teams; escalation paths designed and tested","AI governance for product: NIST AI RMF alignment, vendor strategy, regulatory posture (EU AI Act), second-source planning","Mentor practitioners: deliberate growth of others to Practitioner and Advanced — at least two mentees advancing","Define practice methodology: how the practice does discovery, verification, and governance (Specialist)"],items:[{id:"pm-ex-skill-7",title:"Building agentic workflows — Claude Code, scheduled runs, cross-document work",type:"practice",description:"Prevents AI use trapped in chat windows. Missing the agent leverage.",sourceDocument:v,originalLevel:"Advanced",track:"Ten skills"},{id:"pm-ex-skill-8",title:"Tool integration via MCP — connect agents to Jira, Confluence, support inboxes, analytics",type:"practice",description:"Prevents agents that think but cannot act. Brittle workflows.",sourceDocument:v,originalLevel:"Advanced",track:"Ten skills"},{id:"pm-ex-skill-9",title:"Agent design and oversight — scope, HITL, escalation, audit, kill switch",type:"practice",description:"Prevents agents that do too much, too quietly. Accountability fog.",sourceDocument:v,originalLevel:"Specialist",track:"Ten skills"},{id:"pm-ex-skill-10",title:"AI governance for product — vendor strategy, regulatory posture, second-source planning",type:"practice",description:"Prevents regulatory drift, vendor lock, accountability gaps post-launch.",sourceDocument:v,originalLevel:"Specialist",track:"Ten skills"},{id:"pm-ex-wk9",title:"Week 9 — One scheduled Claude Code run you use",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-ex-wk10",title:"Week 10 — Connect Claude to one team system (MCP)",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-ex-wk11",title:"Week 11 — Specify one agent end-to-end",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-ex-wk12",title:"Week 12 — Regulatory scan + portfolio review",type:"practice",sourceDocument:v,track:"12-week plan"},{id:"pm-ex-pp6",title:"PP-6 — Customer-voice clustering agent on public data",type:"practice",description:"Builds skills 4, 7, 8. Artifact: working agent + 3 weekly digests with verified themes.",sourceDocument:v,track:"Practice projects (Plan B)"},{id:"pm-ex-pp7",title:"PP-7 — End-to-end agent design: discovery synthesis → roadmap items",type:"practice",description:"Builds skills 6, 9, 10. Artifact: 10-page agent spec ready for engineering.",sourceDocument:v,track:"Practice projects (Plan B)"},{id:"pm-ex-pp8",title:"PP-8 — Agent governance playbook for a small product team",type:"capstone",description:"Builds skills 3, 9, 10. Artifact: 12-page playbook that survives a legal review.",sourceDocument:v,track:"Practice projects (Plan B)"},{id:"pm-ex-c1",title:"AI for Everyone — Andrew Ng",provider:"DeepLearning.AI",url:"https://www.deeplearning.ai/courses/ai-for-everyone/",hours:"~7h",type:"course",description:"Audit-free. Aimed at business leaders. AI strategy, organisational change.",sourceDocument:v,track:"Track 3: AI strategy, governance, depth"},p("master-dl-genai-with-llms",{track:"Track 3: AI strategy, governance, depth",sourceDocument:v}),{id:"pm-ex-c3",title:"Generative AI Leader Certification path",provider:"Google",url:"https://www.cloudskillsboost.google/paths/249",hours:"~10h",type:"course",description:"Free learning path. Optional paid cert.",sourceDocument:v,track:"Track 3: AI strategy, governance, depth"},{id:"pm-ex-c4",title:"Foundation Models and Generative AI",provider:"MIT OCW",url:"https://ocw.mit.edu/courses/6-s087-foundation-models-and-generative-ai-january-iap-2024/",hours:"~6h",type:"course",description:"Non-technical MIT lecture series on foundation models.",sourceDocument:v,track:"Track 3: AI strategy, governance, depth"},{id:"pm-ex-c5",title:"CS50's Introduction to AI with Python",provider:"Harvard",url:"https://cs50.harvard.edu/ai/",hours:"~30h",type:"course",description:"Audit-free. Substantial. Take it if you want to understand the underlying mechanics.",sourceDocument:v,track:"Track 3: AI strategy, governance, depth"},p("master-nist-ai-rmf",{track:"Track 3: AI strategy, governance, depth",sourceDocument:v}),p("master-eu-ai-act",{track:"Track 3: AI strategy, governance, depth",sourceDocument:v}),{id:"pm-ex-tool-cc",title:"Claude Code — Day 90: 3+ workflows running; 1 MCP integration live; can specify a new agentic workflow end-to-end",provider:"Anthropic",url:"https://docs.claude.com",type:"practice",description:"Tool playbook: agentic CLI.",sourceDocument:v,track:"Tool playbooks"},{id:"pm-ex-grad-1",title:"Advanced or Specialist on three or four chosen areas",type:"graduation-criteria",sourceDocument:v,track:"Capability map"},{id:"pm-ex-grad-2",title:"Revisit the capability map every 90 days",type:"tracking-evidence",sourceDocument:v,track:"Capability map"}]}]},er={personaId:"architect",displayName:"Solution Architect",sourcePathwayNames:["AI Enabled - Architect"],mappingStatus:"mapped",mappingNotes:'Renamed from "AI-Enabled Architect"; underlying Architect content preserved across Associate → Solution → Principal/Enterprise.',levels:[{level:"Beginner",originalLevelNames:["Associate Architect (0–3 yrs)"],summary:"12–16 weeks of self-study, or first 1–3 years in an architecture role. Foundational architectural thinking — designing components, making reasoned technology choices, documenting decisions, and using AI to accelerate analysis.",skills:["System design: scalability, availability, CAP theorem, load balancing, caching, message queues, fault tolerance — sketch first, research second","API design: REST, OpenAPI, GraphQL basics, gRPC, versioning, rate limiting; Microservices: decomposition, bounded contexts, sync vs async, API gateways","Cloud fundamentals: core AWS/Azure/GCP services — compute, storage, networking, IAM, serverless; containers (Docker, Kubernetes basics), CI/CD pipeline design","Data architecture: relational vs NoSQL selection, CQRS, event sourcing basics; Security: OWASP Top 10, OAuth 2.0/OIDC, RBAC/ABAC, encryption, zero-trust principles","Communication: C4 model (Context/Container/Component), ADRs (Title/Status/Context/Decision/Consequences), UML sequence diagrams; four-block prompt pattern for AI-assisted design reviews"],items:[{id:"arch-jr-comp-1",title:"System design — scalability, availability, CAP theorem, load balancing, caching, message queues",type:"practice",sourceDocument:o,originalLevel:"Associate",track:"Core competencies"},{id:"arch-jr-comp-2",title:"API design — REST, OpenAPI, GraphQL, gRPC, versioning, rate limiting",type:"practice",sourceDocument:o,originalLevel:"Associate",track:"Core competencies"},{id:"arch-jr-comp-3",title:"Cloud fundamentals — AWS/Azure/GCP core services",type:"practice",sourceDocument:o,originalLevel:"Associate",track:"Core competencies"},{id:"arch-jr-comp-4",title:"Microservices — service decomposition, bounded contexts, sync vs async, API gateways",type:"practice",sourceDocument:o,originalLevel:"Associate",track:"Core competencies"},{id:"arch-jr-comp-5",title:"Data architecture — relational vs NoSQL, data modeling, CQRS, event sourcing basics",type:"practice",sourceDocument:o,originalLevel:"Associate",track:"Core competencies"},{id:"arch-jr-comp-6",title:"Security — OWASP Top 10, OAuth 2.0/OIDC, RBAC/ABAC, encryption, zero-trust",type:"practice",sourceDocument:o,originalLevel:"Associate",track:"Core competencies"},{id:"arch-jr-comp-7",title:"Containers & CI/CD — Docker, Kubernetes basics, pipeline design",type:"practice",sourceDocument:o,originalLevel:"Associate",track:"Core competencies"},{id:"arch-jr-comp-8",title:"Communication — C4 diagramming, ADRs, UML sequence diagrams",type:"practice",sourceDocument:o,originalLevel:"Associate",track:"Core competencies"},{id:"arch-jr-u1",title:"The Complete Guide to Becoming a Software Architect — Memi Lavi",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/the-complete-guide-to-becoming-a-software-architect/",type:"course",description:"Udemy Business via Deloitte SSO.",sourceDocument:o,track:"Udemy — architecture fundamentals"},{id:"arch-jr-u2",title:"AWS Certified Solutions Architect — Associate (SAA-C03) — Stephane Maarek",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/aws-certified-solutions-architect-associate-saa-c03/",type:"course",sourceDocument:o,track:"Udemy — architecture fundamentals"},{id:"arch-jr-u3",title:"AZ-305: Microsoft Azure Solutions Architect Expert — Exam Prep",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/az-305-designing-microsoft-azure-infrastructure-solutions/",type:"course",sourceDocument:o,track:"Udemy — architecture fundamentals"},{id:"arch-jr-u4",title:"Docker & Kubernetes: The Practical Guide — Maximilian Schwarzmüller",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/docker-kubernetes-the-practical-guide/",type:"course",sourceDocument:o,track:"Udemy — architecture fundamentals"},{id:"arch-jr-u5",title:"Microservices Architecture — The Complete Guide",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/microservices-architecture-the-complete-guide/",type:"course",sourceDocument:o,track:"Udemy — architecture fundamentals"},{id:"arch-jr-u6",title:"REST API Design, Development & Management",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/rest-api/",type:"course",sourceDocument:o,track:"Udemy — architecture fundamentals"},{id:"arch-jr-u7",title:"Mastering the System Design Interview",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/system-design-interview-guide/",type:"course",sourceDocument:o,track:"Udemy — architecture fundamentals"},{id:"arch-jr-f1",title:"Martin Fowler's Architecture Guide",url:"https://martinfowler.com",type:"resource",sourceDocument:o,track:"Free resources"},{id:"arch-jr-f2",title:"AWS Well-Architected Framework",url:"https://aws.amazon.com/architecture/well-architected/",type:"resource",sourceDocument:o,track:"Free resources"},{id:"arch-jr-f3",title:"Azure Architecture Center",url:"https://learn.microsoft.com/en-us/azure/architecture/",type:"resource",sourceDocument:o,track:"Free resources"},{id:"arch-jr-f4",title:"Google Cloud Architecture Framework",url:"https://cloud.google.com/architecture/framework",type:"resource",sourceDocument:o,track:"Free resources"},{id:"arch-jr-f5",title:"The C4 Model — Simon Brown",url:"https://c4model.com",type:"resource",sourceDocument:o,track:"Free resources"},{id:"arch-jr-f6",title:"System Design Primer — Donne Martin (GitHub)",url:"https://github.com/donnemartin/system-design-primer",type:"resource",sourceDocument:o,track:"Free resources"},{id:"arch-jr-f7",title:"12 Factor App",url:"https://12factor.net",type:"resource",sourceDocument:o,track:"Free resources"},{id:"arch-jr-f8",title:"roadmap.sh — Software Architect Roadmap",url:"https://roadmap.sh",type:"resource",sourceDocument:o,track:"Free resources"},{id:"arch-jr-ai-1",title:"Master the four-block prompt pattern: INSTRUCTIONS, CONTEXT, TASK, OUTPUT FORMAT",type:"practice",sourceDocument:o,track:"AI & Agentic PDLC (Associate)"},{id:"arch-jr-ai-2",title:"AI-assisted design reviews — Claude for failure mode analysis, scalability, security gaps",type:"practice",sourceDocument:o,track:"AI & Agentic PDLC (Associate)"},{id:"arch-jr-ai-3",title:"BMAD basics — the four-phase cycle: Analysis → Planning → Solutioning → Implementation",type:"practice",sourceDocument:o,track:"AI & Agentic PDLC (Associate)"},{id:"arch-jr-ai-u1",title:"Claude AI: The AI Assistant You'll Actually Use",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/claude-ai-the-ai-assistant-youll-actually-use/",type:"course",sourceDocument:o,track:"Udemy — AI fluency"},{id:"arch-jr-ai-u2",title:"GitHub Copilot — The Complete Guide",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/github-copilot-the-complete-guide/",type:"course",sourceDocument:o,track:"Udemy — AI fluency"},{id:"arch-jr-ai-u3",title:"The Complete Prompt Engineering for AI Bootcamp (2026) — Mike Taylor",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/prompt-engineering-for-ai/",type:"course",sourceDocument:o,track:"Udemy — AI fluency"},p("master-anthropic-prompt-eng-tutorial",{track:"Free AI resources",sourceDocument:o}),p("master-anthropic-prompting-best-practices",{track:"Free AI resources",sourceDocument:o}),p("master-bmad-method",{track:"Free AI resources",sourceDocument:o}),p("master-dl-genai-with-llms",{track:"Free AI resources",sourceDocument:o}),p("master-anthropic-academy",{track:"Free AI resources",sourceDocument:o}),{id:"arch-jr-cap-1",title:"Capstone — Greenfield microservice architecture",type:"capstone",description:"3–5 services, API gateway, async messaging, cloud deployment. Use BMAD Analysis to produce the PRD.",sourceDocument:o,track:"Capstone projects"},{id:"arch-jr-cap-2",title:"Capstone — ADR portfolio (5+ ADRs)",type:"capstone",description:"Real/simulated decisions. Use Claude to stress-test each.",sourceDocument:o,track:"Capstone projects"},{id:"arch-jr-cap-3",title:"Capstone — BMAD feature through full cycle",type:"capstone",description:"Analysis → Planning → Solutioning → Implementation oversight. Document the AI trail.",sourceDocument:o,track:"Capstone projects"},{id:"arch-jr-grad-1",title:"Can design a multi-service system from requirements without blindly copying references",type:"graduation-criteria",sourceDocument:o,track:"Graduation criteria"},{id:"arch-jr-grad-2",title:"Completed one cloud certification (AWS SAA, AZ-305, or GCP PCA)",type:"graduation-criteria",sourceDocument:o,track:"Graduation criteria"},{id:"arch-jr-grad-3",title:"Completed one full BMAD cycle; writes structured four-block prompts daily",type:"graduation-criteria",sourceDocument:o,track:"Graduation criteria"},{id:"arch-jr-grad-4",title:"Reviewed 20+ technical designs/PRs from an architecture perspective",type:"graduation-criteria",sourceDocument:o,track:"Graduation criteria"},p("master-aef-101",{track:"AEF Platform",sourceDocument:"AEF Platform"})]},{level:"Intermediate",originalLevelNames:["Solution Architect (3–7 yrs)"],summary:'16–24 weeks. The goal shifts from "can I design it?" to "can I design it to last, scale, and evolve — while orchestrating AI agents across the development lifecycle?" Agentic PDLC mastery is the differentiator.',skills:["Distributed systems: consensus (Raft), Saga/2PC trade-offs, eventual consistency, CRDTs; Event-driven architecture: Kafka/Pulsar, event sourcing, CQRS, choreography vs orchestration","Domain-Driven Design: bounded contexts, aggregates, domain events, anti-corruption layers, context mapping; Platform architecture — internal developer platforms, golden paths","Cloud-native depth: service mesh, serverless at scale, multi-region design, sidecar patterns; Performance: load testing, capacity planning, SLOs/SLIs, observability (OpenTelemetry)","BMAD mastery: all personas (Analyst, PM, Architect, Developer, QA); full PRD → epic → ADRs → story-by-story agent execution; Party Mode for architecture workshops","Claude Code governance: CLAUDE.md with architectural constraints; plan mode before every non-trivial change; treat agent output like a junior dev PR; MCP integration to Jira, GitHub, Confluence, SonarQube"],items:[{id:"arch-sr-comp-1",title:"Distributed systems — consensus (Raft), Saga/2PC, eventual consistency, CRDTs",type:"practice",sourceDocument:o,originalLevel:"Solution",track:"Core competencies"},{id:"arch-sr-comp-2",title:"Event-driven architecture — event sourcing, CQRS, Kafka/Pulsar, choreography vs orchestration",type:"practice",sourceDocument:o,originalLevel:"Solution",track:"Core competencies"},{id:"arch-sr-comp-3",title:"Domain-Driven Design — bounded contexts, aggregates, domain events, anti-corruption layers",type:"practice",sourceDocument:o,originalLevel:"Solution",track:"Core competencies"},{id:"arch-sr-comp-4",title:"Cloud-native depth — service mesh, serverless at scale, multi-region design, sidecar patterns",type:"practice",sourceDocument:o,originalLevel:"Solution",track:"Core competencies"},{id:"arch-sr-comp-5",title:"Platform architecture — internal developer platforms, golden paths, DevEx-as-product",type:"practice",sourceDocument:o,originalLevel:"Solution",track:"Core competencies"},{id:"arch-sr-comp-6",title:"Performance engineering — load testing, capacity planning, SLOs/SLIs, observability",type:"practice",sourceDocument:o,originalLevel:"Solution",track:"Core competencies"},{id:"arch-sr-comp-7",title:"Data at scale — data mesh, lakehouse patterns, streaming vs batch, schema evolution",type:"practice",sourceDocument:o,originalLevel:"Solution",track:"Core competencies"},{id:"arch-sr-comp-8",title:"Security depth — threat modeling (STRIDE/PASTA), zero-trust, supply chain, compliance-as-code",type:"practice",sourceDocument:o,originalLevel:"Solution",track:"Core competencies"},{id:"arch-sr-comp-9",title:"Integration — enterprise integration patterns, API management, legacy modernization (strangler fig)",type:"practice",sourceDocument:o,originalLevel:"Solution",track:"Core competencies"},{id:"arch-sr-u1",title:"AWS Certified Solutions Architect — Professional (SAP-C02) — Stephane Maarek",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/aws-certified-solutions-architect-professional/",type:"course",sourceDocument:o,track:"Udemy — architecture depth"},{id:"arch-sr-u2",title:"Domain-Driven Design & Microservices",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/domain-driven-design-and-microservices/",type:"course",sourceDocument:o,track:"Udemy — architecture depth"},{id:"arch-sr-u3",title:"Apache Kafka Series — Complete Guide — Stephane Maarek",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/apache-kafka/",type:"course",sourceDocument:o,track:"Udemy — architecture depth"},{id:"arch-sr-u4",title:"Microservices: Clean Architecture, DDD, SAGA, Outbox & Kafka",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/microservices-clean-architecture-ddd-saga-outbox-kafka-kubernetes/",type:"course",sourceDocument:o,track:"Udemy — architecture depth"},{id:"arch-sr-u5",title:"Certified Kubernetes Administrator (CKA) — Mumshad Mannambeth",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/certified-kubernetes-administrator-with-practice-tests/",type:"course",sourceDocument:o,track:"Udemy — architecture depth"},{id:"arch-sr-u6",title:"Software Architecture & Design of Modern Large Scale Systems — Michael Pogrebinsky",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/software-architecture-design-of-modern-large-scale-systems/",type:"course",sourceDocument:o,track:"Udemy — architecture depth"},{id:"arch-sr-u7",title:"The Complete Cyber Security Course: Network Security — Nathan House",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/the-complete-cyber-security-course-network-security/",type:"course",sourceDocument:o,track:"Udemy — architecture depth"},{id:"arch-sr-u8",title:"Mastering the System Design Interview — Frank Kane",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/system-design-interview-guide/",type:"course",sourceDocument:o,track:"Udemy — architecture depth"},{id:"arch-sr-b1",title:"Designing Data-Intensive Applications — Martin Kleppmann (O'Reilly)",url:"https://dataintensive.net/",type:"resource",sourceDocument:o,track:"Books & references"},{id:"arch-sr-b2",title:"Software Architecture: The Hard Parts — Ford & Richards (O'Reilly)",url:"https://www.oreilly.com/library/view/software-architecture-the/9781492086888/",type:"resource",sourceDocument:o,track:"Books & references"},{id:"arch-sr-b3",title:"Building Microservices — Sam Newman (O'Reilly)",url:"https://samnewman.io/books/building_microservices_2nd_edition/",type:"resource",sourceDocument:o,track:"Books & references"},{id:"arch-sr-bmad-1",title:"BMAD mastery — Analyst, PM, Architect, Developer, QA/TEA personas",type:"practice",sourceDocument:o,track:"BMAD mastery"},{id:"arch-sr-bmad-2",title:"Run full cycles: PRD → epic/story breakdown → ADRs & API contracts → story-by-story agent execution",type:"practice",sourceDocument:o,track:"BMAD mastery"},{id:"arch-sr-bmad-3",title:"Party Mode — multi-persona sessions for architecture workshops",type:"practice",sourceDocument:o,track:"BMAD mastery"},{id:"arch-sr-bmad-4",title:"Customize personas to match team conventions (npx bmad-method install)",type:"practice",sourceDocument:o,track:"BMAD mastery"},{id:"arch-sr-cc-1",title:"Define CLAUDE.md with architectural constraints",type:"practice",description:"Module boundaries, dependencies, naming, test requirements, API compliance.",sourceDocument:o,track:"Claude Code & implementation oversight"},{id:"arch-sr-cc-2",title:"Use plan mode before every non-trivial change",type:"practice",sourceDocument:o,track:"Claude Code & implementation oversight"},{id:"arch-sr-mcp-1",title:"Connect agents via MCP to Jira, GitHub, Confluence, SonarQube, cloud APIs",type:"practice",sourceDocument:o,track:"Multi-agent workflows & MCP"},{id:"arch-sr-mcp-2",title:"Build custom MCP servers for internal systems (architecture registries, API catalogs)",type:"practice",sourceDocument:o,track:"Multi-agent workflows & MCP"},{id:"arch-sr-au1",title:"AI Engineer Agentic Track: The Complete Agent & MCP Course — Ed Donner",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/the-complete-agentic-ai-engineering-course/",type:"course",sourceDocument:o,track:"Udemy — AI & Agentic PDLC"},{id:"arch-sr-au2",title:"AI Engineer Core Track: LLM Engineering, RAG, QLoRA, Agents — Ed Donner",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/llm-engineering-master-ai-and-large-language-models/",type:"course",sourceDocument:o,track:"Udemy — AI & Agentic PDLC"},{id:"arch-sr-au3",title:"Full Stack Generative and Agentic AI with Python — Hitesh Choudhary",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/full-stack-ai-with-python/",type:"course",sourceDocument:o,track:"Udemy — AI & Agentic PDLC"},{id:"arch-sr-au4",title:"LangChain — Agentic AI Engineering with LangChain & LangGraph — Eden Marco",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/langchain/",type:"course",sourceDocument:o,track:"Udemy — AI & Agentic PDLC"},p("master-anthropic-building-effective-agents",{track:"Free AI resources",sourceDocument:o}),p("master-claude-code-docs",{track:"Free AI resources",sourceDocument:o}),p("master-mcp-spec",{track:"Free AI resources",sourceDocument:o}),{id:"arch-sr-af4",title:"Anthropic Cookbook — production integration patterns",provider:"Anthropic",url:"https://github.com/anthropics/anthropic-cookbook",type:"resource",sourceDocument:o,track:"Free AI resources"},{id:"arch-sr-cap",title:"Capstone — Production system redesign using full BMAD lifecycle with multi-agent orchestration",type:"capstone",description:"PRD → ADRs & C4 diagrams → multi-agent workflow with quality gates and MCP integrations → Claude Code implementation oversight → full artifact trail.",sourceDocument:o,track:"Capstone"},{id:"arch-sr-grad-1",title:"Shipped one production system using full BMAD lifecycle with multi-agent orchestration",type:"graduation-criteria",sourceDocument:o,track:"Graduation criteria"},{id:"arch-sr-grad-2",title:"Maintains CLAUDE.md files that measurably improve agent-generated output",type:"graduation-criteria",sourceDocument:o,track:"Graduation criteria"},{id:"arch-sr-grad-3",title:"Mentored 2+ associates; built/configured at least one MCP integration",type:"graduation-criteria",sourceDocument:o,track:"Graduation criteria"},p("master-aef-201",{track:"AEF Platform",sourceDocument:"AEF Platform"})]},{level:"Advanced",originalLevelNames:["Principal / Enterprise Architect (7+ yrs)"],summary:"Ongoing. Shapes how organizations build — technical strategy, governance, organizational influence, and AI-leverage at enterprise scale.",skills:["Enterprise architecture: TOGAF (pragmatically applied), governance models, technology roadmapping; Multi-system integration: API management at scale, B2B patterns, portfolio modernization","Architecture governance: review boards, fitness functions at scale, technical debt quantification, compliance-as-code; Tech strategy: tech radar, vendor evaluation, build vs buy","Agentic PDLC governance: define AI-augmented phases, human decision gates, quality thresholds; agent trust model — auto-merge / expedited review / full review / human-only by risk class","Enterprise AI platform design: Claude + MCP + BMAD + Skills as cohesive developer experience; AI safety architecture — prompt injection prevention, output validation, audit logging","Organizational architecture: Conway's Law, team topologies; AI measurement — velocity, quality, developer satisfaction, cost-per-feature; author org-wide Claude Skills (SKILL.md)"],items:[{id:"arch-ex-comp-1",title:"Enterprise architecture — TOGAF (pragmatically applied), governance models, technology roadmapping",type:"practice",sourceDocument:o,originalLevel:"Principal / Enterprise",track:"Core competencies"},{id:"arch-ex-comp-2",title:"Multi-system integration — API management at scale, B2B patterns, portfolio modernization",type:"practice",sourceDocument:o,originalLevel:"Principal / Enterprise",track:"Core competencies"},{id:"arch-ex-comp-3",title:"Architecture governance — review boards, fitness functions at scale, tech debt quantification",type:"practice",sourceDocument:o,originalLevel:"Principal / Enterprise",track:"Core competencies"},{id:"arch-ex-comp-4",title:"Technology strategy — build vs buy, vendor evaluation, tech radar management",type:"practice",sourceDocument:o,originalLevel:"Principal / Enterprise",track:"Core competencies"},{id:"arch-ex-comp-5",title:"Organizational architecture — Conway's Law, team topologies",type:"practice",sourceDocument:o,originalLevel:"Principal / Enterprise",track:"Core competencies"},{id:"arch-ex-comp-6",title:"Data & AI platform strategy at enterprise scale",type:"practice",sourceDocument:o,originalLevel:"Principal / Enterprise",track:"Core competencies"},{id:"arch-ex-comp-7",title:"Cloud & FinOps — multi-cloud governance, migration at portfolio scale",type:"practice",sourceDocument:o,originalLevel:"Principal / Enterprise",track:"Core competencies"},{id:"arch-ex-comp-8",title:"Resilience — chaos engineering, DR architecture, BCP, blast radius minimization",type:"practice",sourceDocument:o,originalLevel:"Principal / Enterprise",track:"Core competencies"},{id:"arch-ex-u1",title:"TOGAF Standard 10.0 — Level 1 Enterprise Architect Course — Scott Duffy",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/togaf-certification-training/",type:"course",sourceDocument:o,track:"Udemy — enterprise architecture"},{id:"arch-ex-u2",title:"Enterprise Architecture by Example — Chris B Behrens",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/enterprise-architecture-by-example/",type:"course",sourceDocument:o,track:"Udemy — enterprise architecture"},{id:"arch-ex-u3",title:"Microsoft Azure: Cloud Architecture Case Studies — Memi Lavi",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/microsoft-azure-cloud-architecture-case-studies/",type:"course",sourceDocument:o,track:"Udemy — enterprise architecture"},{id:"arch-ex-u4",title:"Organizational Theory, Design and Change — Robert Barcik",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/organizational-design/",type:"course",sourceDocument:o,track:"Udemy — enterprise architecture"},{id:"arch-ex-u5",title:"Ultimate AWS FinOps Cloud Cost Management Masterclass — Justin Andre",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/ultimate-aws-finops-cloud-cost-management-masterclass/",type:"course",sourceDocument:o,track:"Udemy — enterprise architecture"},{id:"arch-ex-u6",title:"From Engineer to Technical Manager: A Survival Guide — Frank Kane",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/from-engineer-to-technical-manager-a-survival-guide/",type:"course",sourceDocument:o,track:"Udemy — enterprise architecture"},{id:"arch-ex-b1",title:"Fundamentals of Software Architecture — Richards & Ford (O'Reilly)",url:"https://fundamentalsofsoftwarearchitecture.com/",type:"resource",sourceDocument:o,track:"Books & references"},{id:"arch-ex-b2",title:"Team Topologies — Skelton & Pais",url:"https://teamtopologies.com/",type:"resource",sourceDocument:o,track:"Books & references"},{id:"arch-ex-b3",title:"Building Evolutionary Architectures — Ford, Parsons, Kua (O'Reilly)",url:"https://www.thoughtworks.com/insights/blog/microservices/building-evolutionary-architectures",type:"resource",sourceDocument:o,track:"Books & references"},{id:"arch-ex-b4",title:"The Software Architect Elevator — Gregor Hohpe",url:"https://architectelevator.com/",type:"resource",sourceDocument:o,track:"Books & references"},{id:"arch-ex-b5",title:"ThoughtWorks Technology Radar",url:"https://www.thoughtworks.com/radar",type:"resource",sourceDocument:o,track:"Books & references"},{id:"arch-ex-b6",title:"CNCF End User Technology Radar",url:"https://radar.cncf.io",type:"resource",sourceDocument:o,track:"Books & references"},{id:"arch-ex-gov-1",title:"Define the org's Agentic PDLC framework — AI-augmented phases, human decision gates, quality thresholds",type:"practice",sourceDocument:o,track:"Agentic PDLC governance & platform"},{id:"arch-ex-gov-2",title:"Agent trust model — classify changes by risk (auto-merge / expedited / full / human-only)",type:"practice",sourceDocument:o,track:"Agentic PDLC governance & platform"},{id:"arch-ex-gov-3",title:"Design the AI development platform (Claude + MCP + BMAD + Skills as cohesive DevEx)",type:"practice",sourceDocument:o,track:"Agentic PDLC governance & platform"},{id:"arch-ex-gov-4",title:"AI safety architecture — prompt injection prevention, output validation, sensitive data filtering",type:"practice",sourceDocument:o,track:"Agentic PDLC governance & platform"},{id:"arch-ex-skills-1",title:"Author org-wide Claude Skills (SKILL.md): architecture patterns, security, API standards",type:"practice",sourceDocument:o,track:"BMAD & Skills at scale"},{id:"arch-ex-skills-2",title:"BMad Builder (BMB) — domain-specific agent personas for org's tech stack",type:"practice",sourceDocument:o,track:"BMAD & Skills at scale"},{id:"arch-ex-skills-3",title:"Test Architect (TEA) — risk-based test strategies executed by agents",type:"practice",sourceDocument:o,track:"BMAD & Skills at scale"},{id:"arch-ex-au1",title:"AI Leader: Generative AI & Agentic AI for Leaders & Founders — Ed Donner",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/executive-briefing-generative-ai-and-large-language-models-llm/",type:"course",sourceDocument:o,track:"Udemy — AI strategy"},{id:"arch-ex-au2",title:"The AI Ethics Course 2026: Work with AI Responsibly — 365 Careers",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/the-ai-ethics-course-2025-work-with-ai-responsibly/",type:"course",sourceDocument:o,track:"Udemy — AI strategy"},{id:"arch-ex-au3",title:"Complete MLOps Bootcamp With 10+ End To End ML Projects — Krish Naik",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/complete-mlops-bootcamp-with-10-end-to-end-ml-projects/",type:"course",sourceDocument:o,track:"Udemy — AI strategy"},{id:"arch-ex-af1",title:"Anthropic — Enterprise Deployment Guides",provider:"Anthropic",url:"https://docs.anthropic.com",type:"resource",sourceDocument:o,track:"Free AI resources"},p("master-bmad-method",{track:"Free AI resources",sourceDocument:o}),p("master-mcp-spec",{track:"Free AI resources",sourceDocument:o}),p("master-nist-ai-rmf",{track:"Free AI resources",sourceDocument:o}),{id:"arch-ex-cap-1",title:"Capstone — Org-wide Agentic PDLC program",type:"capstone",description:"Define framework, pilot with 2–3 teams, measure outcomes, scale, publish case study.",sourceDocument:o,track:"Capstone"},{id:"arch-ex-cap-2",title:"Capstone — Enterprise architecture strategy",type:"capstone",description:"Roadmap, target state, migration plan, governance model, AI integration, investment case.",sourceDocument:o,track:"Capstone"},{id:"arch-ex-cap-3",title:"Capstone — Enterprise AI development platform",type:"capstone",description:"Claude + BMAD + MCP + Skills with governance, metrics, and self-service onboarding.",sourceDocument:o,track:"Capstone"}]}]},tr={personaId:"designer",displayName:"UX Designer",sourcePathwayNames:["AI Enabled - UI/UX Designer"],mappingStatus:"mapped",mappingNotes:'Renamed from "AI-Enabled UX Designer"; underlying UX Designer content preserved across Junior → Mid → Senior.',levels:[{level:"Beginner",originalLevelNames:["Junior UX Designer (0–2 yrs)"],summary:"Roughly 12–16 weeks of focused self-study or first 18–24 months on the job. Foundational fluency: apply the design process end to end on a small feature with supervision, while learning to use AI as a thoughtful pair.",skills:["Design fundamentals: Design Thinking, Double Diamond, Don Norman's principles; user research basics (interviews, personas, journey mapping, heuristic eval — Nielsen 10)","Figma essentials: frames, components, auto layout, basic prototyping, libraries; accessibility (WCAG 2.2 awareness, contrast 4.5:1, touch targets 44px)","UI fundamentals: HTML5, CSS (Flexbox, Grid, Tailwind), responsive design; JavaScript ES6+; React basics — components, hooks (useState, useEffect, useRef), conditional rendering, React Router","Git: branching, PRs, rebasing, conflict resolution — 30+ reviewed PRs; build tools (Vite); Browser DevTools","Claude 4-block prompts for ideation, synthesis, microcopy, and coding — verify every output against the source"],items:[{id:"ux-jr-craft-1",title:"Design thinking process — empathize, define, ideate, prototype, test (Double Diamond)",type:"practice",sourceDocument:s,originalLevel:"Junior",track:"Design craft"},{id:"ux-jr-craft-2",title:"Don Norman's principles — affordances, signifiers, feedback, mapping, constraints",type:"practice",sourceDocument:s,originalLevel:"Junior",track:"Design craft"},{id:"ux-jr-craft-3",title:"User research basics — empathy interviews, personas, journey mapping, heuristic eval",type:"practice",sourceDocument:s,originalLevel:"Junior",track:"Design craft"},{id:"ux-jr-craft-4",title:"Information architecture basics — site maps, user flows, card sorting, taxonomy",type:"practice",sourceDocument:s,originalLevel:"Junior",track:"Design craft"},{id:"ux-jr-craft-5",title:"Wireframing — low-fi sketches and digital wireframes",type:"practice",sourceDocument:s,originalLevel:"Junior",track:"Design craft"},{id:"ux-jr-craft-6",title:"Visual design basics — typography, color, spacing, grid, gestalt",type:"practice",sourceDocument:s,originalLevel:"Junior",track:"Design craft"},{id:"ux-jr-craft-7",title:"Figma fundamentals — frames, components, auto layout, prototyping, libraries",type:"practice",sourceDocument:s,originalLevel:"Junior",track:"Design craft"},{id:"ux-jr-craft-8",title:"Accessibility basics — WCAG 2.2, contrast, touch targets, keyboard nav",type:"practice",sourceDocument:s,originalLevel:"Junior",track:"Design craft"},{id:"ux-jr-u1",title:"Figma UI UX Design Essentials — Daniel Walter Scott",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/figma-ux-design-advanced-tutorial/",hours:"12+ h",type:"course",description:"Udemy Business via Deloitte SSO. The single best Figma starter.",sourceDocument:s,track:"Udemy — design fundamentals"},{id:"ux-jr-u2",title:"Complete UI/UX Design Course 2026: Figma + AI + Real Project",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/complete-uiux-design-course-figma-ai-real-project/",type:"course",description:"Project-based, 7-day structured plan with AI tools integrated.",sourceDocument:s,track:"Udemy — design fundamentals"},{id:"ux-jr-u3",title:"Complete Figma Megacourse: UI/UX Design Beginner to Expert",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/beginners-guide-to-prototyping-and-designing-using-figma/",type:"course",sourceDocument:s,track:"Udemy — design fundamentals"},{id:"ux-jr-u4",title:"Figma for User Interface and User Experience UI/UX Design",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/figma-ux-ui-design-user-experience-tutorial-course/",type:"course",sourceDocument:s,track:"Udemy — design fundamentals"},{id:"ux-jr-u5",title:"Browse Udemy's UX Design topic catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/user-experience-design/",type:"resource",description:"Browse topic — multiple high-rated UX courses.",sourceDocument:s,track:"Udemy — design fundamentals"},{id:"ux-jr-u6",title:"Browse Udemy's Design Thinking catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/design-thinking/",type:"resource",description:"Browse topic — Design Thinking from IDEO-trained instructors.",sourceDocument:s,track:"Udemy — design fundamentals"},{id:"ux-jr-f1",title:"Google UX Design Professional Certificate",provider:"Coursera",url:"https://www.coursera.org/professional-certificates/google-ux-design",type:"course",description:"Free to audit, paid for certificate. 7-course Google specialization.",sourceDocument:s,track:"Free courses"},{id:"ux-jr-f2",title:"Nielsen Norman Group — articles and free courses",provider:"NN/g",url:"https://www.nngroup.com",type:"resource",description:"Free. The canonical reference for usability and UX research.",sourceDocument:s,track:"Free courses"},{id:"ux-jr-f3",title:"Interaction Design Foundation — free open-access content",provider:"IxDF",url:"https://www.interaction-design.org",type:"resource",sourceDocument:s,track:"Free courses"},{id:"ux-jr-f4",title:"Figma Learn — official Figma Academy",provider:"Figma",url:"https://figma.com",type:"resource",description:"Free.",sourceDocument:s,track:"Free courses"},{id:"ux-jr-f5",title:'"The Design of Everyday Things" — Don Norman',url:"https://www.nngroup.com/books/design-everyday-things-revised/",type:"resource",description:"Paid book. The canonical text for design thinking.",sourceDocument:s,track:"Free courses"},{id:"ux-jr-f6",title:"Laws of UX",url:"https://lawsofux.com",type:"resource",description:"Free. 20+ visual cards explaining psychological principles.",sourceDocument:s,track:"Free courses"},{id:"ux-jr-f7",title:"Refactoring UI — free articles",url:"https://www.refactoringui.com",type:"resource",sourceDocument:s,track:"Free courses"},{id:"ux-jr-r1",title:"Fast-start Usability Testing and UX Research",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/master-usability-testing-and-ux-research/",type:"course",sourceDocument:s,track:"Udemy — research"},{id:"ux-jr-r2",title:"UX Fundamentals: User Testing — Michał Mazur",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/ux-fundamentals-user-testing/",type:"course",sourceDocument:s,track:"Udemy — research"},{id:"ux-jr-r3",title:"Run your own Research and Usability Testing — Eva Jobard",url:"https://www.udemy.com/course/run-your-own-research/",type:"course",description:"Free. 60-minute starter.",sourceDocument:s,track:"Udemy — research"},{id:"ux-jr-r4",title:"NN/g — Usability 101 article",provider:"NN/g",url:"https://www.nngroup.com/articles/usability-101-introduction-to-usability/",type:"resource",description:"Free. Jakob Nielsen's foundational explainer.",sourceDocument:s,track:"Free research resources"},{id:"ux-jr-r5",title:"NN/g — 10 Usability Heuristics",provider:"NN/g",url:"https://www.nngroup.com/articles/ten-usability-heuristics/",type:"resource",description:"Free. The most-cited heuristics in the field.",sourceDocument:s,track:"Free research resources"},{id:"ux-jr-r6",title:"Lyssna — Free UX research blog and templates",provider:"Lyssna",url:"https://www.lyssna.com",type:"resource",sourceDocument:s,track:"Free research resources"},{id:"ux-jr-ai-1",title:"The four-block prompt pattern: INSTRUCTIONS, CONTEXT, TASK, OUTPUT FORMAT",type:"practice",sourceDocument:s,track:"AI fluency"},{id:"ux-jr-ai-2",title:"Claude Projects — one per active design project",type:"practice",sourceDocument:s,track:"AI fluency"},{id:"ux-jr-ai-3",title:"Claude Artifacts for low-fidelity exploration",type:"practice",sourceDocument:s,track:"AI fluency"},{id:"ux-jr-ai-4",title:"AI for research synthesis — always verify each theme against the source",type:"practice",sourceDocument:s,track:"AI fluency"},{id:"ux-jr-aiu1",title:"Browse Udemy's Prompt Engineering catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/prompt-engineering/",type:"resource",description:"Browse topic — pick a 2026 course covering Claude.",sourceDocument:s,track:"Udemy — AI fluency"},{id:"ux-jr-aiu2",title:"Claude Mastery — Learn Prompt Engineering with Claude AI",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/claude-code-cowork-course/",type:"course",description:"No coding required — perfect for designers.",sourceDocument:s,track:"Udemy — AI fluency"},{id:"ux-jr-aiu3",title:"AI for Designers — survey the catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/ai-design/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — AI fluency"},p("master-anthropic-prompt-eng-tutorial",{track:"Free AI resources",sourceDocument:s}),p("master-anthropic-academy",{track:"Free AI resources",sourceDocument:s}),p("master-anthropic-prompting-best-practices",{track:"Free AI resources",sourceDocument:s}),{id:"ux-jr-cap-1",title:"Capstone — Redesign a real product feature",type:"capstone",description:"Heuristic eval, 5-user usability test, redesign, A/B comparison.",sourceDocument:s,track:"Capstones"},{id:"ux-jr-cap-2",title:"Capstone — Design a small mobile app from scratch",type:"capstone",description:"8–12 screens, full user flow, design system tokens, prototype.",sourceDocument:s,track:"Capstones"},{id:"ux-jr-cap-3",title:"Capstone — Research-only project",type:"capstone",description:"5 user interviews, synthesis, recommendations. Deliverable is the insight.",sourceDocument:s,track:"Capstones"},{id:"ux-jr-grad-1",title:"Can take a small feature from research to prototype with light supervision",type:"graduation-criteria",sourceDocument:s,track:"Graduation criteria"},{id:"ux-jr-grad-2",title:"Portfolio with at least three deeply documented case studies",type:"graduation-criteria",sourceDocument:s,track:"Graduation criteria"},{id:"ux-jr-grad-3",title:"Uses Claude daily for ideation and synthesis; writes structured prompts using the four-block pattern",type:"graduation-criteria",sourceDocument:s,track:"Graduation criteria"},{id:"ux-jr-grad-4",title:"Received and incorporated structured critique on at least 20 pieces of work",type:"graduation-criteria",sourceDocument:s,track:"Graduation criteria"},p("master-aef-101",{track:"AEF Platform",sourceDocument:"AEF Platform"})]},{level:"Intermediate",originalLevelNames:["Mid-level UX Designer (2–5 yrs)"],summary:"16–24 weeks of structured upskilling. Autonomy — make design decisions with good foundation. Generative prototyping, AI-paired research synthesis, and Figma MCP enter the daily toolkit.",skills:["Advanced Figma: variables, branching, design tokens, Dev Mode handoff; mixed-methods research (JTBD, synthesis, NPS/SUS/CSAT; moderated and unmoderated testing)","Generative prototyping: Claude Artifacts for working HTML/CSS; UX Pilot for AI wireframes in Figma; Figma MCP — turn PRDs and PDFs into editable FigJam diagrams and user-flow maps","TypeScript: types, interfaces, generics, utility types, narrowing — non-negotiable in 2026; React deep dive (reconciliation, rendering, useMemo/useCallback, custom hooks, error boundaries)","Next.js App Router: server components, server actions, ISR/SSG/SSR, route handlers, caching; testing — Vitest, React Testing Library, Playwright; WCAG 2.2 AA with axe-core in CI","BMAD structured delivery for product features: Analyst PRD → Architect ADR → Developer stories with Claude Code → QA tests"],items:[{id:"ux-sr-craft-1",title:"Advanced Figma — auto layout mastery, components with variants, design tokens via Variables",type:"practice",sourceDocument:s,originalLevel:"Mid",track:"Design craft"},{id:"ux-sr-craft-2",title:"Prototyping — high-fi interactive prototypes, smart animate, conditional logic",type:"practice",sourceDocument:s,originalLevel:"Mid",track:"Design craft"},{id:"ux-sr-craft-3",title:"Design systems — token architecture, component composition, governance",type:"practice",sourceDocument:s,originalLevel:"Mid",track:"Design craft"},{id:"ux-sr-craft-4",title:"Interaction design — micro-interactions, motion design, state machines",type:"practice",sourceDocument:s,originalLevel:"Mid",track:"Design craft"},{id:"ux-sr-craft-5",title:"UX writing — voice and tone, microcopy, error messages, content hierarchy",type:"practice",sourceDocument:s,originalLevel:"Mid",track:"Design craft"},{id:"ux-sr-craft-6",title:"Accessibility intermediate — WCAG 2.2 AA conformance, accessible patterns",type:"practice",sourceDocument:s,originalLevel:"Mid",track:"Design craft"},{id:"ux-sr-craft-7",title:"Cross-platform — responsive web, iOS HIG, Android Material 3",type:"practice",sourceDocument:s,originalLevel:"Mid",track:"Design craft"},{id:"ux-sr-u1",title:"Figma UI UX Design Advanced — Daniel Walter Scott",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/figma-ui-ux-design-advanced/",hours:"9+ h",type:"course",sourceDocument:s,track:"Udemy — Figma & advanced craft"},{id:"ux-sr-u2",title:"Figma UI/UX Complete Bootcamp: Design 10 Job-Ready Projects",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/master-figma-uiux-prototyping-basic-to-advanced-level/",type:"course",sourceDocument:s,track:"Udemy — Figma & advanced craft"},{id:"ux-sr-u3",title:"UI/UX Web Design in Figma 2026 | AI & Big Projects",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/web-design-in-figma-from-zero-complete-course/",type:"course",sourceDocument:s,track:"Udemy — Figma & advanced craft"},{id:"ux-sr-u4",title:"Browse Udemy's Design Systems catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/design-systems/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — Figma & advanced craft"},{id:"ux-sr-u5",title:"Browse Udemy's Prototyping catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/prototyping/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — Figma & advanced craft"},{id:"ux-sr-r1",title:"Mastering UX Research: From Fundamentals to UXR Job Skills",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/ux-research-bootcamp-from-zero-experience-to-job-ready/",type:"course",description:"End-to-end UX research bootcamp.",sourceDocument:s,track:"Udemy — research, writing, accessibility"},{id:"ux-sr-r2",title:"Usability Testing — Michał Mazur",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/master-usability-testing-and-ux-research/",type:"course",sourceDocument:s,track:"Udemy — research, writing, accessibility"},{id:"ux-sr-r3",title:"How To Design for Accessibility: for UX Designers (WCAG 2.2)",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/the-ux-designers-accessibility-guide/",type:"course",description:"Practical, designer-focused.",sourceDocument:s,track:"Udemy — research, writing, accessibility"},{id:"ux-sr-r4",title:"Web Accessibility: Practical Guide",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/introduction-to-web-accessibility-wcag21/",type:"course",sourceDocument:s,track:"Udemy — research, writing, accessibility"},{id:"ux-sr-r5",title:"UX Writing: Microcopy, User Research, Accessibility & More",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/ux-writing-the-art-of-user-centered-copy/",type:"course",sourceDocument:s,track:"Udemy — research, writing, accessibility"},{id:"ux-sr-r6",title:"Browse Udemy's Web Accessibility topic",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/web-accessibility/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — research, writing, accessibility"},{id:"ux-sr-r7",title:"Browse Udemy's Information Architecture catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/information-architecture/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — research, writing, accessibility"},{id:"ux-sr-f1",title:"NN/g UX Conference videos and articles",provider:"NN/g",url:"https://www.nngroup.com",type:"resource",description:"Free articles. The canonical reference.",sourceDocument:s,track:"Free resources"},{id:"ux-sr-f2",title:"Smashing Magazine — UX articles",url:"https://www.smashingmagazine.com/category/ux-design/",type:"resource",description:"Free.",sourceDocument:s,track:"Free resources"},{id:"ux-sr-f3",title:"Smart Interface Design Patterns (Vitaly Friedman)",url:"https://smart-interface-design-patterns.com",type:"resource",sourceDocument:s,track:"Free resources"},{id:"ux-sr-f4",title:"Material Design 3 documentation",provider:"Google",url:"https://m3.material.io",type:"resource",description:"Free.",sourceDocument:s,track:"Free resources"},{id:"ux-sr-f5",title:"Apple Human Interface Guidelines",provider:"Apple",url:"https://developer.apple.com/design/human-interface-guidelines/",type:"resource",description:"Free. Masterclass in design writing.",sourceDocument:s,track:"Free resources"},{id:"ux-sr-f6",title:"WCAG 2.2 Quick Reference (W3C)",provider:"W3C",url:"https://www.w3.org/WAI/WCAG22/quickref/",type:"resource",description:"Free. The canonical accessibility reference.",sourceDocument:s,track:"Free resources"},{id:"ux-sr-ai-1",title:"Generative prototyping — Claude Artifacts and Claude Design",type:"practice",sourceDocument:s,track:"AI fluency (Mid)"},{id:"ux-sr-ai-2",title:"Figma MCP app in Claude — turn conversations into editable FigJam and Figma files",type:"practice",sourceDocument:s,track:"AI fluency (Mid)"},{id:"ux-sr-ai-3",title:"UX Pilot — AI-generated wireframes inside Figma",type:"practice",sourceDocument:s,track:"AI fluency (Mid)"},{id:"ux-sr-ai-4",title:"Contract-style prompts: Role, Success Criteria, Constraints, Output Format",type:"practice",sourceDocument:s,track:"AI fluency (Mid)"},{id:"ux-sr-aiu1",title:"Browse Udemy's Generative AI for designers",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/generative-ai/",type:"resource",description:"Browse topic — look for 2025/2026 updates covering Claude and Figma Make.",sourceDocument:s,track:"Udemy — AI fluency"},{id:"ux-sr-aiu2",title:"Browse Udemy's AI Design topic",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/ai-design/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — AI fluency"},{id:"ux-sr-aiu3",title:"ChatGPT, Claude, Cursor & GitHub Copilot — AI Coding Bootcamp catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/ai-coding/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — AI fluency"},{id:"ux-sr-aif1",title:"Anthropic — Prompting Best Practices",url:"https://docs.claude.com",type:"resource",sourceDocument:s,track:"Free AI resources"},{id:"ux-sr-aif2",title:"Figma blog — AI tools for UX designers",url:"https://www.figma.com/blog/category/design-ai/",type:"resource",sourceDocument:s,track:"Free AI resources"},{id:"ux-sr-aif3",title:"NN/g — AI in UX articles",provider:"NN/g",url:"https://www.nngroup.com/topic/ai/",type:"resource",sourceDocument:s,track:"Free AI resources"},{id:"ux-sr-cap",title:"Capstone — End-to-end product feature: research → design → ship → measurement",type:"capstone",description:"Frame, primary research, AI-assisted synthesis, validate with users, ship, measure, write post-launch reflection.",sourceDocument:s,track:"Capstone"},{id:"ux-sr-grad-1",title:"Has shipped at least one significant feature owned end to end",type:"graduation-criteria",sourceDocument:s,track:"Graduation criteria"},{id:"ux-sr-grad-2",title:"Can lead a design critique competently and constructively",type:"graduation-criteria",sourceDocument:s,track:"Graduation criteria"},{id:"ux-sr-grad-3",title:"Can run AI-assisted research synthesis and explain when AI is reliable vs hallucinating",type:"graduation-criteria",sourceDocument:s,track:"Graduation criteria"},p("master-aef-201",{track:"AEF Platform",sourceDocument:"AEF Platform"})]},{level:"Advanced",originalLevelNames:["Senior UX Designer (5+ yrs)"],summary:"Ongoing. Shapes how design is practiced. Equal parts craft, strategy, mentorship, and AI-leverage stewardship.",skills:["Design strategy: connecting design to business outcomes; influencing roadmap; research strategy (ResearchOps, longitudinal studies, democratising research)","Design system ownership: token architecture, theming, contribution models, governance — across Figma libraries and code-side primitives","Designing AI experiences: generative UI, conversational UX, AI transparency patterns; frontend architecture (rendering strategies, framework evaluation, designing for change)","BMAD as default practice; Claude Skills authoring for team-level AI leverage; MCP integrations (Figma, Sentry, GitHub, Linear, internal API docs)","AI workflow governance: team usage policy, tool evaluation, data handling — applied across both design and code workflows"],items:[{id:"ux-ex-craft-1",title:"Design strategy — connecting design decisions to business outcomes",type:"practice",sourceDocument:s,originalLevel:"Senior",track:"Design craft"},{id:"ux-ex-craft-2",title:"Design system ownership — tokens, theming, contribution models",type:"practice",sourceDocument:s,originalLevel:"Senior",track:"Design craft"},{id:"ux-ex-craft-3",title:"Accessibility leadership — WCAG 2.2 AA baseline, AAA where it matters",type:"practice",sourceDocument:s,originalLevel:"Senior",track:"Design craft"},{id:"ux-ex-craft-4",title:"Research strategy — ResearchOps, longitudinal studies, repository management",type:"practice",sourceDocument:s,originalLevel:"Senior",track:"Design craft"},{id:"ux-ex-craft-5",title:"Product thinking — metrics, business model, growth loops",type:"practice",sourceDocument:s,originalLevel:"Senior",track:"Design craft"},{id:"ux-ex-u1",title:"Browse Udemy's Design Systems advanced courses",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/design-systems/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — strategy & systems"},{id:"ux-ex-u2",title:"Browse Udemy's Service Design catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/service-design/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — strategy & systems"},{id:"ux-ex-u3",title:"Browse Udemy's Product Management catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/product-management/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — strategy & systems"},{id:"ux-ex-u4",title:"Browse Udemy's Design Leadership catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/design-thinking/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — strategy & systems"},{id:"ux-ex-u5",title:"Browse Udemy's Leadership & Management for designers",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/leadership/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — strategy & systems"},{id:"ux-ex-r1",title:"How To Design for Accessibility (WCAG 2.2) — Senior revisit",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/the-ux-designers-accessibility-guide/",type:"course",sourceDocument:s,track:"Udemy — accessibility, research, content leadership"},{id:"ux-ex-r2",title:"Mastering UX Research — revisit with focus on ResearchOps & strategy",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/ux-research-bootcamp-from-zero-experience-to-job-ready/",type:"course",sourceDocument:s,track:"Udemy — accessibility, research, content leadership"},{id:"ux-ex-r3",title:"Browse Udemy's UX Writing & Content Strategy catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/content-strategy/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — accessibility, research, content leadership"},{id:"ux-ex-b1",title:'"Articulating Design Decisions" — Tom Greever',url:"https://www.tomgreever.com/articulating-design-decisions/",type:"resource",description:"Paid book. Standard text on stakeholder communication.",sourceDocument:s,track:"Books & references"},{id:"ux-ex-b2",title:'"Org Design for Design Orgs" — Peter Merholz & Kristin Skinner',url:"https://orgdesignfordesignorgs.com/",type:"resource",description:"Paid book.",sourceDocument:s,track:"Books & references"},{id:"ux-ex-b3",title:'"Just Enough Research" — Erika Hall',url:"https://abookapart.com/products/just-enough-research/",type:"resource",description:"Paid book.",sourceDocument:s,track:"Books & references"},{id:"ux-ex-b4",title:"Smashing Magazine — UX career path articles (Vitaly Friedman, 2026)",url:"https://www.smashingmagazine.com/category/ux-design/",type:"resource",sourceDocument:s,track:"Books & references"},{id:"ux-ex-b5",title:"ADPList — free mentorship platform",url:"https://adplist.org",type:"resource",sourceDocument:s,track:"Books & references"},{id:"ux-ex-b6",title:"NN/g UX Career Strategy articles",provider:"NN/g",url:"https://www.nngroup.com",type:"resource",sourceDocument:s,track:"Books & references"},{id:"ux-ex-ai-1",title:"Designing AI experiences — generative interfaces, conversational UI, agentic experiences",type:"practice",sourceDocument:s,track:"AI fluency (Senior)"},{id:"ux-ex-ai-2",title:"Define team AI usage policy — approved tools, what data may not be sent, disclosure",type:"practice",sourceDocument:s,track:"AI workflow design"},{id:"ux-ex-ai-3",title:"Author Claude prompts and templates the whole team can reuse",type:"practice",sourceDocument:s,track:"AI workflow design"},{id:"ux-ex-ai-4",title:'Run "AI workflow reviews" — like design retros, but for AI-assisted work',type:"practice",sourceDocument:s,track:"AI workflow design"},{id:"ux-ex-au1",title:"Browse Udemy's AI Governance & Responsible AI catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/ai-governance/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — AI fluency & leadership"},{id:"ux-ex-au2",title:"Browse Udemy's AI Agents & Multi-agent systems",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/ai-agents/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — AI fluency & leadership"},{id:"ux-ex-au3",title:"Browse Udemy's Conversational AI Design",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/conversational-ai/",type:"resource",description:"Browse topic.",sourceDocument:s,track:"Udemy — AI fluency & leadership"},{id:"ux-ex-aif1",title:"Anthropic engineering and research blog",provider:"Anthropic",url:"https://www.anthropic.com/research",type:"resource",sourceDocument:s,track:"Free AI resources"},{id:"ux-ex-aif2",title:"Apple Human Interface Guidelines — AI/ML section",provider:"Apple",url:"https://developer.apple.com/design/human-interface-guidelines/machine-learning",type:"resource",sourceDocument:s,track:"Free AI resources"},{id:"ux-ex-aif3",title:"Google PAIR (People + AI Research) Guidebook",provider:"Google",url:"https://pair.withgoogle.com/guidebook",type:"resource",sourceDocument:s,track:"Free AI resources"},{id:"ux-ex-aif4",title:"Microsoft HAX (Human-AI eXperience) Toolkit",provider:"Microsoft",url:"https://www.microsoft.com/en-us/research/project/guidelines-for-human-ai-interaction/",type:"resource",sourceDocument:s,track:"Free AI resources"},{id:"ux-ex-cap-1",title:"Capstone — Lead a strategic product initiative",type:"capstone",description:"Frame, discover, vision, design, ship, measure, present learnings.",sourceDocument:s,track:"Capstone"},{id:"ux-ex-cap-2",title:"Capstone — Build and govern a design system module end to end",type:"capstone",description:"Tokens, components, accessibility, contribution model, adoption metrics.",sourceDocument:s,track:"Capstone"},{id:"ux-ex-cap-3",title:"Capstone — Lead a measurable team-wide AI adoption initiative",type:"capstone",description:"Define workflow, pilot, measure, roll out, publish results.",sourceDocument:s,track:"Capstone"},{id:"ux-ex-cap-4",title:"Capstone — Establish a research program",type:"capstone",description:"Multi-quarter roadmap, repository, team training, impact measurement.",sourceDocument:s,track:"Capstone"}]}]},rr={personaId:"dev_qa",displayName:"Full Stack Dev + QA",sourcePathwayNames:["AI Enabled Engineer","AI Enabled Test Automation"],mappingStatus:"combined",mappingNotes:"Combined AI-Enabled Engineer + AI-Enabled Test Automation pathways. Items are tagged by source track (Engineering, Test Automation / QA, Shared AI Toolchain).",levels:[{level:"Beginner",originalLevelNames:["Engineering Junior (0–18 mo.)","QA Junior (0–2 yrs)"],summary:"Engineering: Claude basics, 4-block prompts, AI as a learning aid. QA: AI foundations + verification reflex, risk-thinking framework, Playwright + structured bug reports with AI-pair traces.",skills:["Core language: Java 21+, C# 12+, or Python 3.12+ — OOP, generics, lambdas, async, exception handling","REST APIs: Spring Boot, ASP.NET Core, or FastAPI with DTOs, request mapping, and input validation","Git: branching, PRs, rebasing, conflict resolution — 30+ reviewed PRs before writing independently","Claude 4-block prompt pattern as a daily learning and coding aid; verification reflex on AI output","JUnit 5 / xUnit / pytest basics; Maven/Gradle/.NET CLI/pip; H2 / SQLite for local dev","Bach's HTSM: exploratory charters, oracles, risk-based thinking; structured bug reports with AI-pair traces","Playwright: locators, waits, Page Object basics, fixtures, parallel runs, trace viewer","Claude 4-block prompts, Claude Projects, verification reflex, synthetic test data generation","Promptfoo or DeepEval basics: first dataset, scoring functions, first 10 evals","Agentic tools awareness: install Playwright MCP, drive a browser via Claude once, capture a trace"],items:[{id:"dq-jr-eng-lang",title:"Core language — Java 21+ / C# 12+ / Python 3.12+: OOP, generics, async, type hints",type:"practice",sourceDocument:b,originalLevel:"Junior",track:"Engineering"},{id:"dq-jr-eng-build",title:"Build & packages — Maven/Gradle, .NET CLI/NuGet, pip/Poetry/pyproject.toml",type:"practice",sourceDocument:b,originalLevel:"Junior",track:"Engineering"},{id:"dq-jr-eng-api",title:"Web / API — Spring Boot, ASP.NET Core, FastAPI/Flask",type:"practice",sourceDocument:b,originalLevel:"Junior",track:"Engineering"},{id:"dq-jr-eng-data",title:"Data access — Spring Data JPA, EF Core, SQLAlchemy/Django ORM",type:"practice",sourceDocument:b,originalLevel:"Junior",track:"Engineering"},{id:"dq-jr-eng-test",title:"Testing — JUnit 5/Mockito, xUnit/NUnit/Moq, pytest/unittest.mock",type:"practice",sourceDocument:b,originalLevel:"Junior",track:"Engineering"},{id:"dq-jr-eng-git",title:"Git — branch, PR, rebase, conflict resolution",type:"practice",sourceDocument:b,originalLevel:"Junior",track:"Engineering"},p("master-anthropic-prompt-eng-tutorial",{track:"Engineering — AI foundation",sourceDocument:b}),p("master-anthropic-academy",{track:"Engineering — AI foundation",sourceDocument:b}),p("master-dl-chatgpt-prompt-eng-for-devs",{track:"Engineering — AI foundation",sourceDocument:b}),{id:"dq-jr-eng-c4",title:"FULL Claude Tutorial For Beginners in 2026! (FULL COURSE)",provider:"Youtube",url:"https://www.youtube.com/watch?v=Xg55nTrbYYY",hours:"~2h",type:"course",description:"Claude-specific workflows, Projects, Artifacts in depth.",sourceDocument:b,track:"Engineering — AI foundation"},{id:"dq-jr-eng-cap",title:"Capstone — Deployed REST API",type:"capstone",description:"CRUD on 2+ resources, input validation, proper error responses, 20+ unit tests, live URL. NOTES.md logging how Claude was used.",sourceDocument:b,track:"Engineering — Capstone"},{id:"dq-jr-eng-grad-1",title:"Builds a feature from a spec without copying tutorials",type:"graduation-criteria",sourceDocument:b,track:"Engineering — Graduation"},{id:"dq-jr-eng-grad-2",title:"Uses 4-block prompts consistently. 30+ PRs reviewed and merged",type:"graduation-criteria",sourceDocument:b,track:"Engineering — Graduation"},{id:"dq-jr-qa-1",title:"Risk thinking — Bach's HTSM, exploratory charters, oracles, risk-based thinking",type:"practice",sourceDocument:m,originalLevel:"Junior",track:"Test Automation / QA"},{id:"dq-jr-qa-2",title:"AI fluency — 4-block prompts, Claude Projects, verification reflex, synthetic data",type:"practice",sourceDocument:m,originalLevel:"Junior",track:"Test Automation / QA"},{id:"dq-jr-qa-3",title:"Evals — Promptfoo or DeepEval basics; first 10 evals against a Claude prompt",type:"practice",sourceDocument:m,originalLevel:"Junior",track:"Test Automation / QA"},{id:"dq-jr-qa-4",title:"Web Automation — Playwright preferred; locators, waits, Page Object, fixtures, traces",type:"practice",sourceDocument:m,originalLevel:"Junior",track:"Test Automation / QA"},{id:"dq-jr-qa-5",title:"API Testing — Postman or pytest + httpx; REST verbs, status codes, contract awareness",type:"practice",sourceDocument:m,originalLevel:"Junior",track:"Test Automation / QA"},{id:"dq-jr-qa-6",title:"Data & SQL — SELECT, JOIN, aggregates, basic data setup/validation",type:"practice",sourceDocument:m,originalLevel:"Junior",track:"Test Automation / QA"},{id:"dq-jr-qa-7",title:"Agentic Tools Awareness — install Playwright MCP, drive browser via Claude once",type:"practice",sourceDocument:m,originalLevel:"Junior",track:"Test Automation / QA"},{id:"dq-jr-qa-c1",title:"Hamel Husain — AI Evals for Engineers & PMs",provider:"Maven (paid)",url:"https://maven.com/parlance-labs/evals",hours:"~10h",type:"course",description:"Datasets, judges, error analysis, eval thinking.",sourceDocument:m,track:"Test Automation / QA — Junior AI"},{id:"dq-jr-qa-c2",title:"Eugene Yan — Evals blog series",provider:"Eugene Yan",url:"https://eugeneyan.com/writing/evals",hours:"~2h",type:"course",description:"Practical evals primer.",sourceDocument:m,track:"Test Automation / QA — Junior AI"},p("master-promptfoo",{track:"Test Automation / QA — Beginner AI",sourceDocument:m}),{id:"dq-jr-qa-c4",title:"Anthropic — Building Effective Agents",provider:"Anthropic",url:"https://www.anthropic.com/research/building-effective-agents",hours:"~1h",type:"course",description:"Canonical agent patterns.",sourceDocument:m,track:"Test Automation / QA — Junior AI"},{id:"dq-jr-qa-c5",title:"James Bach — Heuristic Test Strategy Model",provider:"Satisfice",url:"https://satisfice.com/download/heuristic-test-strategy-model",hours:"~1h",type:"course",description:"Risk-thinking framework for modern QA.",sourceDocument:m,track:"Test Automation / QA — Junior AI"},{id:"dq-jr-qa-cap",title:"Capstone — Eval suite for one AI feature",type:"capstone",description:"30 evals, mix of assertion and LLM-judge, 5 documented failures (hallucination, prompt injection, safety). Optional: 15 Playwright tests under a CLAUDE.md.",sourceDocument:m,track:"Test Automation / QA — Capstone"},{id:"dq-jr-qa-grad-1",title:"Uses Claude daily with 4-block prompts. Verifies AI-generated tests",type:"graduation-criteria",sourceDocument:m,track:"Test Automation / QA — Graduation"},{id:"dq-jr-qa-grad-2",title:"Has driven Playwright MCP once. Applies risk thinking. 30+ PR reviews",type:"graduation-criteria",sourceDocument:m,track:"Test Automation / QA — Graduation"},{id:"dq-jr-shared-1",title:"Claude + Claude Code",provider:"Anthropic",url:"https://claude.ai",type:"resource",description:"Primary AI collaborator for coding, review, agentic flows, log triage.",sourceDocument:`${b}, ${m}`,track:"Shared AI Toolchain"},p("master-bmad-method",{track:"Shared AI Toolchain",sourceDocument:`${b}, ${m}`}),p("master-prompting-guide",{track:"Shared AI Toolchain",sourceDocument:b}),p("master-aef-101",{track:"AEF Platform",sourceDocument:"AEF Platform"})]},{level:"Intermediate",originalLevelNames:["Engineering Mid (18 mo. – 4 yrs)","QA Mid (2–5 yrs)"],summary:"Engineering: cloud-native, microservices, BMAD-anchored feature delivery, Claude Code in production workflows. QA: composition + AI-feature quality, eval engineering, agentic orchestration of Playwright MCP / Browser-use, Claude Skills, BMAD test stories.",skills:["Microservices, Docker, Kubernetes, cloud-native — AWS/Azure: queues, secrets, IAM roles","BMAD structured delivery: PRD → ADR → Story → Ship with Claude Code + CLAUDE.md","Security: OWASP Top 10, JWT/OAuth 2.0, secrets management, container hardening","Integration tests (Testcontainers, WireMock), contract testing (Pact), CI quality gates","Performance: caching, load balancing, queue decoupling, profiling, basic SLO awareness","Eval engineering: golden datasets, LLM-judge calibration, Braintrust/Langfuse/LangSmith observability","AI-feature testing: hallucination, injection, jailbreak, drift, safety, cost, latency vs OWASP LLM Top 10","Agentic orchestration: compose Playwright MCP + Browser-use + Skyvern + Computer Use into pipelines","Claude Skills: author at least one SKILL.md for locator strategy, fixture pattern, or eval style","Framework ownership: Page Object/Screenplay, parallel execution, contract testing (Pact), k6"],items:[{id:"dq-sr-eng-lang",title:"Advanced language — Java virtual threads, C# records & pattern matching, Python asyncio/Pydantic v2",type:"practice",sourceDocument:b,originalLevel:"Mid",track:"Engineering"},{id:"dq-sr-eng-micro",title:"Microservices — Spring Cloud / Dapr / FastAPI services + Celery",type:"practice",sourceDocument:b,originalLevel:"Mid",track:"Engineering"},{id:"dq-sr-eng-cont",title:"Containers — Docker, Compose, multi-stage builds, Kubernetes basics",type:"practice",sourceDocument:b,originalLevel:"Mid",track:"Engineering"},{id:"dq-sr-eng-cloud",title:"Cloud basics — AWS/Azure storage, queues, Secrets Manager, IAM",type:"practice",sourceDocument:b,originalLevel:"Mid",track:"Engineering"},{id:"dq-sr-eng-cicd",title:"CI/CD — GitHub Actions, Azure DevOps, Sonar gate, quality gates",type:"practice",sourceDocument:b,originalLevel:"Mid",track:"Engineering"},{id:"dq-sr-eng-testdepth",title:"Testing depth — Testcontainers, WireMock, Pact contract tests",type:"practice",sourceDocument:b,originalLevel:"Mid",track:"Engineering"},{id:"dq-sr-eng-sec",title:"Security basics — OWASP Top 10, OAuth 2.0/JWT, managed identities",type:"practice",sourceDocument:b,originalLevel:"Mid",track:"Engineering"},{id:"dq-sr-eng-c1",title:"Prompting Best Practices — docs.claude.com",provider:"Anthropic (free)",url:"https://docs.claude.com",hours:"~2h",type:"course",description:"XML tagging, few-shot, chaining, extended thinking.",sourceDocument:b,track:"Engineering — Mid AI"},{id:"dq-sr-eng-c2",title:"Claude Code docs — CLAUDE.md, plan mode, MCP basics",provider:"Anthropic (free)",url:"https://docs.claude.com",hours:"~2h",type:"course",description:"Agentic coding setup; patterns that make Claude Code production-ready.",sourceDocument:b,track:"Engineering — Mid AI"},{id:"dq-sr-eng-c3",title:"BMAD Getting Started + one full feature cycle",provider:"BMAD (free)",url:"https://github.com/bmad-code-org/BMAD-METHOD",hours:"~4h",type:"course",description:"PRD → ADR → story loop; the core structured AI workflow.",sourceDocument:b,track:"Engineering — Mid AI"},{id:"dq-sr-eng-c4",title:"AI Coder: Complete Claude Code & Coding Agents Course",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/ai-coder-from-vibe-coder-to-agentic-engineer/",hours:"~18h",type:"course",sourceDocument:b,track:"Engineering — Mid AI"},{id:"dq-sr-eng-c5",title:"Generative AI with LLMs — audit on Coursera",provider:"DeepLearning.AI (free)",url:"https://www.coursera.org/learn/generative-ai-with-llms",hours:"~6h",type:"course",description:"How LLMs work; essential for reasoning about prompt design.",sourceDocument:b,track:"Engineering — Mid AI"},{id:"dq-sr-eng-cap",title:"Capstone — Production-grade service via full BMAD cycle",type:"capstone",description:"PRD → ADR → story-by-story implementation with Claude Code, CI pipeline, structured logging, integration tests, deployed.",sourceDocument:b,track:"Engineering — Capstone"},{id:"dq-sr-eng-grad-1",title:"Shipped a production feature with a structured AI workflow",type:"graduation-criteria",sourceDocument:b,track:"Engineering — Graduation"},{id:"dq-sr-eng-grad-2",title:"Maintains a CLAUDE.md. Authored a technical design doc",type:"graduation-criteria",sourceDocument:b,track:"Engineering — Graduation"},{id:"dq-sr-qa-1",title:"Eval Engineering — golden datasets, judge calibration, Braintrust/Langfuse/LangSmith",type:"practice",sourceDocument:m,originalLevel:"Mid",track:"Test Automation / QA"},{id:"dq-sr-qa-2",title:"AI-Feature Testing — hallucination, prompt injection, jailbreak, drift, safety, cost/latency",type:"practice",sourceDocument:m,originalLevel:"Mid",track:"Test Automation / QA"},{id:"dq-sr-qa-3",title:"Agentic Orchestration — Playwright MCP / Browser-use / Skyvern / Computer Use",type:"practice",sourceDocument:m,originalLevel:"Mid",track:"Test Automation / QA"},{id:"dq-sr-qa-4",title:"Claude Skills — author at least one SKILL.md for locator strategy or eval style",type:"practice",sourceDocument:m,originalLevel:"Mid",track:"Test Automation / QA"},{id:"dq-sr-qa-5",title:"Framework Ownership — Page Object, parallel runs, cloud grids, flake reduction",type:"practice",sourceDocument:m,originalLevel:"Mid",track:"Test Automation / QA"},{id:"dq-sr-qa-6",title:"Contract Testing — Pact consumer-driven contracts",type:"practice",sourceDocument:m,originalLevel:"Mid",track:"Test Automation / QA"},{id:"dq-sr-qa-7",title:"Performance — k6 with AI-generated load profiles; p50/p95/p99 analysis",type:"practice",sourceDocument:m,originalLevel:"Mid",track:"Test Automation / QA"},{id:"dq-sr-qa-8",title:"Accessibility — axe-core in Playwright/Selenium; WCAG 2.2 AA in CI",type:"practice",sourceDocument:m,originalLevel:"Mid",track:"Test Automation / QA"},{id:"dq-sr-qa-c1",title:"Claude Code docs — CLAUDE.md, Plan Mode, MCP",provider:"Anthropic (free)",url:"https://docs.claude.com/claude-code",hours:"~2h",type:"course",description:"Repo-aware test automation workflows.",sourceDocument:m,track:"Test Automation / QA — Mid AI"},p("master-claude-skills-repo",{track:"Test Automation / QA — Mid AI",sourceDocument:m}),p("master-owasp-llm-top10",{track:"Test Automation / QA — Mid AI",sourceDocument:m}),{id:"dq-sr-qa-c4",title:"MITRE ATLAS Adversarial ML Framework",provider:"MITRE (free)",url:"https://atlas.mitre.org",hours:"~2h",type:"course",sourceDocument:m,track:"Test Automation / QA — Mid AI"},{id:"dq-sr-qa-c5",title:"Red-teaming Language Models",provider:"Anthropic (free)",url:"https://www.anthropic.com/news/red-teaming-language-models",hours:"~1h",type:"course",description:"Red-team methodology for LLM systems.",sourceDocument:m,track:"Test Automation / QA — Mid AI"},{id:"dq-sr-qa-c6",title:"Lakera Gandalf — Prompt Injection Lab",provider:"Lakera",url:"https://gandalf.lakera.ai",hours:"~3h",type:"course",description:"Hands-on prompt injection practice.",sourceDocument:m,track:"Test Automation / QA — Mid AI"},{id:"dq-sr-qa-c7",title:"AI Agents in LangGraph",provider:"DeepLearning.AI (free)",url:"https://www.deeplearning.ai/courses/ai-agents-in-langgraph/",hours:"~2h",type:"course",description:"Agent orchestration concepts.",sourceDocument:m,track:"Test Automation / QA — Mid AI"},{id:"dq-sr-qa-c8",title:"Playwright MCP setup",provider:"Microsoft",url:"https://github.com/microsoft/playwright-mcp",hours:"~2h",type:"course",description:"Claude-driven browser exploration.",sourceDocument:m,track:"Test Automation / QA — Mid AI"},{id:"dq-sr-qa-c9",title:"Braintrust — Evals for Production docs",provider:"Braintrust",url:"https://braintrust.dev",hours:"~2h",type:"course",description:"Datasets, traces, production-scale scoring.",sourceDocument:m,track:"Test Automation / QA — Mid AI"},{id:"dq-sr-qa-cap",title:"Capstone — Agentic test pipeline via BMAD",type:"capstone",description:"PRD → ADRs → Stories. 200+ eval suite with judges and observability. Playwright MCP / Browser-use → Claude triage → eval grading → CI. At least 1 Claude Skill in active use.",sourceDocument:m,track:"Test Automation / QA — Capstone"},{id:"dq-sr-qa-grad-1",title:"Shipped an eval programme for at least 1 AI feature",type:"graduation-criteria",sourceDocument:m,track:"Test Automation / QA — Graduation"},{id:"dq-sr-qa-grad-2",title:"Authored a team-used Skill. Ran AI red-team mapped to OWASP LLM Top 10",type:"graduation-criteria",sourceDocument:m,track:"Test Automation / QA — Graduation"},p("master-mcp-spec",{track:"Shared AI Toolchain",sourceDocument:`${b}, ${m}`}),{id:"dq-sr-shared-2",title:"Browser-use — LLM browser agents",url:"https://github.com/browser-use/browser-use",type:"resource",sourceDocument:m,track:"Shared AI Toolchain"},{id:"dq-sr-shared-3",title:"Skyvern",url:"https://skyvern.com",type:"resource",sourceDocument:m,track:"Shared AI Toolchain"},p("master-deepeval",{track:"Shared AI Toolchain",sourceDocument:m}),p("master-langfuse",{track:"Shared AI Toolchain",sourceDocument:m}),p("master-langsmith",{track:"Shared AI Toolchain",sourceDocument:m}),{id:"dq-sr-shared-7",title:"Anthropic Computer Use",url:"https://docs.claude.com/computer-use",type:"resource",description:"Claude operating a desktop for cross-app and multi-window testing.",sourceDocument:m,track:"Shared AI Toolchain"},{id:"dq-sr-shared-8",title:"Self-healing locators (Healenium) & Visual AI (Applitools)",url:"https://applitools.com",type:"resource",sourceDocument:m,track:"Shared AI Toolchain"},p("master-aef-201",{track:"AEF Platform",sourceDocument:"AEF Platform"})]},{level:"Advanced",originalLevelNames:["Engineering Senior (4+ yrs)","QA Senior (5+ yrs)"],summary:"Engineering: distributed systems, IaC, platform thinking, BMAD playbook authoring, MCP server build, Claude Skills active in the team. QA: platform + governance, MCP authoring for test platforms, AI test governance, eval-driven development at org scale.",skills:["Distributed systems: Kafka/Kinesis, Saga, CQRS + Event Sourcing","MCP server authoring: connect Claude to internal tools, data sources, CI systems","Claude Skills (SKILL.md): encode team conventions so Claude follows your standards","AI governance: NIST AI RMF / ISO 42001 mapping; third-party tool review; audit trail","Observability: OpenTelemetry, distributed tracing, Prometheus/Grafana, IaC","MCP server authoring: connect Claude to TestRail, Allure, Jira, CI, test data systems","AI test governance: NIST AI RMF / ISO 42001 mapping; third-party AI tool review process","Eval-driven development: org eval roadmap, shared datasets, LLM judges, quarterly review rituals","Test platform engineering: self-service QA, paved roads, governance, observability-driven testing","Quality metrics: defect escape rate, MTTR, change failure rate, regression time, flake rate"],items:[{id:"dq-ex-eng-dist",title:"Distributed systems — Kafka/Kinesis, Saga, CQRS + Event Sourcing",type:"practice",sourceDocument:b,originalLevel:"Senior",track:"Engineering"},{id:"dq-ex-eng-obs",title:"Observability — OpenTelemetry, distributed tracing, Prometheus/Grafana",type:"practice",sourceDocument:b,originalLevel:"Senior",track:"Engineering"},{id:"dq-ex-eng-iac",title:"IaC & platform — Terraform, Helm, GitOps with ArgoCD/Flux",type:"practice",sourceDocument:b,originalLevel:"Senior",track:"Engineering"},{id:"dq-ex-eng-sec",title:"Security depth — Spring Security OAuth2/OIDC, secret rotation, SAST, threat modelling",type:"practice",sourceDocument:b,originalLevel:"Senior",track:"Engineering"},{id:"dq-ex-eng-cross",title:"Cross-language literacy — read and contribute to ADRs across Java, .NET, Python",type:"practice",sourceDocument:b,originalLevel:"Senior",track:"Engineering"},{id:"dq-ex-eng-c1",title:"AI Agents & Workflows - The Practical Guide",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/ai-agents-workflows-the-practical-guide/",hours:"~4h",type:"course",description:"MCP tool use, agent orchestration, guardrail design.",sourceDocument:b,track:"Engineering — Senior AI"},{id:"dq-ex-eng-c2",title:"Model Context Protocol — browse 2025/2026 courses",provider:"Udemy Business",hours:"~6h",url:"https://deloittedevelopment.udemy.com/topic/mcp/",type:"course",description:"Authoring and consuming MCP servers for internal systems.",sourceDocument:b,track:"Engineering — Senior AI"},{id:"dq-ex-eng-c3",title:"AI Governance & Responsible AI",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/ai-governance-the-fundamentals-of-ai-governance/",hours:"~5h",type:"course",description:"Risk frameworks, usage policies, audit trails.",sourceDocument:b,track:"Engineering — Senior AI"},{id:"dq-ex-eng-c4",title:"Claude Skills repo + Anthropic Engineering Blog",provider:"Anthropic (free)",url:"https://github.com/anthropics/skills",type:"course",description:"Skill authoring patterns; real agentic case studies.",sourceDocument:b,track:"Engineering — Senior AI"},{id:"dq-ex-eng-role-1",title:"API / Platform — versioning, hypermedia, GraphQL vs REST, Resilience4j/Polly",type:"practice",sourceDocument:b,track:"Role-specific (Engineering)"},{id:"dq-ex-eng-role-2",title:"Data / ML-adjacent — Kafka, batch vs stream, LLM integration via Claude API",type:"practice",sourceDocument:b,track:"Role-specific (Engineering)"},{id:"dq-ex-eng-role-3",title:"DevOps / SRE-adjacent — Terraform/Bicep, Kubernetes RBAC, SLOs",type:"practice",sourceDocument:b,track:"Role-specific (Engineering)"},{id:"dq-ex-eng-role-4",title:"Tech lead / architecture — Grokking System Design, CQRS, hexagonal",type:"practice",sourceDocument:b,track:"Role-specific (Engineering)"},{id:"dq-ex-eng-cap",title:"Capstone — AI-native platform initiative",type:"capstone",description:"Multi-service BMAD lifecycle, 3+ ADRs, one MCP server connecting Claude to an internal system, three Claude Skills (SKILL.md) actively used by the team.",sourceDocument:b,track:"Engineering — Capstone"},{id:"dq-ex-eng-grad-1",title:"Team AI workflow measurably improved. Two or more engineers accelerated by mentorship",type:"graduation-criteria",sourceDocument:b,track:"Engineering — Graduation"},{id:"dq-ex-eng-grad-2",title:"BMAD playbook authored and in active use. Credible voice in cross-team architecture",type:"graduation-criteria",sourceDocument:b,track:"Engineering — Graduation"},{id:"dq-ex-qa-1",title:"MCP Authoring — internal MCP server connecting Claude to TestRail, Allure, Jira, or CI",type:"practice",sourceDocument:m,originalLevel:"Senior",track:"Test Automation / QA"},{id:"dq-ex-qa-2",title:"Test Platform Engineering — internal frameworks, paved roads, governance",type:"practice",sourceDocument:m,originalLevel:"Senior",track:"Test Automation / QA"},{id:"dq-ex-qa-3",title:"Eval-Driven Development — org eval roadmap, shared datasets and judges",type:"practice",sourceDocument:m,originalLevel:"Senior",track:"Test Automation / QA"},{id:"dq-ex-qa-4",title:"AI Test Governance — AI usage policy, NIST AI RMF / ISO 42001 mapping",type:"practice",sourceDocument:m,originalLevel:"Senior",track:"Test Automation / QA"},{id:"dq-ex-qa-5",title:"Performance Engineering — capacity modelling, SLO/SLI design, traffic replay",type:"practice",sourceDocument:m,originalLevel:"Senior",track:"Test Automation / QA"},{id:"dq-ex-qa-6",title:"Distributed System Testing — Pact Broker at scale, schema evolution, chaos testing",type:"practice",sourceDocument:m,originalLevel:"Senior",track:"Test Automation / QA"},{id:"dq-ex-qa-7",title:"Observability — OpenTelemetry instrumentation in tests, traces as test artifacts",type:"practice",sourceDocument:m,originalLevel:"Senior",track:"Test Automation / QA"},{id:"dq-ex-qa-c1",title:"MCP Specification",provider:"modelcontextprotocol.io",url:"https://modelcontextprotocol.io",hours:"~3h",type:"course",sourceDocument:m,track:"Test Automation / QA — Senior AI"},{id:"dq-ex-qa-c2",title:"Build an MCP Server Tutorial",provider:"Anthropic",url:"https://modelcontextprotocol.io/tutorials/building-mcp-with-llms",hours:"~6h",type:"course",description:"Build a server connecting Claude to testing tools.",sourceDocument:m,track:"Test Automation / QA — Senior AI"},{id:"dq-ex-qa-c3",title:"Hamel Husain — Eval-driven Development & LLM Judge",provider:"hamel.dev",url:"https://hamel.dev/blog/posts/evals",hours:"~3h",type:"course",sourceDocument:m,track:"Test Automation / QA — Senior AI"},{id:"dq-ex-qa-c4",title:"NIST AI Risk Management Framework",provider:"NIST",url:"https://nist.gov/itl/ai-risk-management-framework",hours:"~5h",type:"course",sourceDocument:m,track:"Test Automation / QA — Senior AI"},{id:"dq-ex-qa-c5",title:"Responsible AI Toolkit",provider:"Microsoft",url:"https://www.microsoft.com/en-us/ai/responsible-ai",hours:"~3h",type:"course",description:"Fairness, transparency, and governance playbooks.",sourceDocument:m,track:"Test Automation / QA — Senior AI"},{id:"dq-ex-qa-c6",title:"AI Agents & Workflows - The Practical Guide",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/ai-agents-workflows-the-practical-guide/",hours:"~4h",type:"course",sourceDocument:m,track:"Test Automation / QA — Senior AI"},{id:"dq-ex-qa-c7",title:"AI Governance & Responsible AI",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/ai-governance-the-fundamentals-of-ai-governance/",hours:"~5h",type:"course",sourceDocument:m,track:"Test Automation / QA — Senior AI"},{id:"dq-ex-qa-role-1",title:"AI Quality / Red-Team Specialist — MITRE ATLAS, Lakera Gandalf, Promptmap",type:"practice",sourceDocument:m,track:"Role-specific (QA)"},{id:"dq-ex-qa-role-2",title:"Test Platform / MCP Author — internal QA platform reference architecture",type:"practice",sourceDocument:m,track:"Role-specific (QA)"},{id:"dq-ex-qa-role-3",title:"Performance / SRE-Adjacent — k6, Google SRE books, chaos engineering, OpenTelemetry",type:"practice",sourceDocument:m,track:"Role-specific (QA)"},{id:"dq-ex-qa-role-4",title:"Mobile Test Specialist — Appium 2.x, BrowserStack/SauceLabs, axe-android",type:"practice",sourceDocument:m,track:"Role-specific (QA)"},{id:"dq-ex-qa-cap",title:"Capstone — Internal MCP server + 3 Claude Skills + AI test governance policy",type:"capstone",description:"Connecting Claude to a test platform. Three Claude Skills in active use. AI test policy authored. NIST AI RMF mapping in place.",sourceDocument:m,track:"Test Automation / QA — Capstone"},{id:"dq-ex-qa-grad-1",title:"Team AI workflow measurably improved. Two or more engineers accelerated through mentorship",type:"graduation-criteria",sourceDocument:m,track:"Test Automation / QA — Graduation"},{id:"dq-ex-qa-grad-2",title:"MCP server in production. AI test policy authored. NIST AI RMF mapping in place",type:"graduation-criteria",sourceDocument:m,track:"Test Automation / QA — Graduation"},{id:"dq-ex-shared-1",title:"Designing Data-Intensive Applications — Kleppmann",url:"https://dataintensive.net",type:"resource",sourceDocument:b,track:"Shared AI Toolchain"},{id:"dq-ex-shared-2",title:"Backend skills roadmap",url:"https://roadmap.sh/backend",type:"resource",sourceDocument:b,track:"Shared AI Toolchain"},{id:"dq-ex-shared-3",title:"OWASP Top 10",url:"https://owasp.org/www-project-top-ten",type:"resource",sourceDocument:b,track:"Shared AI Toolchain"},{id:"dq-ex-shared-4",title:"OpenTelemetry docs",url:"https://opentelemetry.io/docs",type:"resource",sourceDocument:b,track:"Shared AI Toolchain"},{id:"dq-ex-shared-5",title:"Google SRE books",url:"https://sre.google/books",type:"resource",sourceDocument:m,track:"Shared AI Toolchain"},{id:"dq-ex-shared-6",title:"Pact Contract Testing",url:"https://docs.pact.io",type:"resource",sourceDocument:m,track:"Shared AI Toolchain"},{id:"dq-ex-shared-7",title:"k6 load testing",url:"https://k6.io/docs",type:"resource",sourceDocument:m,track:"Shared AI Toolchain"}]}]};p("master-anthropic-prompt-eng-tutorial",{track:"Anthropic Academy",sourceDocument:c}),p("master-dl-genai-for-everyone",{track:"DeepLearning.AI",sourceDocument:c}),p("master-ms-genai-for-beginners",{track:"Microsoft Learn & HF",sourceDocument:c}),p("master-hf-llm-course",{track:"Microsoft Learn & HF",sourceDocument:c}),p("master-prompting-guide",{track:"GitHub repos to clone",sourceDocument:c}),p("master-dl-agentic-ai",{track:"DeepLearning.AI",sourceDocument:c}),p("master-dl-langgraph",{track:"DeepLearning.AI",sourceDocument:c}),p("master-hf-agents-course",{track:"Microsoft Learn & HF",sourceDocument:c}),p("master-mcp-spec",{track:"Essential reading",sourceDocument:c}),p("master-langsmith",{track:"Evaluations & observability",sourceDocument:c}),p("master-langfuse",{track:"Evaluations & observability",sourceDocument:c}),p("master-nist-ai-rmf",{track:"Governance & responsible AI",sourceDocument:c}),p("master-eu-ai-act",{track:"Governance & responsible AI",sourceDocument:c});const ar=[{level:"Beginner",originalLevelNames:["AEF Platform — Foundation"],summary:"Get familiar with the Ascend Engineering Foundation (AEF) — Deloitte's engineering platform for cloud hosting, CI/CD, and engineering services. Build foundational MLOps awareness for AI workloads.",items:[p("master-aef-101",{track:"AEF Platform",sourceDocument:"AEF Platform"}),{id:"devops-jr-mlops-1",title:"MLOps Bootcamp: Mastering AI Operations for Success - AIOps",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/mlops-bootcamp-mastering-ai-operations-for-success-aiops/",type:"course",description:"Manifold AI Learning. Covers MLflow for enhanced experiment tracking and management.",sourceDocument:"AEF Platform",track:"MLOps & AIOps"}]},{level:"Intermediate",originalLevelNames:["AEF Platform — Advanced Topics"],summary:"Advanced AEF: KMS, Cloud Hosting, Application Common Services, Certify the Factory, and platform governance. Apply AIOps to real-world log analytics and cost optimisation.",items:[p("master-aef-201",{track:"AEF Platform",sourceDocument:"AEF Platform"}),{id:"devops-md-aiops-1",title:"AIOps Mastery: Reducing Log Costs and Optimizing Operations",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/aiops-mastery-reducing-log-costs-and-optimizing-operations/",type:"course",description:"Jonathan Dias Baraldi. Covers AIOps concepts and infrastructure for efficient log analysis using Kubernetes, ElasticSearch, and Kibana.",sourceDocument:"AEF Platform",track:"MLOps & AIOps"}]},{level:"Advanced",originalLevelNames:["AEF Platform — Production LLMOps"],summary:"Operate LLMs and AI agents in production — scaling, cost-efficiency, monitoring, and governance for deployed AI workloads.",items:[{id:"devops-sr-llmops-1",title:"Deploying LLMs: A Practical Guide to LLMOps in Production",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/deploy-ai-smarter-llm-scalability-ml-ops-cost-efficiency/",type:"course",description:"The Fuzzy Scientist (LLM Expert). Practical ML-Ops with MLflow for effective model management and deployment.",sourceDocument:"AEF Platform",track:"MLOps & AIOps"}]}],ir={personaId:"mle_ds",displayName:"ML Engineer / Data Scientist",sourcePathwayNames:["AI-Enabled ML Engineer / Data Scientist"],mappingStatus:"mapped",mappingNotes:"Beginner = AI co-pilot for data/ML work; Intermediate = agentic ML workflows; Advanced = production LLMOps, fine-tuning, and deployment at scale. Each level closes with an ADLC-aligned capstone.",levels:[{level:"Beginner",originalLevelNames:["Beginner"],summary:"Learn to prompt effectively and use AI as a daily co-pilot in data/ML work. Master the 6-element prompt structure, bridge prompting with DS tools (SHAP, XGBoost, CrewAI), and build ML foundations with AI-assisted coding.",skills:["Prompt engineering — 6-element prompt structure, hallucination avoidance, iterative refinement, common failure modes","Daily AI co-pilot use for data/ML work — verify, don’t trust; rewrite AI output in your own words; validate against sample data","ML foundations — regression, classification, clustering with Python and R; supervised vs unsupervised; train/test/validation discipline","Bridging prompt engineering with data science tools — SHAP for explainability, XGBoost, and CrewAI agents inside the DS workflow","LangChain basics — build your first prompt chains and minimal agents; understand how Claude integrates via MCP later","Verification reflex on AI output before merging — never paste client/PII/proprietary data into a public AI tool"],items:[{id:"mle-jr-c1",title:"The Complete Prompt Engineering for AI Bootcamp (2026)",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/prompt-engineering-for-ai/",type:"course",description:"Full 6-element prompt structure, hallucination avoidance, and building agents with LangChain — directly maps to ADLC Lab 1 & 2 skills.",sourceDocument:k,track:"Prompting & AI co-pilot"},{id:"mle-jr-c2",title:"10 Days: Prompt Engineering, Generative AI and Data Science",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/xgboost-python-r/",type:"course",description:"Bridges prompt engineering with DS tools — SHAP, XGBoost, and CrewAI agents in a single course, built for data practitioners.",sourceDocument:k,track:"Prompting & AI co-pilot"},{id:"mle-jr-c3",title:"Machine Learning A-Z 2026: AI, Python & R + ChatGPT",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/machinelearning/",type:"course",description:"Teaches ML foundations with AI-assisted coding woven throughout — builds the domain knowledge needed to supervise Claude’s ML output in ADLC.",sourceDocument:k,track:"ML foundations with AI"},p("master-anthropic-prompt-eng-tutorial",{track:"AI fluency — supporting resources",sourceDocument:k}),p("master-anthropic-academy",{track:"AI fluency — supporting resources",sourceDocument:k}),p("master-prompting-guide",{track:"AI fluency — supporting resources",sourceDocument:k}),p("master-aef-101",{track:"AEF Platform",sourceDocument:k}),{id:"mle-jr-cap-1",title:"AI-paired EDA notebook",type:"capstone",description:"Open a real dataset, run AI-paired exploratory analysis using 4-block prompts, document every claim with its source (sample data or computed result), and produce a 5-page synthesis with a prompt log.",sourceDocument:k,track:"Capstone"},{id:"mle-jr-grad-1",title:"Can write 6-element prompts consistently and maintain a personal prompt journal",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-jr-grad-2",title:"Can build a basic regression/classification/clustering pipeline in Python or R from a brief",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-jr-grad-3",title:"Can supervise AI-generated ML code — explain every line and verify outputs against sample data",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-jr-grad-4",title:"Has used SHAP or equivalent to explain at least one model’s predictions",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-jr-grad-5",title:"Never pastes client, PII, or proprietary data into unapproved AI tools",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"}]},{level:"Intermediate",originalLevelNames:["Intermediate"],summary:"Build agents that automate ML workflows — EDA, model pipelines, evaluation, reporting. Compose CrewAI / LangGraph / AutoGen with MCP and multi-agent handoffs to mirror the ADLC Build → Ship pattern for data science.",skills:["Build a data-science agent team with CrewAI — specialised agents for data cleaning, feature engineering, model training, and evaluation","Automate a full regression workflow end-to-end with multi-agent handoffs","LangGraph for graph-based agentic workflows; AutoGen for multi-agent collaboration; choosing between them defensibly","MCP-enabled tool integration — connect agents to data catalogs, feature stores, notebooks, experiment trackers","RAG pipelines for ML/DS workloads — grounded responses against papers, internal docs, model cards","Eval design for agentic ML workflows — golden cases, LLM-judges, regression detection in CI","ADLC Build & Ship phase patterns applied to data science delivery"],items:[{id:"mle-md-c1",title:"LLM Engineering, RAG & AI Agents Masterclass 2026",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/become-an-llm-agentic-ai-engineer-14-day-bootcamp-2025/",type:"course",description:"Dedicated data-science agent team project using CrewAI — agents for cleaning, feature engineering, training, and evaluation. Mirrors ADLC Build for DS.",sourceDocument:k,track:"Agentic ML workflows"},{id:"mle-md-c2",title:"The Agentic AI Engineering Masterclass (2026)",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/become-an-ai-agent-workflow-automation-engineer/",type:"course",description:"Builds a data-science AI team with CrewAI automating a full regression workflow. Covers LangGraph, AutoGen, MCP, and multi-agent handoffs — the ADLC Ship phase pattern.",sourceDocument:k,track:"Agentic ML workflows"},{id:"mle-md-c3",title:"LangChain: Agentic AI Engineering with LangChain & LangGraph",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/langchain/",type:"course",description:"Explicitly targets data scientists and ML engineers. Production-ready agents, RAG systems, and agentic workflows using the frameworks Claude integrates with via MCP.",sourceDocument:k,track:"Agentic ML workflows"},p("master-dl-langgraph",{track:"Supporting — frameworks & evals",sourceDocument:k}),p("master-dl-agentic-ai",{track:"Supporting — frameworks & evals",sourceDocument:k}),p("master-anthropic-building-effective-agents",{track:"Supporting — frameworks & evals",sourceDocument:k}),p("master-aef-201",{track:"AEF Platform",sourceDocument:k}),{id:"mle-md-cap-1",title:"Multi-agent ML workflow",type:"capstone",description:"Build a CrewAI or LangGraph team that automates EDA → feature engineering → model training → evaluation → executive summary for one regression or classification problem. Deliverables: working agent system, prompt and tool logs, eval set of 20+ cases, design doc explaining handoffs.",sourceDocument:k,track:"Capstone"},{id:"mle-md-grad-1",title:"Has shipped at least one multi-agent ML workflow that runs end-to-end on a real problem",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-md-grad-2",title:"Can choose between LangGraph, AutoGen, CrewAI defensibly for a given use case",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-md-grad-3",title:"Operates a 20+ case eval suite for the agentic workflow with LLM-judge calibration",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-md-grad-4",title:"Has integrated at least one MCP tool into the workflow (catalog, feature store, notebook, or tracker)",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-md-grad-5",title:"Has documented failure modes, cost, and latency for the agentic system",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"}]},{level:"Advanced",originalLevelNames:["Advanced"],summary:"Own the full production stack — fine-tuning (LoRA/QLoRA/RLHF/DPO), LLMOps pipelines, deploying agents at scale with monitoring, evaluation, and governance. Build domain-specific models, not just prompt general-purpose ones. Enables the ADLC Ship phase at enterprise scale.",skills:["Fine-tuning — LoRA, QLoRA, RLHF/DPO, knowledge distillation; pick the right technique for the use case and cost envelope","Multi-modal agents and production RAG pipelines — hybrid retrieval, evaluation harnesses, cost-aware routing","CI/CD for AI systems — GitHub Actions for eval/regression gates, MCP server deployment, microservices architecture for GenAI","Cloud deployment across AWS, GCP, and Azure — go deepest on AWS; understand cross-platform migration trade-offs","Observability & cost control for LLM systems in production — tracing, token budgets, prompt caching, model tiering (Haiku → Sonnet → Opus)","Build domain-specific models rather than prompting general-purpose ones — the ADLC pattern for high-stakes work","AI governance — NIST AI RMF / EU AI Act posture, audit trails, prompt-injection defence at scale, model risk management"],items:[{id:"mle-sr-c1",title:"AI Engineer Core Track: LLM Engineering, RAG, QLoRA, Agents (Ed Donner)",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/llm-engineering-master-ai-and-large-language-models/",type:"course",description:"Ed Donner (ex-JP Morgan MD). QLoRA fine-tuning, multi-modal agents, full RAG pipelines, and a live demo of Claude Sonnet in Cursor reading notebooks and writing ML solutions. ADLC-in-practice for a senior DS.",sourceDocument:k,track:"Production LLM engineering"},{id:"mle-sr-c2",title:"AI Engineer Production Track: Deploy LLMs & Agents at Scale (Ed Donner)",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/generative-and-agentic-ai-in-production/",type:"course",description:"Picks up where the Core Track ends — CI/CD for AI, AWS/GCP/Azure deployment, MCP server deployment, observability and cost control. Enables the ADLC Ship phase at enterprise scale.",sourceDocument:k,track:"Production LLM engineering"},{id:"mle-sr-c3",title:"LLM Fine-Tuning Mastery: Basic to Advanced & Cloud AI",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/llm-fine-tuning-mastery-basic-to-advanced-cloud-deploy/",type:"course",description:"LoRA, QLoRA, RLHF/DPO, knowledge distillation, cloud deployment across Azure/AWS/GCP. Built for intermediate-to-advanced ML engineers and data scientists.",sourceDocument:k,track:"Production LLM engineering"},p("master-anthropic-building-effective-agents",{track:"Supporting — governance & ops",sourceDocument:k}),p("master-mcp-spec",{track:"Supporting — governance & ops",sourceDocument:k}),p("master-nist-ai-rmf",{track:"Supporting — governance & ops",sourceDocument:k}),p("master-eu-ai-act",{track:"Supporting — governance & ops",sourceDocument:k}),p("master-langfuse",{track:"Supporting — governance & ops",sourceDocument:k}),p("master-langsmith",{track:"Supporting — governance & ops",sourceDocument:k}),{id:"mle-sr-cap-1",title:"Production LLMOps capstone",type:"capstone",description:"Take an agentic ML system to production: pick LoRA/QLoRA fine-tuning where it pays off, deploy on AWS (or your client cloud) with CI/CD, run a 50+ case eval suite in CI, wire tracing (LangSmith/Langfuse), optimise tokens, and produce a 30-day operations report with cost and quality KPIs.",sourceDocument:k,track:"Capstone"},{id:"mle-sr-grad-1",title:"Has shipped a fine-tuned (LoRA/QLoRA) or domain-specific model in production for a real problem",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-sr-grad-2",title:"Operates a production agentic ML system with 50+ eval cases in CI and full tracing",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-sr-grad-3",title:"Has measurably reduced cost or latency (target ≥40%) via tiering, caching, or batching",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-sr-grad-4",title:"Can lead architecture reviews for cross-cloud LLM systems and explain trade-offs",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-sr-grad-5",title:"Has authored AI governance artifacts — usage policy, audit trail, prompt-injection defences — adopted by the team",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"},{id:"mle-sr-grad-6",title:"Has mentored at least two engineers to ship their own agentic ML workflow",type:"graduation-criteria",sourceDocument:k,track:"Graduation criteria"}]}]},or={personaId:"data",displayName:"Data Engineer",sourcePathwayNames:["AI-Enabled Data Engineer"],mappingStatus:"mapped",mappingNotes:"Junior → Beginner; Mid-Level → Intermediate; Senior → Advanced.",levels:[{level:"Beginner",originalLevelNames:["Junior Data Engineer (0–18 months)"],summary:"12–16 weeks of focused self-study. Build foundational fluency — SQL, Python, basic ETL, Git, cloud storage, and orchestration basics. Use AI to learn and debug without blindly copying output.",skills:["SQL & relational thinking — SELECT/WHERE/JOIN/GROUP BY, CTEs, subqueries, window functions, basic indexing and query plan awareness","Python for data work — core syntax, functions, virtual environments, Pandas basics, API calls, reading/writing CSV/JSON/Parquet","Data modeling basics — OLTP vs OLAP, facts and dimensions, star and snowflake schemas, slowly changing dimensions","ETL / ELT — extract, transform, load; batch ingestion; incremental loads; idempotency basics","Git engineering workflow — branching, pull requests, commit hygiene; Linux shell scripting, cron basics","Cloud fundamentals — object storage (S3/ADLS/GCS), compute basics, IAM basics, managed databases and warehouses","Orchestration basics — DAGs, scheduling, dependencies, retries, failure notifications","AI fluency — four-block prompt pattern; SQL explanation/refactor prompts; Python debugging prompts; data-quality validation prompts"],items:[{id:"data-jr-sql-1",title:"The Complete SQL Bootcamp: Go from Zero to Hero — Jose Portilla",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/the-complete-sql-bootcamp/",type:"course",description:"Best for PostgreSQL fundamentals. Complete before attempting pipeline projects.",sourceDocument:i,track:"SQL & databases"},{id:"data-jr-sql-2",title:"SQL for Data Analysis — Mode SQL Tutorial",provider:"Mode",url:"https://mode.com/sql-tutorial",type:"resource",description:"Free. Practical supplement for analytics-style querying.",sourceDocument:i,track:"SQL & databases"},{id:"data-jr-sql-3",title:"Advanced SQL: MySQL for Ecommerce & Web Analytics — Maven Analytics",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/advanced-sql-mysql-for-analytics-business-intelligence/",type:"course",description:"Case-style query thinking and business analytics.",sourceDocument:i,track:"SQL & databases"},{id:"data-jr-sql-4",title:"Databases and SQL for Data Science with Python — IBM",provider:"Coursera",url:"https://www.coursera.org/learn/sql-data-science",type:"course",description:"Guided academic format.",sourceDocument:i,track:"SQL & databases"},{id:"data-jr-py-1",title:"Complete Python Bootcamp: From Zero to Hero in Python — Jose Portilla",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/complete-python-bootcamp/",type:"course",description:"Python fundamentals required before data pipeline work.",sourceDocument:i,track:"Python"},{id:"data-jr-py-2",title:"Python for Everybody Specialization — Charles Severance",provider:"Coursera",url:"https://www.coursera.org/specializations/python",type:"course",description:"Beginner-friendly alternative.",sourceDocument:i,track:"Python"},{id:"data-jr-py-3",title:"Python Project for Data Engineering — IBM",provider:"Coursera",url:"https://www.coursera.org/learn/python-project-for-data-engineering",type:"course",description:"Files, APIs, automation, data manipulation.",sourceDocument:i,track:"Python"},{id:"data-jr-py-4",title:"Data Engineering with Python — Paul Crickard",provider:"O'Reilly",url:"https://www.oreilly.com/library/view/data-engineering-with/9781839214189/",type:"resource",description:"Reference while building projects.",sourceDocument:i,track:"Python"},{id:"data-jr-tools-1",title:"Git Complete: Definitive Step-by-Step Guide — Jason Taylor",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/git-complete/",type:"course",description:"Branching, merging, rebasing, GitHub workflows.",sourceDocument:i,track:"Git, Linux & Docker"},{id:"data-jr-tools-2",title:"Linux Command Line Basics",provider:"Coursera Project Network",url:"https://www.coursera.org/projects/linux-command-line",type:"course",description:"Navigation, permissions, grep, pipes, shell scripts.",sourceDocument:i,track:"Git, Linux & Docker"},{id:"data-jr-tools-3",title:"Docker for the Absolute Beginner — KodeKloud",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/learn-docker/",type:"course",description:"Containers before running local databases and Airflow.",sourceDocument:i,track:"Git, Linux & Docker"},{id:"data-jr-de-1",title:"Data Engineering Zoomcamp — DataTalksClub",provider:"Free",url:"https://github.com/DataTalksClub/data-engineering-zoomcamp",type:"course",description:"One of the strongest free practical paths. Docker, Terraform, orchestration, warehouses, dbt, Spark, Kafka.",sourceDocument:i,track:"Data engineering foundations"},{id:"data-jr-de-2",title:"Fundamentals of Data Engineering — Joe Reis & Matt Housley",provider:"O'Reilly",url:"https://www.oreilly.com/library/view/fundamentals-of-data/9781098108298/",type:"resource",description:"Required reading. Junior focus: lifecycle, generation, storage, ingestion, transformation, serving.",sourceDocument:i,track:"Data engineering foundations"},{id:"data-jr-de-3",title:"ETL and Data Pipelines with Shell, Airflow and Kafka — IBM",provider:"Coursera",url:"https://www.coursera.org/learn/etl-and-data-pipelines-shell-airflow-kafka",type:"course",description:"Hands-on introduction to pipeline construction.",sourceDocument:i,track:"Data engineering foundations"},{id:"data-jr-af-1",title:"The Complete Hands-On Introduction to Apache Airflow 3 — Marc Lamberti",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/the-complete-hands-on-course-to-master-apache-airflow/",type:"course",description:"DAG authoring, operators, scheduling, retries, local setup.",sourceDocument:i,track:"Airflow & orchestration"},{id:"data-jr-af-2",title:"Astronomer Academy: Airflow 101",provider:"Astronomer",url:"https://academy.astronomer.io/path/airflow-101",type:"course",description:"Free. Vendor-quality supplement.",sourceDocument:i,track:"Airflow & orchestration"},{id:"data-jr-aws-1",title:"AWS Certified Cloud Practitioner CLF-C02 — Stephane Maarek",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/aws-certified-cloud-practitioner-new/",type:"course",sourceDocument:i,track:"Cloud — AWS"},{id:"data-jr-aws-2",title:"AWS Skill Builder — Cloud Essentials & Storage paths",provider:"AWS",url:"https://skillbuilder.aws/",type:"resource",description:"Cloud Essentials + Getting Started with Storage.",sourceDocument:i,track:"Cloud — AWS"},{id:"data-jr-az-1",title:"AZ-900: Microsoft Azure Fundamentals — Scott Duffy",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/az900-azure/",type:"course",sourceDocument:i,track:"Cloud — Azure / Fabric"},{id:"data-jr-az-2",title:"Get started with Microsoft Fabric",provider:"Microsoft Learn",url:"https://learn.microsoft.com/en-us/training/paths/get-started-fabric/",type:"course",description:"Beginner-to-intermediate entry into Fabric.",sourceDocument:i,track:"Cloud — Azure / Fabric"},{id:"data-jr-az-3",title:"Implement a Lakehouse with Microsoft Fabric",provider:"Microsoft Learn",url:"https://learn.microsoft.com/en-us/training/paths/implement-lakehouse-microsoft-fabric/",type:"course",sourceDocument:i,track:"Cloud — Azure / Fabric"},{id:"data-jr-gcp-1",title:"Google Cloud Digital Leader Training",provider:"Google Cloud Skills Boost",url:"https://www.cloudskillsboost.google/paths/9",type:"course",sourceDocument:i,track:"Cloud — GCP"},{id:"data-jr-gcp-2",title:"BigQuery for Data Analysts",provider:"Google Cloud Skills Boost",url:"https://www.cloudskillsboost.google/course_templates/865",type:"course",sourceDocument:i,track:"Cloud — GCP"},{id:"data-jr-gcp-3",title:"Preparing for Google Cloud Certification: Cloud Digital Leader",provider:"Coursera",url:"https://www.coursera.org/professional-certificates/google-cloud-digital-leader-training",type:"course",sourceDocument:i,track:"Cloud — GCP"},p("master-anthropic-prompt-eng-tutorial",{track:"AI fluency",sourceDocument:i}),p("master-anthropic-academy",{track:"AI fluency",sourceDocument:i}),p("master-dl-chatgpt-prompt-eng-for-devs",{track:"AI fluency",sourceDocument:i}),p("master-prompting-guide",{track:"AI fluency",sourceDocument:i}),{id:"data-jr-ai-5",title:"Claude Mastery: Prompt Engineering with Claude AI",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/claude-course/",type:"course",sourceDocument:i,track:"AI fluency"},p("master-aef-101",{track:"AEF Platform",sourceDocument:i}),{id:"data-jr-cap-1",title:"Project 1 — CSV-to-Warehouse Pipeline",type:"capstone",description:"Reads CSV files, validates schema/nulls/duplicates/dates, transforms in Python, loads to PostgreSQL/Snowflake/BigQuery/Fabric Warehouse with a simple dimensional model. Includes README.",sourceDocument:i,track:"Capstone projects"},{id:"data-jr-cap-2",title:"Project 2 — API Ingestion Pipeline",type:"capstone",description:"Pulls from a public API (GitHub, OpenWeather, REST Countries, NYC Taxi); handles pagination/errors; stores raw JSON; transforms to analytics tables; schedules via Airflow.",sourceDocument:i,track:"Capstone projects"},{id:"data-jr-cap-3",title:"Project 3 — Mini Data Lake",type:"capstone",description:"Bronze/Silver/Gold layers, data dictionary, 5+ data-quality checks, basic dashboard or query output.",sourceDocument:i,track:"Capstone projects"},{id:"data-jr-grad-1",title:"Can write and explain SQL using joins, CTEs, and window functions",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-jr-grad-2",title:"Can build a basic ETL/ELT pipeline without copying a tutorial",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-jr-grad-3",title:"Can use Git and pull requests correctly",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-jr-grad-4",title:"Can troubleshoot a failed pipeline using logs",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-jr-grad-5",title:"Can explain raw, staged, and curated data layers",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-jr-grad-6",title:"Can use AI to support learning while still owning the final answer",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-jr-grad-7",title:"Has completed three working projects with documentation",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"}]},{level:"Intermediate",originalLevelNames:["Mid-Level Data Engineer (18 months–4 years)"],summary:"16–24 weeks of structured upskilling. Move from implementation to ownership — Spark, lakehouse, dbt, Airflow production patterns, Kafka, CI/CD, observability, and BMAD/Claude Code workflows.",skills:["Advanced SQL — window functions, query tuning, incremental models, surrogate keys, slowly changing dimensions","Apache Spark / PySpark — DataFrames, joins/aggregations, partitioning, caching, file formats, shuffle & skew","Lakehouse architecture — Delta Lake / Iceberg / Hudi; Bronze/Silver/Gold; ACID; schema evolution; time travel","dbt — models, sources, seeds, snapshots, tests, macros, documentation, CI/CD","Airflow production patterns — DAG factories, sensors, task groups, backfills, SLAs, secrets management","Kafka & streaming — topics, consumer groups, offsets, schema registry, exactly-once vs at-least-once","Data quality & observability — freshness, volume, distribution, schema drift, lineage, pipeline health","CI/CD and infrastructure — GitHub Actions / Azure DevOps, Terraform basics, Docker, environment promotion","BMAD for data engineering — Analysis (PRD) → Planning (stories) → Solutioning (architecture) → Implementation","Claude Code with CLAUDE.md, plan mode, patch-sized changes, review every generated diff"],items:[{id:"data-md-sql-1",title:"SQL for Data Analysis: Advanced SQL Querying Techniques — Maven Analytics",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/sql-advanced-queries/",type:"course",description:"Joins, subqueries, CTEs, window functions — production query depth.",sourceDocument:i,track:"Advanced SQL & modeling"},{id:"data-md-sql-2",title:"Data Warehouse Concepts: Basic to Advanced",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/master-datawarehouse-concepts-step-by-step-from-scratch/",type:"course",sourceDocument:i,track:"Advanced SQL & modeling"},{id:"data-md-sql-3",title:"Agile Data Warehouse Design — Lawrence Corr",provider:"Book",url:"https://lawrencecorr.gumroad.com/l/modelstorming",type:"resource",description:"Dimensional modeling driven by business processes.",sourceDocument:i,track:"Advanced SQL & modeling"},{id:"data-md-sql-4",title:"The Data Warehouse Toolkit — Kimball & Ross",provider:"Book",url:"https://www.kimballgroup.com/data-warehouse-business-intelligence-resources/books/data-warehouse-dw-toolkit/",type:"resource",description:"Canonical dimensional modeling reference.",sourceDocument:i,track:"Advanced SQL & modeling"},{id:"data-md-spark-1",title:"Spark and Python for Big Data with PySpark — Jose Portilla",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/spark-and-python-for-big-data-with-pyspark/",type:"course",description:"Strong practical introduction to PySpark.",sourceDocument:i,track:"Spark & distributed processing"},{id:"data-md-spark-2",title:"Taming Big Data with Apache Spark and Python — Frank Kane",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/taming-big-data-with-apache-spark-hands-on/",type:"course",sourceDocument:i,track:"Spark & distributed processing"},{id:"data-md-spark-3",title:"Apache Spark 3 with Scala — Rock the JVM",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/spark-essentials/",type:"course",description:"Spark internals with Scala exposure.",sourceDocument:i,track:"Spark & distributed processing"},{id:"data-md-spark-4",title:"Databricks Certified Associate Developer for Apache Spark",provider:"Databricks",url:"https://www.databricks.com/learn/certification/apache-spark-developer-associate",type:"course",description:"Certification-oriented Spark preparation.",sourceDocument:i,track:"Spark & distributed processing"},{id:"data-md-dbx-1",title:"Databricks Lakehouse Fundamentals",provider:"Databricks Academy",url:"https://www.databricks.com/learn/training/lakehouse-fundamentals",type:"course",description:"Free. Baseline for Databricks-aligned learners.",sourceDocument:i,track:"Databricks & lakehouse"},{id:"data-md-dbx-2",title:"Databricks Data Engineer Learning Plan",provider:"Databricks Academy",url:"https://www.databricks.com/learn/training/data-engineering-courses",type:"course",sourceDocument:i,track:"Databricks & lakehouse"},{id:"data-md-dbx-3",title:"Databricks Certified Data Engineer Associate",provider:"Databricks",url:"https://www.databricks.com/learn/certification/data-engineer-associate",type:"course",description:"Proof of Lakehouse, ingestion, transformation, CI/CD, monitoring, governance.",sourceDocument:i,track:"Databricks & lakehouse"},{id:"data-md-dbx-4",title:"Delta Lake Essentials",provider:"Databricks Academy",url:"https://docs.delta.io/latest/index.html",type:"course",description:"Delta tables, ACID transactions, schema evolution, medallion architecture.",sourceDocument:i,track:"Databricks & lakehouse"},{id:"data-md-ms-1",title:"Implement a Lakehouse with Microsoft Fabric",provider:"Microsoft Learn",url:"https://learn.microsoft.com/en-us/training/paths/implement-lakehouse-microsoft-fabric/",type:"course",description:"Spark, Delta tables, Dataflows Gen2, Fabric Data Factory, orchestration, medallion.",sourceDocument:i,track:"Microsoft Fabric / Azure"},{id:"data-md-ms-2",title:"Microsoft Certified: Fabric Data Engineer Associate (DP-700)",provider:"Microsoft Learn",url:"https://learn.microsoft.com/en-us/credentials/certifications/fabric-data-engineer-associate/",type:"course",description:"Current Microsoft data engineer cert (replaces DP-203).",sourceDocument:i,track:"Microsoft Fabric / Azure"},{id:"data-md-ms-3",title:"Microsoft Fabric Analytics Engineer Associate (DP-600)",provider:"Microsoft Learn",url:"https://learn.microsoft.com/en-us/credentials/certifications/fabric-analytics-engineer-associate/",type:"course",description:"Adjacent cert: semantic models, Power BI, warehouses, lakehouses.",sourceDocument:i,track:"Microsoft Fabric / Azure"},{id:"data-md-sf-1",title:"Snowflake Hands-On Essentials",provider:"Snowflake University",url:"https://learn.snowflake.com/",type:"course",description:"Free. Recommended before Udemy courses.",sourceDocument:i,track:"Snowflake"},{id:"data-md-sf-2",title:"SnowPro Core Certification Preparation",provider:"Snowflake University",url:"https://learn.snowflake.com/en/certifications/snowpro-core/",type:"course",description:"Use the official SnowPro Core study guide as the primary reference.",sourceDocument:i,track:"Snowflake"},{id:"data-md-sf-3",title:"Snowflake — The Complete Masterclass",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/snowflake-masterclass/",type:"course",description:"SQL, loading, virtual warehouses, roles, performance.",sourceDocument:i,track:"Snowflake"},{id:"data-md-sf-4",title:"SnowPro Core Certification",provider:"Snowflake",url:"https://learn.snowflake.com/en/certifications/snowpro-core/",type:"course",description:"Optional certification after 6+ months of hands-on practice.",sourceDocument:i,track:"Snowflake"},{id:"data-md-dbt-1",title:"dbt Fundamentals",provider:"dbt Learn",url:"https://learn.getdbt.com/courses/dbt-fundamentals",type:"course",description:"Free. Required for anyone using dbt.",sourceDocument:i,track:"dbt & analytics engineering"},{id:"data-md-dbt-2",title:"Jinja, Macros, Packages, and Advanced dbt Materializations",provider:"dbt Docs",url:"https://docs.getdbt.com/docs/build/jinja-macros",type:"resource",description:"After dbt Fundamentals.",sourceDocument:i,track:"dbt & analytics engineering"},{id:"data-md-dbt-3",title:"The Complete dbt Bootcamp: Zero to Hero",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/complete-dbt-data-build-tool-bootcamp-zero-to-hero-learn-dbt/",type:"course",sourceDocument:i,track:"dbt & analytics engineering"},{id:"data-md-dbt-4",title:"Analytics Engineering with dbt",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/dbt/",type:"course",description:"Model design, testing, lineage, documentation.",sourceDocument:i,track:"dbt & analytics engineering"},{id:"data-md-af-1",title:"The Complete Hands-On Introduction to Apache Airflow 3 — Marc Lamberti",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/the-complete-hands-on-course-to-master-apache-airflow/",type:"course",description:"Advanced DAG design and deployment sections.",sourceDocument:i,track:"Airflow production patterns"},{id:"data-md-af-2",title:"Astronomer Academy: DAG Authoring and Airflow Best Practices",provider:"Astronomer",url:"https://academy.astronomer.io/",type:"course",description:"Free. Strong production-pattern reference.",sourceDocument:i,track:"Airflow production patterns"},{id:"data-md-kafka-1",title:"Apache Kafka Series: Learn Apache Kafka for Beginners v3 — Stephane Maarek",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/apache-kafka/",type:"course",description:"Core Kafka: topics, producers, consumers, offsets, brokers.",sourceDocument:i,track:"Kafka & streaming"},{id:"data-md-kafka-2",title:"Apache Kafka Series: Kafka Connect Hands-on Learning",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/kafka-connect/",type:"course",description:"Ingestion and connector use cases.",sourceDocument:i,track:"Kafka & streaming"},{id:"data-md-kafka-3",title:"Apache Kafka 101",provider:"Confluent Developer",url:"https://developer.confluent.io/courses/apache-kafka/events/",type:"course",description:"Free vendor-quality conceptual learning.",sourceDocument:i,track:"Kafka & streaming"},{id:"data-md-kafka-4",title:"Designing Event-Driven Microservices",provider:"Confluent Developer",url:"https://developer.confluent.io/courses/event-driven-microservices/",type:"course",description:"Free. Architecture patterns for event-driven systems.",sourceDocument:i,track:"Kafka & streaming"},{id:"data-md-aws-1",title:"AWS Certified Data Engineer – Associate",provider:"AWS",url:"https://aws.amazon.com/certification/certified-data-engineer-associate/",type:"course",description:"Validates ingestion, transformation, orchestration, modeling, lifecycle, quality.",sourceDocument:i,track:"Cloud certifications — AWS"},{id:"data-md-aws-2",title:"AWS Certified Data Engineer Associate DEA-C01 — Stephane Maarek",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/aws-data-engineer/",type:"course",description:"Exam prep alongside AWS Skill Builder.",sourceDocument:i,track:"Cloud certifications — AWS"},{id:"data-md-aws-3",title:"AWS Glue, Redshift, Athena, Kinesis, Lake Formation paths",provider:"AWS Skill Builder",url:"https://skillbuilder.aws/",type:"resource",description:"Use based on project stack.",sourceDocument:i,track:"Cloud certifications — AWS"},{id:"data-md-gcp-1",title:"Professional Data Engineer Certification Learning Path",provider:"Google Cloud Skills Boost",url:"https://www.cloudskillsboost.google/paths/16",type:"course",sourceDocument:i,track:"Cloud certifications — GCP"},{id:"data-md-gcp-2",title:"Preparing for Google Cloud Certification: Cloud Data Engineer",provider:"Coursera",url:"https://www.coursera.org/professional-certificates/gcp-data-engineering",type:"course",description:"BigQuery, Dataflow, Pub/Sub, Dataproc, Composer.",sourceDocument:i,track:"Cloud certifications — GCP"},{id:"data-md-gcp-3",title:"Google Cloud Professional Data Engineer Certification",provider:"Google Cloud",url:"https://cloud.google.com/learn/certification/data-engineer",type:"course",sourceDocument:i,track:"Cloud certifications — GCP"},{id:"data-md-ms-cert-1",title:"Microsoft Fabric Data Engineer Associate (DP-700)",provider:"Microsoft Learn",url:"https://learn.microsoft.com/en-us/credentials/certifications/fabric-data-engineer-associate/",type:"course",sourceDocument:i,track:"Cloud certifications — Azure / Fabric"},{id:"data-md-ms-cert-2",title:"Data Factory, OneLake, Fabric Warehouse, Spark, Delta Lake modules",provider:"Microsoft Learn",url:"https://learn.microsoft.com/en-us/fabric/",type:"resource",sourceDocument:i,track:"Cloud certifications — Azure / Fabric"},{id:"data-md-ai-1",title:"Anthropic Academy: Claude Code",provider:"Anthropic",url:"https://anthropic.skilljar.com/claude-code-101",type:"course",sourceDocument:i,track:"AI fluency"},{id:"data-md-ai-2",title:"Anthropic: Prompting Best Practices",provider:"Anthropic",url:"https://docs.claude.com/en/docs/build-with-claude/prompt-engineering/overview",type:"resource",sourceDocument:i,track:"AI fluency"},{id:"data-md-ai-3",title:"BMAD Method Documentation",provider:"BMAD",url:"https://docs.bmad-method.org/",type:"resource",sourceDocument:i,track:"AI fluency"},{id:"data-md-ai-4",title:"Generative AI for Software Developers",provider:"Coursera",url:"https://www.coursera.org/learn/generative-ai-for-software-developers",type:"course",sourceDocument:i,track:"AI fluency"},{id:"data-md-ai-5",title:"ChatGPT, Claude, Cursor and GitHub Copilot — AI Coding Bootcamp",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/ai-coding/",type:"course",sourceDocument:i,track:"AI fluency"},{id:"data-md-ai-6",title:"GitHub Copilot for Developers — GitHub Skills",provider:"GitHub",url:"https://github.com/skills",type:"course",sourceDocument:i,track:"AI fluency"},p("master-aef-201",{track:"AEF Platform",sourceDocument:i}),{id:"data-md-cap-1",title:"Option 1 — Modern ELT Platform",type:"capstone",description:"Airflow + dbt + warehouse (Snowflake/BigQuery/Fabric/Redshift) + GitHub Actions/Azure DevOps + tests. Deliverables: PRD, architecture diagram, source-to-target mapping, dbt models with tests/docs, CI/CD, monitoring plan, runbook, AI workflow log.",sourceDocument:i,track:"Capstone (choose one)"},{id:"data-md-cap-2",title:"Option 2 — Lakehouse Pipeline",type:"capstone",description:"Databricks or Microsoft Fabric + Delta Lake + PySpark + medallion + Unity Catalog/Fabric governance. Deliverables: Bronze/Silver/Gold design, PySpark notebooks, incremental processing, DQ checks, cost/perf notes, runbook.",sourceDocument:i,track:"Capstone (choose one)"},{id:"data-md-cap-3",title:"Option 3 — Streaming Analytics Pipeline",type:"capstone",description:"Kafka + Kafka Connect/producer + Spark Structured Streaming or Flink + lakehouse/warehouse sink + dashboard. Deliverables: event schema, topic design, consumer strategy, failure/replay strategy, monitoring, data contract.",sourceDocument:i,track:"Capstone (choose one)"},{id:"data-md-grad-1",title:"Has shipped at least one production-grade data feature or equivalent capstone",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-md-grad-2",title:"Can explain trade-offs across warehouse, lakehouse, and streaming patterns",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-md-grad-3",title:"Can write and optimize Spark or distributed processing jobs",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-md-grad-4",title:"Can build dbt models with tests and documentation",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-md-grad-5",title:"Can design reliable Airflow DAGs",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-md-grad-6",title:"Can implement CI/CD and data quality checks",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-md-grad-7",title:"Can use AI in a structured workflow and document its role",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-md-grad-8",title:"Can mentor a junior engineer through a real data engineering task",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-md-grad-9",title:"Has measurably improved reliability, cost, performance, quality, or maintainability",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"}]},{level:"Advanced",originalLevelNames:["Senior Data Engineer (4+ years)"],summary:"Ongoing. Shape platforms, standards, governance, delivery models, and team capability. A Senior Data Engineer designs systems, multiplies teams, and stewards trusted enterprise data.",skills:["Enterprise data architecture — data mesh, lakehouse strategy, warehouse modernization, data product thinking, domain-oriented ownership","Distributed systems design — fault tolerance, scalability, partitioning, backpressure, replay and recovery","Streaming architecture — event-driven systems, schema evolution, exactly-once vs at-least-once, stream-table duality","Governance and security — RBAC/ABAC, data classification, lineage, masking, encryption, regulatory controls","Platform engineering — golden paths, self-service templates, IaC, CI/CD standardization, observability by default","Cost and performance engineering — warehouse sizing, partitioning/clustering, file compaction, Spark optimization, cost guardrails","BMAD as standard practice — define when BMAD is required, author templates, train mid-level engineers","MCP and tool integration — connect AI tools to GitHub/ADO, Jira, Databricks, Snowflake, dbt metadata, catalog/lineage, observability","Custom skills & reusable prompts — data modeling templates, dbt style guides, DAG review checklists, Spark optimization templates, DQ generators","Leadership and influence — architecture reviews, technical strategy, coaching, hiring input, cross-team decisions"],items:[{id:"data-sr-arch-1",title:"Designing Data-Intensive Applications — Martin Kleppmann",provider:"O'Reilly",url:"https://dataintensive.net/",type:"resource",description:"Required reading. Storage, replication, partitioning, transactions, distributed systems, batch & stream processing.",sourceDocument:i,track:"Architecture & systems thinking"},{id:"data-sr-arch-2",title:"Fundamentals of Data Engineering — Reis & Housley (revisit)",provider:"O'Reilly",url:"https://www.oreilly.com/library/view/fundamentals-of-data/9781098108298/",type:"resource",description:"Revisit with emphasis on lifecycle design, architecture, security, DataOps, orchestration.",sourceDocument:i,track:"Architecture & systems thinking"},{id:"data-sr-arch-3",title:"Software Architecture: The Hard Parts — Ford, Richards, Sadalage, Dehghani",provider:"O'Reilly",url:"https://www.oreilly.com/library/view/software-architecture-the/9781492086888/",type:"resource",description:"Trade-off-driven architecture thinking.",sourceDocument:i,track:"Architecture & systems thinking"},{id:"data-sr-arch-4",title:"System Design — Senior-level courses",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/system-design/",type:"resource",description:"Strengthen communication of distributed architecture decisions.",sourceDocument:i,track:"Architecture & systems thinking"},{id:"data-sr-gov-1",title:"Data Mesh — Zhamak Dehghani",provider:"O'Reilly",url:"https://www.oreilly.com/library/view/data-mesh/9781492092384/",type:"resource",description:"Decentralized ownership and data product thinking.",sourceDocument:i,track:"Data architecture, mesh & governance"},{id:"data-sr-gov-2",title:"Data Management at Scale — Piethein Strengholt",provider:"O'Reilly",url:"https://www.oreilly.com/library/view/data-management-at/9781098138851/",type:"resource",description:"Practical data platform and governance patterns.",sourceDocument:i,track:"Data architecture, mesh & governance"},{id:"data-sr-gov-3",title:"DAMA-DMBOK Data Management Body of Knowledge",provider:"DAMA International",url:"https://www.dama.org/cpages/body-of-knowledge",type:"resource",description:"Reference for governance, metadata, quality, security, architecture.",sourceDocument:i,track:"Data architecture, mesh & governance"},{id:"data-sr-gov-4",title:"Enterprise Data Governance — browse catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/data-governance/",type:"resource",description:"Choose based on client technology and account context.",sourceDocument:i,track:"Data architecture, mesh & governance"},{id:"data-sr-str-1",title:"Designing Event-Driven Systems — Ben Stopford",provider:"Confluent",url:"https://www.confluent.io/designing-event-driven-systems/",type:"resource",description:"Required reading for Kafka/event-driven architecture leads.",sourceDocument:i,track:"Streaming & real-time systems"},{id:"data-sr-str-2",title:"Streaming Systems — Akidau, Chernyak, Lax",provider:"O'Reilly",url:"https://www.oreilly.com/library/view/streaming-systems/9781491983867/",type:"resource",description:"Time, windows, triggers, streaming correctness.",sourceDocument:i,track:"Streaming & real-time systems"},{id:"data-sr-str-3",title:"Apache Kafka Series: Kafka Streams for Data Processing — Stephane Maarek",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/course/kafka-streams/",type:"course",sourceDocument:i,track:"Streaming & real-time systems"},{id:"data-sr-str-4",title:"Apache Flink 101",provider:"Confluent Developer",url:"https://developer.confluent.io/courses/apache-flink/intro/",type:"course",description:"Free. For teams adopting Flink.",sourceDocument:i,track:"Streaming & real-time systems"},{id:"data-sr-str-5",title:"Designing Event-Driven Microservices",provider:"Confluent Developer",url:"https://developer.confluent.io/courses/event-driven-microservices/",type:"course",description:"Free. Architecture resource for event-driven design.",sourceDocument:i,track:"Streaming & real-time systems"},{id:"data-sr-plat-1",title:"Databricks Certified Data Engineer Professional",provider:"Databricks",url:"https://www.databricks.com/learn/certification/data-engineer-professional",type:"course",description:"For Senior engineers working heavily on Databricks.",sourceDocument:i,track:"Advanced platforms"},{id:"data-sr-plat-2",title:"Databricks Platform Architect learning paths",provider:"Databricks Academy",url:"https://www.databricks.com/learn/training",type:"resource",description:"Platform leads and architects.",sourceDocument:i,track:"Advanced platforms"},{id:"data-sr-plat-3",title:"SnowPro Advanced: Architect",provider:"Snowflake",url:"https://learn.snowflake.com/en/certifications/snowpro-advanced-architect/",type:"course",description:"For Senior Snowflake platform owners.",sourceDocument:i,track:"Advanced platforms"},{id:"data-sr-plat-4",title:"Microsoft Fabric Data Engineer Associate (DP-700)",provider:"Microsoft Learn",url:"https://learn.microsoft.com/en-us/credentials/certifications/fabric-data-engineer-associate/",type:"course",description:"Current Microsoft data engineering baseline.",sourceDocument:i,track:"Advanced platforms"},{id:"data-sr-plat-5",title:"Google Cloud Professional Data Engineer",provider:"Google Cloud",url:"https://cloud.google.com/learn/certification/data-engineer",type:"course",sourceDocument:i,track:"Advanced platforms"},{id:"data-sr-plat-6",title:"AWS Certified Data Engineer – Associate",provider:"AWS",url:"https://aws.amazon.com/certification/certified-data-engineer-associate/",type:"course",description:"Pair with architecture and security depth.",sourceDocument:i,track:"Advanced platforms"},{id:"data-sr-ops-1",title:"DataOps Methodology",provider:"Coursera (IBM)",url:"https://www.coursera.org/learn/dataops-methodology",type:"course",description:"Release discipline, testing, orchestration, operations.",sourceDocument:i,track:"DataOps & platform engineering"},{id:"data-sr-ops-2",title:"Great Expectations Core Concepts",provider:"Great Expectations",url:"https://docs.greatexpectations.io/docs/oss/tutorials/quickstart/",type:"resource",description:"Data validation frameworks.",sourceDocument:i,track:"DataOps & platform engineering"},{id:"data-sr-ops-3",title:"OpenLineage & Marquez documentation",provider:"OpenLineage",url:"https://openlineage.io/docs/",type:"resource",description:"Lineage and observability architecture.",sourceDocument:i,track:"DataOps & platform engineering"},{id:"data-sr-ops-4",title:"Terraform: Up & Running — Yevgeniy Brikman",provider:"O'Reilly",url:"https://www.terraformupandrunning.com/",type:"resource",description:"Infrastructure-as-code standards.",sourceDocument:i,track:"DataOps & platform engineering"},{id:"data-sr-ops-5",title:"GitHub Actions: The Complete Guide",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/github-actions/",type:"course",description:"CI/CD standardization where GitHub is the delivery platform.",sourceDocument:i,track:"DataOps & platform engineering"},{id:"data-sr-lead-1",title:"Staff Engineer — Will Larson",provider:"Book",url:"https://staffeng.com/book",type:"resource",description:"Senior-to-Staff growth.",sourceDocument:i,track:"Engineering leadership"},{id:"data-sr-lead-2",title:"An Elegant Puzzle — Will Larson",provider:"Book",url:"https://lethain.com/elegant-puzzle/",type:"resource",description:"Operating model and engineering leadership reference.",sourceDocument:i,track:"Engineering leadership"},{id:"data-sr-lead-3",title:"The Manager's Path — Camille Fournier",provider:"O'Reilly",url:"https://www.oreilly.com/library/view/the-managers-path/9781491973882/",type:"resource",description:"Whether staying IC or moving toward management.",sourceDocument:i,track:"Engineering leadership"},{id:"data-sr-lead-4",title:"Engineering Leadership — browse catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/leadership/",type:"resource",description:"Mentorship and influence.",sourceDocument:i,track:"Engineering leadership"},{id:"data-sr-ai-1",title:"Anthropic — Building Effective Agents",provider:"Anthropic",url:"https://www.anthropic.com/research/building-effective-agents",type:"resource",sourceDocument:i,track:"AI fluency"},{id:"data-sr-ai-2",title:"Anthropic — Model Context Protocol documentation",provider:"Anthropic",url:"https://modelcontextprotocol.io",type:"resource",sourceDocument:i,track:"AI fluency"},{id:"data-sr-ai-3",title:"BMAD Method advanced documentation",provider:"BMAD",url:"https://docs.bmad-method.org/",type:"resource",sourceDocument:i,track:"AI fluency"},{id:"data-sr-ai-4",title:"Building Agentic AI Applications & Multi-Agent Systems — browse catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/ai-agents/",type:"resource",sourceDocument:i,track:"AI fluency"},{id:"data-sr-ai-5",title:"AI Governance, Ethics & Responsible AI — browse catalog",provider:"Udemy Business",url:"https://deloittedevelopment.udemy.com/topic/ai-governance/",type:"resource",sourceDocument:i,track:"AI fluency"},{id:"data-sr-ai-6",title:"GitHub Copilot for Business / Enterprise administration",provider:"GitHub",url:"https://docs.github.com/en/copilot/managing-copilot/managing-copilot-for-your-enterprise",type:"resource",sourceDocument:i,track:"AI fluency"},{id:"data-sr-cap-1",title:"Option 1 — Enterprise Lakehouse Modernization",type:"capstone",description:"Lead a modernization initiative: current-state assessment, target-state architecture, platform selection rationale, migration strategy, governance model, cost model, performance benchmarking, DQ framework, rollout plan, executive-ready summary.",sourceDocument:i,track:"Capstone (choose one)"},{id:"data-sr-cap-2",title:"Option 2 — Streaming Data Platform",type:"capstone",description:"Design a streaming platform blueprint: topic strategy, event schema standards, schema registry, replay/recovery, monitoring/alerting, data contracts, security model, consumer onboarding, SLA/SLOs.",sourceDocument:i,track:"Capstone (choose one)"},{id:"data-sr-cap-3",title:"Option 3 — Data Engineering Golden Path",type:"capstone",description:"Reusable internal accelerator: standard repo structure, pipeline template, dbt/Spark template, CI/CD workflow, DQ framework, observability hooks, doc templates, AI-assisted prompts, review checklist, onboarding guide.",sourceDocument:i,track:"Capstone (choose one)"},{id:"data-sr-cap-4",title:"Option 4 — AI-Native Data Engineering Operating Model",type:"capstone",description:"Define team AI use: approved/prohibited use cases, prompt library, BMAD templates, AI code-review pattern, privacy/security guardrails, productivity & quality metrics, rollout plan, training plan, governance cadence.",sourceDocument:i,track:"Capstone (choose one)"},{id:"data-sr-grad-1",title:"Has led architecture for a platform, domain, or major modernization effort",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-sr-grad-2",title:"Can evaluate build-vs-buy and platform trade-offs",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-sr-grad-3",title:"Can design for reliability, quality, governance, security, and cost",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-sr-grad-4",title:"Can lead cross-team architecture reviews",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-sr-grad-5",title:"Can create reusable standards and accelerators",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-sr-grad-6",title:"Can mentor multiple engineers",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-sr-grad-7",title:"Can define team-level AI usage standards",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-sr-grad-8",title:"Can communicate technical decisions to engineering and non-engineering stakeholders",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"},{id:"data-sr-grad-9",title:"Can turn ambiguous business needs into durable data platform outcomes",type:"graduation-criteria",sourceDocument:i,track:"Graduation criteria"}]}]},sr={personaId:"devops",displayName:"DevOps / Infrastructure",sourcePathwayNames:[],mappingStatus:"provisional",mappingNotes:"Full DevOps / Infrastructure pathway document pending. AEF platform resources shown in the meantime.",levels:ar},nr=[{category:"AI Core & Tooling",links:[{name:"Claude (claude.ai)",url:"https://claude.ai"},{name:"Anthropic Academy",url:"https://www.anthropic.com/learn"},{name:"Prompt Eng. Tutorial",url:"https://github.com/anthropics/prompt-eng-interactive-tutorial"},{name:"BMAD Method Repo",url:"https://github.com/bmad-code-org/BMAD-METHOD"},{name:"BMAD Docs",url:"https://docs.bmad-method.org/"},{name:"Claude Code Docs",url:"https://docs.claude.com/en/docs/agents-and-tools/claude-code/overview"},{name:"Model Context Protocol",url:"https://modelcontextprotocol.io/"},{name:"Anthropic Engineering Blog",url:"https://www.anthropic.com/engineering"}]},{category:"Product & Discovery",links:[{name:"GenAI for Everyone — Ng",url:"https://www.coursera.org/learn/generative-ai-for-everyone"},{name:"AI Prompting for Everyone",url:"https://www.deeplearning.ai/courses/ai-prompting-for-everyone/"},{name:"Duke AI PM Specialization",url:"https://www.coursera.org/specializations/ai-product-management-duke"},{name:"IBM AI Product Manager Cert",url:"https://www.coursera.org/professional-certificates/ibm-ai-product-manager"},{name:"Continuous Discovery Habits",url:"https://www.producttalk.org/"},{name:"Evaluating & Debugging GenAI",url:"https://www.deeplearning.ai/short-courses/evaluating-debugging-generative-ai/"}]},{category:"Strategy, Governance & Depth",links:[{name:"NIST AI Risk Management Framework",url:"https://www.nist.gov/itl/ai-risk-management-framework"},{name:"EU AI Act Overview",url:"https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai"},{name:"GenAI with LLMs",url:"https://www.coursera.org/learn/generative-ai-with-llms"},{name:"Google GenAI Leader Path",url:"https://www.cloudskillsboost.google/paths/1779"},{name:"Harvard CS50 AI",url:"https://cs50.harvard.edu/ai/"},{name:"AI for Everyone (leadership)",url:"https://www.coursera.org/learn/ai-for-everyone"}]}],cr=[{name:"Claude + Claude Projects",url:"https://claude.ai",description:"Primary everyday assistant; open a Project, add context, build a prompt library"},{name:"BMAD Method",url:"https://github.com/bmad-code-org/BMAD-METHOD",description:"Structured workflow: Analyst → PM → Architect → PO on real product work"},{name:"Claude Code",url:"https://docs.claude.com/en/docs/agents-and-tools/claude-code/overview",description:"Agentic CLI for scheduled workflows, file synthesis, and MCP integration"},{name:"Model Context Protocol",url:"https://modelcontextprotocol.io/",description:"Connect Claude agents to Jira, Confluence, support inboxes, analytics"},{name:"Anthropic Academy",url:"https://www.anthropic.com/learn",description:"Official short courses on Claude, prompting, and Claude Code"},{name:"Generative AI for Everyone",url:"https://www.coursera.org/learn/generative-ai-for-everyone",description:"Andrew Ng — the single best non-technical GenAI intro (audit free)"},{name:"Duke AI PM Specialization",url:"https://www.coursera.org/specializations/ai-product-management-duke",description:"Deepest free option for AI product roles — audit free"},{name:"Prompt Eng. Tutorial",url:"https://github.com/anthropics/prompt-eng-interactive-tutorial",description:"9-chapter interactive tutorial — the required starting point"}],lr=[{category:"AI Core & BMAD",links:[{name:"Claude + Claude Code",url:"https://claude.ai"},{name:"Prompt Eng. Tutorial",url:"https://github.com/anthropics/prompt-eng-interactive-tutorial"},{name:"Building Effective Agents",url:"https://www.anthropic.com/engineering/building-effective-agents"},{name:"BMAD Method Repo",url:"https://github.com/bmad-code-org/BMAD-METHOD"},{name:"Claude Code Docs",url:"https://docs.anthropic.com/en/docs/claude-code"},{name:"Model Context Protocol",url:"https://modelcontextprotocol.io"},{name:"Anthropic Cookbook",url:"https://github.com/anthropics/anthropic-cookbook"}]},{category:"Architecture Fundamentals",links:[{name:"Martin Fowler's Architecture",url:"https://martinfowler.com/architecture/"},{name:"System Design Primer",url:"https://github.com/donnemartin/system-design-primer"},{name:"The C4 Model",url:"https://c4model.com"},{name:"12 Factor App",url:"https://12factor.net"},{name:"roadmap.sh — Software Architect",url:"https://roadmap.sh/software-architect"},{name:"AWS Well-Architected Framework",url:"https://aws.amazon.com/architecture/well-architected/"},{name:"Azure Architecture Center",url:"https://learn.microsoft.com/en-us/azure/architecture/"},{name:"Google Cloud Architecture Framework",url:"https://cloud.google.com/architecture/framework"}]},{category:"Advanced & Enterprise",links:[{name:"CNCF Landscape",url:"https://landscape.cncf.io/"},{name:"ThoughtWorks Technology Radar",url:"https://www.thoughtworks.com/radar"},{name:"CNCF End User Tech Radar",url:"https://radar.cncf.io/"},{name:"InfoQ Architecture & Design",url:"https://www.infoq.com/architecture-design/"},{name:"NIST AI Risk Management Framework",url:"https://www.nist.gov/artificial-intelligence/ai-risk-management-framework"},{name:"MCP Server Authoring Guide",url:"https://modelcontextprotocol.io/docs/concepts/servers"},{name:"Udemy Business SSO",url:"https://deloittedevelopment.udemy.com"}]}],dr=[{name:"Claude + Claude Code",url:"https://claude.ai",description:"Primary AI collaborator for analysis, generation, and implementation oversight"},{name:"BMAD Method",url:"https://github.com/bmad-code-org/BMAD-METHOD",description:"Structured Agentic PDLC — all personas, Party Mode, custom agents via BMad Builder"},{name:"Model Context Protocol",url:"https://modelcontextprotocol.io",description:"Connect AI agents to Jira, GitHub, Confluence, SonarQube, internal systems"},{name:"Claude Skills",url:"https://github.com/anthropics/skills",description:"Reusable SKILL.md packages encoding architecture patterns and org standards"},{name:"GitHub Copilot / Cursor",url:"https://github.com/features/copilot",description:"AI-native IDE workflows for implementation oversight and code review"},{name:"C4 Model / Structurizr",url:"https://c4model.com",description:"Architecture diagramming as code — Context, Container, Component, Code levels"},{name:"Martin Fowler's Architecture",url:"https://martinfowler.com/architecture/",description:"Canonical patterns reference for architectural decision making"},{name:"System Design Primer",url:"https://github.com/donnemartin/system-design-primer",description:"Comprehensive system design reference (Donne Martin, GitHub)"}],pr=[{category:"AI Core",links:[{name:"Claude (claude.ai)",url:"https://claude.ai"},{name:"Anthropic Academy",url:"https://www.anthropic.com/learn"},{name:"Prompt Eng. Tutorial",url:"https://github.com/anthropics/prompt-eng-interactive-tutorial"},{name:"Claude Code Docs",url:"https://docs.claude.com/en/docs/claude-code/overview"},{name:"Figma MCP + Claude Blog",url:"https://www.figma.com/blog/think-outside-of-the-box-with-claude-and-figjam/"},{name:"UX Pilot Plugin",url:"https://uxpilot.ai/"},{name:"BMAD Method Repo",url:"https://github.com/bmad-code-org/BMAD-METHOD"},{name:"Claude Skills Repo",url:"https://github.com/anthropics/skills"},{name:"MCP",url:"https://modelcontextprotocol.io"}]},{category:"Design & Research",links:[{name:"Figma Learn Academy",url:"https://www.figma.com/resources/learn-design/"},{name:"NN/g Articles",url:"https://www.nngroup.com/articles/"},{name:"Laws of UX",url:"https://lawsofux.com/"},{name:"Mobbin",url:"https://mobbin.com/"},{name:"Material Design 3",url:"https://m3.material.io/"},{name:"Apple HIG",url:"https://developer.apple.com/design/human-interface-guidelines/"},{name:"WCAG 2.2 Quick Ref",url:"https://www.w3.org/WAI/WCAG22/quickref/"},{name:"Google PAIR Guidebook",url:"https://pair.withgoogle.com/guidebook/"},{name:"Microsoft HAX Toolkit",url:"https://www.microsoft.com/en-us/haxtoolkit/"},{name:"ADPList",url:"https://adplist.org/"}]},{category:"UI Engineering",links:[{name:"The Odin Project",url:"https://www.theodinproject.com/"},{name:"MDN Curriculum",url:"https://developer.mozilla.org/en-US/curriculum/"},{name:"React.dev",url:"https://react.dev/learn"},{name:"JavaScript.info",url:"https://javascript.info/"},{name:"web.dev — Learn",url:"https://web.dev/learn/"},{name:"Frontend Roadmap",url:"https://roadmap.sh/frontend"},{name:"React Roadmap",url:"https://roadmap.sh/react"},{name:"Playwright Docs",url:"https://playwright.dev"},{name:"Udemy Business SSO",url:"https://www.udemy.com/organization/home"}]}],ur=[{name:"Claude (Artifacts + Code)",url:"https://claude.ai",description:"Generative prototyping, research synthesis, microcopy, and production coding"},{name:"Figma + Figma MCP",url:"https://www.figma.com",description:"Core design platform; MCP turns Claude conversations into FigJam flows"},{name:"UX Pilot (Figma plugin)",url:"https://uxpilot.ai/",description:"AI wireframe and screen generation inside Figma"},{name:"Claude Code",url:"https://docs.claude.com/en/docs/claude-code/overview",description:"Agentic coding CLI; CLAUDE.md, Plan Mode, MCP"},{name:"BMAD Method",url:"https://github.com/bmad-code-org/BMAD-METHOD",description:"Spec-to-ship structured AI delivery framework"},{name:"Claude Skills",url:"https://github.com/anthropics/skills",description:"SKILL.md encoding team conventions for Claude"},{name:"Playwright",url:"https://playwright.dev",description:"Modern E2E testing; write tests as part of feature work"},{name:"NN/g Articles",url:"https://www.nngroup.com/articles/",description:"The canonical UX research reference"}],mr=[{category:"AI Core",links:[{name:"Claude + Claude Code",url:"https://claude.ai"},{name:"Anthropic Academy",url:"https://www.anthropic.com/learn"},{name:"Prompt Eng. Tutorial",url:"https://github.com/anthropics/prompt-eng-interactive-tutorial"},{name:"Prompting Best Practices",url:"https://docs.claude.com/en/docs/build-with-claude/prompt-engineering/overview"},{name:"Claude Code Docs",url:"https://docs.claude.com/en/docs/claude-code"},{name:"Building Effective Agents",url:"https://www.anthropic.com/engineering/building-effective-agents"},{name:"Claude Skills Repo",url:"https://github.com/anthropics/skills"}]},{category:"BMAD & MCP",links:[{name:"BMAD Method Repo",url:"https://github.com/bmad-code-org/BMAD-METHOD"},{name:"BMAD Docs",url:"https://docs.bmad-method.org/"},{name:"Model Context Protocol",url:"https://modelcontextprotocol.io"},{name:"Claude Skills Repo",url:"https://github.com/anthropics/skills"}]},{category:"Engineering & Platform",links:[{name:"Backend Roadmap",url:"https://roadmap.sh/backend"},{name:"OWASP Top 10",url:"https://owasp.org/www-project-top-ten"},{name:"OpenTelemetry",url:"https://opentelemetry.io/docs"},{name:"Prompt Engineering Guide",url:"https://www.promptingguide.ai/"},{name:"Udemy Business SSO",url:"https://www.udemy.com/organization/home"}]},{category:"Eval & Observability",links:[{name:"Promptfoo",url:"https://www.promptfoo.dev"},{name:"DeepEval",url:"https://www.deepeval.com"},{name:"Braintrust",url:"https://www.braintrust.dev"},{name:"Langfuse",url:"https://langfuse.com"},{name:"LangSmith",url:"https://smith.langchain.com"},{name:"Eugene Yan — Evals",url:"https://eugeneyan.com/writing/evals/"},{name:"Hamel — Evals Blog",url:"https://hamel.dev/blog/posts/evals/"},{name:"Google SRE Books",url:"https://sre.google/books"}]},{category:"Security & Standards",links:[{name:"OWASP LLM Top 10",url:"https://genai.owasp.org/llm-top-10/"},{name:"MITRE ATLAS",url:"https://atlas.mitre.org"},{name:"Lakera Gandalf",url:"https://gandalf.lakera.ai"},{name:"NIST AI RMF",url:"https://www.nist.gov/itl/ai-risk-management-framework"}]},{category:"Testing & Platform",links:[{name:"Playwright Docs",url:"https://playwright.dev"},{name:"Playwright MCP",url:"https://github.com/microsoft/playwright-mcp"},{name:"Pact Contract Testing",url:"https://docs.pact.io"},{name:"k6",url:"https://k6.io/docs"},{name:"Bach HTSM",url:"https://www.satisfice.com/download/heuristic-test-strategy-model"},{name:"MCP Spec",url:"https://modelcontextprotocol.io"}]}],gr=[{name:"Claude + Claude Code",url:"https://claude.ai",description:"Primary AI collaborator for coding, review, agentic workflows and test design"},{name:"BMAD Method",url:"https://github.com/bmad-code-org/BMAD-METHOD",description:"Structured delivery: PRD → ADR → Story → Ship"},{name:"Model Context Protocol",url:"https://modelcontextprotocol.io",description:"Standard for connecting Claude to external tools"},{name:"Claude Skills",url:"https://github.com/anthropics/skills",description:"SKILL.md files encoding team conventions for Claude"},{name:"OpenTelemetry",url:"https://opentelemetry.io/docs",description:"Distributed tracing, metrics and observability"},{name:"Playwright MCP",url:"https://github.com/microsoft/playwright-mcp",description:"Enables Claude to drive a browser for agentic UI exploration"},{name:"Promptfoo / DeepEval",url:"https://www.promptfoo.dev",description:"Open-source eval frameworks for prompt and model regression testing"},{name:"Braintrust / Langfuse",url:"https://www.braintrust.dev",description:"Eval observability, traces, datasets, scoring at production scale"},{name:"OWASP LLM Top 10",url:"https://genai.owasp.org/llm-top-10/",description:"Threat catalogue for AI-feature testing and red-team exercises"},{name:"MITRE ATLAS",url:"https://atlas.mitre.org",description:"Adversarial ML threat framework mapped to mitigations"}],hr=[{category:"AI Core & Anthropic Academy",links:[{name:"Anthropic Academy (Skilljar)",url:"https://anthropic.skilljar.com/"},{name:"Claude 101",url:"https://anthropic.skilljar.com/claude-101"},{name:"AI Fluency Framework",url:"https://anthropic.skilljar.com/ai-fluency-framework-foundations"},{name:"Intro to MCP",url:"https://anthropic.skilljar.com/introduction-to-model-context-protocol"},{name:"Intro to Agent Skills",url:"https://anthropic.skilljar.com/introduction-to-agent-skills"},{name:"Building Effective Agents",url:"https://www.anthropic.com/engineering/building-effective-agents"},{name:"Anthropic Cookbook",url:"https://github.com/anthropics/anthropic-cookbook"},{name:"Prompt Eng. Tutorial",url:"https://github.com/anthropics/prompt-eng-interactive-tutorial"},{name:"Claude Prompt Library",url:"https://docs.claude.com/en/prompt-library/library"}]},{category:"DeepLearning.AI & Hugging Face",links:[{name:"DeepLearning.AI Courses",url:"https://www.deeplearning.ai/courses"},{name:"Generative AI for Everyone",url:"https://www.deeplearning.ai/courses/generative-ai-for-everyone/"},{name:"Agentic AI — Andrew Ng",url:"https://www.deeplearning.ai/courses/agentic-ai/"},{name:"AI Agents in LangGraph",url:"https://www.deeplearning.ai/short-courses/ai-agents-in-langgraph/"},{name:"Multi-Agent with CrewAI",url:"https://www.deeplearning.ai/short-courses/multi-ai-agent-systems-with-crewai/"},{name:"Advanced RAG",url:"https://www.deeplearning.ai/short-courses/building-evaluating-advanced-rag/"},{name:"HF Learn",url:"https://huggingface.co/learn"},{name:"HF Agents Course",url:"https://huggingface.co/learn/agents-course"},{name:"HF MCP Course",url:"https://huggingface.co/learn/mcp-course"}]},{category:"Frameworks, Evals, Cloud & Governance",links:[{name:"MCP Spec",url:"https://modelcontextprotocol.io/"},{name:"MCP Servers Repo",url:"https://github.com/modelcontextprotocol/servers"},{name:"LangGraph",url:"https://github.com/langchain-ai/langgraph"},{name:"CrewAI",url:"https://github.com/crewAIInc/crewAI"},{name:"AutoGen",url:"https://github.com/microsoft/autogen"},{name:"LangSmith Docs",url:"https://docs.smith.langchain.com/"},{name:"Langfuse Docs",url:"https://langfuse.com/docs"},{name:"Arize Phoenix",url:"https://docs.arize.com/phoenix"},{name:"Microsoft AI Agents for Beginners",url:"https://github.com/microsoft/ai-agents-for-beginners"},{name:"Google Cloud Skills Boost",url:"https://www.cloudskillsboost.google/"},{name:"NIST AI RMF",url:"https://www.nist.gov/itl/ai-risk-management-framework"},{name:"EU AI Act Overview",url:"https://digital-strategy.ec.europa.eu/en/policies/regulatory-framework-ai"},{name:"BMAD Docs",url:"https://docs.bmad-method.org/"},{name:"Udemy Business (Deloitte SSO)",url:"https://deloittedevelopment.udemy.com/organization/home/"}]}],fr=[{name:"Claude + Claude Code",url:"https://claude.ai",description:"Primary AI collaborator across all three phases"},{name:"Anthropic Academy (Skilljar)",url:"https://anthropic.skilljar.com/",description:"Authoritative free courses on Claude, MCP, and Agent Skills"},{name:"DeepLearning.AI Courses",url:"https://www.deeplearning.ai/courses",description:"Andrew Ng's flagship GenAI and Agentic AI curriculum"},{name:"Hugging Face Learn",url:"https://huggingface.co/learn",description:"Agents Course, MCP Course (with Anthropic), LLM Course"},{name:"Model Context Protocol",url:"https://modelcontextprotocol.io/",description:"Canonical MCP specification"},{name:"Anthropic Cookbook",url:"https://github.com/anthropics/anthropic-cookbook",description:"Production-quality reference notebooks for tool use, RAG, evals"},{name:"BMAD Method",url:"https://docs.bmad-method.org/",description:"Build More Architect Dreams — Deloitte delivery framework"},{name:"Udemy Business (Deloitte SSO)",url:"https://deloittedevelopment.udemy.com/organization/home/",description:"Project-based courses — n8n, LangChain, agents, cloud platforms"}],vr=[{category:"AI Core & BMAD",links:[{name:"Claude (claude.ai)",url:"https://claude.ai"},{name:"Anthropic Academy",url:"https://anthropic.skilljar.com/"},{name:"Prompt Engineering Tutorial",url:"https://github.com/anthropics/prompt-eng-interactive-tutorial"},{name:"Claude Code Docs",url:"https://docs.claude.com/en/docs/agents-and-tools/claude-code/overview"},{name:"BMAD Method Repo",url:"https://github.com/bmad-code-org/BMAD-METHOD"},{name:"BMAD Docs",url:"https://docs.bmad-method.org/"},{name:"Model Context Protocol",url:"https://modelcontextprotocol.io"},{name:"Building Effective Agents",url:"https://www.anthropic.com/research/building-effective-agents"}]},{category:"Data Platforms",links:[{name:"Databricks Academy",url:"https://www.databricks.com/learn/training"},{name:"Snowflake University",url:"https://learn.snowflake.com/"},{name:"Microsoft Fabric Docs",url:"https://learn.microsoft.com/en-us/fabric/"},{name:"AWS Skill Builder",url:"https://skillbuilder.aws/"},{name:"Google Cloud Skills Boost",url:"https://www.cloudskillsboost.google/"},{name:"Confluent Developer",url:"https://developer.confluent.io/"},{name:"dbt Learn",url:"https://learn.getdbt.com/"},{name:"Astronomer Academy",url:"https://academy.astronomer.io/"}]},{category:"Architecture & Governance",links:[{name:"Designing Data-Intensive Applications",url:"https://dataintensive.net/"},{name:"Fundamentals of Data Engineering",url:"https://www.oreilly.com/library/view/fundamentals-of-data/9781098108298/"},{name:"Data Mesh — Dehghani",url:"https://www.oreilly.com/library/view/data-mesh/9781492092384/"},{name:"Data Management at Scale",url:"https://www.oreilly.com/library/view/data-management-at/9781098138851/"},{name:"DAMA-DMBOK",url:"https://www.dama.org/cpages/body-of-knowledge"},{name:"Great Expectations Docs",url:"https://docs.greatexpectations.io/"},{name:"OpenLineage",url:"https://openlineage.io/"},{name:"NIST AI RMF",url:"https://www.nist.gov/itl/ai-risk-management-framework"}]},{category:"Tooling & Community",links:[{name:"DataTalksClub Zoomcamp",url:"https://github.com/DataTalksClub/data-engineering-zoomcamp"},{name:"Apache Airflow Docs",url:"https://airflow.apache.org/docs/"},{name:"Apache Spark Docs",url:"https://spark.apache.org/docs/latest/"},{name:"Delta Lake Docs",url:"https://docs.delta.io/"},{name:"Apache Iceberg",url:"https://iceberg.apache.org/"},{name:"Apache Kafka Docs",url:"https://kafka.apache.org/documentation/"},{name:"Terraform Docs",url:"https://developer.hashicorp.com/terraform/docs"},{name:"Udemy Business SSO",url:"https://deloittedevelopment.udemy.com"}]}],yr=[{name:"Claude + Claude Code",url:"https://claude.ai",description:"Primary AI collaborator for SQL/Python, pipeline review, ADR drafting, incident summarization"},{name:"BMAD Method",url:"https://github.com/bmad-code-org/BMAD-METHOD",description:"Structured delivery for non-trivial data features: Analysis → Planning → Solutioning → Implementation"},{name:"Model Context Protocol",url:"https://modelcontextprotocol.io",description:"Connect AI tools to GitHub, Jira, Databricks, Snowflake, dbt metadata, catalog, observability — with governance"},{name:"dbt",url:"https://www.getdbt.com/",description:"Modular SQL transformations with tests, snapshots, documentation, and CI/CD"},{name:"Apache Airflow",url:"https://airflow.apache.org/",description:"Production orchestration — DAG factories, sensors, task groups, backfills, SLAs"},{name:"Apache Spark / Databricks",url:"https://spark.apache.org/",description:"Distributed processing for batch and streaming, lakehouse workloads"},{name:"Apache Kafka",url:"https://kafka.apache.org/",description:"Event streaming backbone for near-real-time ingestion and event-driven architectures"},{name:"Great Expectations",url:"https://greatexpectations.io/",description:"Open-source data quality framework — expectations, validation, docs"}],ze={pm:{...Zt,references:nr,toolchain:cr},architect:{...er,references:lr,toolchain:dr},designer:{...tr,references:pr,toolchain:ur},dev_qa:{...rr,references:mr,toolchain:gr},mle_ds:{...ir,references:hr,toolchain:fr},data:{...or,references:vr,toolchain:yr},devops:sr};function br(r){return ze[r]}const _e="idt-cookbook.learning",wr=365,kr="idt-cookbook.learning.v1.",He="idt-cookbook.learning.v2.shared";function xr(r){if(typeof document>"u")return null;const a=`${r}=`,n=document.cookie?document.cookie.split("; "):[];for(const l of n)if(l.startsWith(a))try{return decodeURIComponent(l.slice(a.length))}catch{return null}return null}function Ar(r,a,n){if(typeof document>"u")return;const l=new Date(Date.now()+n*86400*1e3).toUTCString();document.cookie=`${r}=${encodeURIComponent(a)}; expires=${l}; path=/; SameSite=Lax`}function Ne(r){if(!r)return{};try{const a=JSON.parse(r);if(Array.isArray(a)){const n={};for(const l of a)typeof l=="string"&&(n[l]=!0);return n}if(a&&typeof a=="object"){const n={};for(const[l,d]of Object.entries(a))d&&(n[l]=!0);return n}}catch{}return{}}function Dr(r){return JSON.stringify(Object.keys(r).sort())}function Cr(){if(typeof window>"u")return{};const r={};try{for(const[a,n]of Object.entries(ze)){const l=window.localStorage.getItem(kr+a);if(!l)continue;let d;try{d=JSON.parse(l)}catch{continue}if(!(!d||typeof d!="object"))for(const w of n.levels)for(const h of w.items)d[h.id]&&(r[h.id]=!0)}}catch{}return r}function Sr(){const r=Ne(xr(_e));if(Object.keys(r).length>0)return r;if(typeof window<"u"){const n=Ne(window.localStorage.getItem(He));if(Object.keys(n).length>0)return n}const a=Cr();return Object.keys(a).length>0&&We(a),a}function We(r){const a=Dr(r);if(Ar(_e,a,wr),typeof window<"u")try{window.localStorage.setItem(He,a)}catch{}}function Ir(){const[r,a]=x.useState(()=>Sr()),n=x.useCallback(d=>{a(w=>{const h={...w};return h[d]?delete h[d]:h[d]=!0,We(h),h})},[]),l=x.useCallback(d=>!!r[d],[r]);return{toggle:n,isDone:l}}const jr={courses:{id:"courses",label:"Courses",trackable:!0,defaultOpen:!0},practice:{id:"practice",label:"Practice",description:"Hands-on activities and practice projects.",trackable:!0,defaultOpen:!0},references:{id:"references",label:"Graduation criteria",description:"Self-assessment checkpoints and graduation criteria. Use these to confirm you have reached the level.",trackable:!1,defaultOpen:!1},resources:{id:"resources",label:"Resources",description:"Docs, repos, specs, and tool websites. Open as needed — not tracked as completion.",trackable:!1,defaultOpen:!1},capstones:{id:"capstones",label:"Capstone",helperText:"Use these as reference examples for the type of artifact or outcome expected at this level. They are not course links and are not counted toward completion.",trackable:!1,defaultOpen:!1}};function Pr(r){switch(r.type){case"capstone":return"capstones";case"graduation-criteria":case"tracking-evidence":case"note":return"references";case"resource":return"resources";case"course":return"courses";case"mock-practice":return"practice";case"practice":return"practice";default:return"resources"}}function Mr(r){return/^https?:\/\//i.test(r)?r:`https://${r}`}function Lr(r){return!!(r&&/udemy business/i.test(r))}const Nr="https://deloittedevelopment.udemy.com";function Er(r){return r.description?r.type==="mock-practice"||r.type==="capstone"||r.type==="practice"&&r.description.length>140:!1}const Tr={pm:"Builds agent-first product skills.",architect:"Builds AI-orchestrated system design skills.",designer:"Builds AI-augmented design skills.",dev_qa:"Builds AI-native engineering and quality skills."},Br={Beginner:"Start here if you are building foundational fluency and need guided practice before applying AI-enabled delivery independently.",Intermediate:"Use this level when you can own work with moderate guidance and are ready to apply structured AI workflows to real delivery.",Advanced:"Use this level when you are shaping standards, mentoring others, and applying AI-enabled practices across teams or complex work."},Rr={course:{label:"Course",cls:"lp-tag--course"},practice:{label:"Practice",cls:"lp-tag--practice"},"mock-practice":{label:"Mock practice",cls:"lp-tag--practice"},resource:{label:"Resource",cls:"lp-tag--resource"},capstone:{label:"Capstone",cls:"lp-tag--capstone"},"graduation-criteria":{label:"Reference",cls:"lp-tag--reference"},"tracking-evidence":{label:"Reference",cls:"lp-tag--reference"},note:{label:"Reference",cls:"lp-tag--reference"}};function Fr({personaId:r}){const a=x.useMemo(()=>br(r),[r]),{isDone:n,toggle:l}=Ir(),[d,w]=x.useState(null);if(x.useEffect(()=>{w(null)},[a.personaId]),a.mappingStatus==="pending-documents")return e.jsxs("div",{className:"lp-wrap",children:[e.jsx(Ee,{pathway:a}),e.jsxs("div",{className:"lp-pending",children:[e.jsx("div",{className:"lp-pending-icon","aria-hidden":!0,children:"✨"}),e.jsx("h3",{className:"lp-pending-title",children:"Learning pathway not live yet"}),e.jsx("p",{className:"lp-pending-body",children:"This role-specific pathway is being prepared and will be available soon."})]}),a.references&&a.references.length>0&&e.jsx(Te,{categories:a.references}),a.toolchain&&a.toolchain.length>0&&e.jsx(Be,{tools:a.toolchain}),e.jsx(Re,{})]});const h=d?a.levels.find(g=>g.level===d):null,f=d!==null;return e.jsxs("div",{className:"lp-wrap",children:[e.jsx(Ee,{pathway:a}),a.levels.length>0&&e.jsxs(e.Fragment,{children:[e.jsxs("div",{className:"lp-level-group",children:[e.jsx("span",{className:"lp-level-group-label",children:"Level of readiness"}),e.jsxs("div",{className:"lp-level-row",children:[e.jsx("div",{className:"lp-level-tabs",role:"tablist","aria-label":"Learning levels",children:a.levels.map(g=>{const C=g.level===d,D=f&&!C;return e.jsx("button",{role:"tab","aria-selected":C,"aria-disabled":D,disabled:D,className:`lp-level-tab${C?" lp-level-tab--active":""}${D?" lp-level-tab--locked":""}`,onClick:()=>!D&&w(g.level),children:g.level},g.level)})}),f&&e.jsx("button",{type:"button",className:"lp-level-reset",onClick:()=>w(null),"aria-label":"Reset level selection",children:"↺ Reset"})]})]}),h&&e.jsx(Or,{level:h,isDone:n,toggle:l})]}),a.references&&a.references.length>0&&e.jsx(Te,{categories:a.references}),a.toolchain&&a.toolchain.length>0&&e.jsx(Be,{tools:a.toolchain}),e.jsx(Re,{})]})}function Ee({pathway:r}){const a=Tr[r.personaId];return e.jsxs("p",{className:"lp-header-line",children:[e.jsx("span",{className:"lp-header-persona",children:r.displayName}),a&&e.jsxs("span",{className:"lp-header-helper",children:[" — ",a]})]})}function Or({level:r,isDone:a,toggle:n}){const l=x.useMemo(()=>{const w={courses:[],practice:[],references:[],resources:[],capstones:[]},h={courses:new Set,practice:new Set,references:new Set,resources:new Set,capstones:new Set};for(const f of r.items){const g=Pr(f);h[g].has(f.id)||(h[g].add(f.id),w[g].push(f))}return w},[r]),d=["courses","capstones","resources","references"];return e.jsxs("div",{className:"lp-level-panel",role:"tabpanel","aria-label":`${r.level} level`,children:[r.summary&&e.jsx("p",{className:"lp-level-summary",children:r.summary}),e.jsx(qr,{level:r.level}),e.jsxs("div",{className:"lp-sections",children:[r.skills&&r.skills.length>0&&e.jsx(zr,{skills:r.skills}),d.map(w=>{const h=l[w];return h.length===0?null:e.jsx(Ur,{meta:jr[w],items:h,isDone:a,toggle:n},w)})]})]})}function Ur({meta:r,items:a,isDone:n,toggle:l}){const[d,w]=x.useState(r.defaultOpen);r.trackable&&a.filter(g=>n(g.id)).length;const h=x.useMemo(()=>{const g=new Map;for(const C of a){const D=C.track??"";g.has(D)||g.set(D,[]),g.get(D).push(C)}return Array.from(g.entries())},[a]),f=r.id==="references";return r.id==="courses"||r.id==="practice"||r.id==="resources"||r.id,e.jsxs("section",{className:"lp-section",children:[e.jsxs("button",{type:"button",className:"lp-sec-toggle",onClick:()=>w(g=>!g),"aria-expanded":d,children:[e.jsx("span",{className:"lp-sec-name",children:r.label}),e.jsx("span",{className:"lp-sec-chevron","aria-hidden":!0,children:d?"▾":"▸"})]}),d&&e.jsxs("div",{className:"lp-sec-body",children:[r.description&&e.jsx("p",{className:"lp-sec-desc",children:r.description}),r.helperText&&e.jsx("p",{className:"lp-sec-helper",children:r.helperText}),h.map(([g,C])=>e.jsxs("div",{className:"lp-track",children:[g&&e.jsx("p",{className:"lp-track-label",children:g}),f?e.jsx("ul",{className:"lp-readiness-list",children:C.map(D=>e.jsxs("li",{className:"lp-readiness-item",children:[e.jsx("span",{className:"lp-readiness-bullet","aria-hidden":!0,children:"✓"}),e.jsx("span",{children:D.title})]},D.id))}):e.jsx("ul",{className:"lp-items",children:C.map(D=>e.jsx(Gr,{item:D,section:r,done:r.trackable?n(D.id):!1,onToggle:r.trackable?()=>l(D.id):void 0},D.id))})]},g||"_default"))]})]})}function Gr({item:r,section:a,done:n,onToggle:l}){const d=`lp-check-${r.id}`,w=r.url?Mr(r.url):void 0,h=!w&&Lr(r.provider),f=Er(r),[g,C]=x.useState(!1),D=Rr[r.type],j=w?e.jsxs("a",{href:w,target:"_blank",rel:"noopener noreferrer",className:"lp-item-title lp-item-title--link",children:[r.title,e.jsx("span",{"aria-hidden":!0,children:" ↗"})]}):a.trackable&&l?e.jsx("label",{htmlFor:d,className:"lp-item-title",children:r.title}):e.jsx("span",{className:"lp-item-title",children:r.title});return e.jsxs("li",{className:`lp-item${n?" lp-item--done":""}${a.trackable?"":" lp-item--readonly"}`,children:[a.trackable&&l&&e.jsx("input",{id:d,type:"checkbox",className:"lp-check",checked:n,onChange:l,"aria-label":`Mark "${r.title}" as ${n?"incomplete":"complete"}`}),e.jsxs("div",{className:"lp-item-body",children:[j,e.jsxs("div",{className:"lp-item-meta",children:[e.jsx("span",{className:`lp-tag ${D.cls}`,children:D.label}),r.provider&&e.jsx("span",{className:"lp-provider",children:r.provider}),r.hours&&e.jsx("span",{className:"lp-hours",children:r.hours}),h&&e.jsx("a",{href:Nr,target:"_blank",rel:"noopener noreferrer",className:"lp-link",children:"Search in Udemy Business ↗"}),f&&e.jsx("button",{type:"button",className:"lp-details-toggle",onClick:()=>C(P=>!P),"aria-expanded":g,children:g?"Hide details ▾":"View details ▸"})]}),r.description&&(f?g&&e.jsx("p",{className:"lp-desc lp-desc--detail",children:r.description}):e.jsx("p",{className:"lp-desc",children:r.description}))]})]})}function qr({level:r}){const[a,n]=x.useState(!1);return e.jsxs("div",{className:"lp-learn-more-wrap",children:[e.jsx("button",{type:"button",className:"lp-learn-more-btn",onClick:()=>n(l=>!l),"aria-expanded":a,children:a?"Hide readiness guide ▾":"Learn more about this level ▸"}),a&&e.jsxs("div",{className:"lp-learn-more-panel",children:[e.jsxs("p",{className:"lp-learn-more-title",children:[r," — readiness"]}),e.jsx("p",{className:"lp-learn-more-body",children:Br[r]})]})]})}function zr({skills:r}){const[a,n]=x.useState(!0);return e.jsxs("section",{className:"lp-section",children:[e.jsxs("button",{type:"button",className:"lp-sec-toggle",onClick:()=>n(l=>!l),"aria-expanded":a,children:[e.jsx("span",{className:"lp-sec-name",children:"Skills"}),e.jsx("span",{className:"lp-sec-chevron","aria-hidden":!0,children:a?"▾":"▸"})]}),a&&e.jsx("div",{className:"lp-sec-body",children:e.jsx("ul",{className:"lp-skill-list",children:r.map((l,d)=>e.jsxs("li",{className:"lp-skill-item",children:[e.jsx("span",{className:"lp-skill-bullet","aria-hidden":!0,children:"•"}),e.jsx("span",{children:l})]},d))})})]})}function Te({categories:r}){const[a,n]=x.useState(!1);return e.jsxs("section",{className:"lp-section",children:[e.jsxs("button",{type:"button",className:"lp-sec-toggle",onClick:()=>n(l=>!l),"aria-expanded":a,children:[e.jsx("span",{className:"lp-sec-name",children:"References"}),e.jsx("span",{className:"lp-sec-chevron","aria-hidden":!0,children:a?"▾":"▸"})]}),a&&e.jsxs("div",{className:"lp-sec-body",children:[e.jsx("p",{className:"lp-sec-desc",children:"Curated quick-access links organised by topic. Open as needed — not tracked."}),e.jsx("div",{className:"lp-ref-grid",children:r.map(l=>e.jsxs("div",{className:"lp-ref-cat",children:[e.jsx("p",{className:"lp-ref-cat-label",children:l.category}),e.jsx("ul",{className:"lp-ref-links",children:l.links.map(d=>e.jsx("li",{children:e.jsxs("a",{href:d.url,target:"_blank",rel:"noopener noreferrer",className:"lp-ref-link",children:[d.name,e.jsx("span",{"aria-hidden":!0,children:" ↗"})]})},d.url))})]},l.category))})]})]})}function Be({tools:r}){const[a,n]=x.useState(!1);return e.jsxs("section",{className:"lp-section",children:[e.jsxs("button",{type:"button",className:"lp-sec-toggle",onClick:()=>n(l=>!l),"aria-expanded":a,children:[e.jsx("span",{className:"lp-sec-name",children:"Toolchain"}),e.jsx("span",{className:"lp-sec-chevron","aria-hidden":!0,children:a?"▾":"▸"})]}),a&&e.jsxs("div",{className:"lp-sec-body",children:[e.jsx("p",{className:"lp-sec-desc",children:"Key tools for this pathway. Click to visit the official resource."}),e.jsx("div",{className:"lp-toolchain-grid",children:r.map(l=>e.jsxs("a",{href:l.url,target:"_blank",rel:"noopener noreferrer",className:"lp-tool-card",children:[e.jsxs("span",{className:"lp-tool-name",children:[l.name," ↗"]}),e.jsx("span",{className:"lp-tool-desc",children:l.description})]},l.name))})]})]})}function Re(){return e.jsx("style",{children:`
      /* Deloitte palette — scoped to Learning Pathways */
      .lp-wrap {
        --lp-green:       #86BC25;
        --lp-green-dark:  #5A8718;
        --lp-green-tint:  #EEF6DC;
        --lp-neon:        #86EB22;
        --lp-neon-tint:   #F0FCD9;
        --lp-neon-dark:   #2C5A0E;
        --lp-blue:        #00A3E0;
        --lp-blue-dark:   #006C9A;
        --lp-blue-tint:   #E3F4FA;
        --lp-black:       #000000;
        --lp-darkgray:    #282728;
        --lp-darkgray-tint: #F1F1F1;
        --lp-white:       #FFFFFF;

        display: flex;
        flex-direction: column;
        gap: var(--space-4);
      }

      /* Subtle one-line persona header */
      .lp-header-line {
        margin: 0;
        font-size: var(--text-sm);
        line-height: 1.5;
        color: var(--text-muted);
      }
      .lp-header-persona {
        font-weight: 700;
        color: var(--lp-green-dark);
      }
      .lp-header-helper {
        color: var(--text-muted);
      }


      /* Pending state — premium, concise */
      .lp-pending {
        padding: var(--space-10) var(--space-6);
        background: var(--bg-subtle);
        border: 1px dashed var(--border-strong);
        border-radius: var(--radius);
        text-align: center;
      }
      .lp-pending-icon { font-size: 36px; margin-bottom: var(--space-3); }
      .lp-pending-title {
        font-size: var(--text-lg);
        font-weight: 700;
        margin: 0 0 var(--space-2) 0;
        color: var(--text);
      }
      .lp-pending-body {
        font-size: var(--text-sm);
        color: var(--text-muted);
        margin: 0 auto;
        max-width: 440px;
        line-height: 1.55;
      }

      /* Level group label — mirrors gs-tab-group / gs-tab-group-label */
      .lp-level-group {
        display: flex;
        flex-direction: column;
        gap: var(--space-1);
      }
      .lp-level-group-label {
        font-size: 9px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: var(--lp-green);
        padding: 0 2px;
      }

      /* Level tabs — green pill style matching GetStarted role tabs */
      .lp-level-tabs {
        display: flex;
        gap: var(--space-1);
        flex-wrap: wrap;
        margin-bottom: var(--space-1);
      }
      .lp-level-tab {
        border-radius: var(--radius);
        padding: 5px var(--space-3);
        font-size: var(--text-sm);
        font-weight: 500;
        font-family: inherit;
        cursor: pointer;
        transition: background 0.12s, color 0.12s, border-color 0.12s;
        white-space: nowrap;
        background: rgba(134, 188, 37, 0.10);
        color: #5a8215;
        border: 1px solid rgba(134, 188, 37, 0.28);
      }
      .lp-level-tab:hover {
        background: rgba(134, 188, 37, 0.20);
        color: var(--lp-green);
      }
      .lp-level-tab--active {
        background: var(--lp-green);
        color: #fff;
        border-color: var(--lp-green);
        font-weight: 700;
      }

      .lp-level-panel { display: flex; flex-direction: column; gap: var(--space-3); }
      .lp-level-summary {
        font-size: var(--text-sm);
        color: var(--text-muted);
        line-height: 1.6;
        margin: 0;
      }

      /* Learn More — mirrors Project Type tab pattern, placed above Courses */
      .lp-learn-more-wrap {
        display: flex;
        flex-direction: column;
        margin-top: var(--space-1);
      }
      .lp-learn-more-btn {
        align-self: flex-start;
        background: var(--bg-subtle);
        border: 1px solid var(--border);
        border-radius: var(--radius);
        padding: 5px var(--space-4);
        font-family: inherit;
        font-size: var(--text-xs);
        font-weight: 600;
        color: var(--text-muted);
        cursor: pointer;
        text-align: left;
        transition: color 0.1s, background 0.1s, border-color 0.1s;
      }
      .lp-learn-more-btn:hover { color: var(--lp-green); background: var(--bg-hover); border-color: var(--lp-green); }
      .lp-learn-more-btn[aria-expanded="true"] {
        border-radius: var(--radius) var(--radius) 0 0;
        border-bottom: none;
      }
      .lp-learn-more-panel {
        border: 1px solid var(--border);
        border-radius: 0 var(--radius) var(--radius) var(--radius);
        background: var(--bg-subtle);
        padding: var(--space-3) var(--space-4);
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .lp-learn-more-title {
        font-size: var(--text-sm);
        font-weight: 700;
        color: var(--text);
        margin: 0;
      }
      .lp-learn-more-body {
        font-size: var(--text-sm);
        color: var(--text-muted);
        line-height: 1.55;
        margin: 0;
      }

      /* Sections — gs-step style */
      .lp-sections { display: flex; flex-direction: column; gap: var(--space-4); }
      .lp-section {
        background: var(--bg-card);
        border: 1px solid var(--border);
        border-radius: var(--radius);
        overflow: hidden;
      }
      .lp-sec-toggle {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: var(--space-2) var(--space-3);
        background: var(--bg-subtle);
        border: none;
        border-bottom: 1px solid transparent;
        font-family: inherit;
        cursor: pointer;
        text-align: left;
        transition: background 0.1s;
      }
      .lp-sec-toggle:hover { background: var(--bg-hover); }
      .lp-sec-toggle[aria-expanded="true"] { border-bottom-color: var(--border); }
      .lp-sec-name {
        font-size: var(--text-sm);
        font-weight: 700;
        color: var(--text);
      }
      .lp-sec-chevron {
        font-size: var(--text-sm);
        color: var(--text-muted);
        font-weight: 700;
      }
      .lp-sec-body {
        display: flex;
        flex-direction: column;
        gap: var(--space-3);
        padding: var(--space-3) var(--space-4) var(--space-4);
      }
      .lp-sec-desc {
        font-size: var(--text-xs);
        color: var(--text-muted);
        margin: 0;
        line-height: 1.5;
      }
      .lp-sec-helper {
        font-size: var(--text-xs);
        color: var(--text);
        margin: 0;
        line-height: 1.55;
        padding: 8px 10px;
        background: var(--lp-green-tint);
        border: 1px solid var(--lp-green);
        border-radius: var(--radius-sm);
      }

      .lp-track { display: flex; flex-direction: column; gap: var(--space-2); }
      .lp-track-label {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.07em;
        color: var(--text-faint);
        margin: 0;
      }

      .lp-items {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 6px;
      }

      .lp-item {
        display: flex;
        gap: var(--space-3);
        padding: 10px var(--space-3);
        background: var(--bg);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        transition: border-color 0.12s, background 0.12s, opacity 0.12s;
      }
      .lp-item:hover { border-color: var(--border-strong); }
      .lp-item--done {
        background: var(--lp-green-tint);
        border-color: var(--lp-green);
      }
      .lp-item--done .lp-item-title,
      .lp-item--done .lp-item-title--link {
        color: var(--text-muted);
        text-decoration: line-through;
      }

      .lp-check {
        appearance: none;
        -webkit-appearance: none;
        width: 18px;
        height: 18px;
        border: 2px solid var(--border-strong);
        border-radius: 4px;
        background: var(--bg);
        cursor: pointer;
        flex-shrink: 0;
        margin-top: 2px;
        position: relative;
        transition: background 0.1s, border-color 0.1s;
      }
      .lp-check:hover { border-color: var(--lp-green); }
      .lp-check:focus-visible { outline: 2px solid var(--lp-green); outline-offset: 2px; }
      .lp-check:checked { background: var(--lp-green); border-color: var(--lp-green); }
      .lp-check:checked::after {
        content: "";
        position: absolute;
        left: 4px;
        top: 0px;
        width: 5px;
        height: 10px;
        border: solid var(--lp-white);
        border-width: 0 2px 2px 0;
        transform: rotate(45deg);
      }

      .lp-item-body { flex: 1; min-width: 0; display: flex; flex-direction: column; gap: 4px; }
      .lp-item-title {
        display: block;
        font-size: var(--text-sm);
        font-weight: 600;
        color: var(--text);
        cursor: pointer;
        line-height: 1.45;
      }
      .lp-item-title--link { color: var(--text); text-decoration: none; }
      .lp-item-title--link:hover { color: var(--lp-green); text-decoration: underline; }
      .lp-item--readonly .lp-item-title { cursor: default; }
      .lp-item--readonly .lp-item-title--link { cursor: pointer; }

      .lp-item-meta {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: var(--space-2);
        font-size: var(--text-xs);
        color: var(--text-muted);
      }

      /* ── Deloitte-palette tags ─────────────────────────────────────────── */
      .lp-tag {
        display: inline-flex;
        align-items: center;
        padding: 2px 8px;
        border-radius: 4px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.06em;
        font-size: 10px;
        border: 1px solid transparent;
      }
      .lp-tag--head {
        font-size: var(--text-xs);
        padding: 4px 10px;
      }
      .lp-tag--course    { background: var(--lp-green-tint);   color: var(--lp-green-dark);  border-color: var(--lp-green); }
      .lp-tag--practice  { background: var(--lp-blue-tint);    color: var(--lp-blue-dark);   border-color: var(--lp-blue); }
      .lp-tag--reference { background: var(--lp-darkgray-tint); color: var(--lp-darkgray);   border-color: var(--lp-darkgray); }
      .lp-tag--resource  { background: var(--lp-neon-tint);    color: var(--lp-neon-dark);   border-color: var(--lp-neon); }
      .lp-tag--capstone  { background: var(--lp-black);        color: var(--lp-green);       border-color: var(--lp-black); }

      .lp-provider { font-weight: 600; }
      .lp-hours { color: var(--text-faint); }
      .lp-link {
        color: var(--lp-green);
        text-decoration: none;
        font-weight: 600;
        white-space: nowrap;
      }
      .lp-link:hover { text-decoration: underline; }
      .lp-details-toggle {
        background: transparent;
        border: none;
        padding: 0;
        font: inherit;
        font-size: var(--text-xs);
        font-weight: 600;
        color: var(--lp-green);
        cursor: pointer;
      }
      .lp-details-toggle:hover { text-decoration: underline; }
      .lp-desc { font-size: var(--text-xs); color: var(--text-muted); line-height: 1.5; margin: 0; }
      .lp-desc--detail {
        padding: 8px 10px;
        background: var(--bg-subtle);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
      }

      /* References list — checklist style */
      .lp-readiness-list {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .lp-readiness-item {
        display: flex;
        align-items: flex-start;
        gap: var(--space-2);
        font-size: var(--text-sm);
        color: var(--text);
        line-height: 1.5;
      }
      .lp-readiness-bullet {
        color: var(--lp-green);
        font-weight: 700;
        flex-shrink: 0;
        margin-top: 1px;
      }

      /* ── References Panel ─────────────────────────────────────────────── */
      .lp-ref-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: var(--space-4);
      }
      .lp-ref-cat { display: flex; flex-direction: column; gap: var(--space-2); }
      .lp-ref-cat-label {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.07em;
        color: var(--lp-green);
        margin: 0;
      }
      .lp-ref-links {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .lp-ref-link {
        font-size: var(--text-xs);
        font-weight: 500;
        color: var(--text-muted);
        text-decoration: none;
        transition: color 0.1s;
      }
      .lp-ref-link:hover { color: var(--lp-green); text-decoration: underline; }

      /* ── Toolchain Panel ──────────────────────────────────────────────── */
      .lp-toolchain-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
        gap: var(--space-3);
      }
      .lp-tool-card {
        display: flex;
        flex-direction: column;
        gap: 4px;
        padding: 10px var(--space-3);
        background: var(--bg);
        border: 1px solid var(--border);
        border-radius: var(--radius-sm);
        text-decoration: none;
        transition: border-color 0.12s, background 0.12s;
      }
      .lp-tool-card:hover {
        border-color: var(--lp-green);
        background: var(--bg-hover);
      }
      .lp-tool-name {
        font-size: var(--text-sm);
        font-weight: 600;
        color: var(--text);
      }
      .lp-tool-card:hover .lp-tool-name { color: var(--lp-green); }
      .lp-tool-desc {
        font-size: var(--text-xs);
        color: var(--text-muted);
        line-height: 1.45;
      }

      /* Level row — tabs on the left, reset button on the right */
      .lp-level-row {
        display: flex;
        align-items: center;
        gap: var(--space-3);
        flex-wrap: wrap;
      }
      .lp-level-tab--locked {
        opacity: 0.4;
        cursor: not-allowed;
        pointer-events: none;
      }
      .lp-level-reset {
        background: transparent;
        border: 1px solid var(--lp-green);
        color: var(--lp-green);
        border-radius: var(--radius);
        padding: 5px var(--space-3);
        font-family: inherit;
        font-size: var(--text-xs);
        font-weight: 700;
        letter-spacing: 0.04em;
        cursor: pointer;
        transition: background 0.12s, color 0.12s;
      }
      .lp-level-reset:hover {
        background: var(--lp-green);
        color: #fff;
      }
      /* Skills section bullets */
      .lp-skill-list {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .lp-skill-item {
        display: flex;
        align-items: flex-start;
        gap: var(--space-2);
        font-size: var(--text-sm);
        color: var(--text);
        line-height: 1.55;
      }
      .lp-skill-bullet {
        color: var(--lp-green);
        font-weight: 700;
        flex-shrink: 0;
        font-size: var(--text-base);
        line-height: 1.3;
      }

      @media (max-width: 640px) {
        .lp-header { flex-direction: column; align-items: stretch; }
        .lp-progress-summary { align-items: flex-start; }
        .lp-progress-bar { width: 100%; }
        .lp-level-tabs { gap: 2px; }
        .lp-level-tab { padding: var(--space-2) var(--space-3); }
        .lp-sec-toggle { padding: var(--space-3); }
        .lp-sec-body { padding: var(--space-3); }
      }
    `})}const Fe={step:"traditional",traditional:null,persona:null,archetype:null,pattern:null,tool:null},Oe=[{label:"Current Role"},{label:"Future Role"},{label:"Project Type"},{label:"Tools"},{label:"Get Started"},{label:"Learning Pathway"}],Qe=["traditional","persona","projecttype","tools","getstarted","learning"];function Ve(r){return Qe.indexOf(r)}function Qr({data:r}){const[a,n]=x.useState(Fe),l=h=>n(f=>({...f,...h})),d=()=>n(Fe);function w(h){const f=Qe[h],g=Ve(a.step);h>=g||n(C=>{const D={step:f};return h<=0?Object.assign(D,{traditional:null,persona:null,archetype:null,pattern:null}):h<=1&&Object.assign(D,{archetype:null,pattern:null}),{...C,...D}})}return e.jsxs("div",{className:"wizard",children:[e.jsx(_r,{step:a.step,onNavigate:w}),a.step==="traditional"&&e.jsx(bt,{roles:r.traditional_roles,initialRole:a.traditional,onSelect:(h,f)=>l({traditional:h,persona:f,step:"persona"})}),a.step==="persona"&&e.jsx(wt,{personas:r.personas,roles:r.roles,suggestedPersonaId:a.persona,onSelect:h=>l({persona:h,step:"projecttype"}),onBack:()=>l({step:"traditional"})}),a.step==="projecttype"&&a.persona&&e.jsx(Nt,{initialArchetype:a.archetype,onSelect:(h,f)=>l({archetype:h,pattern:f,step:"tools"}),onBack:()=>l({step:"persona"})}),a.step==="tools"&&a.persona&&e.jsx(zt,{personaId:a.persona,pattern:a.pattern,initialTool:a.tool,onNext:h=>l({step:"getstarted",tool:h}),onBack:()=>l({step:"projecttype"})}),a.step==="getstarted"&&a.persona&&a.archetype&&e.jsx(Xt,{personaId:a.persona,archetypeId:a.archetype,tool:a.tool??void 0,traditional:a.traditional,scenarios:r.scenarios,onBack:()=>l({step:"tools"}),onRestart:d,onNext:()=>l({step:"learning"})}),a.step==="learning"&&a.persona&&e.jsxs("div",{className:"lp-wizard-wrap card",children:[e.jsx("div",{className:"lp-wizard-topbar",children:e.jsx("button",{className:"link-back",onClick:()=>l({step:"getstarted"}),children:"← Back"})}),e.jsx(Fr,{personaId:a.persona}),e.jsx("div",{className:"lp-wizard-bottom",children:e.jsx("button",{className:"lp-restart-btn",onClick:d,children:"↺ Start over"})})]})]})}function _r({step:r,onNavigate:a}){const n=Ve(r);return e.jsxs("nav",{"aria-label":"Progress",className:"progress-nav",children:[e.jsx("ol",{className:"progress",children:Oe.map((l,d)=>{const w=d<n,h=d===n,f=d===0,g=d===Oe.length-1;return e.jsxs("li",{className:["progress-step",w?"done":"",h?"current":"",f?"first":"",g?"last":"",w?"clickable":""].filter(Boolean).join(" "),"aria-current":h?"step":void 0,onClick:w?()=>a(d):void 0,title:w?`Go back to ${l.label}`:void 0,children:[e.jsx("span",{className:"progress-num",children:w?"✓":d+1}),e.jsx("span",{className:"progress-label",children:l.label})]},d)})}),e.jsx("style",{children:`
        .progress-nav { margin: 0 0 var(--space-8); }
        .progress {
          display: flex;
          list-style: none;
          padding: 0;
          margin: 0;
          justify-content: center;
          align-items: stretch;
        }
        .progress-step {
          position: relative;
          display: flex;
          align-items: center;
          gap: 7px;
          padding: 9px 18px 9px 28px;
          font-size: var(--text-sm);
          font-weight: 500;
          background: var(--bg-subtle);
          color: var(--text-faint);
          clip-path: polygon(0% 0%, calc(100% - 14px) 0%, 100% 50%, calc(100% - 14px) 100%, 0% 100%, 14px 50%);
          min-width: 110px;
          justify-content: center;
          transition: background 0.15s, color 0.15s;
          margin-right: -1px;
          user-select: none;
        }
        .progress-step.first {
          clip-path: polygon(0% 0%, calc(100% - 14px) 0%, 100% 50%, calc(100% - 14px) 100%, 0% 100%);
          padding-left: 16px;
        }
        .progress-step.last {
          clip-path: polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%, 14px 50%);
          padding-right: 16px;
        }
        .progress-step.done {
          background: var(--tier-1-bg);
          color: var(--accent);
        }
        .progress-step.current {
          background: var(--accent);
          color: var(--text-on-green, #fff);
          font-weight: 700;
          z-index: 1;
        }
        .progress-step.clickable { cursor: pointer; }
        .progress-step.clickable:hover { filter: brightness(0.93); }
        .progress-num {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          width: 20px;
          height: 20px;
          border-radius: 50%;
          font-size: var(--text-xs);
          font-weight: 700;
          background: rgba(0,0,0,0.10);
          flex-shrink: 0;
        }
        .progress-step.current .progress-num { background: rgba(255,255,255,0.25); color: #fff; }
        .progress-step.done .progress-num { background: var(--accent); color: #fff; }
        @media (max-width: 640px) {
          .progress-step { min-width: 0; padding: 8px 14px 8px 24px; }
          .progress-label { display: none; }
        }
        .lp-wizard-topbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: var(--space-4);
        }
        .link-back {
          background: transparent;
          border: none;
          color: var(--text-muted);
          padding: 0;
          cursor: pointer;
          font-size: var(--text-sm);
        }
        .link-back:hover { color: var(--text); }
        .lp-wizard-bottom {
          display: flex;
          justify-content: flex-start;
          padding-top: var(--space-5);
          margin-top: var(--space-4);
          border-top: 1px solid var(--border);
        }
        .lp-restart-btn {
          background: transparent;
          border: 1px solid var(--border);
          color: var(--text-muted);
          border-radius: 6px;
          padding: 3px 10px;
          font-size: var(--text-xs);
          font-weight: 600;
          cursor: pointer;
          transition: border-color 0.1s, color 0.1s;
        }
        .lp-restart-btn:hover { border-color: var(--accent); color: var(--accent); }
      `})]})}export{Qr as default};

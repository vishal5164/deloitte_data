import{j as e,T as b,a as S,A as T,P,L as C,b as I,c as L,d as _,E as n}from"./reference.CoM6j2Ux.js";import{r}from"./index.CVf8TyFT.js";const R={universal:{label:"All models",cls:"rp-scope-green"},claude:{label:"Claude / Anthropic",cls:"rp-scope-grey"},concept:{label:"Concept universal",cls:"rp-scope-amber"}},D=["tokens","prompts","playbook","standards"];function G(s){return D.includes(s)}function B(){const[s,x]=r.useState("tokens"),v=a=>{x(a),typeof window<"u"&&window.location.hash.slice(1)!==a&&(window.location.hash=a)};r.useEffect(()=>{const a=()=>{const t=window.location.hash.slice(1);G(t)&&x(t)};return a(),window.addEventListener("hashchange",a),()=>window.removeEventListener("hashchange",a)},[]);const[g,f]=r.useState(null),[i,u]=r.useState(!1),[o,j]=r.useState(!1),[c,y]=r.useState(!1),[l,N]=r.useState(!1),[p,k]=r.useState(!1),[d,w]=r.useState(!1),[m,z]=r.useState(!1),E=[{id:"tokens",label:"Token Economics"},{id:"prompts",label:"Prompt Engineering"},{id:"playbook",label:"Playbook"},{id:"standards",label:"Eng Standards"}];return e.jsxs("div",{className:"rp-wrap card",children:[e.jsxs("div",{className:"rp-header",children:[e.jsx("h2",{className:"rp-title",children:"Reference"}),e.jsx("p",{className:"rp-subtitle",children:"Prompting techniques, token economics, delivery playbook, and engineering standards."})]}),e.jsx("div",{className:"rp-tabs",children:E.map(a=>e.jsx("button",{className:`rp-tab${s===a.id?" rp-tab--active":""}`,onClick:()=>v(a.id),children:a.label},a.id))}),e.jsxs("div",{className:"rp-panel",children:[s==="tokens"&&e.jsxs("div",{className:"rp-tokens-wrap",children:[e.jsxs("button",{className:"rp-section-hdr",onClick:()=>u(a=>!a),"aria-expanded":i,children:[e.jsx("span",{children:"Key levers"}),e.jsx("span",{className:"rp-chevron",children:i?"▾":"▸"})]}),i&&e.jsxs("div",{className:"rp-callout",children:[e.jsx("p",{children:b.intro}),e.jsx("ul",{children:b.items.map(a=>e.jsxs("li",{children:[e.jsx("strong",{children:a.label})," — ",a.body]},a.label))})]}),e.jsxs("button",{className:"rp-section-hdr",onClick:()=>j(a=>!a),"aria-expanded":o,children:[e.jsxs("span",{className:"rp-section-hdr-left",children:["Token optimisation overview",e.jsx("span",{className:"rp-cheatsheet-badge",children:"Cheat sheet"})]}),e.jsx("span",{className:"rp-chevron",children:o?"▾":"▸"})]}),o&&e.jsx("img",{src:"/Token_Optimization.png",alt:"Token Optimization — 13 tactics to reduce cost and latency across any LLM or agent",className:"rp-token-img"}),e.jsxs("button",{className:"rp-section-hdr",onClick:()=>y(a=>!a),"aria-expanded":c,children:[e.jsx("span",{children:"13 tactics — expand each to see examples"}),e.jsx("span",{className:"rp-chevron",children:c?"▾":"▸"})]}),e.jsx("div",{className:"rp-tactic-list",style:c?{}:{display:"none"},children:S.map(a=>{const t=g===a.n,{label:A,cls:O}=R[a.scope];return e.jsxs("div",{className:`rp-tactic${t?" rp-tactic--open":""}`,children:[e.jsxs("button",{className:"rp-tactic-hdr",onClick:()=>f(t?null:a.n),"aria-expanded":t,children:[e.jsxs("div",{className:"rp-tactic-hdr-left",children:[e.jsx("span",{className:"rp-tactic-n",children:a.n}),e.jsx("span",{className:"rp-tactic-title",children:a.title}),e.jsx("span",{className:`rp-scope-badge ${O}`,children:A})]}),e.jsx("span",{className:"rp-chevron",children:t?"▾":"▸"})]}),t&&e.jsxs("div",{className:"rp-tactic-body",children:[e.jsx("p",{className:"rp-tactic-summary",children:a.summary}),a.note&&e.jsx("p",{className:"rp-tactic-note",children:a.note}),(a.bad||a.good)&&e.jsxs("div",{className:"rp-tactic-examples",children:[a.bad&&e.jsxs("div",{children:[e.jsx("span",{className:"rp-ex-label rp-ex-bad",children:"✗ Avoid"}),e.jsx("pre",{className:"rp-code rp-code-bad",children:a.bad})]}),a.good&&e.jsxs("div",{children:[e.jsx("span",{className:"rp-ex-label rp-ex-good",children:"✓ Do this"}),e.jsx("pre",{className:"rp-code rp-code-good",children:a.good})]})]}),a.tips&&e.jsx("ul",{className:"rp-tactic-tips",children:a.tips.map(h=>e.jsx("li",{children:h},h))})]})]},a.n)})})]}),s==="prompts"&&e.jsxs("div",{className:"rp-prompts-wrap",children:[e.jsx("div",{className:"rp-principles-grid",children:T.map(a=>e.jsxs("div",{className:"rp-principle-card",children:[e.jsx("span",{className:"rp-principle-title",children:a.title}),e.jsx("p",{className:"rp-principle-body",children:a.body})]},a.title))}),e.jsx("p",{className:"rp-section-label",children:"Prompting techniques"}),e.jsxs("table",{className:"rp-tech-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Technique"}),e.jsx("th",{children:"When to use"})]})}),e.jsx("tbody",{children:P.map(a=>e.jsxs("tr",{children:[e.jsx("td",{className:"rp-tech-name",children:a.name}),e.jsx("td",{className:"rp-tech-desc",children:a.desc})]},a.name))})]}),e.jsxs("div",{className:"rp-learn-links",children:[e.jsx("p",{className:"rp-learn-label",children:"Learn more:"}),e.jsx("ul",{children:C.map(a=>e.jsx("li",{children:e.jsxs("a",{href:a.href,target:"_blank",rel:"noopener noreferrer",className:"rp-link",children:[a.label," ↗"]})},a.href))})]})]}),s==="playbook"&&e.jsxs("div",{className:"rp-playbook-wrap",children:[e.jsx("p",{className:"rp-section-label",children:"Playbook · Quality, Architecture & Operability"}),e.jsxs("button",{className:"rp-section-hdr",onClick:()=>N(a=>!a),"aria-expanded":l,children:[e.jsx("span",{children:"Quality & traceability discipline"}),e.jsx("span",{className:"rp-chevron",children:l?"▾":"▸"})]}),l&&e.jsxs("div",{className:"rp-playbook-section",children:[e.jsxs("div",{className:"rp-callout",style:{marginBottom:"var(--space-4)"},children:[e.jsx("span",{className:"rp-callout-label",children:"The discipline in one line"}),e.jsx("p",{children:"Change → Update Spec → Rebuild. Every agent-generated change is traceable to a spec, not a conversation."})]}),e.jsx("div",{className:"rp-playbook-items",children:I.map(a=>e.jsxs("div",{className:"rp-playbook-item",children:[e.jsx("span",{className:"rp-playbook-item-title",children:a.title}),e.jsx("p",{className:"rp-playbook-item-body",children:a.body})]},a.title))})]}),e.jsxs("button",{className:"rp-section-hdr",onClick:()=>k(a=>!a),"aria-expanded":p,children:[e.jsx("span",{children:"Archetype reference matrix"}),e.jsx("span",{className:"rp-chevron",children:p?"▾":"▸"})]}),p&&e.jsxs("div",{className:"rp-playbook-section",children:[e.jsx("p",{className:"rp-muted-note",children:"Eight archetypes across two tracks."}),e.jsxs("table",{className:"rp-arch-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"ID"}),e.jsx("th",{children:"Name"}),e.jsx("th",{children:"Pattern"}),e.jsx("th",{children:"Pod size"}),e.jsx("th",{children:"Typical range"})]})}),e.jsx("tbody",{children:[{id:"A1",name:"App · Greenfield",pattern:"Rapid",pod:"3–4 core",range:"2–5× · ~50% cap."},{id:"A2",name:"Data/AI · Greenfield",pattern:"Rapid (cautious)",pod:"4–5 core",range:"1.5–3× · ~37% cap."},{id:"B1",name:"App · Enhancement",pattern:"Spec-driven",pod:"3–4 core",range:"2–4× · ~40% cap."},{id:"B2",name:"Data/AI · Enhancement",pattern:"Spec-driven",pod:"3–4 core",range:"1.5–2.5× · dir."},{id:"C1",name:"App · Modernisation",pattern:"Spec-driven",pod:"5–6 core",range:"1.5–3× · ~35% cap."},{id:"C2",name:"Data/AI · Modernisation",pattern:"Spec-driven",pod:"4–5 core",range:"1.5–2× · dir."},{id:"D1",name:"App · Maintenance",pattern:"Spec-driven (small)",pod:"2–3 core",range:"2–3× · ~42% cap."},{id:"D2",name:"Data/AI · Maintenance",pattern:"Spec-driven (small)",pod:"2–3 core",range:"1.5–2× · dir."}].map(a=>e.jsxs("tr",{children:[e.jsx("td",{className:"rp-arch-id",children:a.id}),e.jsx("td",{children:a.name}),e.jsx("td",{children:a.pattern}),e.jsx("td",{children:a.pod}),e.jsx("td",{children:a.range})]},a.id))})]}),e.jsx("p",{className:"rp-faint-note",children:"Capacity figures are directional — based on observed patterns, not guaranteed outcomes."})]}),e.jsxs("button",{className:"rp-section-hdr",onClick:()=>w(a=>!a),"aria-expanded":d,children:[e.jsx("span",{children:"Operability & observability standards"}),e.jsx("span",{className:"rp-chevron",children:d?"▾":"▸"})]}),d&&e.jsx("div",{className:"rp-playbook-section",children:e.jsx("div",{className:"rp-playbook-items",children:L.map(a=>e.jsxs("div",{className:"rp-playbook-item",children:[e.jsx("span",{className:"rp-playbook-item-title",children:a.title}),e.jsx("p",{className:"rp-playbook-item-body",children:a.body})]},a.title))})}),e.jsxs("button",{className:"rp-section-hdr",onClick:()=>z(a=>!a),"aria-expanded":m,children:[e.jsx("span",{children:"Programme-level gates (org-enforced)"}),e.jsx("span",{className:"rp-chevron",children:m?"▾":"▸"})]}),m&&e.jsxs("div",{className:"rp-playbook-section",children:[e.jsx("p",{className:"rp-muted-note",children:"These gates apply at the programme level regardless of persona. Each is enforced by an owner above the pod."}),e.jsx("ol",{className:"rp-gates-list",children:_.map(a=>e.jsxs("li",{className:"rp-gate-item",children:[e.jsxs("span",{className:"rp-gate-num",children:[a.n,"."]}),e.jsxs("div",{className:"rp-gate-body",children:[e.jsx("span",{className:"rp-gate-label",children:a.label}),e.jsx("span",{className:"rp-gate-detail",children:a.detail})]})]},a.n))})]})]}),s==="standards"&&e.jsxs("div",{className:"rp-standards-wrap",children:[e.jsx("p",{className:"rp-section-label",children:n.label}),e.jsx("p",{className:"rp-standards-desc",children:n.description}),e.jsx("div",{className:"rp-standards-links",children:n.links.map(a=>e.jsx("a",{href:a.href,target:"_blank",rel:"noopener noreferrer",className:`rp-link-btn${a.primary?" rp-link-btn--primary":""}`,children:a.label},a.href))}),e.jsx("ul",{className:"rp-standards-list",children:n.items.map(a=>e.jsx("li",{children:a},a))})]})]}),e.jsx("style",{children:`
        .rp-wrap { margin-bottom: var(--space-6); }
        .rp-header { margin-bottom: var(--space-4); }
        .rp-title { font-size: var(--text-xl); font-weight: 700; color: var(--text); margin: 0 0 var(--space-1); }
        .rp-subtitle { font-size: var(--text-sm); color: var(--text-muted); margin: 0; }

        .rp-tabs {
          display: flex;
          gap: var(--space-1);
          border-bottom: 1px solid var(--border);
          margin-bottom: var(--space-4);
          flex-wrap: wrap;
        }
        .rp-tab {
          background: transparent;
          border: none;
          border-bottom: 2px solid transparent;
          padding: var(--space-2) var(--space-3);
          font-size: var(--text-sm);
          font-weight: 600;
          color: var(--text-muted);
          cursor: pointer;
          transition: color 0.15s, border-color 0.15s;
          margin-bottom: -1px;
        }
        .rp-tab:hover { color: var(--accent); }
        .rp-tab--active { color: var(--accent); border-bottom-color: var(--accent); }

        .rp-panel { min-height: 240px; }
        .rp-section-label { font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; color: var(--text-faint); margin-bottom: var(--space-3); margin-top: var(--space-5); }
        .rp-muted-note { font-size: var(--text-xs); color: var(--text-muted); margin-bottom: var(--space-3); }
        .rp-faint-note { font-size: var(--text-xs); color: var(--text-faint); margin-top: var(--space-2); }

        .rp-section-hdr {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 100%;
          background: var(--bg-subtle);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: var(--space-2) var(--space-3);
          font-size: var(--text-sm);
          font-weight: 600;
          color: var(--text);
          cursor: pointer;
          text-align: left;
          margin-bottom: var(--space-2);
          transition: background 0.1s;
        }
        .rp-section-hdr:hover { background: var(--bg-hover); }
        .rp-chevron { font-size: 10px; color: var(--text-faint); }

        /* Token tactics */
        .rp-tactic-list { margin-bottom: var(--space-4); }
        .rp-tactic {
          border: 1px solid var(--border);
          border-radius: var(--radius);
          margin-bottom: var(--space-2);
          overflow: hidden;
        }
        .rp-tactic--open { border-color: var(--accent); }
        .rp-tactic-hdr {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 100%;
          background: transparent;
          border: none;
          padding: var(--space-2) var(--space-3);
          cursor: pointer;
          text-align: left;
        }
        .rp-tactic-hdr:hover { background: var(--bg-subtle); }
        .rp-tactic-hdr-left { display: flex; align-items: center; gap: var(--space-2); flex-wrap: wrap; }
        .rp-tactic-n {
          font-size: var(--text-xs); font-weight: 700;
          width: 20px; height: 20px;
          display: inline-flex; align-items: center; justify-content: center;
          background: var(--accent); color: #fff; border-radius: 50%;
          flex-shrink: 0;
        }
        .rp-tactic-title { font-size: var(--text-sm); font-weight: 600; color: var(--text); }
        .rp-scope-badge {
          font-size: 10px; font-weight: 600; padding: 2px 7px;
          border-radius: 20px; white-space: nowrap;
        }
        .rp-scope-green { background: #e8f5d0; color: #3d6e0a; }
        .rp-scope-grey  { background: var(--bg-subtle); color: var(--text-muted); border: 1px solid var(--border); }
        .rp-scope-amber { background: #fff3cd; color: #7a5700; }
        .rp-tactic-body { padding: var(--space-3); border-top: 1px solid var(--border); background: var(--bg-subtle); }
        .rp-tactic-summary { font-size: var(--text-sm); color: var(--text); margin-bottom: var(--space-2); }
        .rp-tactic-note { font-size: var(--text-xs); color: var(--text-muted); font-style: italic; margin-bottom: var(--space-2); }
        .rp-tactic-examples { display: flex; flex-direction: column; gap: var(--space-2); margin-bottom: var(--space-2); }
        .rp-ex-label { font-size: var(--text-xs); font-weight: 700; display: block; margin-bottom: 4px; }
        .rp-ex-bad  { color: #b91c1c; }
        .rp-ex-good { color: #15803d; }
        .rp-code {
          font-family: monospace; font-size: var(--text-xs);
          padding: var(--space-2) var(--space-3);
          border-radius: var(--radius);
          white-space: pre-wrap; word-break: break-word;
          margin: 0;
        }
        .rp-code-bad  { background: #fef2f2; border: 1px solid #fecaca; color: var(--text); }
        .rp-code-good { background: #f0fdf4; border: 1px solid #bbf7d0; color: var(--text); }
        .rp-tactic-tips { font-size: var(--text-xs); color: var(--text-muted); padding-left: var(--space-4); margin: 0; }
        .rp-tactic-tips li { margin-bottom: 3px; }

        /* Callout */
        .rp-callout {
          background: var(--bg-subtle);
          border-left: 3px solid var(--accent);
          border-radius: 0 var(--radius) var(--radius) 0;
          padding: var(--space-3);
          margin-bottom: var(--space-3);
        }
        .rp-callout-label { font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; color: var(--accent); display: block; margin-bottom: 4px; }
        .rp-callout p, .rp-callout ul { font-size: var(--text-sm); color: var(--text); margin: 0; }
        .rp-callout ul { padding-left: var(--space-4); margin-top: var(--space-2); }
        .rp-callout li { margin-bottom: 4px; }

        /* Prompt engineering */
        .rp-principles-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
          gap: var(--space-3);
          margin-bottom: var(--space-5);
        }
        .rp-principle-card {
          background: var(--bg-subtle);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: var(--space-3);
        }
        .rp-principle-title { font-size: var(--text-sm); font-weight: 700; color: var(--accent); display: block; margin-bottom: var(--space-1); }
        .rp-principle-body { font-size: var(--text-xs); color: var(--text-muted); margin: 0; line-height: 1.5; }

        .rp-tech-table { width: 100%; border-collapse: collapse; font-size: var(--text-sm); margin-bottom: var(--space-5); }
        .rp-tech-table th { text-align: left; padding: var(--space-2) var(--space-3); font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-faint); border-bottom: 2px solid var(--border); }
        .rp-tech-table td { padding: var(--space-2) var(--space-3); border-bottom: 1px solid var(--border); vertical-align: top; }
        .rp-tech-name { font-weight: 600; color: var(--text); width: 160px; }
        .rp-tech-desc { color: var(--text-muted); }

        .rp-learn-links { margin-top: var(--space-4); }
        .rp-learn-label { font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.06em; color: var(--text-faint); margin-bottom: var(--space-2); }
        .rp-learn-links ul { list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; gap: var(--space-2); }
        .rp-link { color: var(--accent); font-size: var(--text-sm); text-decoration: none; }
        .rp-link:hover { text-decoration: underline; }

        /* Playbook */
        .rp-playbook-section { padding: var(--space-3) 0 var(--space-4); }
        .rp-playbook-items { display: flex; flex-direction: column; gap: var(--space-3); }
        .rp-playbook-item {
          background: var(--bg-subtle);
          border: 1px solid var(--border);
          border-radius: var(--radius);
          padding: var(--space-3);
        }
        .rp-playbook-item-title { font-size: var(--text-sm); font-weight: 700; color: var(--text); display: block; margin-bottom: var(--space-1); }
        .rp-playbook-item-body { font-size: var(--text-sm); color: var(--text-muted); margin: 0; }

        .rp-arch-table { width: 100%; border-collapse: collapse; font-size: var(--text-sm); margin-bottom: var(--space-2); }
        .rp-arch-table th { text-align: left; padding: var(--space-2) var(--space-3); font-size: var(--text-xs); font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; color: var(--text-faint); border-bottom: 2px solid var(--border); }
        .rp-arch-table td { padding: var(--space-2) var(--space-3); border-bottom: 1px solid var(--border); vertical-align: top; }
        .rp-arch-id { font-family: monospace; font-size: var(--text-xs); font-weight: 700; color: var(--accent); }

        .rp-gates-list { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: var(--space-3); }
        .rp-gate-item { display: flex; gap: var(--space-2); align-items: flex-start; }
        .rp-gate-num {
          font-size: var(--text-sm); font-weight: 700;
          width: 24px; height: 24px; min-width: 24px;
          display: inline-flex; align-items: center; justify-content: center;
          background: var(--accent); color: #fff; border-radius: 50%;
        }
        .rp-gate-body { display: flex; flex-direction: column; gap: 2px; }
        .rp-gate-label { font-size: var(--text-sm); font-weight: 600; color: var(--text); }
        .rp-gate-detail { font-size: var(--text-xs); color: var(--text-muted); }

        /* Standards */
        .rp-standards-desc { font-size: var(--text-sm); color: var(--text-muted); margin-bottom: var(--space-4); line-height: 1.6; }
        .rp-standards-links { margin-bottom: var(--space-4); display: flex; gap: var(--space-3); flex-wrap: wrap; }
        .rp-standards-list { font-size: var(--text-sm); color: var(--text-muted); padding-left: var(--space-4); }
        .rp-standards-list li { margin-bottom: var(--space-2); }
        .rp-link-btn {
          display: inline-block;
          padding: var(--space-2) var(--space-4);
          border-radius: var(--radius);
          font-size: var(--text-sm);
          font-weight: 600;
          text-decoration: none;
          border: 1px solid var(--border);
          color: var(--text-muted);
          background: var(--bg-subtle);
          transition: border-color 0.1s, color 0.1s;
        }
        .rp-link-btn:hover { border-color: var(--accent); color: var(--accent); }
        .rp-link-btn--primary { background: var(--accent); border-color: var(--accent); color: #fff; }
        .rp-link-btn--primary:hover { opacity: 0.88; color: #fff; }
        .rp-token-img { width: 100%; border-radius: var(--radius); margin-bottom: var(--space-4); border: 1px solid var(--border); }
        .rp-section-hdr-left { display: flex; align-items: center; gap: var(--space-2); }
        .rp-cheatsheet-badge {
          display: inline-block;
          padding: 2px 8px;
          background: var(--accent);
          color: #fff;
          font-size: 10px;
          font-weight: 700;
          letter-spacing: 0.05em;
          text-transform: uppercase;
          border-radius: 20px;
          line-height: 1.4;
        }
      `})]})}export{B as default};

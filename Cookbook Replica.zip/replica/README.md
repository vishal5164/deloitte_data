# The Agentic SDLC Cookbook — Local Replica

A 1:1 offline copy of `https://crispy-giggle-4qvymmm.pages.github.io/`, captured on 2026-06-02.

## Structure

```
replica/
├── index.html               # Home page
├── wizard/index.html        # 6-step interactive wizard (Astro + React island)
├── reference/index.html     # Reference page (#tokens, #prompts, #playbook, #standards)
├── favicon.svg
├── _astro/                  # Hashed JS/CSS bundles
│   ├── feedback.DLjauFG_.css
│   ├── client.DrE9CFQR.js
│   ├── index.CVf8TyFT.js          (React 18 production runtime)
│   ├── ReferencePanel.CVEPpudb.js
│   ├── reference.CoM6j2Ux.js      (React-DOM)
│   └── Wizard.BWdotX1u.js         (~466 KB — all role/tool/pathway data is inlined here)
└── serve.py                 # Tiny static server (UTF-8 + clean-URL friendly)
```

## Run it

```powershell
cd C:\Users\vishalkumar5\Desktop\Cookbook\replica
python serve.py             # starts at http://localhost:8765
# or:  python serve.py 9000  to use a different port
```

Then open `http://localhost:8765/` in any browser.

> A plain `python -m http.server` also works, but doesn't send the
> `charset=utf-8` Content-Type header, so emoji in the WIP banner render
> as mojibake. Use `serve.py`.

## Pathways available

1. **`/`** — Hero, "Get Started" CTA → `/wizard`, and a "What it covers / Why it matters" overview table.
2. **`/wizard/`** — 6-step interactive flow:
   `Current Role → Future Role → Project Type → Tools → Get Started → Learning Pathway`
3. **`/reference/`** — Reference tabs (Token Economics, Prompt Engineering, Playbook, Eng Standards), reachable from the header dropdown on every page.

## Notes

- The wizard's role/tool/pathway data is bundled inside `Wizard.BWdotX1u.js`; no API calls are needed at runtime, so it works fully offline.
- The "Share your Feedback" footer link points at the original Microsoft Forms URL; that one needs internet (and your auth) to actually submit.
- Google Fonts (`Open Sans`) is loaded over the network. Without it the page falls back to `-apple-system`/Segoe UI.

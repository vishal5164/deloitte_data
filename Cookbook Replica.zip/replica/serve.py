"""Tiny static server for the Cookbook replica with UTF-8 + clean URL support.

Run:  python serve.py            (defaults to port 8765)
      python serve.py 9000       (custom port)
"""
import sys
import os
from http.server import HTTPServer, SimpleHTTPRequestHandler


class Handler(SimpleHTTPRequestHandler):
    extensions_map = {
        **SimpleHTTPRequestHandler.extensions_map,
        ".html": "text/html; charset=utf-8",
        ".js":   "application/javascript; charset=utf-8",
        ".mjs":  "application/javascript; charset=utf-8",
        ".css":  "text/css; charset=utf-8",
        ".svg":  "image/svg+xml",
        ".json": "application/json; charset=utf-8",
        "":      "application/octet-stream",
    }

    def do_GET(self):
        # Allow /wizard and /reference (no trailing slash) to map to the index file
        path = self.path.split("?", 1)[0].split("#", 1)[0]
        if path in ("/wizard", "/reference"):
            self.path = path + "/"
        return super().do_GET()


if __name__ == "__main__":
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8765
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    print(f"Serving Cookbook replica at http://localhost:{port}/  (Ctrl+C to stop)")
    HTTPServer(("", port), Handler).serve_forever()
